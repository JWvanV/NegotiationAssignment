package negotiator;

import java.io.PrintStream;

public class ContinuousTimeline
  extends Timeline
{
  private final int totalSeconds;
  protected final long startTime;
  
  public ContinuousTimeline(int totalSecs)
  {
    this.totalSeconds = totalSecs;
    this.startTime = System.nanoTime();
    this.hasDeadline = true;
    System.out.println("Started time line of " + totalSecs + " seconds.");
  }
  
  public double getElapsedSeconds()
  {
    long t2 = System.nanoTime();
    return (t2 - this.startTime) / 1000000000.0D;
  }
  
  public double getElapsedMilliSeconds()
  {
    long t2 = System.nanoTime();
    return (t2 - this.startTime) / 1000000.0D;
  }
  
  public long getTotalMiliseconds()
  {
    return 1000 * this.totalSeconds;
  }
  
  public long getTotalSeconds()
  {
    return this.totalSeconds;
  }
  
  public void printElapsedSeconds()
  {
    System.out.println("Elapsed: " + getElapsedSeconds() + " seconds");
  }
  
  public void printTime()
  {
    System.out.println("t = " + getTime());
  }
  
  public double getTime()
  {
    double t = getElapsedSeconds() / this.totalSeconds;
    if (t > 1.0D) {
      t = 1.0D;
    }
    return t;
  }
  
  public double getTotalTime()
  {
    return getTotalSeconds();
  }
  
  public double getCurrentTime()
  {
    return getElapsedSeconds();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.ContinuousTimeline
 * JD-Core Version:    0.7.1
 */