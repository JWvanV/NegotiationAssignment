package negotiator.actions;

import negotiator.AgentID;

public class Accept
  extends Action
{
  public Accept() {}
  
  public Accept(AgentID agentID)
  {
    super(agentID);
  }
  
  public String toString()
  {
    return "(Accept)";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.Accept
 * JD-Core Version:    0.7.1
 */