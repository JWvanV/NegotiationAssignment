package negotiator.actions;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import negotiator.AgentID;
import negotiator.Feedback;
import negotiator.Party;

@XmlRootElement
public class GiveFeedback
  extends Action
{
  @XmlElement
  protected Feedback feedback;
  
  public GiveFeedback(AgentID party, Feedback feedback)
  {
    super(party);
    this.feedback = feedback;
  }
  
  public GiveFeedback(Party party, Feedback feedback)
  {
    this(party.getPartyID(), feedback);
  }
  
  public Feedback getFeedback()
  {
    return this.feedback;
  }
  
  public String toString()
  {
    return "Feedback: " + (this.feedback == Feedback.SAME ? "SAME" : this.feedback == Feedback.BETTER ? "Better" : this.feedback == null ? "null" : "Worse");
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.GiveFeedback
 * JD-Core Version:    0.7.1
 */