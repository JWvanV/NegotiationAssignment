package negotiator.actions;

public class Inform
  extends Action
{
  private Object value;
  private String name;
  
  public Inform() {}
  
  public Inform(String name, Object value)
  {
    this.name = name;
    this.value = value;
  }
  
  public Object getValue()
  {
    return this.value;
  }
  
  public Inform setValue(Object information)
  {
    this.value = information;
    return this;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public Inform setName(String name)
  {
    this.name = name;
    return this;
  }
  
  public String toString()
  {
    return this.name + ":" + this.value.toString();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.Inform
 * JD-Core Version:    0.7.1
 */