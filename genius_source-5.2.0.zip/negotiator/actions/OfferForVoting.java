package negotiator.actions;

import javax.xml.bind.annotation.XmlRootElement;
import negotiator.Agent;
import negotiator.AgentID;
import negotiator.Bid;

@XmlRootElement
public class OfferForVoting
  extends Offer
{
  public OfferForVoting(AgentID agent, Bid bid)
  {
    super(agent, bid);
  }
  
  public OfferForVoting(Agent agent, Bid bid)
  {
    this(agent.getAgentID(), bid);
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public String toString()
  {
    return "(Offer: " + (this.bid == null ? "null" : this.bid.toString()) + ")";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.OfferForVoting
 * JD-Core Version:    0.7.1
 */