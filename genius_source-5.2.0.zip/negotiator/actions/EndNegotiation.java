package negotiator.actions;

import negotiator.AgentID;

public class EndNegotiation
  extends Action
{
  public EndNegotiation() {}
  
  public EndNegotiation(AgentID agentID)
  {
    super(agentID);
  }
  
  public String toString()
  {
    return "(EndNegotiation)";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.EndNegotiation
 * JD-Core Version:    0.7.1
 */