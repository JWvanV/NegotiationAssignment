package negotiator.actions;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import negotiator.AgentID;
import negotiator.Party;
import negotiator.Vote;

@XmlRootElement
public class VoteForOfferAcceptance
  extends Action
{
  @XmlElement
  protected Vote vote;
  
  public VoteForOfferAcceptance()
  {
    this.vote = Vote.ACCEPT;
  }
  
  public VoteForOfferAcceptance(AgentID party, Vote vote)
  {
    super(party);
    this.vote = vote;
  }
  
  public VoteForOfferAcceptance(Party party, Vote vote)
  {
    this(party.getPartyID(), vote);
  }
  
  public Vote getVote()
  {
    return this.vote;
  }
  
  public String toString()
  {
    return "Vote: " + (this.vote == Vote.ACCEPT ? "Accept" : this.vote == null ? "null" : "Reject");
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.VoteForOfferAcceptance
 * JD-Core Version:    0.7.1
 */