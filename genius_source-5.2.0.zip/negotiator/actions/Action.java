package negotiator.actions;

import negotiator.AgentID;
import negotiator.Bid;

public abstract class Action
{
  private AgentID agentID;
  
  public Action() {}
  
  public Action(AgentID agentID)
  {
    this.agentID = agentID;
  }
  
  public AgentID getAgent()
  {
    return this.agentID;
  }
  
  public abstract String toString();
  
  public static Bid getBidFromAction(Action currentAction)
  {
    Bid currentBid = null;
    if ((currentAction instanceof EndNegotiationWithAnOffer)) {
      currentBid = ((EndNegotiationWithAnOffer)currentAction).getBid();
    } else if ((currentAction instanceof Offer)) {
      currentBid = ((Offer)currentAction).getBid();
    }
    return currentBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.Action
 * JD-Core Version:    0.7.1
 */