package negotiator.actions;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.Party;

@XmlRootElement
public class EndNegotiationWithAnOffer
  extends Action
{
  @XmlElement
  protected Bid bid;
  
  public EndNegotiationWithAnOffer() {}
  
  public EndNegotiationWithAnOffer(AgentID party, Bid bid)
  {
    super(party);
    this.bid = bid;
  }
  
  public EndNegotiationWithAnOffer(Party party, Bid bid)
  {
    this(party.getPartyID(), bid);
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public String toString()
  {
    return "End Negotiation with Offer: " + (this.bid == null ? "null" : this.bid.toString());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.EndNegotiationWithAnOffer
 * JD-Core Version:    0.7.1
 */