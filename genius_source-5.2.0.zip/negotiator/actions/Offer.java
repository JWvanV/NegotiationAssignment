package negotiator.actions;

import negotiator.Agent;
import negotiator.AgentID;
import negotiator.Bid;

public class Offer
  extends Action
{
  protected Bid bid;
  
  public Offer(AgentID agentID, Bid bid)
  {
    super(agentID);
    this.bid = bid;
  }
  
  public Offer(Bid bid)
  {
    this.bid = bid;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (this.bid == null ? 0 : this.bid.hashCode());
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Offer other = (Offer)obj;
    if (this.bid == null)
    {
      if (other.bid != null) {
        return false;
      }
    }
    else if (!this.bid.equals(other.bid)) {
      return false;
    }
    return true;
  }
  
  public Offer(Agent agent, Bid bid)
  {
    this(agent.getAgentID(), bid);
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public String toString()
  {
    return "(Offer: " + (this.bid == null ? "null" : this.bid.toString()) + ")";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.Offer
 * JD-Core Version:    0.7.1
 */