package negotiator.actions;

import java.util.ArrayList;
import negotiator.parties.NegotiationParty;

public class InformPartyList
  extends Action
{
  ArrayList<NegotiationParty> parties = new ArrayList();
  
  public InformPartyList(ArrayList<NegotiationParty> parties)
  {
    this.parties = parties;
  }
  
  public ArrayList<NegotiationParty> getParties()
  {
    return this.parties;
  }
  
  public String toString()
  {
    String stringRepr = "Parties: ";
    for (int i = 0; i < this.parties.size(); i++)
    {
      stringRepr = stringRepr + this.parties.toString();
      if (i < this.parties.size() - 1) {
        stringRepr = stringRepr + ", ";
      }
    }
    return stringRepr;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.InformPartyList
 * JD-Core Version:    0.7.1
 */