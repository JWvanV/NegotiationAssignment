package negotiator.actions;

import negotiator.AgentID;

public class IllegalAction
  extends Action
{
  private String details;
  
  public IllegalAction(AgentID agentID, String details)
  {
    super(agentID);
    this.details = details;
  }
  
  public IllegalAction(String details)
  {
    this.details = details;
  }
  
  public String toString()
  {
    return "(IllegalAction- " + this.details + ")";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.IllegalAction
 * JD-Core Version:    0.7.1
 */