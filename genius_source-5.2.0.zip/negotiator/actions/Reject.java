package negotiator.actions;

import negotiator.AgentID;

public class Reject
  extends Action
{
  public Reject() {}
  
  public Reject(AgentID agentID)
  {
    super(agentID);
  }
  
  public String toString()
  {
    return "(Reject)";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.Reject
 * JD-Core Version:    0.7.1
 */