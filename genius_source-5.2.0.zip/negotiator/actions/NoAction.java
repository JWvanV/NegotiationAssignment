package negotiator.actions;

import javax.xml.bind.annotation.XmlRootElement;
import negotiator.Agent;
import negotiator.AgentID;

@XmlRootElement
public class NoAction
  extends Action
{
  public NoAction() {}
  
  public NoAction(AgentID agent)
  {
    super(agent);
  }
  
  public NoAction(Agent agent)
  {
    this(agent.getAgentID());
  }
  
  public String toString()
  {
    return "(No additional action)";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.actions.NoAction
 * JD-Core Version:    0.7.1
 */