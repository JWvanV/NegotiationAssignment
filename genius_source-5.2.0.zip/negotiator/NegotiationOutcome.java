package negotiator;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import negotiator.actions.Action;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidPointSorterA;
import negotiator.analysis.BidPointSorterB;
import negotiator.analysis.BidPointTime;
import negotiator.analysis.BidSpace;
import negotiator.analysis.BidSpaceCache;
import negotiator.protocol.alternatingoffers.AlternatingOffersBilateralAtomicNegoSession;
import negotiator.qualitymeasures.OpponentModelMeasuresResults;
import negotiator.qualitymeasures.logmanipulation.OutcomeInfo;
import negotiator.tournament.TournamentConfiguration;
import negotiator.utility.UtilitySpace;
import negotiator.xml.OrderedSimpleElement;
import negotiator.xml.SimpleElement;

public class NegotiationOutcome
{
  public String agentAname;
  public String agentBname;
  public String agentAclass;
  public String agentBclass;
  public Double agentAutility;
  public Double agentButility;
  public Double agentAutilityDiscount;
  public Double agentButilityDiscount;
  public String ErrorRemarks;
  public ArrayListXML<BidPointTime> AgentABids;
  public ArrayListXML<BidPointTime> AgentBBids;
  public Double agentAmaxUtil;
  public Double agentBmaxUtil;
  public boolean agentAstarts;
  public String agentAutilSpaceName;
  public String agentButilSpaceName;
  public SimpleElement additional;
  public SimpleElement trajectoryMeasures;
  public SimpleElement qualityMeasures;
  public List<String> extraNames = new ArrayList();
  public List<String> extraValues = new ArrayList();
  public double time;
  public String domainName;
  private final AlternatingOffersBilateralAtomicNegoSession alternatingOffersBilateralAtomicNegoSession;
  private final Action lastAction;
  private int runNr = 0;
  private OpponentModelMeasuresResults omMeasuresResults = null;
  private String acceptedBy;
  
  public NegotiationOutcome(AlternatingOffersBilateralAtomicNegoSession alternatingOffersBilateralAtomicNegoSession, int runNumber, Action lastAction, ArrayList<BidPointTime> agentASize, ArrayList<BidPointTime> agentBSize, boolean startingWithA, SimpleElement additional, double distanceToNash, OutcomeInfo outcomeInfo)
  {
    this.alternatingOffersBilateralAtomicNegoSession = alternatingOffersBilateralAtomicNegoSession;
    this.runNr = runNumber;
    this.lastAction = lastAction;
    this.agentAutility = outcomeInfo.getAgentAutility();
    this.agentButility = Double.valueOf(outcomeInfo.getAgentButility());
    this.agentAutilityDiscount = Double.valueOf(outcomeInfo.getAgentAutilityDiscount());
    this.agentButilityDiscount = Double.valueOf(outcomeInfo.getAgentButilityDiscount());
    this.agentAname = outcomeInfo.getAgentAname();
    this.agentBname = outcomeInfo.getAgentBname();
    this.agentAclass = outcomeInfo.getAgentAclass();
    this.agentBclass = outcomeInfo.getAgentBclass();
    this.domainName = outcomeInfo.getDomainName();
    this.additional = additional;
    this.AgentABids = new ArrayListXML(agentASize);
    this.AgentBBids = new ArrayListXML(agentBSize);
    this.ErrorRemarks = outcomeInfo.getErrorRemarks();
    this.agentAmaxUtil = Double.valueOf(outcomeInfo.getAgentAmaxUtil());
    this.agentBmaxUtil = Double.valueOf(outcomeInfo.getAgentBmaxUtil());
    this.agentAstarts = startingWithA;
    this.agentAutilSpaceName = outcomeInfo.getAgentAutilSpaceName();
    this.agentButilSpaceName = outcomeInfo.getAgentButilSpaceName();
    this.time = outcomeInfo.getTimeOfAgreement();
    this.acceptedBy = outcomeInfo.getAcceptedBy();
  }
  
  public String toString()
  {
    String startingagent = "agentB";
    if (this.agentAstarts) {
      startingagent = "agentA";
    }
    return " agentAName=" + this.agentAname + " agentBName=" + this.agentBname + " agentAutility=" + this.agentAutility + " agentButility=" + this.agentButility + " agentAutilityDiscount=" + this.agentAutilityDiscount + " agentButilityDiscount=" + this.agentButilityDiscount + " errors='" + this.ErrorRemarks + "'" + " agentAmaxUtil=" + this.agentAmaxUtil + " agentBmaxUtil=" + this.agentBmaxUtil + " startingAgent=" + startingagent + " agentAutilspacefilename=" + this.agentAutilSpaceName + " agentButilspacefilename=" + this.agentButilSpaceName + " agentAbids=" + this.AgentABids + " agentBbids=" + this.AgentBBids;
  }
  
  SimpleElement resultsOfAgent(String agentX, String agentName, String agentClass, String utilspacefilename, String oppName, String oppClass, String oppUtilSpaceName, Double agentAUtil, Double agentAUtilDiscount, Double agentAMaxUtil, ArrayListXML<BidPointTime> bids, boolean addBids)
  {
    double minDemandedUtil = -1.0D;
    double fyu = -1.0D;
    double bsCR = -1.0D;
    double normACCR = -1.0D;
    double totalCR = -1.0D;
    double acCR = -1.0D;
    boolean logCompetitiveness = TournamentConfiguration.getBooleanOption("logCompetitiveness", false);
    if (logCompetitiveness)
    {
      UtilitySpace[] spaces = { this.alternatingOffersBilateralAtomicNegoSession.getAgentAUtilitySpace(), this.alternatingOffersBilateralAtomicNegoSession.getAgentBUtilitySpace() };
      BidSpace bidSpace = BidSpaceCache.getBidSpace(spaces);
      fyu = getFYU(agentX, bidSpace);
      
      minDemandedUtil = getMinDemandedUtil(agentX, bids);
      bsCR = determineCR(agentX, bids, fyu, minDemandedUtil);
      
      double minUtil = (agentX.equals("A") ? this.agentAutility : this.agentButility).doubleValue();
      totalCR = determineCR(agentX, bids, fyu, minUtil);
      if (totalCR < bsCR) {
        totalCR = bsCR;
      }
      acCR = totalCR - bsCR;
      if (1.0D - bsCR == 0.0D) {
        normACCR = 0.0D;
      } else {
        normACCR = acCR / (1.0D - bsCR);
      }
    }
    OrderedSimpleElement outcome = new OrderedSimpleElement("resultsOfAgent");
    
    outcome.setAttribute("agent", agentX);
    outcome.setAttribute("agentName", agentName);
    if (agentX.equals("A")) {
      outcome.setAttribute("discount", this.alternatingOffersBilateralAtomicNegoSession
      
        .getAgentAUtilitySpace().getDiscountFactor() + "");
    } else {
      outcome.setAttribute("discount", this.alternatingOffersBilateralAtomicNegoSession
      
        .getAgentBUtilitySpace().getDiscountFactor() + "");
    }
    if (agentName.contains("bs"))
    {
      outcome.setAttribute("offering_strategy", 
        getOfferingStrategyName(agentName));
      outcome.setAttribute("acceptance_strategy", 
        getAcceptanceStrategyName(agentName));
      outcome.setAttribute("opponent_model", 
        getOpponentModelName(agentName));
    }
    outcome.setAttribute("agentClass", agentClass);
    outcome.setAttribute("utilspace", utilspacefilename);
    outcome.setAttribute("Opponent-agentName", oppName);
    outcome.setAttribute("Opponent-agentClass", oppClass);
    outcome.setAttribute("Opponent-utilspace", oppUtilSpaceName);
    outcome.setAttribute("finalUtility", "" + agentAUtil);
    outcome.setAttribute("discountedUtility", "" + agentAUtilDiscount);
    
    double bestAcceptableBid = 0.0D;
    double bestDiscountedAccepableBid = 0.0D;
    if ((agentX.equals("A")) && (this.acceptedBy.equals("agentA")))
    {
      bestAcceptableBid = getMaxRecievedUtil(agentX, this.AgentBBids);
      bestDiscountedAccepableBid = getMaxDiscountedRecievedUtil(agentX, this.AgentBBids);
    }
    else if ((agentX.equals("B")) && (this.acceptedBy.equals("agentB")))
    {
      bestAcceptableBid = getMaxRecievedUtil(agentX, this.AgentABids);
      bestDiscountedAccepableBid = getMaxDiscountedRecievedUtil(agentX, this.AgentABids);
    }
    outcome.setAttribute("bestAcceptableBid", 
      String.valueOf(bestAcceptableBid));
    outcome.setAttribute("bestDiscountedAccepableBid", 
      String.valueOf(bestDiscountedAccepableBid));
    if (logCompetitiveness)
    {
      outcome.setAttribute("minDemandedUtility", 
        String.valueOf(minDemandedUtil));
      outcome.setAttribute("FYU", String.valueOf(fyu));
      outcome.setAttribute("Total_CR", String.valueOf(totalCR));
      outcome.setAttribute("BS_CR", String.valueOf(bsCR));
      outcome.setAttribute("AC_CR", String.valueOf(acCR));
      outcome.setAttribute("Normalized_AC_CR", String.valueOf(normACCR));
    }
    if ((this.omMeasuresResults != null) && 
      (agentX.equals("A"))) {
      setOMMeasures(outcome);
    }
    outcome.setAttribute("maxUtility", "" + agentAMaxUtil);
    Double normalized = Double.valueOf(0.0D);
    if (agentAMaxUtil.doubleValue() > 0.0D) {
      normalized = Double.valueOf(agentAUtil.doubleValue() / agentAMaxUtil.doubleValue());
    }
    outcome.setAttribute("normalizedUtility", "" + normalized);
    outcome.setAttribute("AcceptedBy", this.acceptedBy);
    return outcome;
  }
  
  private void setOMMeasures(OrderedSimpleElement outcome)
  {
    outcome.setAttribute("Pearson_Correlation_Bids", this.omMeasuresResults
      .getPearsonCorrelationCoefficientOfBidsList().get(0) + "");
    outcome.setAttribute("Ranking_Distance_Bids", this.omMeasuresResults
      .getRankingDistanceOfBidsList().get(0) + "");
    outcome.setAttribute("Ranking_Distance_Issue_Weights", this.omMeasuresResults
      .getRankingDistanceOfIssueWeightsList().get(0) + "");
    
    outcome.setAttribute("Average_Difference_Bids", this.omMeasuresResults
      .getAverageDifferenceBetweenBidsList().get(0) + "");
    outcome.setAttribute("Average_Difference_Issue_Weights", this.omMeasuresResults
      .getAverageDifferenceBetweenIssueWeightsList()
      .get(0) + "");
    outcome.setAttribute("Kalai_Difference", this.omMeasuresResults
      .getKalaiDistanceList().get(0) + "");
    outcome.setAttribute("Nash_Difference", this.omMeasuresResults
      .getNashDistanceList().get(0) + "");
    outcome.setAttribute("Difference_Pareto_Frontier", this.omMeasuresResults
      .getAverageDifferenceOfParetoFrontierList().get(0) + "");
    outcome.setAttribute("Percentage_Correct_Pareto_Bids", this.omMeasuresResults
    

      .getPercentageOfCorrectlyEstimatedParetoBidsList().get(0) + "");
    

    outcome.setAttribute("Percentage_Incorrect_Pareto_Bids", this.omMeasuresResults
    
      .getPercentageOfIncorrectlyEstimatedParetoBidsList()
      .get(0) + "");
    
    outcome.setAttribute("Pareto_Frontier_Distance", this.omMeasuresResults
      .getParetoFrontierDistanceList().get(0) + "");
  }
  
  private double determineCR(String agentX, ArrayListXML<BidPointTime> bids, double fyu, double minUtil)
  {
    double CR;
    double CR;
    if (minUtil != -1.0D)
    {
      double yield = Math.max(minUtil, fyu);
      double competitiveness = (yield - fyu) / (1.0D - fyu);
      CR = 1.0D - competitiveness;
    }
    else
    {
      CR = -1.0D;
      System.out.println("No bids exchanged; no CR computed.");
    }
    return CR;
  }
  
  public ArrayListXML<BidPointTime> getAgentABids()
  {
    return this.AgentABids;
  }
  
  public ArrayListXML<BidPointTime> getAgentBBids()
  {
    return this.AgentBBids;
  }
  
  public static double getFYU(String agentX, BidSpace bidSpace)
  {
    List<BidPoint> paretoFrontier = null;
    try
    {
      paretoFrontier = bidSpace.getParetoFrontier();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    BidPoint bestOutcomeForA = (BidPoint)paretoFrontier.get(paretoFrontier.size() - 1);
    BidPoint bestOutcomeForB = (BidPoint)paretoFrontier.get(0);
    double fyu = Double.NaN;
    if ("A".equals(agentX)) {
      fyu = bestOutcomeForB.getUtilityA().doubleValue();
    } else if ("B".equals(agentX)) {
      fyu = bestOutcomeForA.getUtilityB().doubleValue();
    } else {
      System.err.println("Unknown agent " + agentX);
    }
    return fyu;
  }
  
  private double getMaxDiscountedRecievedUtil(String agentX, ArrayListXML<BidPointTime> bids)
  {
    double discountFactorA = this.alternatingOffersBilateralAtomicNegoSession.getAgentAUtilitySpace().getDiscountFactor();
    
    double discountFactorB = this.alternatingOffersBilateralAtomicNegoSession.getAgentBUtilitySpace().getDiscountFactor();
    
    double maxRecievedDiscountedUtil = 0.0D;
    if (!bids.isEmpty()) {
      for (BidPointTime bidPointTime : bids)
      {
        double discountedBidPoint;
        double discountedBidPoint;
        if (agentX.equals("A")) {
          discountedBidPoint = UtilitySpace.discount(bidPointTime
            .getUtilityA().doubleValue(), bidPointTime.getTime(), discountFactorA);
        } else {
          discountedBidPoint = UtilitySpace.discount(bidPointTime
            .getUtilityB().doubleValue(), bidPointTime.getTime(), discountFactorB);
        }
        if (discountedBidPoint > maxRecievedDiscountedUtil) {
          maxRecievedDiscountedUtil = bidPointTime.getTime();
        }
      }
    }
    return maxRecievedDiscountedUtil;
  }
  
  private double getMaxRecievedUtil(String agentX, ArrayListXML<BidPointTime> bids)
  {
    Comparator<BidPoint> comp = null;
    if ("A".equals(agentX)) {
      comp = new BidPointSorterA();
    } else if ("B".equals(agentX)) {
      comp = new BidPointSorterB();
    } else {
      System.err.println("Unknown agent " + agentX);
    }
    double maxRecievedUtil;
    double maxRecievedUtil;
    if (!bids.isEmpty())
    {
      BidPointTime minDemandedBid = (BidPointTime)Collections.max(bids, comp);
      
      maxRecievedUtil = (agentX.equals("A") ? minDemandedBid.getUtilityA() : minDemandedBid
        .getUtilityB()).doubleValue();
    }
    else
    {
      maxRecievedUtil = -1.0D;
    }
    return maxRecievedUtil;
  }
  
  private double getMinDemandedUtil(String agentX, ArrayListXML<BidPointTime> bids)
  {
    Comparator<BidPoint> comp = null;
    if ("A".equals(agentX)) {
      comp = new BidPointSorterA();
    } else if ("B".equals(agentX)) {
      comp = new BidPointSorterB();
    } else {
      System.err.println("Unknown agent " + agentX);
    }
    double minDemandedUtil;
    double minDemandedUtil;
    if (!bids.isEmpty())
    {
      BidPoint minDemandedBid = (BidPoint)Collections.min(bids, comp);
      

      minDemandedUtil = (agentX.equals("A") ? minDemandedBid.getUtilityA() : minDemandedBid
        .getUtilityB()).doubleValue();
    }
    else
    {
      minDemandedUtil = -1.0D;
    }
    return minDemandedUtil;
  }
  
  public void addExtraAttribute(String name, String value)
  {
    this.extraNames.add(name);
    this.extraValues.add(value);
  }
  
  public SimpleElement toXML()
  {
    return toXML(false);
  }
  
  public SimpleElement toXMLWithBids()
  {
    return toXML(true);
  }
  
  private SimpleElement toXML(boolean addBids)
  {
    OrderedSimpleElement outcome = new OrderedSimpleElement("NegotiationOutcome");
    
    outcome.setAttribute("currentTime", "" + Global.getCurrentTime());
    outcome.setAttribute("timeOfAgreement", "" + this.time);
    outcome.setAttribute("bids", "" + (this.AgentABids
      .size() + this.AgentBBids.size()));
    outcome.setAttribute("domain", this.domainName);
    outcome.setAttribute("lastAction", "" + this.lastAction);
    outcome.setAttribute("runNumber", this.runNr + "");
    outcome.setAttribute("finalOutcome", getAcceptedBid());
    
    SimpleElement agentResultsA = resultsOfAgent("A", this.agentAname, this.agentAclass, this.agentAutilSpaceName, this.agentBname, this.agentBclass, this.agentButilSpaceName, this.agentAutility, this.agentAutilityDiscount, this.agentAmaxUtil, this.AgentABids, addBids);
    



    SimpleElement agentResultsB = resultsOfAgent("B", this.agentBname, this.agentBclass, this.agentButilSpaceName, this.agentAname, this.agentAclass, this.agentAutilSpaceName, this.agentButility, this.agentButilityDiscount, this.agentBmaxUtil, this.AgentBBids, addBids);
    if ((this.trajectoryMeasures != null) && (!this.trajectoryMeasures.isEmpty()))
    {
      agentResultsA.combineLists(
        (HashMap)((SimpleElement)this.trajectoryMeasures.getChildElements()[0]).getAttributes().clone());
      agentResultsB
        .combineLists(
        (HashMap)((SimpleElement)this.trajectoryMeasures.getChildElements()[1]).getAttributes().clone());
    }
    if ((this.qualityMeasures != null) && (!this.qualityMeasures.isEmpty()))
    {
      agentResultsA.combineLists(
        (HashMap)this.qualityMeasures.getAttributes().clone());
      agentResultsB
        .combineLists(
        (HashMap)this.qualityMeasures.getAttributes().clone());
    }
    outcome.addChildElement(agentResultsA);
    outcome.addChildElement(agentResultsB);
    
    outcome.setAttribute("errors", this.ErrorRemarks != null ? this.ErrorRemarks : "");
    

    String startingagent = "B";
    if (this.agentAstarts) {
      startingagent = "A";
    }
    outcome.setAttribute("startingAgent", startingagent);
    
    int i = 0;
    for (String extraName : this.extraNames)
    {
      String extraValue = (String)this.extraValues.get(i);
      if ((extraName != null) && (extraValue != null)) {
        outcome.setAttribute(extraName, extraValue);
      }
      i++;
    }
    if (addBids) {
      outcome.addChildElement(bidsToXML());
    }
    return outcome;
  }
  
  private static String getOfferingStrategyName(String agentName)
  {
    int left = agentName.indexOf("bs:");
    int right = agentName.indexOf("as:");
    
    String agentOfferingStrategyName = agentName.substring(left + 3, right);
    agentOfferingStrategyName = agentOfferingStrategyName.trim();
    
    return agentOfferingStrategyName;
  }
  
  private static String getAcceptanceStrategyName(String agentName)
  {
    int left = agentName.indexOf("as:");
    int right = agentName.indexOf("om:");
    
    String agentAcceptanceStrategyName = agentName.substring(left + 3, right);
    
    agentAcceptanceStrategyName = agentAcceptanceStrategyName.trim();
    
    return agentAcceptanceStrategyName;
  }
  
  private static String getOpponentModelName(String agentName)
  {
    int left = agentName.indexOf("om:");
    int right = agentName.indexOf("oms:");
    
    String agentOpponentModelName = agentName.substring(left + 3, right);
    agentOpponentModelName = agentOpponentModelName.trim();
    
    return agentOpponentModelName;
  }
  
  private OrderedSimpleElement bidsToXML()
  {
    OrderedSimpleElement bids = new OrderedSimpleElement("bidHistory");
    
    int total = Math.max(this.AgentABids.size(), this.AgentBBids.size());
    for (int i = 0; i < total; i++)
    {
      if (i < this.AgentABids.size())
      {
        BidPoint a = (BidPoint)this.AgentABids.get(i);
        SimpleElement xmlBidpoint = new OrderedSimpleElement("bidpoint");
        xmlBidpoint.setAttribute("fromAgent", "A");
        xmlBidpoint.setAttribute("utilityA", 
          String.valueOf(a.getUtilityA()));
        xmlBidpoint.setAttribute("utilityB", 
          String.valueOf(a.getUtilityB()));
        bids.addChildElement(xmlBidpoint);
      }
      if (i < this.AgentBBids.size())
      {
        BidPoint b = (BidPoint)this.AgentBBids.get(i);
        SimpleElement xmlBidpoint = new OrderedSimpleElement("bidpoint");
        xmlBidpoint.setAttribute("fromAgent", "B");
        xmlBidpoint.setAttribute("utilityA", 
          String.valueOf(b.getUtilityA()));
        xmlBidpoint.setAttribute("utilityB", 
          String.valueOf(b.getUtilityB()));
        bids.addChildElement(xmlBidpoint);
      }
    }
    return bids;
  }
  
  public int getRunNr()
  {
    return this.runNr;
  }
  
  public void setRunNr(int runNr)
  {
    this.runNr = runNr;
  }
  
  public boolean getAgentAFirst()
  {
    return this.agentAstarts;
  }
  
  public void setNegotiationOutcome(OpponentModelMeasuresResults omMeasuresResults)
  {
    this.omMeasuresResults = omMeasuresResults;
  }
  
  public String getAcceptedBid()
  {
    String result = "Reservation";
    if ((this.lastAction != null) && (this.lastAction.toString().equals("(Accept)"))) {
      result = this.alternatingOffersBilateralAtomicNegoSession.getLastBid().toString();
    }
    return result;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.NegotiationOutcome
 * JD-Core Version:    0.7.1
 */