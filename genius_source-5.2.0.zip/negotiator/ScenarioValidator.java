package negotiator;

import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map.Entry;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.Objective;
import negotiator.issue.ValueDiscrete;
import negotiator.repository.DomainRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.RepItem;
import negotiator.repository.Repository;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class ScenarioValidator
{
  private static String validateDomain(Domain domain)
  {
    String errors = "";
    ArrayList<Objective> objectives = domain.getObjectives();
    HashSet<String> names = new HashSet();
    for (int i = 0; i < objectives.size(); i++)
    {
      if (((Objective)objectives.get(i)).getNumber() != i) {
        errors = errors + "Index of \"" + ((Objective)objectives.get(i)).getName() + "\" is " + ((Objective)objectives.get(i)).getNumber() + " but should be " + i + "\n";
      }
      if (!names.add(((Objective)objectives.get(i)).getName())) {
        errors = errors + "There already exists an element with objective name \"" + ((Objective)objectives.get(i)).getName() + "\"\n";
      }
    }
    return errors;
  }
  
  private static String validateCorrespondenceDomainAndProfile(Domain domain, UtilitySpace space)
  {
    String errors = isComplete(space);
    if (errors == null) {
      errors = "";
    } else {
      errors = errors + "\n";
    }
    return errors;
  }
  
  private static String isComplete(UtilitySpace space)
  {
    Domain domain = space.getDomain();
    ArrayList<Issue> issues = domain.getIssues();
    if (issues == null) {
      return "Utility space is not complete, in fact it is empty!";
    }
    for (Issue issue : issues)
    {
      Evaluator ev = space.getEvaluator(issue.getNumber());
      if (ev == null) {
        return "issue " + issue.getName() + " has no evaluator";
      }
      String mess = ev.isComplete(issue);
      if (mess != null) {
        return mess;
      }
    }
    return null;
  }
  
  private static String validatePreferenceProfile(UtilitySpace space)
  {
    String errors = "";
    double weightSum = 0.0D;
    for (Map.Entry<Objective, Evaluator> pair : space.getEvaluators())
    {
      Objective obj = (Objective)pair.getKey();
      Evaluator eval = (Evaluator)pair.getValue();
      if (obj == null)
      {
        errors = errors + "Mismatch in objective indices between domain and preference profile\n";
        return errors;
      }
      if (obj.getType() == ISSUETYPE.DISCRETE)
      {
        EvaluatorDiscrete dEval = (EvaluatorDiscrete)eval;
        boolean allZero = true;
        for (ValueDiscrete dValue : dEval.getValues()) {
          try
          {
            double evaluation = dEval.getEvaluationNotNormalized(dValue).intValue();
            if (evaluation < 0.0D) {
              errors = errors + "Value \"" + dValue.getValue() + "\"" + " of objective \"" + obj.getName() + "\" must have a non-negative evaluation\n";
            } else if (evaluation > 0.0D) {
              allZero = false;
            }
          }
          catch (Exception e)
          {
            errors = errors + e.getMessage() + "\n";
          }
        }
        if (allZero) {
          errors = errors + "Objective \"" + obj.getName() + "\" does not have a value with a non-zero positive evaluation\n";
        }
      }
      weightSum += eval.getWeight();
    }
    if (Math.abs(1.0D - weightSum) > 0.01D) {
      errors = errors + "The sum of the issue weights differs significantly from one\n";
    }
    return errors;
  }
  
  public static String validateDomainRepository(Repository domainrepository)
  {
    String errors = "";
    try
    {
      for (RepItem repitem : domainrepository.getItems())
      {
        dri = (DomainRepItem)repitem;
        domain = new Domain(dri.getURL().getFile());
        for (ProfileRepItem pri : dri.getProfiles())
        {
          UtilitySpace space = new UtilitySpace(domain, pri.getURL().getFile());
          
          String newErrors = "";
          newErrors = newErrors + validateDomain(domain);
          newErrors = newErrors + validateCorrespondenceDomainAndProfile(domain, space);
          
          newErrors = newErrors + validatePreferenceProfile(space);
          if (!newErrors.trim().equals("")) {
            errors = errors + "DOMAIN: " + dri.getName() + " PROFILE: " + pri.getURL().getFile() + "\n" + newErrors + "\n";
          }
        }
      }
    }
    catch (Exception e)
    {
      DomainRepItem dri;
      Domain domain;
      e.printStackTrace();
    }
    return errors;
  }
  
  public static void main(String[] args)
  {
    try
    {
      Repository domainrepository = Repository.get_domain_repos();
      String result = validateDomainRepository(domainrepository);
      if (result.trim().equals("")) {
        System.out.println("All scenarios are OK");
      } else {
        System.out.println(result);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.ScenarioValidator
 * JD-Core Version:    0.7.1
 */