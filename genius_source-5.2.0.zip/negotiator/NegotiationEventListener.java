package negotiator;

import negotiator.events.ActionEvent;
import negotiator.events.BilateralAtomicNegotiationSessionEvent;
import negotiator.events.LogMessageEvent;
import negotiator.events.NegotiationSessionEvent;

public abstract interface NegotiationEventListener
{
  public abstract void handleActionEvent(ActionEvent paramActionEvent);
  
  public abstract void handleLogMessageEvent(LogMessageEvent paramLogMessageEvent);
  
  public abstract void handeNegotiationSessionEvent(NegotiationSessionEvent paramNegotiationSessionEvent);
  
  public abstract void handleBlateralAtomicNegotiationSessionEvent(BilateralAtomicNegotiationSessionEvent paramBilateralAtomicNegotiationSessionEvent);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.NegotiationEventListener
 * JD-Core Version:    0.7.1
 */