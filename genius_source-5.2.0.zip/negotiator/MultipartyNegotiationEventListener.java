package negotiator;

import negotiator.events.LogMessageEvent;
import negotiator.events.MultipartyNegotiationOfferEvent;
import negotiator.events.MultipartyNegotiationSessionEvent;

public abstract interface MultipartyNegotiationEventListener
{
  public abstract void handleOfferActionEvent(MultipartyNegotiationOfferEvent paramMultipartyNegotiationOfferEvent);
  
  public abstract void handleLogMessageEvent(LogMessageEvent paramLogMessageEvent);
  
  public abstract void handleMultipartyNegotiationEvent(MultipartyNegotiationSessionEvent paramMultipartyNegotiationSessionEvent);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.MultipartyNegotiationEventListener
 * JD-Core Version:    0.7.1
 */