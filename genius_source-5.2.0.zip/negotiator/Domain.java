package negotiator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Random;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.xml.SimpleDOMParser;
import negotiator.xml.SimpleElement;

public class Domain
  implements Serializable
{
  private static final long serialVersionUID = -8729366996052137300L;
  private Objective fObjectivesRoot;
  private String name;
  private SimpleElement root;
  
  public Domain()
  {
    this.fObjectivesRoot = null;
    this.name = "";
  }
  
  public SimpleElement getXMLRoot()
  {
    return this.root;
  }
  
  public Domain(SimpleElement root)
  {
    this.root = root;
    loadTreeFromXML(root);
  }
  
  public Domain(String filename)
    throws Exception
  {
    this(new File(filename));
    this.name = filename;
  }
  
  public Domain(File filename)
    throws Exception
  {
    this.name = filename.getAbsolutePath();
    SimpleDOMParser parser = new SimpleDOMParser();
    
    BufferedReader file = new BufferedReader(new FileReader(filename));
    this.root = parser.parse(file);
    try
    {
      xml_utility_space = (SimpleElement)this.root.getChildByTagName("utility_space")[0];
    }
    catch (Exception err)
    {
      SimpleElement xml_utility_space;
      throw new Exception("Can't read from " + filename + ", incorrect format of file");
    }
    SimpleElement xml_utility_space;
    loadTreeFromXML(xml_utility_space);
  }
  
  public final Objective getIssue(int index)
  {
    return (Objective)getIssues().get(index);
  }
  
  public final Objective getObjective(int ID)
  {
    return this.fObjectivesRoot.getObjective(ID);
  }
  
  public final Objective getObjectivesRoot()
  {
    return this.fObjectivesRoot;
  }
  
  public final void setObjectivesRoot(Objective ob)
  {
    this.fObjectivesRoot = ob;
  }
  
  private final void loadTreeFromXML(SimpleElement pRoot)
  {
    SimpleElement root = (SimpleElement)pRoot.getChildByTagName("objective")[0];
    int rootIndex = Integer.valueOf(root.getAttribute("index")).intValue();
    Objective objAlmostRoot = new Objective();
    objAlmostRoot.setNumber(rootIndex);
    String name = root.getAttribute("name");
    if (name != null) {
      objAlmostRoot.setName(name);
    } else {
      objAlmostRoot.setName("root");
    }
    this.fObjectivesRoot = buildTreeRecursive(root, objAlmostRoot);
  }
  
  private final Objective buildTreeRecursive(SimpleElement currentLevelRoot, Objective currentParent)
  {
    Object[] currentLevelObjectives = currentLevelRoot.getChildByTagName("objective");
    Object[] currentLevelIssues = currentLevelRoot.getChildByTagName("issue");
    for (int i = 0; i < currentLevelObjectives.length; i++)
    {
      SimpleElement childObjectives = (SimpleElement)currentLevelObjectives[i];
      int obj_index = Integer.valueOf(childObjectives.getAttribute("index")).intValue();
      Objective child = new Objective(currentParent);
      child.setNumber(obj_index);
      
      child.setName(childObjectives.getAttribute("name"));
      



      currentParent.addChild(buildTreeRecursive(childObjectives, child));
    }
    for (int j = 0; j < currentLevelIssues.length; j++)
    {
      Issue child = null;
      
      SimpleElement childIssues = (SimpleElement)currentLevelIssues[j];
      
      String name = childIssues.getAttribute("name");
      int index = Integer.parseInt(childIssues.getAttribute("index"));
      

      String type = childIssues.getAttribute("type");
      String vtype = childIssues.getAttribute("vtype");
      ISSUETYPE issueType;
      ISSUETYPE issueType;
      if (type == null)
      {
        issueType = ISSUETYPE.DISCRETE;
      }
      else
      {
        ISSUETYPE issueType;
        if (type.equals(vtype))
        {
          issueType = ISSUETYPE.convertToType(type);
        }
        else
        {
          ISSUETYPE issueType;
          if ((type != null) && (vtype == null))
          {
            issueType = ISSUETYPE.convertToType(type);
          }
          else
          {
            System.out.println("Conflicting value types specified for issue in template file.");
            

            issueType = ISSUETYPE.convertToType(type);
          }
        }
      }
      String[] values;
      switch (issueType)
      {
      case DISCRETE: 
        Object[] xml_items = childIssues.getChildByTagName("item");
        int nrOfItems = xml_items.length;
        
        values = new String[nrOfItems];
        String[] desc = new String[nrOfItems];
        for (int k = 0; k < nrOfItems; k++)
        {
          values[k] = ((SimpleElement)xml_items[k]).getAttribute("value");
          desc[k] = ((SimpleElement)xml_items[k]).getAttribute("description");
        }
        child = new IssueDiscrete(name, index, values, desc, currentParent);
        break;
      case INTEGER: 
        Object[] xml_item = childIssues.getChildByTagName("range");
        int minI = Integer.valueOf(childIssues.getAttribute("lowerbound")).intValue();
        int maxI = Integer.valueOf(childIssues.getAttribute("upperbound")).intValue();
        child = new IssueInteger(name, index, minI, maxI, currentParent);
        break;
      case REAL: 
        Object[] xml_item = childIssues.getChildByTagName("range");
        double minR = Double.valueOf(((SimpleElement)xml_item[0]).getAttribute("lowerbound")).doubleValue();
        double maxR = Double.valueOf(((SimpleElement)xml_item[0]).getAttribute("upperbound")).doubleValue();
        child = new IssueReal(name, index, minR, maxR);
        break;
      default: 
        Object[] xml_items = childIssues.getChildByTagName("item");
        int nrOfItems = xml_items.length;
        values = new String[nrOfItems];
        child = new IssueDiscrete(name, index, values, currentParent);
      }
      child.setNumber(index);
      try
      {
        currentParent.addChild(child);
      }
      catch (Exception e)
      {
        System.out.println("child is NULL");
        e.printStackTrace();
      }
    }
    return currentParent;
  }
  
  public final Bid getRandomBid()
  {
    return getRandomBid(new Random());
  }
  
  public final Bid getRandomBid(Random r)
  {
    HashMap<Integer, Value> values = new HashMap();
    for (Issue lIssue : getIssues()) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int lNrOfOptions = lIssueDiscrete.getNumberOfValues();
        int lOptionIndex = Double.valueOf(r.nextDouble() * lNrOfOptions).intValue();
        if (lOptionIndex >= lNrOfOptions) {
          lOptionIndex = lNrOfOptions - 1;
        }
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(lOptionIndex));
        break;
      case INTEGER: 
        int lNrOfOptions = ((IssueInteger)lIssue).getUpperBound() - ((IssueInteger)lIssue).getLowerBound() + 1;
        int lOptionIndex = Double.valueOf(r.nextDouble() * lNrOfOptions).intValue();
        if (lOptionIndex >= lNrOfOptions) {
          lOptionIndex = lNrOfOptions - 1;
        }
        values.put(Integer.valueOf(lIssue.getNumber()), new ValueInteger(((IssueInteger)lIssue).getLowerBound() + lOptionIndex));
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int lNrOfOptions = lIssueReal.getNumberOfDiscretizationSteps();
        double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNrOfOptions;
        int lOptionIndex = Double.valueOf(r.nextDouble() * lNrOfOptions).intValue();
        if (lOptionIndex >= lNrOfOptions) {
          lOptionIndex = lNrOfOptions - 1;
        }
        values.put(Integer.valueOf(lIssue.getNumber()), new ValueReal(lIssueReal.getLowerBound() + lOneStep * lOptionIndex));
      }
    }
    try
    {
      return new Bid(this, values);
    }
    catch (Exception e)
    {
      System.out.println("problem getrandombid:" + e.getMessage());
    }
    return null;
  }
  
  public SimpleElement toXML()
  {
    SimpleElement root = new SimpleElement("negotiation_template");
    SimpleElement utilRoot = new SimpleElement("utility_space");
    
    utilRoot.setAttribute("number_of_issues", "" + this.fObjectivesRoot.getChildCount());
    utilRoot.addChildElement(this.fObjectivesRoot.toXML());
    root.addChildElement(utilRoot);
    return root;
  }
  
  public ArrayList<Objective> getObjectives()
  {
    Enumeration<Objective> objectives = this.fObjectivesRoot.getPreorderEnumeration();
    ArrayList<Objective> objectivelist = new ArrayList();
    while (objectives.hasMoreElements()) {
      objectivelist.add(objectives.nextElement());
    }
    return objectivelist;
  }
  
  public ArrayList<Issue> getIssues()
  {
    Enumeration<Objective> issues = this.fObjectivesRoot.getPreorderIssueEnumeration();
    ArrayList<Issue> issuelist = new ArrayList();
    while (issues.hasMoreElements()) {
      issuelist.add((Issue)issues.nextElement());
    }
    return issuelist;
  }
  
  public long getNumberOfPossibleBids()
  {
    long lNumberOfPossibleBids = 1L;
    ArrayList<Issue> lIssues = getIssues();
    for (Issue lIssue : lIssues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        lNumberOfPossibleBids *= ((IssueDiscrete)lIssue).getNumberOfValues();
        break;
      case REAL: 
        lNumberOfPossibleBids *= ((IssueReal)lIssue).getNumberOfDiscretizationSteps();
      }
    }
    return lNumberOfPossibleBids;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    
    result = 31 * result + (this.fObjectivesRoot == null ? 0 : this.fObjectivesRoot.hashCode());
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    Domain other = (Domain)obj;
    if (this.fObjectivesRoot == null)
    {
      if (other.fObjectivesRoot != null) {
        return false;
      }
    }
    else if (!this.fObjectivesRoot.equals(other.fObjectivesRoot)) {
      return false;
    }
    return true;
  }
  
  public String getName()
  {
    return this.name;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Domain
 * JD-Core Version:    0.7.1
 */