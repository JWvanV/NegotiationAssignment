package negotiator;

public abstract class Timeline
{
  protected boolean hasDeadline;
  protected boolean paused;
  
  public Timeline()
  {
    this.paused = false;
  }
  
  public abstract double getTime();
  
  public abstract double getTotalTime();
  
  public abstract double getCurrentTime();
  
  public abstract void printTime();
  
  public static enum Type
  {
    Time,  Rounds;
    
    private Type() {}
  }
  
  public boolean isDeadlineReached()
  {
    return (this.hasDeadline) && (getTime() >= 1.0D);
  }
  
  public void pause()
    throws Exception
  {
    throw new Exception("This timeline can not be paused and resumed.");
  }
  
  public void resume()
    throws Exception
  {
    throw new Exception("This timeline can not be paused and resumed.");
  }
  
  public Type getType()
  {
    return Type.Time;
  }
  
  public boolean isPaused()
  {
    return this.paused;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Timeline
 * JD-Core Version:    0.7.1
 */