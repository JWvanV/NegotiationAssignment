package negotiator;

import java.util.ArrayList;

public enum Feedback
{
  BETTER,  SAME,  WORSE;
  
  private Feedback() {}
  
  public static Vote isAcceptable(ArrayList<Feedback> feedbackList)
  {
    for (Feedback currentFeedback : feedbackList) {
      if (currentFeedback == WORSE) {
        return Vote.REJECT;
      }
    }
    return Vote.ACCEPT;
  }
  
  public static Feedback madeupFeedback(double previous, double current)
  {
    if (previous > current) {
      return WORSE;
    }
    if (previous == current) {
      return SAME;
    }
    return BETTER;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Feedback
 * JD-Core Version:    0.7.1
 */