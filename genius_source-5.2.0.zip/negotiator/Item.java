package negotiator;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import negotiator.issue.Value;

@XmlRootElement
class Item
{
  @XmlAttribute(name="index")
  public Integer key;
  @XmlElement
  public Value value;
  
  public Item() {}
  
  public Item(Integer key, Value val)
  {
    this.key = key;
    this.value = val;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Item
 * JD-Core Version:    0.7.1
 */