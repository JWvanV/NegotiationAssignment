package negotiator;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import negotiator.issue.Issue;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.xml.SimpleElement;

@XmlRootElement
public final class Bid
  implements XMLable, Serializable
{
  private static final long serialVersionUID = -7723017380013100614L;
  Domain fDomain;
  @XmlElement(name="values")
  @XmlJavaTypeAdapter(MyMapAdapter.class)
  private HashMap<Integer, Value> fValues;
  
  public Bid()
  {
    this.fValues = new HashMap();
  }
  
  public Bid(Domain domainP, HashMap<Integer, Value> bidP)
    throws Exception
  {
    this.fDomain = domainP;
    













    this.fValues = bidP;
  }
  
  public Bid(Bid bid)
  {
    this.fDomain = bid.fDomain;
    this.fValues = ((HashMap)bid.fValues.clone());
  }
  
  public Value getValue(int issueNr)
    throws Exception
  {
    Value v = (Value)this.fValues.get(Integer.valueOf(issueNr));
    if (v == null)
    {
      if (this.fDomain.getIssue(issueNr) == null) {
        throw new Exception("Bid.getValue: issue " + issueNr + " does not exist at all");
      }
      throw new Exception("There is no evaluator for issue " + issueNr);
    }
    return v;
  }
  
  public void setValue(int issueId, Value pValue)
  {
    if (((Value)this.fValues.get(Integer.valueOf(issueId))).getType() == pValue.getType()) {
      this.fValues.put(Integer.valueOf(issueId), pValue);
    }
  }
  
  public String toString()
  {
    String s = "Bid[";
    Set<Map.Entry<Integer, Value>> value_set = this.fValues.entrySet();
    Iterator<Map.Entry<Integer, Value>> value_it = value_set.iterator();
    while (value_it.hasNext())
    {
      int ind = ((Integer)((Map.Entry)value_it.next()).getKey()).intValue();
      Object tmpobj = this.fDomain.getObjective(ind);
      if (tmpobj != null)
      {
        String nm = this.fDomain.getObjective(ind).getName();
        
        s = s + nm + ": " + this.fValues.get(Integer.valueOf(ind)) + ", ";
      }
      else
      {
        System.out.println("objective with index " + ind + " does not exist");
      }
    }
    s = s + "]";
    return s;
  }
  
  public boolean equals(Bid pBid)
  {
    return this.fValues.equals(pBid.getValues());
  }
  
  public boolean equals(Object obj)
  {
    if ((obj instanceof Bid)) {
      return equals((Bid)obj);
    }
    return false;
  }
  
  public HashMap<Integer, Value> getValues()
  {
    return this.fValues;
  }
  
  public ArrayList<Issue> getIssues()
  {
    return this.fDomain.getIssues();
  }
  
  public SimpleElement toXML()
  {
    SimpleElement lXMLBid = new SimpleElement("bid");
    for (Issue lIssue : this.fDomain.getIssues())
    {
      Value lVal = (Value)this.fValues.get(Integer.valueOf(lIssue.getNumber()));
      SimpleElement lXMLIssue = new SimpleElement("issue");
      lXMLIssue.setAttribute("type", lIssue.convertToString());
      lXMLIssue.setAttribute("index", String.valueOf(lIssue.getNumber()));
      lXMLBid.addChildElement(lXMLIssue);SimpleElement lXMLItem = null;
      switch (lVal.getType())
      {
      case DISCRETE: 
        ValueDiscrete lDiscVal = (ValueDiscrete)lVal;
        lXMLItem = new SimpleElement("item");
        lXMLItem.setAttribute("value", lDiscVal.getValue());
        break;
      case INTEGER: 
        ValueInteger lIntVal = (ValueInteger)lVal;
        lXMLItem = new SimpleElement("value");
        lXMLItem.setText(String.valueOf(lIntVal.getValue()));
        break;
      case REAL: 
        ValueReal lRealVal = (ValueReal)lVal;
        lXMLItem = new SimpleElement("value");
        lXMLItem.setText(String.valueOf(lRealVal.getValue()));
      }
      lXMLIssue.addChildElement(lXMLItem);
    }
    return lXMLBid;
  }
  
  public int hashCode()
  {
    int code = 0;
    for (Map.Entry<Integer, Value> lEntry : this.fValues.entrySet()) {
      code += ((Value)lEntry.getValue()).hashCode();
    }
    return code;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Bid
 * JD-Core Version:    0.7.1
 */