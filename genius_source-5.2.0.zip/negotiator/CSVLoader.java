package negotiator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import negotiator.protocol.OldProtocol;
import negotiator.repository.AgentRepItem;
import negotiator.repository.DomainRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.ProtocolRepItem;
import negotiator.repository.RepItem;
import negotiator.repository.Repository;
import negotiator.tournament.Tournament;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.tournament.VariablesAndValues.AgentValue;
import negotiator.tournament.VariablesAndValues.AgentVariable;
import negotiator.tournament.VariablesAndValues.ProfileValue;
import negotiator.tournament.VariablesAndValues.ProfileVariable;
import negotiator.tournament.VariablesAndValues.ProtocolValue;
import negotiator.tournament.VariablesAndValues.ProtocolVariable;
import negotiator.tournament.VariablesAndValues.TotalSessionNumberValue;
import negotiator.tournament.VariablesAndValues.TotalSessionNumberVariable;

public class CSVLoader
{
  ArrayList<OldProtocol> sessions = new ArrayList();
  String filePath = "";
  
  public CSVLoader(String csvFilePath)
    throws Exception
  {
    this.filePath = csvFilePath;
    try
    {
      FileReader fr = new FileReader(csvFilePath);
      BufferedReader br = new BufferedReader(fr);
      String line;
      while ((line = br.readLine()) != null)
      {
        line = line.trim();
        String[] tokens = line.split("\t");
        if ((tokens.length != 0) && (!line.startsWith(";")))
        {
          if (tokens.length < 5)
          {
            System.out.println("Invalid line " + line + " parsed as " + Arrays.toString(tokens));
            break;
          }
          String protocol = tokens[0].trim();
          String domain = tokens[1].trim();
          String[] agentsA = tokens[2].split(",");
          String[] agentsB = tokens[3].split(",");
          String[] profiles = tokens[4].split(",");
          
          ArrayList<HashMap<String, String>> agentParamsA = new ArrayList();
          for (int i = 0; i < agentsA.length; i++) {
            agentParamsA.add(new HashMap());
          }
          ArrayList<HashMap<String, String>> agentParamsB = new ArrayList();
          for (int i = 0; i < agentsB.length; i++) {
            agentParamsB.add(new HashMap());
          }
          if (tokens.length > 6)
          {
            String[] allAgentAParams = tokens[5].split(",");
            for (int i = 0; i < allAgentAParams.length; i++)
            {
              String[] stringAgentParams = allAgentAParams[i].split(";");
              for (int j = 0; j < stringAgentParams.length; j++)
              {
                String[] keyValuePair = stringAgentParams[j].split("=");
                if (keyValuePair.length > 2) {
                  throw new Exception("Syntax error in agent parameters list!");
                }
                ((HashMap)agentParamsA.get(i)).put(keyValuePair[0], keyValuePair[1]);
              }
            }
            String[] allAgentBParams = tokens[6].split(",");
            for (int i = 0; i < allAgentBParams.length; i++)
            {
              String[] stringAgentParams = allAgentBParams[i].split(";");
              for (int j = 0; j < stringAgentParams.length; j++)
              {
                String[] keyValuePair = stringAgentParams[j].split("=");
                if (keyValuePair.length > 2) {
                  throw new Exception("Syntax error in agent parameters list!");
                }
                ((HashMap)agentParamsB.get(i)).put(keyValuePair[0], keyValuePair[1]);
              }
            }
          }
          HashMap<String, String> params = new HashMap();
          if (tokens.length > 7)
          {
            String[] stringParams = tokens[7].split(";");
            for (int i = 0; i < stringParams.length; i++)
            {
              String[] keyValuePair = stringParams[i].split("=");
              if (keyValuePair.length > 2) {
                throw new Exception("Syntax error in parameters list!");
              }
              params.put(keyValuePair[0], keyValuePair[1]);
            }
          }
          loadSessions(protocol, domain, agentsA, agentsB, profiles, agentParamsA, agentParamsB, params);
        }
      }
      br.close();
      fr.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
      throw new Exception("Batch file error!");
    }
  }
  
  public ArrayList<OldProtocol> getSessions()
  {
    return this.sessions;
  }
  
  public String getFilePath()
  {
    return this.filePath;
  }
  
  private void loadSessions(String protocol, String domain, String[] agentsA, String[] agentsB, String[] profiles, ArrayList<HashMap<String, String>> agentParamsA, ArrayList<HashMap<String, String>> agentParamsB, HashMap<String, String> parameters)
    throws Exception
  {
    Repository repProtocol = Repository.getProtocolRepository();
    ProtocolRepItem protocolRI = (ProtocolRepItem)repProtocol.getItemByName(protocol);
    repProtocol = null;
    if (protocolRI == null) {
      throw new Exception("Unable to createFrom protocol: " + protocol);
    }
    Repository repDomain = Repository.get_domain_repos();
    RepItem domainRI = repDomain.getItemByName(domain);
    repDomain = null;
    if (domainRI == null) {
      throw new Exception("Unable to find domain: " + domain);
    }
    Repository repAgent = Repository.get_agent_repository();
    AgentRepItem[] agentsARI = new AgentRepItem[agentsA.length];
    for (int i = 0; i < agentsA.length; i++)
    {
      agentsARI[i] = ((AgentRepItem)repAgent.getItemByName(agentsA[i]));
      if (agentsARI[i] == null) {
        throw new Exception("Unable to createFrom agent " + agentsA[i] + "!");
      }
    }
    AgentRepItem[] agentsBRI = new AgentRepItem[agentsB.length];
    for (int i = 0; i < agentsB.length; i++)
    {
      agentsBRI[i] = ((AgentRepItem)repAgent.getItemByName(agentsB[i]));
      if (agentsBRI[i] == null) {
        throw new Exception("Unable to createFrom agent " + agentsB[i] + "!");
      }
    }
    ArrayList<ProfileRepItem> profileArray = ((DomainRepItem)domainRI).getProfiles();
    ProfileRepItem[] profilesRI = new ProfileRepItem[profiles.length];
    for (int i = 0; i < profiles.length; i++)
    {
      for (ProfileRepItem prf : profileArray) {
        if (prf.getName().equals(profiles[i])) {
          profilesRI[i] = prf;
        }
      }
      if (profilesRI[i] == null) {
        throw new Exception("Unable to createFrom profile: " + profiles[i]);
      }
    }
    HashMap<AgentParameterVariable, AgentParamValue>[] agentParamsAp = new HashMap[agentsARI.length];
    for (int i = 0; i < agentsARI.length; i++) {
      agentParamsAp[i] = new HashMap();
    }
    if (parameters.get("tournament") != null) {
      loadMultipleSessions(protocolRI, agentsARI, agentsBRI, profilesRI, agentParamsA, agentParamsB, parameters);
    } else {
      loadOneSession(protocolRI, agentsARI, agentsBRI, profilesRI, agentParamsA, agentParamsB, parameters);
    }
  }
  
  private void loadMultipleSessions(ProtocolRepItem protocol, AgentRepItem[] agentsA, AgentRepItem[] agentsB, ProfileRepItem[] profiles, ArrayList<HashMap<String, String>> agentParamsA, ArrayList<HashMap<String, String>> agentParamsB, HashMap<String, String> parameters)
    throws Exception
  {
    String[] tournamentParams = ((String)parameters.get("tournament")).split(",");
    
    parameters.remove("tournament");
    

    boolean selfplay = false;
    boolean play_both_sides = false;
    HashSet<Integer> partiesHash = new HashSet();
    int n2;
    for (int i = 0; i < tournamentParams.length; i++)
    {
      if (Character.isDigit(tournamentParams[i].charAt(0)))
      {
        String[] intervals = tournamentParams[i].split("-");
        int n1 = Integer.parseInt(intervals[0]);
        switch (intervals.length)
        {
        case 1: 
          partiesHash.add(Integer.valueOf(n1));
          break;
        case 2: 
          n1 = Integer.parseInt(intervals[0]);
          n2 = Integer.parseInt(intervals[1]);
          if (n1 > n2) {
            throw new Exception("In tournament property the left side of the interval must be smaller than the right one!");
          }
          for (j = n1; j <= n2; j++) {
            partiesHash.add(Integer.valueOf(j));
          }
          break;
        }
      }
      if (tournamentParams[i].equals("all_combinations")) {
        partiesHash.add(Integer.valueOf(2));
      }
      if (tournamentParams[i].equals("selfplay")) {
        selfplay = true;
      } else if (tournamentParams[i].equals("play_both_sides")) {
        play_both_sides = true;
      }
    }
    Tournament t = new Tournament();
    ProtocolVariable protocolVariable = new ProtocolVariable();
    protocolVariable.addValue(new ProtocolValue(protocol));
    t.getVariables().add(protocolVariable);
    
    AgentVariable agentVariableA = new AgentVariable();
    agentVariableA.setSide("A");
    for (aRI : agentsA) {
      agentVariableA.addValue(new AgentValue(aRI));
    }
    t.getVariables().add(agentVariableA);
    
    ProfileVariable profileVariable = new ProfileVariable();
    int j = profiles;??? = j.length;
    for (AgentRepItem aRI = 0; aRI < ???; aRI++)
    {
      pRI = j[aRI];
      
      profileVariable.addValue(new ProfileValue(pRI));
    }
    t.getVariables().add(profileVariable);
    
    AgentVariable agentVariableB = new AgentVariable();
    agentVariableB.setSide("B");
    AgentRepItem[] arrayOfAgentRepItem = agentsB;aRI = arrayOfAgentRepItem.length;
    for (ProfileRepItem pRI = 0; pRI < aRI; pRI++)
    {
      AgentRepItem aRI = arrayOfAgentRepItem[pRI];
      
      agentVariableB.addValue(new AgentValue(aRI));
    }
    t.getVariables().add(agentVariableB);
    
    TotalSessionNumberVariable totalVariable = new TotalSessionNumberVariable();
    if (parameters.containsKey("total_sessions")) {
      totalVariable.addValue(new TotalSessionNumberValue(Integer.parseInt((String)parameters.get("total_sessions"))));
    } else {
      totalVariable.addValue(new TotalSessionNumberValue());
    }
    t.getVariables().add(totalVariable);
    
    this.sessions.addAll(t.getSessions());
  }
  
  private void loadOneSession(ProtocolRepItem protocol, AgentRepItem[] agentsA, AgentRepItem[] agentsB, ProfileRepItem[] profiles, ArrayList<HashMap<String, String>> agentParamsA, ArrayList<HashMap<String, String>> agentParamsB, HashMap<String, String> parameters)
    throws Exception
  {
    int totalNumberOfAgents = agentsA.length + agentsB.length;
    AgentRepItem[] agentsRI = new AgentRepItem[totalNumberOfAgents];
    System.arraycopy(agentsA, 0, agentsRI, 0, agentsA.length);
    System.arraycopy(agentsB, 0, agentsRI, agentsA.length, agentsB.length);
    
    HashMap<AgentParameterVariable, AgentParamValue>[] agentParamsp = new HashMap[totalNumberOfAgents];
    for (int i = 0; i < agentParamsp.length; i++) {
      agentParamsp[i] = new HashMap();
    }
    if (profiles.length != agentsRI.length) {
      throw new Exception("Invalid file - non-equal number of profiles and agents");
    }
    try
    {
      OldProtocol ns = Global.createProtocolInstance(protocol, agentsRI, profiles, agentParamsp);
      this.sessions.add(ns);
    }
    catch (Exception e)
    {
      throw new Exception("Cannot createFrom protocol!");
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.CSVLoader
 * JD-Core Version:    0.7.1
 */