package negotiator.bidding;

import java.util.Comparator;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class BidStrictSorterUtility
  implements Comparator<Bid>
{
  private UtilitySpace utilitySpace;
  
  public BidStrictSorterUtility(UtilitySpace utilitySpace)
  {
    this.utilitySpace = utilitySpace;
  }
  
  public int compare(Bid b1, Bid b2)
  {
    try
    {
      if ((b1 == null) || (b2 == null)) {
        throw new NullPointerException();
      }
      if (this.utilitySpace.getUtility(b1) == this.utilitySpace.getUtility(b2)) {
        return String.CASE_INSENSITIVE_ORDER.compare(b1.toString(), b2.toString());
      }
      if (this.utilitySpace.getUtility(b1) > this.utilitySpace.getUtility(b2)) {
        return -1;
      }
      if (this.utilitySpace.getUtility(b1) < this.utilitySpace.getUtility(b2)) {
        return 1;
      }
      return Integer.valueOf(b1.hashCode()).compareTo(Integer.valueOf(b2.hashCode()));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return -1;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.bidding.BidStrictSorterUtility
 * JD-Core Version:    0.7.1
 */