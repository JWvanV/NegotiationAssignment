package negotiator;

import java.io.PrintStream;

public class PausableContinuousTimeline
  extends ContinuousTimeline
{
  private long timeAtPause;
  private long totalPausedTime;
  
  public PausableContinuousTimeline(int totalSecs)
  {
    super(totalSecs);
  }
  
  public double getElapsedSeconds()
  {
    long t2;
    long t2;
    if (this.paused) {
      t2 = this.timeAtPause;
    } else {
      t2 = System.nanoTime();
    }
    return (t2 - this.startTime - this.totalPausedTime) / 1000000000.0D;
  }
  
  public double getElapsedMilliSeconds()
  {
    long t2;
    long t2;
    if (this.paused) {
      t2 = this.timeAtPause;
    } else {
      t2 = System.nanoTime();
    }
    return (t2 - this.startTime - this.totalPausedTime) / 1000000.0D;
  }
  
  public static void main(String[] args)
  {
    PausableContinuousTimeline timeline = new PausableContinuousTimeline(3);
    System.out.println("Elapsed: " + timeline.getElapsedSeconds() + " seconds");
    try
    {
      timeline.pause();
      Thread.sleep(2000L);
      timeline.resume();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    System.out.println("Elapsed: " + timeline.getElapsedSeconds() + " seconds");
    try
    {
      timeline.pause();
      Thread.sleep(2000L);
      timeline.resume();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    timeline.printElapsedSeconds();
    while (!timeline.isDeadlineReached()) {
      System.out.println("Elapsed: " + timeline.getElapsedSeconds() + " seconds");
    }
  }
  
  public void pause()
  {
    if (!this.paused)
    {
      this.paused = true;
      this.timeAtPause = System.nanoTime();
    }
  }
  
  public void resume()
  {
    if (this.paused)
    {
      this.totalPausedTime += System.nanoTime() - this.timeAtPause;
      this.paused = false;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.PausableContinuousTimeline
 * JD-Core Version:    0.7.1
 */