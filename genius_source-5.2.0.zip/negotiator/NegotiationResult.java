package negotiator;

import negotiator.actions.Accept;
import negotiator.actions.Action;

public class NegotiationResult
{
  private final double myDiscountedUtility;
  private final Action lastAction;
  private final Bid lastBid;
  
  public NegotiationResult(double myDiscountedUtility, Action lastAction, Bid lastBid)
  {
    this.myDiscountedUtility = myDiscountedUtility;
    this.lastAction = lastAction;
    this.lastBid = lastBid;
  }
  
  public boolean isAgreement()
  {
    return this.lastAction instanceof Accept;
  }
  
  public double getMyDiscountedUtility()
  {
    return this.myDiscountedUtility;
  }
  
  public Action getLastAction()
  {
    return this.lastAction;
  }
  
  public Bid getLastBid()
  {
    return this.lastBid;
  }
  
  public String toString()
  {
    return this.myDiscountedUtility + "\n" + this.lastAction + "\n" + this.lastBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.NegotiationResult
 * JD-Core Version:    0.7.1
 */