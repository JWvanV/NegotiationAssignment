package negotiator;

import java.util.ArrayList;
import negotiator.actions.Action;

public class NegoRound
{
  private ArrayList<NegoTurn> partyActionList;
  private int currentTurnIndex;
  private int currentRoundNo;
  private ArrayList<Class> actionsTerminateSessionWithSuccess;
  private ArrayList<Class> actionsTerminateSessionWithFailure;
  
  public NegoRound()
  {
    setPartyActionList(new ArrayList());
    setActionsTerminateSessionWithFailure(new ArrayList());
    setActionsTerminateSessionWithSuccess(new ArrayList());
    this.currentTurnIndex = 0;
    setCurrentRoundNo(1);
  }
  
  public NegoRound(ArrayList<NegoTurn> partyActionList, int numberOfTurnInARound)
  {
    setPartyActionList(partyActionList);
    setActionsTerminateSessionWithFailure(new ArrayList());
    setActionsTerminateSessionWithSuccess(new ArrayList());
    this.currentTurnIndex = 0;
    setCurrentRoundNo(1);
  }
  
  public NegoRound(ArrayList<NegoTurn> partyActionList, ArrayList<Class> actionsTerminateWithSuccess, ArrayList<Class> actionsTerminateWithFailure, int numberOfTurnInARound)
  {
    setPartyActionList(partyActionList);
    setActionsTerminateSessionWithFailure(actionsTerminateWithFailure);
    setActionsTerminateSessionWithSuccess(actionsTerminateWithSuccess);
    this.currentTurnIndex = 0;
    setCurrentRoundNo(1);
  }
  
  public NegoRound(NegoRound negoRound)
  {
    this.partyActionList = negoRound.getPartyActionList();
    this.currentTurnIndex = negoRound.getCurrentTurnIndex();
    this.currentRoundNo = negoRound.getCurrentRoundNo();
    this.actionsTerminateSessionWithFailure = negoRound.getActionsTerminateSessionWithFailure();
    this.actionsTerminateSessionWithSuccess = negoRound.getActionsTerminateSessionWithSuccess();
  }
  
  protected int getCurrentTurnIndex()
  {
    return this.currentTurnIndex;
  }
  
  public ArrayList<Class> getActionsTerminateSessionWithFailure()
  {
    return this.actionsTerminateSessionWithFailure;
  }
  
  public void setActionsTerminateSessionWithFailure(ArrayList<Class> actions)
  {
    this.actionsTerminateSessionWithFailure = actions;
  }
  
  public void addActionTerminateSessionWithFailure(Class action)
  {
    this.actionsTerminateSessionWithFailure.add(action);
  }
  
  public void removeActionTeminateSessionWithFailure(Class action)
  {
    this.actionsTerminateSessionWithFailure.remove(action);
  }
  
  public void clearActionsTerminateSessionWithFailure()
  {
    this.actionsTerminateSessionWithFailure = new ArrayList();
  }
  
  public ArrayList<Class> getActionsTerminateSessionWithSuccess()
  {
    return this.actionsTerminateSessionWithSuccess;
  }
  
  public void setActionsTerminateSessionWithSuccess(ArrayList<Class> actions)
  {
    this.actionsTerminateSessionWithSuccess = actions;
  }
  
  public void addActionTerminateSessionWithSuccess(Class action)
  {
    this.actionsTerminateSessionWithSuccess.add(action);
  }
  
  public void removeActionTeminateSessionWithSuccess(Class action)
  {
    this.actionsTerminateSessionWithSuccess.remove(action);
  }
  
  public void clearActionsTerminateSessionWithSuccess()
  {
    this.actionsTerminateSessionWithSuccess = new ArrayList();
  }
  
  public int getCurrentRoundNo()
  {
    return this.currentRoundNo;
  }
  
  public void setCurrentRoundNo(int currentRoundNo)
  {
    this.currentRoundNo = currentRoundNo;
  }
  
  public ArrayList<NegoTurn> getPartyActionList()
  {
    return this.partyActionList;
  }
  
  public void setPartyActionList(ArrayList<NegoTurn> partyActionList)
  {
    this.partyActionList = partyActionList;
  }
  
  public void addPartyActions(NegoTurn partyAction)
  {
    this.partyActionList.add(partyAction);
  }
  
  public NegoTurn getCurrentPartyAndValidActions()
  {
    return (NegoTurn)this.partyActionList.get(this.currentTurnIndex);
  }
  
  public int getCurrentPartyIndex()
  {
    return ((NegoTurn)this.partyActionList.get(this.currentTurnIndex)).getPartyIndex();
  }
  
  public ArrayList<Class> getCurrentPartysValidActions()
  {
    return ((NegoTurn)this.partyActionList.get(this.currentTurnIndex)).getValidActions();
  }
  
  public boolean setNextTurn()
  {
    this.currentTurnIndex = ((this.currentTurnIndex + 1) % this.partyActionList.size());
    if (this.currentTurnIndex == 0)
    {
      this.currentRoundNo += 1;
      return true;
    }
    return false;
  }
  
  public boolean isCurrentActionValid(Action currentAction)
  {
    if (getCurrentPartysValidActions().contains(currentAction.getClass())) {
      return true;
    }
    return false;
  }
  
  public boolean isDeadlineReached(int maxRound)
  {
    if (this.currentRoundNo > maxRound) {
      return true;
    }
    return false;
  }
  
  public boolean doesTerminateWithSuccess(Action currentAction)
  {
    if (this.actionsTerminateSessionWithSuccess.contains(currentAction.getClass())) {
      return true;
    }
    return false;
  }
  
  public boolean doesTerminateWithFailure(Action currentAction)
  {
    if (this.actionsTerminateSessionWithFailure.contains(currentAction.getClass())) {
      return true;
    }
    return false;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.NegoRound
 * JD-Core Version:    0.7.1
 */