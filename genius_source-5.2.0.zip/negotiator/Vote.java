package negotiator;

public enum Vote
{
  REJECT,  ACCEPT;
  
  private Vote() {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Vote
 * JD-Core Version:    0.7.1
 */