package negotiator;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializeHandling
{
  public static boolean writeToDisc(Serializable data, String path)
  {
    try
    {
      FileOutputStream fout = new FileOutputStream(path);
      ObjectOutputStream oos = new ObjectOutputStream(fout);
      oos.writeObject(data);
      oos.close();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      return false;
    }
    return true;
  }
  
  public static Serializable readFromDisc(String path)
  {
    try
    {
      FileInputStream fin = new FileInputStream(path);
      ObjectInputStream ois = new ObjectInputStream(fin);
      Serializable data = (Serializable)ois.readObject();
      ois.close();
      
      return data;
    }
    catch (FileNotFoundException e)
    {
      return null;
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.SerializeHandling
 * JD-Core Version:    0.7.1
 */