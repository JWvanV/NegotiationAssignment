package negotiator;

import negotiator.actions.Action;
import negotiator.utility.UtilitySpace;

public abstract interface PocketNegotiatorAgent
{
  public abstract void initPN(UtilitySpace paramUtilitySpace1, UtilitySpace paramUtilitySpace2, Timeline paramTimeline);
  
  public abstract void handleAction(Action paramAction);
  
  public abstract Action getAction();
  
  public abstract void updateProfiles(UtilitySpace paramUtilitySpace1, UtilitySpace paramUtilitySpace2);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.PocketNegotiatorAgent
 * JD-Core Version:    0.7.1
 */