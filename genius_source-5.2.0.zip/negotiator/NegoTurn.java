package negotiator;

import java.util.ArrayList;

public class NegoTurn
{
  private int partyIndex;
  private ArrayList<Class> validActions;
  
  public NegoTurn(int partyIndex)
  {
    setPartyIndex(partyIndex);
    setValidActions(new ArrayList());
  }
  
  public NegoTurn(int partyIndex, ArrayList<Class> validNegoActions)
  {
    setPartyIndex(partyIndex);
    setValidActions(validNegoActions);
  }
  
  public NegoTurn(int partyIndex, Class validNegoAction)
  {
    setPartyIndex(partyIndex);
    setValidActions(new ArrayList());
    addValidAction(validNegoAction);
  }
  
  public int getPartyIndex()
  {
    return this.partyIndex;
  }
  
  public void setPartyIndex(int partyIndex)
  {
    this.partyIndex = partyIndex;
  }
  
  public ArrayList<Class> getValidActions()
  {
    return this.validActions;
  }
  
  public void setValidActions(ArrayList<Class> validNegoActions)
  {
    this.validActions = validNegoActions;
  }
  
  public void addValidAction(Class validNegoAction)
  {
    this.validActions.add(validNegoAction);
  }
  
  public void removeValidAction(Class validNegoAction)
  {
    this.validActions.remove(validNegoAction);
  }
  
  public void clearValidActions()
  {
    setValidActions(new ArrayList());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.NegoTurn
 * JD-Core Version:    0.7.1
 */