package negotiator;

import negotiator.utility.UTILITYSPACETYPE;

public class SupportedNegotiationSetting
{
  private static final UTILITYSPACETYPE defaultSpace = UTILITYSPACETYPE.NONLINEAR;
  private UTILITYSPACETYPE utilityspaceType = defaultSpace;
  
  public static SupportedNegotiationSetting getLinearUtilitySpaceInstance()
  {
    SupportedNegotiationSetting s = new SupportedNegotiationSetting();
    s.setUtilityspaceType(UTILITYSPACETYPE.LINEAR);
    return s;
  }
  
  public static SupportedNegotiationSetting getDefault()
  {
    return new SupportedNegotiationSetting();
  }
  
  boolean supportsOnlyLinearUtilitySpaces()
  {
    return this.utilityspaceType == UTILITYSPACETYPE.LINEAR;
  }
  
  public UTILITYSPACETYPE getUtilityspaceType()
  {
    return this.utilityspaceType;
  }
  
  public void setUtilityspaceType(UTILITYSPACETYPE utilityspaceType)
  {
    this.utilityspaceType = utilityspaceType;
  }
  
  public String toExplainingString()
  {
    if (this.utilityspaceType == UTILITYSPACETYPE.NONLINEAR) {
      return "compatible with non-linear utility spaces";
    }
    return "";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.SupportedNegotiationSetting
 * JD-Core Version:    0.7.1
 */