package negotiator;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.TimeZone;
import java.util.regex.Matcher;
import javax.swing.JOptionPane;
import negotiator.gui.NegoGUIApp;
import negotiator.gui.agentrepository.AgentRepositoryUI;
import negotiator.multipartyprotocol.MultiPartyProtocol;
import negotiator.protocol.OldProtocol;
import negotiator.repository.AgentRepItem;
import negotiator.repository.MultiPartyProtocolRepItem;
import negotiator.repository.PartyRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.ProtocolRepItem;
import negotiator.tournament.TournamentConfiguration;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;

public class Global
{
  public static final String DOMAIN_REPOSITORY = "domainrepository.xml";
  public static final String AGENT_REPOSITORY = "agentrepository.xml";
  public static final String PROTOCOL_REPOSITORY = "protocolrepository.xml";
  public static final String SIMULATOR_REPOSITORY = "simulatorrepository.xml";
  public static String logPrefix = "";
  public static String logPreset = "";
  private static final Date loadDate = Calendar.getInstance().getTime();
  public static final boolean AAMAS_2014_EXPERIMENTS = false;
  
  public static String getCurrentTime()
  {
    Calendar cal = Calendar.getInstance(TimeZone.getDefault());
    String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
    SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
    




    sdf.setTimeZone(TimeZone.getDefault());
    
    return sdf.format(cal.getTime());
  }
  
  public static String getLocalDirName()
  {
    URL myURL = NegoGUIApp.class.getResource(NegoGUIApp.getClassName());
    



    String localDirName = myURL.getPath();
    localDirName = myURL.getPath().replaceAll("%20", " ");
    



    localDirName = localDirName.substring(0, localDirName.lastIndexOf("/"));
    




    return localDirName;
  }
  
  public static String getFileNameWithoutExtension(String fileName)
  {
    File tmpFile = new File(fileName);
    tmpFile.getName();
    int whereDot = tmpFile.getName().lastIndexOf('.');
    if ((0 < whereDot) && (whereDot <= tmpFile.getName().length() - 2)) {
      return tmpFile.getName().substring(0, whereDot);
    }
    return "";
  }
  
  public static Class<OldProtocol> getProtocolClass(ProtocolRepItem protRepItem)
    throws Exception
  {
    ClassLoader loader = Global.class.getClassLoader();
    Class<OldProtocol> klass = loader.loadClass(protRepItem.getClassPath());
    
    return klass;
  }
  
  public static Class<OldProtocol> getProtocolClass(ProtocolRepItem protRepItem, ClassLoader loader)
    throws Exception
  {
    Class<OldProtocol> klass = loader.loadClass(protRepItem.getClassPath());
    
    return klass;
  }
  
  public static OldProtocol createProtocolInstance(ProtocolRepItem protRepItem, AgentRepItem[] agentRepItems, ProfileRepItem[] profileRepItems, HashMap<AgentParameterVariable, AgentParamValue>[] agentParams)
    throws Exception
  {
    ClassLoader loader = ClassLoader.getSystemClassLoader();
    
    Class klass = loader.loadClass(protRepItem.getClassPath());
    Class[] paramTypes = { AgentRepItem[].class, ProfileRepItem[].class, HashMap[].class, Integer.TYPE };
    

    Constructor cons = klass.getConstructor(paramTypes);
    
    System.out.println("Found the constructor: " + cons);
    
    Object[] args = { agentRepItems, profileRepItems, agentParams, Integer.valueOf(1) };
    
    Object theObject = cons.newInstance(args);
    
    OldProtocol ns = (OldProtocol)theObject;
    return ns;
  }
  
  public static OldProtocol createProtocolInstance(ProtocolRepItem protRepItem, AgentRepItem[] agentRepItems, ProfileRepItem[] profileRepItems, HashMap<AgentParameterVariable, AgentParamValue>[] agentParams, ClassLoader classLoader)
    throws Exception
  {
    Class klass = classLoader.loadClass(protRepItem.getClassPath());
    Class[] paramTypes = { AgentRepItem[].class, ProfileRepItem[].class, HashMap[].class };
    

    Constructor cons = klass.getConstructor(paramTypes);
    
    System.out.println("Found the constructor: " + cons);
    
    Object[] args = { agentRepItems, profileRepItems, agentParams };
    
    Object theObject = cons.newInstance(args);
    
    OldProtocol ns = (OldProtocol)theObject;
    return ns;
  }
  
  public static MultiPartyProtocol createMultiPartyProtocolInstance(MultiPartyProtocolRepItem protRepItem, ArrayList<PartyRepItem> partyRepItems, ArrayList<AgentID> partyIDList, ArrayList<ProfileRepItem> profileRepItems, ArrayList<HashMap<AgentParameterVariable, AgentParamValue>> partyParams, DeadlineType deadlineType, int totalRoundOrTime)
    throws Exception
  {
    ClassLoader loader = ClassLoader.getSystemClassLoader();
    Class klass = loader.loadClass(protRepItem.getClassPath());
    
    Class[] paramTypes = { ArrayList.class, ArrayList.class, ArrayList.class, ArrayList.class, DeadlineType.class, Integer.TYPE };
    

    Constructor cons = klass.getConstructor(paramTypes);
    


    Object[] args = { partyRepItems, partyIDList, profileRepItems, partyParams, deadlineType, Integer.valueOf(totalRoundOrTime) };
    

    Object theObject = cons.newInstance(args);
    MultiPartyProtocol ns = (MultiPartyProtocol)theObject;
    
    return ns;
  }
  
  public static Party loadParty(String partyClassName)
    throws InstantiationException, IllegalAccessException, ClassNotFoundException
  {
    ClassLoader loaderA = Global.class.getClassLoader();
    Party party = (Party)loaderA.loadClass(partyClassName).newInstance();
    return party;
  }
  
  public static Object loadObject(String path)
    throws InstantiationException, IllegalAccessException, ClassNotFoundException, MalformedURLException
  {
    if (path.endsWith(".class")) {
      return loadClassFromFile(new File(path));
    }
    ClassLoader loaderA = Global.class.getClassLoader();
    return loaderA.loadClass(path).newInstance();
  }
  
  public static Object loadClassFromFile(File file)
    throws MalformedURLException, InstantiationException, IllegalAccessException, ClassNotFoundException
  {
    String className = file.getName();
    if (!className.endsWith(".class")) {
      throw new IllegalArgumentException("file " + file + " is not a .class file");
    }
    className = className.substring(0, className.length() - 6);
    File packageDir = file.getParentFile();
    if (packageDir == null) {
      packageDir = new File(".");
    }
    try
    {
      return loadClassfile(className, packageDir);
    }
    catch (NoClassDefFoundError e)
    {
      String errormsg = e.getMessage();
      
      String wrongname = "wrong name: ";
      int i = errormsg.indexOf(wrongname);
      if (i == -1) {
        throw e;
      }
      String correctName = errormsg.substring(i + wrongname.length(), errormsg.length() - 1).replaceAll("/", ".");
      




      String expectedPath = File.separator + correctName.replaceAll("\\.", Matcher.quoteReplacement(File.separator)) + ".class";
      if (!file.getAbsolutePath().endsWith(expectedPath)) {
        throw new NoClassDefFoundError("file " + file + "\nis not in the correct directory structure, " + "\nas its class is " + correctName + "." + "\nEnsure the file is in ..." + expectedPath);
      }
      for (int up = 0; up < correctName.split("\\.").length - 1; up++) {
        packageDir = packageDir.getParentFile();
      }
      return loadClassfile(correctName, packageDir);
    }
  }
  
  private static Object loadClassfile(String classname, File packagedir)
    throws MalformedURLException, InstantiationException, IllegalAccessException, ClassNotFoundException
  {
    try
    {
      ClassLoader loader = AgentRepositoryUI.class.getClassLoader();
      
      URLClassLoader urlLoader = new URLClassLoader(new URL[] { packagedir.toURI().toURL() }, loader);
      

      Class<?> theclass = urlLoader.loadClass(classname);
      return theclass.newInstance();
    }
    catch (ClassNotFoundException e)
    {
      throw new ClassNotFoundException("agent " + classname + " is not available in directory '" + packagedir + "'", e);
    }
  }
  
  public static Agent loadAgent(String path)
    throws InstantiationException, IllegalAccessException, ClassNotFoundException, MalformedURLException, ClassCastException, IllegalArgumentException
  {
    return (Agent)loadObject(path);
  }
  
  public static Agent loadAgent(String agentClassName, String variables)
    throws InstantiationException, IllegalAccessException, ClassNotFoundException, MalformedURLException, ClassCastException, IllegalArgumentException
  {
    Agent agent = loadAgent(agentClassName);
    try
    {
      agent.parseStrategyParameters(variables);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return agent;
  }
  
  public static String getAgentDescription(Agent agent)
  {
    if (agent == null) {
      return "";
    }
    String agentDescription = agent.getName();
    if ((agentDescription == null) || ("Agent A".equals(agentDescription)) || ("Agent B".equals(agentDescription))) {
      agentDescription = agent.getClass().getSimpleName();
    }
    return agentDescription;
  }
  
  public static void showLoadError(File fc, Throwable e)
  {
    e.printStackTrace();
    if ((e instanceof ClassNotFoundException)) {
      showLoadError("No class found at " + fc, e);
    } else if ((e instanceof InstantiationException)) {
      showLoadError("Class cannot be instantiated. Reasons may be that there is no constructor without arguments, or the class is abstract or an interface.", e);
    } else if ((e instanceof IllegalAccessException)) {
      showLoadError("Missing constructor without arguments", e);
    } else if ((e instanceof NoClassDefFoundError)) {
      showLoadError("Errors in loaded class.", e);
    } else if ((e instanceof ClassCastException)) {
      showLoadError("The loaded class seems to be of the wrong type. ", e);
    } else if ((e instanceof IllegalArgumentException)) {
      showLoadError("The given file can not be used.", e);
    } else if ((e instanceof IOException)) {
      showLoadError("The file can not be read.", e);
    } else {
      showLoadError("Something went wrong loading the file", e);
    }
  }
  
  private static void showLoadError(String text, Throwable e)
  {
    String message = e.getMessage();
    if (message == null) {
      message = "";
    }
    JOptionPane.showMessageDialog(null, text + "\n" + message, "Load error", 0);
  }
  
  private static String getLoadDate()
  {
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH.mm.ss");
    

    String name = formatter.format(loadDate);
    
    return name;
  }
  
  public static String getOutcomesFileName()
  {
    if (!logPreset.equals("")) {
      return logPreset;
    }
    if (!logPrefix.equals("")) {
      return logPrefix + "log.xml";
    }
    return "log/" + getLoadDate() + getPostFix() + ".xml";
  }
  
  public static String getDistributedOutcomesFileName()
  {
    return "log/DT-" + getLoadDate() + getPostFix() + ".xml";
  }
  
  public static String getTournamentOutcomeFileName()
  {
    return "log/TM-" + getLoadDate() + getPostFix() + ".xml";
  }
  
  public static String getExtensiveOutcomesFileName()
  {
    if (!logPrefix.equals("")) {
      return logPrefix + "extensive_log.xml";
    }
    return "log/extensive " + getLoadDate() + getPostFix() + ".xml";
  }
  
  public static String getOQMOutcomesFileName()
  {
    return "log/OQM " + getLoadDate() + getPostFix() + ".csv";
  }
  
  public static String getBinaryRoot()
  {
    String root = null;
    try
    {
      root = new File(".").getCanonicalPath() + File.separator;
      if (!isJar()) {
        root = root + "bin" + File.separator;
      }
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    return root;
  }
  
  public static boolean isJar()
  {
    boolean inJar = false;
    try
    {
      CodeSource cs = Global.class.getProtectionDomain().getCodeSource();
      inJar = cs.getLocation().toURI().getPath().endsWith(".jar");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return inJar;
  }
  
  private static String getPostFix()
  {
    String postFix = "";
    if (TournamentConfiguration.getBooleanOption("appendModeAndDeadline", false))
    {
      String mode = "time";
      if (TournamentConfiguration.getBooleanOption("protocolMode", false)) {
        mode = "rounds";
      }
      postFix = postFix + "_" + mode + "_" + TournamentConfiguration.getIntegerOption("deadline", 180);
    }
    return postFix;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Global
 * JD-Core Version:    0.7.1
 */