package negotiator.analysis;

import java.util.Arrays;
import negotiator.Bid;

public class BidPoint
{
  private Bid bid;
  private Double[] utility;
  private static final String[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
  
  public BidPoint(Bid bid, Double... utility)
  {
    this.bid = bid;
    this.utility = ((Double[])utility.clone());
  }
  
  public String toString()
  {
    String result = "BidPoint [" + this.bid;
    for (int i = 0; i < this.utility.length; i++) {
      result = result + "util" + alphabet[i] + "[" + this.utility[i] + "],";
    }
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    BidPoint other = (BidPoint)obj;
    if (this.bid == null)
    {
      if (other.bid != null) {
        return false;
      }
    }
    else if (!this.bid.equals(other.bid)) {
      return false;
    }
    if (this.utility.length != other.utility.length) {
      return false;
    }
    for (int i = 0; i < this.utility.length; i++) {
      if (!this.utility[i].equals(other.utility[i])) {
        return false;
      }
    }
    return true;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (this.bid == null ? 0 : this.bid.hashCode());
    result = 31 * result + Arrays.hashCode(this.utility);
    return result;
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public Double getUtility(int index)
  {
    return this.utility[index];
  }
  
  public Double getUtilityA()
  {
    return this.utility[0];
  }
  
  public Double getUtilityB()
  {
    return this.utility[1];
  }
  
  public boolean isStrictlyDominatedBy(BidPoint other)
  {
    if (this == other) {
      return false;
    }
    boolean atleastOneBetter = false;
    for (int i = 0; i < this.utility.length; i++) {
      if (other.utility[i].doubleValue() >= this.utility[i].doubleValue())
      {
        if (other.utility[i].doubleValue() > this.utility[i].doubleValue()) {
          atleastOneBetter = true;
        }
      }
      else {
        return false;
      }
    }
    return atleastOneBetter;
  }
  
  public double getDistance(BidPoint other)
  {
    double sum = 0.0D;
    for (int i = 0; i < this.utility.length; i++) {
      sum += Math.pow(this.utility[i].doubleValue() - other.utility[i].doubleValue(), 2.0D);
    }
    return Math.sqrt(sum);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.BidPoint
 * JD-Core Version:    0.7.1
 */