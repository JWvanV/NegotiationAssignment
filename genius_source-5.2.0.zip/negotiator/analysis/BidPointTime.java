package negotiator.analysis;

import negotiator.Bid;

public class BidPointTime
  extends BidPoint
{
  private double time;
  
  public BidPointTime(Bid bid, Double utilityA, Double utilityB, double time)
  {
    super(bid, new Double[] { utilityA, utilityB });
    this.time = time;
  }
  
  public String toString()
  {
    return "BidPointTime [" + getBid() + " utilA[" + getUtilityA() + "],utilB[" + getUtilityB() + "], Time[" + this.time + "]]";
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = super.hashCode();
    
    long temp = Double.doubleToLongBits(this.time);
    result = 31 * result + (int)(temp ^ temp >>> 32);
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (!super.equals(obj)) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    BidPointTime other = (BidPointTime)obj;
    if (Double.doubleToLongBits(this.time) != Double.doubleToLongBits(other.time)) {
      return false;
    }
    return true;
  }
  
  public double getTime()
  {
    return this.time;
  }
  
  public void setTime(double time)
  {
    this.time = time;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.BidPointTime
 * JD-Core Version:    0.7.1
 */