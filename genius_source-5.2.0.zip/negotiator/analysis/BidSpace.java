package negotiator.analysis;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.exceptions.AnalysisException;
import negotiator.utility.UtilitySpace;

public class BidSpace
{
  private UtilitySpace[] utilspaces;
  private Domain domain;
  public ArrayList<BidPoint> bidPoints;
  List<BidPoint> paretoFrontier = null;
  BidPoint kalaiSmorodinsky = null;
  BidPoint nash = null;
  
  public BidSpace(UtilitySpace... utilityspaces)
    throws Exception
  {
    initializeUtilitySpaces(utilityspaces);
    buildSpace(true);
  }
  
  public BidSpace(UtilitySpace utilityspaceA, UtilitySpace utilityspaceB, boolean excludeBids)
    throws Exception
  {
    UtilitySpace[] spaces = { utilityspaceA, utilityspaceB };
    initializeUtilitySpaces(spaces);
    buildSpace(excludeBids);
  }
  
  public BidSpace(UtilitySpace utilityspaceA, UtilitySpace utilityspaceB, boolean excludeBids, boolean skipCheckSpaceB)
    throws Exception
  {
    if ((utilityspaceA == null) || (utilityspaceB == null)) {
      throw new NullPointerException("util space is null");
    }
    UtilitySpace[] spaces = { utilityspaceA, utilityspaceB };
    this.utilspaces = ((UtilitySpace[])spaces.clone());
    this.domain = this.utilspaces[0].getDomain();
    utilityspaceA.checkReadyForNegotiation(this.domain);
    buildSpace(excludeBids);
  }
  
  private void initializeUtilitySpaces(UtilitySpace[] utilityspaces)
    throws Exception
  {
    this.utilspaces = ((UtilitySpace[])utilityspaces.clone());
    for (UtilitySpace utilitySpace : utilityspaces) {
      if (utilitySpace == null) {
        throw new NullPointerException("util space is null: " + utilityspaces);
      }
    }
    this.domain = this.utilspaces[0].getDomain();
    for (UtilitySpace space : utilityspaces) {
      space.checkReadyForNegotiation(this.domain);
    }
  }
  
  private boolean checkParetoFileExist(String filePathStr)
  {
    File f = new File(filePathStr);
    if (f.exists()) {
      return true;
    }
    return false;
  }
  
  private void readParetoFromFile(String fileName, boolean isAgentAHasProfile1)
  {
    this.paretoFrontier = new ArrayList();
    this.bidPoints = new ArrayList();
    try
    {
      FileReader input = new FileReader(fileName);
      BufferedReader bufRead = new BufferedReader(input);
      
      Double[] utility = new Double[2];
      String line;
      do
      {
        line = bufRead.readLine();
        if (line != null)
        {
          int index = line.indexOf(",");
          if (index > 0)
          {
            if (isAgentAHasProfile1)
            {
              utility[0] = Double.valueOf(Double.parseDouble(line.substring(0, line.indexOf(","))));
              
              utility[1] = Double.valueOf(Double.parseDouble(line.substring(line.indexOf(",") + 1)));
            }
            else
            {
              utility[1] = Double.valueOf(Double.parseDouble(line.substring(0, line.indexOf(","))));
              
              utility[0] = Double.valueOf(Double.parseDouble(line.substring(line.indexOf(",") + 1)));
            }
            BidPoint bidpt = new BidPoint(null, utility);
            this.paretoFrontier.add(bidpt);
          }
        }
      } while (line != null);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    System.out.println(this.paretoFrontier);
  }
  
  private void buildSpace(boolean excludeBids)
    throws Exception
  {
    String fname = this.utilspaces[0].getFileName();
    if (fname == null) {
      fname = "";
    }
    if (fname.contains("profile-1.xml"))
    {
      String fileName = fname.replaceAll("profile-1.xml", "pareto.xml");
      if (checkParetoFileExist(fileName))
      {
        readParetoFromFile(fileName, true);
        return;
      }
    }
    else if (fname.contains("profile-2.xml"))
    {
      String fileName = fname.replaceAll("profile-2.xml", "pareto.xml");
      if (checkParetoFileExist(fileName))
      {
        readParetoFromFile(fileName, false);
        return;
      }
    }
    this.bidPoints = new ArrayList();
    BidIterator lBidIter = new BidIterator(this.domain);
    while (lBidIter.hasNext())
    {
      Bid bid = lBidIter.next();
      Double[] utils = new Double[this.utilspaces.length];
      for (int i = 0; i < this.utilspaces.length; i++) {
        utils[i] = Double.valueOf(this.utilspaces[i].getUtility(bid));
      }
      if (excludeBids) {
        this.bidPoints.add(new BidPoint(null, utils));
      } else {
        this.bidPoints.add(new BidPoint(bid, utils));
      }
    }
  }
  
  public List<BidPoint> getParetoFrontier()
    throws Exception
  {
    boolean isBidSpaceAvailable = !this.bidPoints.isEmpty();
    if (this.paretoFrontier == null)
    {
      if (isBidSpaceAvailable)
      {
        this.paretoFrontier = computeParetoFrontier(this.bidPoints).getFrontier();
        return this.paretoFrontier;
      }
      ArrayList<BidPoint> subPareto = new ArrayList();
      BidIterator lBidIter = new BidIterator(this.domain);
      ArrayList<BidPoint> tmpBidPoints = new ArrayList();
      boolean isSplitted = false;
      int count = 0;
      while (lBidIter.hasNext())
      {
        Bid bid = lBidIter.next();
        Double[] utils = new Double[this.utilspaces.length];
        for (int i = 0; i < this.utilspaces.length; i++) {
          utils[i] = Double.valueOf(this.utilspaces[i].getUtility(bid));
        }
        tmpBidPoints.add(new BidPoint(bid, utils));
        count++;
        if (count > 500000)
        {
          subPareto.addAll(computeParetoFrontier(tmpBidPoints).getFrontier());
          
          tmpBidPoints = new ArrayList();
          count = 0;
          isSplitted = true;
        }
      }
      if (tmpBidPoints.size() > 0) {
        subPareto.addAll(computeParetoFrontier(tmpBidPoints).getFrontier());
      }
      if (isSplitted) {
        this.paretoFrontier = computeParetoFrontier(subPareto).getFrontier();
      } else {
        this.paretoFrontier = subPareto;
      }
    }
    return this.paretoFrontier;
  }
  
  private ParetoFrontier computeParetoFrontier(List<BidPoint> points)
    throws Exception
  {
    ParetoFrontier frontier = new ParetoFrontier();
    for (BidPoint p : points) {
      frontier.mergeIntoFrontier(p);
    }
    frontier.sort();
    return frontier;
  }
  
  public List<Bid> getParetoFrontierBids()
    throws Exception
  {
    ArrayList<Bid> bids = new ArrayList();
    List<BidPoint> points = getParetoFrontier();
    for (BidPoint p : points) {
      bids.add(p.getBid());
    }
    return bids;
  }
  
  public BidPoint getKalaiSmorodinsky()
    throws Exception
  {
    if (this.kalaiSmorodinsky != null) {
      return this.kalaiSmorodinsky;
    }
    if (getParetoFrontier().size() < 1) {
      throw new AnalysisException("kalaiSmorodinsky product: Pareto frontier is unavailable.");
    }
    double asymmetry = 2.0D;
    for (BidPoint p : this.paretoFrontier)
    {
      double asymofp = 0.0D;
      for (int i = 0; i < this.utilspaces.length; i++) {
        for (int j = i + 1; j < this.utilspaces.length; j++) {
          asymofp += Math.abs(p.getUtility(i).doubleValue() - p.getUtility(j).doubleValue());
        }
      }
      if (asymofp < asymmetry)
      {
        this.kalaiSmorodinsky = p;
        asymmetry = asymofp;
      }
    }
    return this.kalaiSmorodinsky;
  }
  
  public BidPoint getNash()
    throws Exception
  {
    if (this.nash != null) {
      return this.nash;
    }
    if (getParetoFrontier().size() < 1) {
      throw new AnalysisException("Nash product: Pareto frontier is unavailable.");
    }
    double maxp = -1.0D;
    double[] agentResValue = new double[this.utilspaces.length];
    for (int i = 0; i < this.utilspaces.length; i++) {
      if (this.utilspaces[i].getReservationValue() != null) {
        agentResValue[i] = this.utilspaces[i].getReservationValue().doubleValue();
      } else {
        agentResValue[i] = 0.0D;
      }
    }
    for (BidPoint p : this.paretoFrontier)
    {
      double utilofp = 1.0D;
      for (int i = 0; i < this.utilspaces.length; i++) {
        utilofp *= (p.getUtility(i).doubleValue() - agentResValue[i]);
      }
      if (utilofp > maxp)
      {
        this.nash = p;
        maxp = utilofp;
      }
    }
    return this.nash;
  }
  
  public double ourUtilityOnPareto(double opponentUtility)
    throws Exception
  {
    if ((opponentUtility < 0.0D) || (opponentUtility > 1.0D)) {
      throw new Exception("opponentUtil " + opponentUtility + " is out of [0,1].");
    }
    List<BidPoint> pareto = getParetoFrontier();
    if (((BidPoint)pareto.get(0)).getUtility(1).doubleValue() < 1.0D) {
      pareto.add(0, new BidPoint(null, new Double[] { Double.valueOf(0.0D), Double.valueOf(1.0D) }));
    }
    if (((BidPoint)pareto.get(pareto.size() - 1)).getUtility(1).doubleValue() > 0.0D) {
      pareto.add(new BidPoint(null, new Double[] { Double.valueOf(1.0D), Double.valueOf(0.0D) }));
    }
    if (pareto.size() < 2) {
      throw new Exception("Pareto has only 1 point?!" + pareto);
    }
    int i = 0;
    while ((((BidPoint)pareto.get(i)).getUtility(1).doubleValue() < opponentUtility) || (opponentUtility <= ((BidPoint)pareto.get(i + 1)).getUtility(1).doubleValue())) {
      i++;
    }
    double oppUtil1 = ((BidPoint)pareto.get(i)).getUtility(1).doubleValue();
    double oppUtil2 = ((BidPoint)pareto.get(i + 1)).getUtility(1).doubleValue();
    double f = (opponentUtility - oppUtil1) / (oppUtil2 - oppUtil1);
    







    double lininterpol = (1.0D - f) * ((BidPoint)pareto.get(i)).getUtility(0).doubleValue() + f * ((BidPoint)pareto.get(i + 1)).getUtility(0).doubleValue();
    
    return lininterpol;
  }
  
  public String toString()
  {
    return this.bidPoints.toString();
  }
  
  public BidPoint getNearestBidPoint(double utilA, double utilB, double weightA, double weightB, ArrayList<Bid> excludeList)
  {
    System.out.println("determining nearest bid to " + utilA + "," + utilB);
    System.out.println("excludes=" + excludeList);
    double mindist = 9.0D;
    BidPoint bestPoint = null;
    for (BidPoint p : this.bidPoints)
    {
      boolean contains = false;
      for (Bid b : excludeList) {
        if (b.equals(p.getBid()))
        {
          contains = true;
          break;
        }
      }
      if (!contains)
      {
        double r = weightA * Math.pow(p.getUtility(0).doubleValue() - utilA, 2.0D) + weightB * Math.pow(p.getUtility(1).doubleValue() - utilB, 2.0D);
        if (r < mindist)
        {
          mindist = r;
          bestPoint = p;
        }
      }
    }
    System.out.println("point found=" + bestPoint.getBid());
    if (excludeList.size() > 1) {
      System.out.println("bid equals exclude(1):" + bestPoint.getBid().equals((Bid)excludeList.get(1)));
    }
    return bestPoint;
  }
  
  public double distanceToNearestParetoBid(BidPoint bid)
  {
    if (this.paretoFrontier == null) {
      try
      {
        this.paretoFrontier = getParetoFrontier();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    double distance = Double.POSITIVE_INFINITY;
    for (BidPoint paretoBid : this.paretoFrontier)
    {
      double paretoDistance = bid.getDistance(paretoBid);
      if (paretoDistance < distance) {
        distance = paretoDistance;
      }
    }
    return distance;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.BidSpace
 * JD-Core Version:    0.7.1
 */