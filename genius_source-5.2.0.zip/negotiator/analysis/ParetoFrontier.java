package negotiator.analysis;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ParetoFrontier
{
  private List<BidPoint> frontier;
  
  public ParetoFrontier()
  {
    this.frontier = new ArrayList();
  }
  
  public void mergeIntoFrontier(BidPoint bidpoint)
  {
    for (BidPoint f : this.frontier)
    {
      if (bidpoint.isStrictlyDominatedBy(f)) {
        return;
      }
      if (f.isStrictlyDominatedBy(bidpoint))
      {
        merge(bidpoint, f);
        return;
      }
    }
    this.frontier.add(bidpoint);
  }
  
  private void merge(BidPoint newParetoBid, BidPoint dominatedParetoBid)
  {
    this.frontier.remove(dominatedParetoBid);
    
    ArrayList<BidPoint> toBeRemoved = new ArrayList();
    for (BidPoint f : this.frontier) {
      if (f.isStrictlyDominatedBy(newParetoBid)) {
        toBeRemoved.add(f);
      }
    }
    this.frontier.removeAll(toBeRemoved);
    this.frontier.add(newParetoBid);
  }
  
  public boolean isBelowFrontier(BidPoint bid)
  {
    for (BidPoint f : getFrontier()) {
      if (bid.isStrictlyDominatedBy(f)) {
        return true;
      }
    }
    return false;
  }
  
  public void sort()
  {
    Collections.sort(this.frontier, new Comparator()
    {
      public int compare(BidPoint x, BidPoint y)
      {
        if (x.getUtilityA().doubleValue() < y.getUtilityA().doubleValue()) {
          return -1;
        }
        if (x.getUtilityA().doubleValue() > y.getUtilityA().doubleValue()) {
          return 1;
        }
        return 0;
      }
    });
  }
  
  public List<BidPoint> getFrontier()
  {
    return this.frontier;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.ParetoFrontier
 * JD-Core Version:    0.7.1
 */