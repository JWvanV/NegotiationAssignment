package negotiator.analysis;

import java.io.PrintStream;
import java.util.ArrayList;
import misc.Range;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.qualitymeasures.ScenarioInfo;
import negotiator.utility.UtilitySpace;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class ParetoTest
{
  static class DomainParser
    extends DefaultHandler
  {
    ScenarioInfo domain = null;
    ArrayList<ScenarioInfo> domains = new ArrayList();
    
    public void startElement(String nsURI, String strippedName, String tagName, Attributes attributes)
      throws SAXException
    {
      if ((tagName.equals("domainRepItem")) && (attributes.getLength() > 0)) {
        this.domain = new ScenarioInfo(attributes.getValue("url").substring(5));
      } else if (tagName.equals("profile")) {
        if (this.domain.getPrefProfA() == null) {
          this.domain.setPrefProfA(attributes.getValue("url").substring(5));
        } else if (this.domain.getPrefProfB() == null) {
          this.domain.setPrefProfB(attributes.getValue("url").substring(5));
        } else {
          System.out.println("WARNING: Violation of two preference profiles per domain assumption for " + strippedName);
        }
      }
    }
    
    public void endElement(String nsURI, String strippedName, String tagName)
      throws SAXException
    {
      if ((tagName.equals("domainRepItem")) && (this.domain != null))
      {
        this.domains.add(this.domain);
        this.domain = null;
      }
    }
    
    public ArrayList<ScenarioInfo> getDomains()
    {
      return this.domains;
    }
  }
  
  public static void main(String[] args)
    throws Exception
  {
    String dir = "c:/Users/Mark/workspace/Genius/";
    
    process(dir);
  }
  
  public static void process(String dir)
    throws Exception
  {
    ArrayList<ScenarioInfo> domains = parseDomainFile(dir);
    for (ScenarioInfo domainSt : domains)
    {
      Domain domain = new Domain(dir + domainSt.getDomain());
      
      UtilitySpace utilitySpaceA = new UtilitySpace(domain, dir + domainSt.getPrefProfA());
      UtilitySpace utilitySpaceB = new UtilitySpace(domain, dir + domainSt.getPrefProfB());
      

      ArrayList<BidPoint> realParetoBids = bruteforceParetoBids(domain, utilitySpaceA, utilitySpaceB);
      BidSpace space = new BidSpace(new UtilitySpace[] { utilitySpaceA, utilitySpaceB });
      ArrayList<BidPoint> estimatedParetoBids = new ArrayList(space.getParetoFrontier());
      if (checkValidity(estimatedParetoBids, realParetoBids))
      {
        System.out.println("No problems in: " + domain.getName());
      }
      else
      {
        System.out.println("Found difference in: " + domain.getName());
        System.out.println("REAL " + realParetoBids.size());
        for (int i = 0; i < realParetoBids.size(); i++) {
          System.out.println(((BidPoint)realParetoBids.get(i)).getBid() + " " + ((BidPoint)realParetoBids.get(i)).getUtilityA() + " " + ((BidPoint)realParetoBids.get(i)).getUtilityB());
        }
        System.out.println("ESTIMATE " + estimatedParetoBids.size());
        for (int i = 0; i < estimatedParetoBids.size(); i++) {
          System.out.println(((BidPoint)estimatedParetoBids.get(i)).getUtilityA() + " " + ((BidPoint)estimatedParetoBids.get(i)).getUtilityB());
        }
      }
    }
    System.out.println("Finished processing domains");
  }
  
  private static boolean checkValidity(ArrayList<BidPoint> estimatedParetoBids, ArrayList<BidPoint> realParetoBids)
  {
    if (realParetoBids.size() != estimatedParetoBids.size()) {
      return false;
    }
    for (BidPoint paretoBid : realParetoBids)
    {
      boolean found = false;
      for (int a = 0; a < estimatedParetoBids.size(); a++) {
        if ((((BidPoint)estimatedParetoBids.get(a)).getUtilityA().equals(paretoBid.getUtilityA())) && 
          (((BidPoint)estimatedParetoBids.get(a)).getUtilityB().equals(paretoBid.getUtilityB())))
        {
          found = true;
          break;
        }
      }
      if (!found) {
        return false;
      }
    }
    return true;
  }
  
  private static ArrayList<ScenarioInfo> parseDomainFile(String dir)
    throws Exception
  {
    XMLReader xr = XMLReaderFactory.createXMLReader();
    DomainParser handler = new DomainParser();
    xr.setContentHandler(handler);
    xr.setErrorHandler(handler);
    xr.parse(dir + "domainrepository.xml");
    
    return handler.getDomains();
  }
  
  private static ArrayList<BidPoint> bruteforceParetoBids(Domain domain, UtilitySpace spaceA, UtilitySpace spaceB)
  {
    SortedOutcomeSpace outcomeSpaceA = new SortedOutcomeSpace(spaceA);
    ArrayList<BidPoint> paretoBids = new ArrayList();
    try
    {
      for (BidDetails bid : outcomeSpaceA.getAllOutcomes())
      {
        double utilA = spaceA.getUtility(bid.getBid());
        double utilB = spaceB.getUtility(bid.getBid());
        boolean found = false;
        for (BidDetails otherBid : outcomeSpaceA.getBidsinRange(new Range(utilA - 0.01D, 1.1D))) {
          if (((otherBid != bid) && (spaceA.getUtility(otherBid.getBid()) > utilA) && 
            (spaceB.getUtility(otherBid.getBid()) >= utilB)) || ((otherBid != bid) && 
            (spaceA.getUtility(otherBid.getBid()) >= utilA) && 
            (spaceB.getUtility(otherBid.getBid()) > utilB)))
          {
            found = true;
            break;
          }
        }
        if (!found) {
          paretoBids.add(new BidPoint(bid.getBid(), new Double[] { Double.valueOf(bid.getMyUndiscountedUtil()), Double.valueOf(spaceB.getUtility(bid.getBid())) }));
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return paretoBids;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.ParetoTest
 * JD-Core Version:    0.7.1
 */