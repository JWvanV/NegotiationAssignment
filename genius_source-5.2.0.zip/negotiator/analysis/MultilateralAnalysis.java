package negotiator.analysis;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.exceptions.AnalysisException;
import negotiator.parties.NegotiationParty;
import negotiator.protocol.MediatorProtocol;
import negotiator.protocol.Protocol;
import negotiator.session.Session;
import negotiator.utility.UtilitySpace;

public class MultilateralAnalysis
{
  public static final int ENUMERATION_CUTOFF = 100000;
  private ArrayList<BidPoint> bidPoints;
  private List<BidPoint> paretoFrontier = null;
  private BidPoint nash = null;
  private BidPoint agreement = null;
  private final Session session;
  private final List<NegotiationParty> parties;
  private final Protocol protocol;
  private Timeline timeline;
  private UtilitySpace[] utilitySpaces;
  private Domain domain;
  
  public MultilateralAnalysis(Session session, List<NegotiationParty> parties, Protocol protocol)
    throws Exception
  {
    System.out.println("Generating analysis");
    
    this.session = session;
    this.parties = parties;
    this.protocol = protocol;
    this.timeline = session.getTimeline();
    initializeUtilitySpaces(getUtilitySpaces(parties));
    buildSpace(true);
    
    Bid finalBid = protocol.getCurrentAgreement(session, parties);
    Double[] utils = new Double[this.utilitySpaces.length];
    if (finalBid == null) {
      for (int i = 0; i < this.utilitySpaces.length; i++) {
        utils[i] = Double.valueOf(0.0D);
      }
    } else {
      for (int i = 0; i < this.utilitySpaces.length; i++) {
        utils[i] = Double.valueOf(this.timeline == null ? this.utilitySpaces[i].getUtility(finalBid) : this.utilitySpaces[i].getUtilityWithDiscount(finalBid, this.timeline));
      }
    }
    this.agreement = new BidPoint(finalBid, utils);
    
    System.out.println("Analysis done, now returning results.");
  }
  
  public static ArrayList<double[][]> getPartyBidSeries(ArrayList<ArrayList<Double[]>> partyUtilityHistoryList)
  {
    ArrayList<double[][]> bidSeries = new ArrayList();
    double[][] product = new double[2][((ArrayList)partyUtilityHistoryList.get(0)).size()];
    try
    {
      for (int i = 0; i < partyUtilityHistoryList.size() - 1; i++)
      {
        double[][] xPartyUtilities = new double[2][((ArrayList)partyUtilityHistoryList.get(i)).size()];
        int index = 0;
        for (Double[] utilityHistory : (ArrayList)partyUtilityHistoryList.get(i))
        {
          xPartyUtilities[0][index] = utilityHistory[0].doubleValue();
          xPartyUtilities[1][index] = utilityHistory[1].doubleValue();
          
          product[0][index] = utilityHistory[0].doubleValue();
          if (i == 0) {
            product[1][index] = utilityHistory[1].doubleValue();
          } else {
            product[1][index] *= utilityHistory[1].doubleValue();
          }
          index++;
        }
        bidSeries.add(xPartyUtilities);
      }
      bidSeries.add(product);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      return null;
    }
    return bidSeries;
  }
  
  public UtilitySpace[] getUtilitySpaces(List<NegotiationParty> parties)
  {
    List<NegotiationParty> agents = MediatorProtocol.getNonMediators(parties);
    UtilitySpace[] spaces = new UtilitySpace[agents.size()];
    for (int i = 0; i < agents.size(); i++) {
      spaces[i] = ((NegotiationParty)agents.get(i)).getUtilitySpace();
    }
    return spaces;
  }
  
  private void buildSpace(boolean excludeBids)
    throws Exception
  {
    this.bidPoints = new ArrayList();
    BidIterator lBidIterator = new BidIterator(this.domain);
    



    int iterationNumber = 0;
    while (lBidIterator.hasNext())
    {
      iterationNumber++;
      if (iterationNumber > 100000)
      {
        System.out.printf("Could not enumerate complete bid space, enumerated first %d bids\n", new Object[] { Integer.valueOf(100000) });
        
        break;
      }
      Bid bid = lBidIterator.next();
      Double[] utils = new Double[this.utilitySpaces.length];
      for (int i = 0; i < this.utilitySpaces.length; i++) {
        utils[i] = Double.valueOf(this.timeline == null ? this.utilitySpaces[i].getUtility(bid) : this.utilitySpaces[i].getUtilityWithDiscount(bid, this.timeline));
      }
      if (excludeBids) {
        this.bidPoints.add(new BidPoint(null, utils));
      } else {
        this.bidPoints.add(new BidPoint(bid, utils));
      }
    }
  }
  
  public List<BidPoint> getParetoFrontier()
    throws Exception
  {
    boolean isBidSpaceAvailable = !this.bidPoints.isEmpty();
    if (this.paretoFrontier == null)
    {
      if (isBidSpaceAvailable)
      {
        this.paretoFrontier = computeParetoFrontier(this.bidPoints).getFrontier();
        return this.paretoFrontier;
      }
      ArrayList<BidPoint> subPareto = new ArrayList();
      BidIterator lBidIterator = new BidIterator(this.domain);
      ArrayList<BidPoint> tmpBidPoints = new ArrayList();
      boolean isSplit = false;
      int count = 0;
      while ((lBidIterator.hasNext()) && (count < 100000))
      {
        Bid bid = lBidIterator.next();
        Double[] utils = new Double[this.utilitySpaces.length];
        for (int i = 0; i < this.utilitySpaces.length; i++) {
          utils[i] = Double.valueOf(this.timeline == null ? this.utilitySpaces[i].getUtility(bid) : this.utilitySpaces[i].getUtilityWithDiscount(bid, this.timeline));
        }
        tmpBidPoints.add(new BidPoint(bid, utils));
        count++;
        if (count > 500000)
        {
          subPareto.addAll(computeParetoFrontier(tmpBidPoints).getFrontier());
          
          tmpBidPoints = new ArrayList();
          count = 0;
          isSplit = true;
        }
      }
      if (tmpBidPoints.size() > 0) {
        subPareto.addAll(computeParetoFrontier(tmpBidPoints).getFrontier());
      }
      if (isSplit) {
        this.paretoFrontier = computeParetoFrontier(subPareto).getFrontier();
      } else {
        this.paretoFrontier = subPareto;
      }
    }
    return this.paretoFrontier;
  }
  
  private ParetoFrontier computeParetoFrontier(List<BidPoint> points)
  {
    ParetoFrontier frontier = new ParetoFrontier();
    for (BidPoint p : points) {
      frontier.mergeIntoFrontier(p);
    }
    frontier.sort();
    return frontier;
  }
  
  public List<Bid> getParetoFrontierBids()
    throws Exception
  {
    ArrayList<Bid> bids = new ArrayList();
    List<BidPoint> points = getParetoFrontier();
    for (BidPoint p : points) {
      bids.add(p.getBid());
    }
    return bids;
  }
  
  private void initializeUtilitySpaces(UtilitySpace[] utilitySpaces)
    throws Exception
  {
    this.utilitySpaces = ((UtilitySpace[])utilitySpaces.clone());
    for (UtilitySpace utilitySpace : utilitySpaces) {
      if (utilitySpace == null) {
        throw new NullPointerException("util space is null");
      }
    }
    this.domain = this.utilitySpaces[0].getDomain();
    for (UtilitySpace space : utilitySpaces) {
      space.checkReadyForNegotiation(this.domain);
    }
  }
  
  public double getSocialWelfare()
  {
    double totalUtility = 0.0D;
    List<NegotiationParty> agents = MediatorProtocol.getNonMediators(this.parties);
    for (NegotiationParty agent : agents) {
      totalUtility += agent.getUtilityWithDiscount(this.protocol.getCurrentAgreement(this.session, this.parties));
    }
    return totalUtility;
  }
  
  public double getDistanceToNash()
    throws Exception
  {
    return this.agreement.getDistance(getNashPoint());
  }
  
  public double getDistanceToPareto()
  {
    if (this.paretoFrontier == null) {
      try
      {
        this.paretoFrontier = getParetoFrontier();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    double distance = Double.POSITIVE_INFINITY;
    for (BidPoint paretoBid : this.paretoFrontier)
    {
      double paretoDistance = this.agreement.getDistance(paretoBid);
      if (paretoDistance < distance) {
        distance = paretoDistance;
      }
    }
    return distance;
  }
  
  public BidPoint getNashPoint()
    throws Exception
  {
    if (this.nash != null) {
      return this.nash;
    }
    if (getParetoFrontier().size() < 1) {
      throw new AnalysisException("Nash product: Pareto frontier is unavailable.");
    }
    double maxP = -1.0D;
    double[] agentResValue = new double[this.utilitySpaces.length];
    for (int i = 0; i < this.utilitySpaces.length; i++) {
      if (this.utilitySpaces[i].getReservationValue() != null) {
        agentResValue[i] = this.utilitySpaces[i].getReservationValue().doubleValue();
      } else {
        agentResValue[i] = 0.0D;
      }
    }
    for (BidPoint p : this.paretoFrontier)
    {
      double utilOfP = 1.0D;
      for (int i = 0; i < this.utilitySpaces.length; i++) {
        utilOfP *= (p.getUtility(i).doubleValue() - agentResValue[i]);
      }
      if (utilOfP > maxP)
      {
        this.nash = p;
        maxP = utilOfP;
      }
    }
    return this.nash;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.MultilateralAnalysis
 * JD-Core Version:    0.7.1
 */