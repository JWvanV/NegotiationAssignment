package negotiator.analysis;

import java.util.Comparator;

public class BidPointSorterA
  implements Comparator<BidPoint>
{
  public int compare(BidPoint b1, BidPoint b2)
  {
    if ((b1 == null) || (b2 == null)) {
      throw new NullPointerException();
    }
    if (b1.getUtilityA().equals(b2.getUtilityA())) {
      return 0;
    }
    if (b1.getUtilityA().doubleValue() < b2.getUtilityA().doubleValue()) {
      return -1;
    }
    if (b1.getUtilityA().doubleValue() > b2.getUtilityA().doubleValue()) {
      return 1;
    }
    return Integer.valueOf(b1.hashCode()).compareTo(Integer.valueOf(b2.hashCode()));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.BidPointSorterA
 * JD-Core Version:    0.7.1
 */