package negotiator.analysis;

import java.util.Arrays;
import negotiator.utility.UtilitySpace;

public class BidSpaceCache
{
  private static String[] identifier;
  private static BidSpace cachedBidSpace;
  
  public static BidSpace getBidSpace(UtilitySpace... spaces)
  {
    String[] ident = new String[spaces.length];
    for (int i = 0; i < spaces.length; i++) {
      ident[i] = spaces[i].getFileName();
    }
    if (!Arrays.equals(ident, identifier)) {
      try
      {
        cachedBidSpace = new BidSpace(spaces);
        identifier = ident;
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return cachedBidSpace;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.analysis.BidSpaceCache
 * JD-Core Version:    0.7.1
 */