package negotiator;

import javax.swing.JTextArea;
import javax.swing.text.Document;

public class Logger
{
  private JTextArea output;
  
  public Logger(JTextArea output)
  {
    this.output = output;
  }
  
  public synchronized void add(String text)
  {
    if (text != null)
    {
      this.output.append("\n" + text);
      this.output.setCaretPosition(this.output.getDocument().getLength());
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Logger
 * JD-Core Version:    0.7.1
 */