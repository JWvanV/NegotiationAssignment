package negotiator;

import java.util.HashMap;

public class StrategyParameters
{
  protected HashMap<String, String> strategyParam;
  
  public StrategyParameters()
  {
    this.strategyParam = new HashMap();
  }
  
  public void addVariable(String name, String value)
  {
    this.strategyParam.put(name, value);
  }
  
  public String getValueAsString(String name)
  {
    return (String)this.strategyParam.get(name);
  }
  
  public double getValueAsDouble(String name)
  {
    return Double.parseDouble((String)this.strategyParam.get(name));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.StrategyParameters
 * JD-Core Version:    0.7.1
 */