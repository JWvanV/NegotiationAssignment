package negotiator.boaframework.agent;

import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.acceptanceconditions.other.AC_Next;
import negotiator.boaframework.offeringstrategy.other.TimeDependent_Offering;
import negotiator.boaframework.omstrategy.NullStrategy;
import negotiator.boaframework.opponentmodel.ScalableBayesianModel;

public class SimpleBOAagent
  extends BOAagent
{
  public void agentSetup()
  {
    OpponentModel om = new ScalableBayesianModel();
    om.init(this.negotiationSession);
    OMStrategy oms = new NullStrategy(this.negotiationSession);
    OfferingStrategy offering = new TimeDependent_Offering(this.negotiationSession, om, oms, 0.2D, 0.0D, 1.0D, 0.0D);
    AcceptanceStrategy ac = new AC_Next(this.negotiationSession, offering, 1.0D, 0.0D);
    setDecoupledComponents(ac, offering, om, oms);
  }
  
  public String getName()
  {
    return "SimpleBOAagent";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.agent.SimpleBOAagent
 * JD-Core Version:    0.7.1
 */