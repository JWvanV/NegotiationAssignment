package negotiator.boaframework.agent;

import misc.Serializer;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.BOAagentInfo;
import negotiator.boaframework.BOAcomponent;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.repository.BOAagentRepository;

public class TheBOAagent
  extends BOAagent
{
  private String name = "";
  private BOAagentInfo dagent;
  
  public void agentSetup()
  {
    String os = this.dagent.getOfferingStrategy().getClassname();
    String as = this.dagent.getAcceptanceStrategy().getClassname();
    String om = this.dagent.getOpponentModel().getClassname();
    String oms = this.dagent.getOMStrategy().getClassname();
    


    this.offeringStrategy = BOAagentRepository.getInstance().getOfferingStrategy(os);
    this.acceptConditions = BOAagentRepository.getInstance().getAcceptanceStrategy(as);
    this.opponentModel = BOAagentRepository.getInstance().getOpponentModel(om);
    this.omStrategy = BOAagentRepository.getInstance().getOMStrategy(oms);
    try
    {
      this.opponentModel.init(this.negotiationSession, this.dagent.getOpponentModel().getParameters());
      this.opponentModel.setOpponentUtilitySpace(this.fNegotiation);
      this.omStrategy.init(this.negotiationSession, this.opponentModel, this.dagent.getOMStrategy().getParameters());
      this.offeringStrategy.init(this.negotiationSession, this.opponentModel, this.omStrategy, this.dagent.getOfferingStrategy().getParameters());
      this.acceptConditions.init(this.negotiationSession, this.offeringStrategy, this.opponentModel, this.dagent.getAcceptanceStrategy().getParameters());
      this.acceptConditions.setOpponentUtilitySpace(this.fNegotiation);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.dagent = null;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void cleanUp()
  {
    this.offeringStrategy = null;
    this.acceptConditions = null;
    this.opponentModel = null;
    this.negotiationSession = null;
    this.utilitySpace = null;
    this.dagent = null;
  }
  
  public void parseStrategyParameters(String variables)
    throws Exception
  {
    Serializer<BOAagentInfo> serializer = new Serializer("");
    this.dagent = ((BOAagentInfo)serializer.readStringToObject(variables));
    this.name = this.dagent.getName();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.agent.TheBOAagent
 * JD-Core Version:    0.7.1
 */