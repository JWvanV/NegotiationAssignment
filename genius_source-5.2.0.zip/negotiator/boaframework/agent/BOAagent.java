package negotiator.boaframework.agent;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import misc.Pair;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.NegotiationResult;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.OutcomeSpace;
import negotiator.boaframework.SessionData;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.utility.UtilitySpace;

public abstract class BOAagent
  extends Agent
{
  protected AcceptanceStrategy acceptConditions;
  protected OfferingStrategy offeringStrategy;
  protected OpponentModel opponentModel;
  protected NegotiationSession negotiationSession;
  protected OMStrategy omStrategy;
  public ArrayList<Pair<Bid, String>> savedOutcomes;
  protected OutcomeSpace outcomeSpace;
  
  public void init()
  {
    super.init();
    Serializable storedData = loadSessionData();
    SessionData sessionData;
    SessionData sessionData;
    if (storedData == null) {
      sessionData = new SessionData();
    } else {
      sessionData = (SessionData)storedData;
    }
    this.negotiationSession = new NegotiationSession(sessionData, this.utilitySpace, this.timeline);
    
    agentSetup();
  }
  
  public abstract void agentSetup();
  
  public void setDecoupledComponents(AcceptanceStrategy ac, OfferingStrategy os, OpponentModel om, OMStrategy oms)
  {
    this.acceptConditions = ac;
    this.offeringStrategy = os;
    this.opponentModel = om;
    this.omStrategy = oms;
  }
  
  protected String getUniqueIdentifier()
  {
    return getName().hashCode() + "";
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public abstract String getName();
  
  public void ReceiveMessage(Action opponentAction)
  {
    if ((opponentAction instanceof Offer))
    {
      Bid bid = ((Offer)opponentAction).getBid();
      try
      {
        BidDetails opponentBid = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
        this.negotiationSession.getOpponentBidHistory().add(opponentBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      if ((this.opponentModel != null) && (!(this.opponentModel instanceof NoModel))) {
        if (this.omStrategy.canUpdateOM()) {
          this.opponentModel.updateModel(bid);
        } else if (!this.opponentModel.isCleared()) {
          this.opponentModel.cleanUp();
        }
      }
    }
  }
  
  public Action chooseAction()
  {
    BidDetails bid;
    BidDetails bid;
    if (this.negotiationSession.getOwnBidHistory().getHistory().isEmpty())
    {
      bid = this.offeringStrategy.determineOpeningBid();
    }
    else
    {
      bid = this.offeringStrategy.determineNextBid();
      if (this.offeringStrategy.isEndNegotiation()) {
        return new EndNegotiation();
      }
    }
    if (bid == null)
    {
      System.out.println("Error in code, null bid was given");
      return new Accept();
    }
    this.offeringStrategy.setNextBid(bid);
    


    Actions decision = Actions.Reject;
    if (!this.negotiationSession.getOpponentBidHistory().getHistory().isEmpty()) {
      decision = this.acceptConditions.determineAcceptability();
    }
    if (decision.equals(Actions.Break))
    {
      System.out.println("send EndNegotiation");
      return new EndNegotiation();
    }
    if (decision.equals(Actions.Reject))
    {
      this.negotiationSession.getOwnBidHistory().add(bid);
      return new Offer(bid.getBid());
    }
    return new Accept();
  }
  
  public OfferingStrategy getOfferingStrategy()
  {
    return this.offeringStrategy;
  }
  
  public OpponentModel getOpponentModel()
  {
    return this.opponentModel;
  }
  
  public AcceptanceStrategy getAcceptanceStrategy()
  {
    return this.acceptConditions;
  }
  
  public void endSession(NegotiationResult result)
  {
    this.offeringStrategy.endSession(result);
    this.acceptConditions.endSession(result);
    this.opponentModel.endSession(result);
    SessionData savedData = this.negotiationSession.getSessionData();
    if ((!savedData.isEmpty()) && (savedData.isChanged()))
    {
      savedData.changesCommitted();
      saveSessionData(savedData);
    }
  }
  
  public void cleanUp()
  {
    this.offeringStrategy = null;
    this.acceptConditions = null;
    this.omStrategy = null;
    this.opponentModel = null;
    this.outcomeSpace = null;
    this.negotiationSession = null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.agent.BOAagent
 * JD-Core Version:    0.7.1
 */