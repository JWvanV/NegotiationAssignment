package negotiator.boaframework;

import Jama.Matrix;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import misc.Pair;
import negotiator.utility.UtilitySpace;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
import uk.ac.soton.ecs.gp4j.bmc.BasicPrior;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessMixture;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessMixturePrediction;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessRegressionBMC;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.CovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.Matern3CovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.NoiseCovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.SumCovarianceFunction;

public class IAMhaggler_Concession
{
  protected double RISK_PARAMETER = 1.0D;
  private double maxOfferedUtility = Double.MIN_NORMAL;
  private double minOfferedUtility = Double.MAX_VALUE;
  private int lastTimeSlot = -1;
  private ArrayList<Double> opponentTimes = new ArrayList();
  private ArrayList<Double> opponentUtilities = new ArrayList();
  private double intercept;
  private double maxUtilityInTimeSlot;
  private Matrix timeSamples;
  private Matrix matrixTimeSamplesAdjust;
  private Matrix means;
  private Matrix variances;
  private GaussianProcessRegressionBMC regression;
  private double lastRegressionTime = 0.0D;
  private double lastRegressionUtility = 1.0D;
  private Matrix utility;
  private Matrix utilitySamples;
  
  public IAMhaggler_Concession(UtilitySpace utilitySpace)
  {
    double discountingFactor = 0.5D;
    try
    {
      discountingFactor = utilitySpace.getDiscountFactor();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    if (discountingFactor == 0.0D) {
      discountingFactor = 1.0D;
    }
    makeUtilitySamples(100);
    makeTimeSamples(25);
    Matrix discounting = generateDiscountingFunction(discountingFactor);
    Matrix risk = generateRiskFunction(this.RISK_PARAMETER);
    this.utility = risk.arrayTimes(discounting);
    BasicPrior[] bps = { new BasicPrior(11, 0.252D, 0.5D), new BasicPrior(11, 0.166D, 0.5D), new BasicPrior(1, 0.01D, 1.0D) };
    
    CovarianceFunction cf = new SumCovarianceFunction(new CovarianceFunction[] { Matern3CovarianceFunction.getInstance(), NoiseCovarianceFunction.getInstance() });
    


    this.regression = new GaussianProcessRegressionBMC();
    this.regression.setCovarianceFunction(cf);
    this.regression.setPriors(bps);
  }
  
  public double getTarget(double opponentUtility, double time)
  {
    this.maxOfferedUtility = Math.max(this.maxOfferedUtility, opponentUtility);
    this.minOfferedUtility = Math.min(this.minOfferedUtility, opponentUtility);
    

    int timeSlot = (int)Math.floor(time * 36.0D);
    
    boolean regressionUpdateRequired = false;
    if (this.lastTimeSlot == -1) {
      regressionUpdateRequired = true;
    }
    if (timeSlot != this.lastTimeSlot)
    {
      if (this.lastTimeSlot != -1)
      {
        this.opponentTimes.add(Double.valueOf((this.lastTimeSlot + 0.5D) / 36.0D));
        if (this.opponentUtilities.size() == 0)
        {
          this.intercept = Math.max(0.5D, this.maxUtilityInTimeSlot);
          double[] timeSamplesAdjust = new double[this.timeSamples.getColumnDimension()];
          int i = 0;
          double gradient = 0.9D - this.intercept;
          for (double d : this.timeSamples.getRowPackedCopy()) {
            timeSamplesAdjust[(i++)] = (this.intercept + gradient * d);
          }
          this.matrixTimeSamplesAdjust = new Matrix(timeSamplesAdjust, timeSamplesAdjust.length);
        }
        this.opponentUtilities.add(Double.valueOf(this.maxUtilityInTimeSlot));
        
        regressionUpdateRequired = true;
      }
      this.lastTimeSlot = timeSlot;
      
      this.maxUtilityInTimeSlot = 0.0D;
    }
    this.maxUtilityInTimeSlot = Math.max(this.maxUtilityInTimeSlot, opponentUtility);
    if (timeSlot == 0) {
      return 1.0D - time / 2.0D;
    }
    if (regressionUpdateRequired)
    {
      double gradient = 0.9D - this.intercept;
      GaussianProcessMixture predictor;
      GaussianProcessMixture predictor;
      if (this.lastTimeSlot == -1)
      {
        predictor = this.regression.calculateRegression(new double[0], new double[0]);
      }
      else
      {
        double x;
        double y;
        try
        {
          x = ((Double)this.opponentTimes.get(this.opponentTimes.size() - 1)).doubleValue();
          y = ((Double)this.opponentUtilities.get(this.opponentUtilities.size() - 1)).doubleValue();
        }
        catch (Exception ex)
        {
          System.out.println("Error getting x or y");
          throw new Error(ex);
        }
        predictor = this.regression.updateRegression(new Matrix(new double[] { x }, 1), new Matrix(new double[] { y - this.intercept - gradient * x }, 1));
      }
      GaussianProcessMixturePrediction prediction = predictor.calculatePrediction(this.timeSamples.transpose());
      


      this.means = prediction.getMean().plus(this.matrixTimeSamplesAdjust);
      
      this.variances = prediction.getVariance();
      
      StringWriter variancesWriter = new StringWriter();
      PrintWriter variancesPrintWriter = new PrintWriter(variancesWriter);
      this.variances.print(variancesPrintWriter, 10, 4);
      System.out.println("variances: " + variancesWriter.getBuffer().toString());
      

      StringWriter meanWriter = new StringWriter();
      PrintWriter meanPrintWriter = new PrintWriter(meanWriter);
      this.means.print(meanPrintWriter, 10, 4);
      System.out.println("means: " + meanWriter.getBuffer().toString());
    }
    Pair<Matrix, Matrix> acceptMatrices = generateProbabilityAccept(this.means, this.variances, time);
    
    Matrix probabilityAccept = (Matrix)acceptMatrices.getFirst();
    Matrix cumulativeAccept = (Matrix)acceptMatrices.getSecond();
    
    Matrix probabilityExpectedUtility = probabilityAccept.arrayTimes(this.utility);
    Matrix cumulativeExpectedUtility = cumulativeAccept.arrayTimes(this.utility);
    
    Pair<Double, Double> bestAgreement = getExpectedBestAgreement(probabilityExpectedUtility, cumulativeExpectedUtility, time);
    
    double bestTime = ((Double)bestAgreement.getFirst()).doubleValue();
    double bestUtility = ((Double)bestAgreement.getSecond()).doubleValue();
    
    double targetUtility = this.lastRegressionUtility + (time - this.lastRegressionTime) * (bestUtility - this.lastRegressionUtility) / (bestTime - this.lastRegressionTime);
    




    this.lastRegressionUtility = targetUtility;
    this.lastRegressionTime = time;
    

    return limitConcession(targetUtility);
  }
  
  private double limitConcession(double targetUtility)
  {
    double limit = 1.0D - (this.maxOfferedUtility - this.minOfferedUtility + 0.1D);
    if (limit > targetUtility) {
      return limit;
    }
    return targetUtility;
  }
  
  private Pair<Matrix, Matrix> generateProbabilityAccept(Matrix mean, Matrix variance, double time)
  {
    for (int i = 0; i < this.timeSamples.getColumnDimension(); i++) {
      if (this.timeSamples.get(0, i) > time) {
        break;
      }
    }
    Matrix cumulativeAccept = new Matrix(this.utilitySamples.getRowDimension(), this.timeSamples.getColumnDimension(), 0.0D);
    
    Matrix probabilityAccept = new Matrix(this.utilitySamples.getRowDimension(), this.timeSamples.getColumnDimension(), 0.0D);
    

    double interval = 1.0D / this.utilitySamples.getRowDimension();
    for (; i < this.timeSamples.getColumnDimension(); i++)
    {
      double s = Math.sqrt(2.0D * variance.get(i, 0));
      double m = mean.get(i, 0);
      
      double minp = 1.0D - 0.5D * (1.0D + erf((this.utilitySamples.get(0, 0) + interval / 2.0D - m) / s));
      
      double maxp = 1.0D - 0.5D * (1.0D + erf((this.utilitySamples.get(this.utilitySamples.getRowDimension() - 1, 0) - interval / 2.0D - m) / s));
      for (int j = 0; j < this.utilitySamples.getRowDimension(); j++)
      {
        double utility = this.utilitySamples.get(j, 0);
        double p = 1.0D - 0.5D * (1.0D + erf((utility - m) / s));
        
        double p1 = 1.0D - 0.5D * (1.0D + erf((utility - interval / 2.0D - m) / s));
        
        double p2 = 1.0D - 0.5D * (1.0D + erf((utility + interval / 2.0D - m) / s));
        

        cumulativeAccept.set(j, i, (p - minp) / (maxp - minp));
        probabilityAccept.set(j, i, (p1 - p2) / (maxp - minp));
      }
    }
    return new Pair(probabilityAccept, cumulativeAccept);
  }
  
  private Pair<Double, Double> getExpectedBestAgreement(Matrix probabilityExpectedValues, Matrix cumulativeExpectedValues, double time)
  {
    Matrix probabilityFutureExpectedValues = getFutureExpectedValues(probabilityExpectedValues, time);
    Matrix cumulativeFutureExpectedValues = getFutureExpectedValues(cumulativeExpectedValues, time);
    
    double[][] probabilityFutureExpectedValuesArray = probabilityFutureExpectedValues.getArray();
    double[][] cumulativeFutureExpectedValuesArray = cumulativeFutureExpectedValues.getArray();
    
    Double bestX = null;
    Double bestY = null;
    
    double[] colSums = new double[probabilityFutureExpectedValuesArray[0].length];
    double bestColSum = 0.0D;
    int bestCol = 0;
    for (int x = 0; x < probabilityFutureExpectedValuesArray[0].length; x++)
    {
      colSums[x] = 0.0D;
      for (int y = 0; y < probabilityFutureExpectedValuesArray.length; y++) {
        colSums[x] += probabilityFutureExpectedValuesArray[y][x];
      }
      if (colSums[x] >= bestColSum)
      {
        bestColSum = colSums[x];
        bestCol = x;
      }
    }
    int bestRow = 0;
    double bestRowValue = 0.0D;
    for (int y = 0; y < cumulativeFutureExpectedValuesArray.length; y++)
    {
      double expectedValue = cumulativeFutureExpectedValuesArray[y][bestCol];
      if (expectedValue > bestRowValue)
      {
        bestRowValue = expectedValue;
        bestRow = y;
      }
    }
    bestX = Double.valueOf(this.timeSamples.get(0, bestCol + probabilityExpectedValues.getColumnDimension() - probabilityFutureExpectedValues.getColumnDimension()));
    

    bestY = Double.valueOf(this.utilitySamples.get(bestRow, 0));
    
    return new Pair(bestX, bestY);
  }
  
  private double erf(double x)
  {
    if (x > 6.0D) {
      return 1.0D;
    }
    if (x < -6.0D) {
      return -1.0D;
    }
    try
    {
      double d = Erf.erf(x);
      if (d > 1.0D) {
        return 1.0D;
      }
      if (d < -1.0D) {
        return -1.0D;
      }
      return d;
    }
    catch (MaxIterationsExceededException e)
    {
      if (x > 0.0D) {
        return 1.0D;
      }
      return -1.0D;
    }
    catch (MathException e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  private Matrix getFutureExpectedValues(Matrix expectedValues, double time)
  {
    for (int i = 0; i < this.timeSamples.getColumnDimension(); i++) {
      if (this.timeSamples.get(0, i) > time) {
        break;
      }
    }
    return expectedValues.getMatrix(0, expectedValues.getRowDimension() - 1, i, expectedValues.getColumnDimension() - 1);
  }
  
  private void makeUtilitySamples(int m)
  {
    double[] utilitySamplesArray = new double[m];
    for (int i = 0; i < utilitySamplesArray.length; i++) {
      utilitySamplesArray[i] = (1.0D - (i + 0.5D) / (m + 1.0D));
    }
    this.utilitySamples = new Matrix(utilitySamplesArray, utilitySamplesArray.length);
  }
  
  private void makeTimeSamples(int n)
  {
    double[] timeSamplesArray = new double[n + 1];
    for (int i = 0; i < timeSamplesArray.length; i++) {
      timeSamplesArray[i] = (i / n);
    }
    this.timeSamples = new Matrix(timeSamplesArray, 1);
  }
  
  private Matrix generateDiscountingFunction(double discountingFactor)
  {
    double[] discountingSamples = this.timeSamples.getRowPackedCopy();
    double[][] m = new double[this.utilitySamples.getRowDimension()][this.timeSamples.getColumnDimension()];
    for (int i = 0; i < m.length; i++) {
      for (int j = 0; j < m[i].length; j++) {
        m[i][j] = Math.pow(discountingFactor, discountingSamples[j]);
      }
    }
    return new Matrix(m);
  }
  
  protected Matrix generateRiskFunction(double riskParameter)
  {
    double mmin = generateRiskFunction(riskParameter, 0.0D);
    double mmax = generateRiskFunction(riskParameter, 1.0D);
    double range = mmax - mmin;
    
    double[] riskSamples = this.utilitySamples.getColumnPackedCopy();
    double[][] m = new double[this.utilitySamples.getRowDimension()][this.timeSamples.getColumnDimension()];
    for (int i = 0; i < m.length; i++)
    {
      double val;
      double val;
      if (range == 0.0D) {
        val = riskSamples[i];
      } else {
        val = (generateRiskFunction(riskParameter, riskSamples[i]) - mmin) / range;
      }
      for (int j = 0; j < m[i].length; j++) {
        m[i][j] = val;
      }
    }
    return new Matrix(m);
  }
  
  protected double generateRiskFunction(double riskParameter, double utility)
  {
    return Math.pow(utility, riskParameter);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.IAMhaggler_Concession
 * JD-Core Version:    0.7.1
 */