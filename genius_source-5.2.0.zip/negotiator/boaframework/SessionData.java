package negotiator.boaframework;

import java.io.Serializable;

public class SessionData
  implements Serializable
{
  private static final long serialVersionUID = -2269008062554989046L;
  private Serializable biddingStrategyData;
  private Serializable opponentModelData;
  private Serializable acceptanceStrategyData;
  private boolean changed;
  
  public SessionData()
  {
    this.biddingStrategyData = null;
    this.opponentModelData = null;
    this.acceptanceStrategyData = null;
    this.changed = false;
  }
  
  public Serializable getData(ComponentsEnum type)
  {
    Serializable result = null;
    if (type == ComponentsEnum.BIDDINGSTRATEGY) {
      result = this.biddingStrategyData;
    } else if (type == ComponentsEnum.OPPONENTMODEL) {
      result = this.opponentModelData;
    } else if (type == ComponentsEnum.ACCEPTANCESTRATEGY) {
      result = this.acceptanceStrategyData;
    }
    return result;
  }
  
  public void setData(ComponentsEnum component, Serializable data)
  {
    if (component == ComponentsEnum.BIDDINGSTRATEGY) {
      this.biddingStrategyData = data;
    } else if (component == ComponentsEnum.OPPONENTMODEL) {
      this.opponentModelData = data;
    } else if (component == ComponentsEnum.ACCEPTANCESTRATEGY) {
      this.acceptanceStrategyData = data;
    }
    this.changed = true;
  }
  
  public boolean isEmpty()
  {
    return (this.biddingStrategyData == null) && (this.opponentModelData == null) && (this.acceptanceStrategyData == null);
  }
  
  public boolean isChanged()
  {
    return this.changed;
  }
  
  public void changesCommitted()
  {
    this.changed = false;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.SessionData
 * JD-Core Version:    0.7.1
 */