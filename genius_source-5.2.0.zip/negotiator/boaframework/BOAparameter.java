package negotiator.boaframework;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.HashSet;
import misc.Pair;

public class BOAparameter
  implements Serializable
{
  private static final long serialVersionUID = 2555736049221913613L;
  private String name;
  private BigDecimal low;
  private BigDecimal high;
  private BigDecimal step;
  private HashSet<Pair<String, BigDecimal>> valuePairs;
  private String description;
  
  public BOAparameter(String name, BigDecimal low, BigDecimal high, BigDecimal step)
  {
    this.name = name;
    this.low = low;
    this.high = high;
    this.step = step;
    this.description = "";
    generatePairs();
  }
  
  public BOAparameter(String name, BigDecimal defaultValue, String description)
  {
    this.name = name;
    this.description = description;
    this.low = defaultValue;
    this.high = defaultValue;
    this.step = BigDecimal.ONE;
    generatePairs();
  }
  
  public BOAparameter(String name, BigDecimal low, BigDecimal high, BigDecimal step, String description)
  {
    this.name = name;
    this.low = low;
    this.high = high;
    this.step = step;
    this.description = description;
    generatePairs();
  }
  
  private void generatePairs()
  {
    this.valuePairs = new HashSet();
    for (BigDecimal value = this.low; value.compareTo(this.high) <= 0; value = value.add(this.step)) {
      this.valuePairs.add(new Pair(this.name, value));
    }
  }
  
  public HashSet<Pair<String, BigDecimal>> getValuePairs()
  {
    return this.valuePairs;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public BigDecimal getLow()
  {
    return this.low;
  }
  
  public BigDecimal getHigh()
  {
    return this.high;
  }
  
  public BigDecimal getStep()
  {
    return this.step;
  }
  
  public String toString()
  {
    if (!this.name.equals("null"))
    {
      if (this.low.compareTo(this.high) == 0) {
        return this.name + ": " + this.low.doubleValue();
      }
      return this.name + ": [" + this.low + " : " + this.step + " : " + this.high + "]";
    }
    return "";
  }
  
  public String getDescription()
  {
    return this.description;
  }
  
  public String toXML()
  {
    return "<parameter name=\"" + this.name + "\" default=\"" + this.high + "\" description=\"" + this.description + "\"/>";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.BOAparameter
 * JD-Core Version:    0.7.1
 */