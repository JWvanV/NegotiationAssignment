package negotiator.boaframework;

import java.io.Serializable;
import java.util.HashMap;
import negotiator.protocol.BilateralAtomicNegotiationSession;

public abstract class AcceptanceStrategy
  extends BOA
{
  protected OfferingStrategy offeringStrategy;
  protected SharedAgentState helper;
  protected OpponentModel opponentModel;
  
  public void init(NegotiationSession negotiationSession, OfferingStrategy offeringStrategy, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negotiationSession);
    this.offeringStrategy = offeringStrategy;
    this.opponentModel = opponentModel;
  }
  
  public String printParameters()
  {
    return "";
  }
  
  public void setOpponentUtilitySpace(BilateralAtomicNegotiationSession fNegotiation) {}
  
  public abstract Actions determineAcceptability();
  
  public final void storeData(Serializable object)
  {
    this.negotiationSession.setData(ComponentsEnum.ACCEPTANCESTRATEGY, object);
  }
  
  public final Serializable loadData()
  {
    return this.negotiationSession.getData(ComponentsEnum.ACCEPTANCESTRATEGY);
  }
  
  public boolean isMAC()
  {
    return false;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.AcceptanceStrategy
 * JD-Core Version:    0.7.1
 */