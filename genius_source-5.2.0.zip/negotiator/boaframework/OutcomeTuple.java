package negotiator.boaframework;

import negotiator.Bid;

public class OutcomeTuple
{
  private Bid lastBid;
  private String name;
  private double time;
  private int agentASize;
  private int agentBSize;
  private String logMsgType;
  private String acceptedBy;
  
  public OutcomeTuple(Bid lastBid, String name, double time, int agentASize, int agentBSize, String logMsg, String acceptedBy)
  {
    this.lastBid = lastBid;
    this.name = name;
    this.time = time;
    this.agentASize = agentASize;
    this.agentBSize = agentBSize;
    this.logMsgType = logMsg;
    this.acceptedBy = acceptedBy;
  }
  
  public String getAcceptedBy()
  {
    return this.acceptedBy;
  }
  
  public void setAcceptedBy(String acceptedBy)
  {
    this.acceptedBy = acceptedBy;
  }
  
  public int getAgentASize()
  {
    return this.agentASize;
  }
  
  public void setAgentASize(int agentASize)
  {
    this.agentASize = agentASize;
  }
  
  public int getAgentBSize()
  {
    return this.agentBSize;
  }
  
  public void setAgentBSize(int agentBSize)
  {
    this.agentBSize = agentBSize;
  }
  
  public Bid getLastBid()
  {
    return this.lastBid;
  }
  
  public void setLastBid(Bid lastBid)
  {
    this.lastBid = lastBid;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public double getTime()
  {
    return this.time;
  }
  
  public void setTime(double time)
  {
    this.time = time;
  }
  
  public String getLogMsgType()
  {
    return this.logMsgType;
  }
  
  public String toString()
  {
    return "LastBid: " + this.lastBid + ", Name of AC: " + this.name + ", Time of agreement: " + this.time + " agentASize: " + this.agentASize + " agentBSize: " + this.agentBSize;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.OutcomeTuple
 * JD-Core Version:    0.7.1
 */