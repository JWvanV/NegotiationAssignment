package negotiator.boaframework.offeringstrategy.anac2011.hardheaded;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public class BidSelector
{
  private UtilitySpace utilitySpace;
  private TreeMap<Double, Bid> BidList;
  
  public BidSelector(UtilitySpace pUtilitySpace)
  {
    this.utilitySpace = pUtilitySpace;
    this.BidList = new TreeMap();
    

    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    
    HashMap<Integer, Value> InitialBid = new HashMap();
    for (Issue lIssue : issues)
    {
      Value v = ((IssueDiscrete)lIssue).getValue(0);
      InitialBid.put(Integer.valueOf(lIssue.getNumber()), v);
    }
    try
    {
      Bid b = new Bid(this.utilitySpace.getDomain(), InitialBid);
      this.BidList.put(Double.valueOf(this.utilitySpace.getUtility(b)), b);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    for (Iterator i$ = issues.iterator(); i$.hasNext();)
    {
      lIssue = (Issue)i$.next();
      

      TempBids = new TreeMap();
      
      IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
      optionIndex = lIssueDiscrete.getNumberOfValues();
      


      d = -1.0E-008D;
      for (Bid TBid : this.BidList.values())
      {
        for (int i = 0; i < optionIndex; i++)
        {
          HashMap<Integer, Value> NewBidV = Bidconfig(TBid);
          NewBidV.put(Integer.valueOf(lIssue.getNumber()), ((IssueDiscrete)lIssue).getValue(i));
          try
          {
            Bid webid = new Bid(this.utilitySpace.getDomain(), NewBidV);
            TempBids.put(Double.valueOf(this.utilitySpace.getUtility(webid) + d), webid);
            d -= 1.0E-008D;
          }
          catch (Exception e) {}
        }
        this.BidList = TempBids;
      }
    }
    Issue lIssue;
    TreeMap<Double, Bid> TempBids;
    int optionIndex;
    double d;
  }
  
  private HashMap<Integer, Value> Bidconfig(Bid pBid)
  {
    HashMap<Integer, Value> lNewBidValues = new HashMap();
    for (Issue lIssue : this.utilitySpace.getDomain().getIssues()) {
      try
      {
        lNewBidValues.put(Integer.valueOf(lIssue.getNumber()), pBid.getValue(lIssue.getNumber()));
      }
      catch (Exception e) {}
    }
    return lNewBidValues;
  }
  
  public UtilitySpace getUtilitySpace()
  {
    return this.utilitySpace;
  }
  
  public void setUtilitySpace(UtilitySpace utilitySpace)
  {
    this.utilitySpace = utilitySpace;
  }
  
  public TreeMap<Double, Bid> getBidList()
  {
    return this.BidList;
  }
  
  public void setBidList(TreeMap<Double, Bid> bidList)
  {
    this.BidList = bidList;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.hardheaded.BidSelector
 * JD-Core Version:    0.7.1
 */