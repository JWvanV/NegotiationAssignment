package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.offeringstrategy.anac2011.hardheaded.BidSelector;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.HardHeadedFrequencyModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2011.HardHeadedSAS;
import negotiator.utility.UtilitySpace;

public class HardHeaded_Offering
  extends OfferingStrategy
{
  private double Ka = 0.05D;
  private double e = 0.05D;
  private double maxUtil = 1.0D;
  private double MINIMUM_BID_UTILITY = 0.585D;
  private double minUtil = this.MINIMUM_BID_UTILITY;
  private LinkedList<Map.Entry<Double, Bid>> offerQueue;
  private final double UTILITY_TOLORANCE = 0.01D;
  private final int TOP_SELECTED_BIDS = 4;
  private double discountF = 1.0D;
  int round = 0;
  private BidSelector BSelector;
  private Bid opponentbestbid = null;
  private Map.Entry<Double, Bid> opponentbestentry;
  private boolean firstRound = true;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  private Random random200;
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel))
    {
      model = new HardHeadedFrequencyModel();
      model.init(negotiationSession, null);
      oms.setOpponentModel(model);
    }
    initializeAgent(negotiationSession, model, oms);
  }
  
  public void initializeAgent(NegotiationSession negoSession, OpponentModel model, OMStrategy oms)
  {
    this.negotiationSession = negoSession;
    this.BSelector = new BidSelector(this.negotiationSession.getUtilitySpace());
    this.offerQueue = new LinkedList();
    this.opponentModel = model;
    this.omStrategy = oms;
    this.helper = new HardHeadedSAS(negoSession);
    Map.Entry<Double, Bid> highestBid = this.BSelector.getBidList().lastEntry();
    try
    {
      this.maxUtil = this.negotiationSession.getUtilitySpace().getUtility((Bid)highestBid.getValue());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if ((negoSession.getDiscountFactor() <= 1.0D) && (negoSession.getDiscountFactor() > 0.0D)) {
      this.discountF = negoSession.getDiscountFactor();
    }
    this.random100 = new Random();
    this.random200 = new Random();
  }
  
  public BidDetails determineNextBid()
  {
    this.round += 1;
    
    double p = get_p();
    
    Map.Entry<Double, Bid> potentialNextBid = null;
    if (!this.negotiationSession.getOpponentBidHistory().getHistory().isEmpty())
    {
      Bid opponentLastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid();
      try
      {
        if (this.opponentbestbid == null) {
          this.opponentbestbid = opponentLastBid;
        } else if (this.negotiationSession.getUtilitySpace().getUtility(opponentLastBid) > this.negotiationSession.getUtilitySpace().getUtility(this.opponentbestbid)) {
          this.opponentbestbid = opponentLastBid;
        }
        double opbestvalue = ((Double)this.BSelector.getBidList().floorEntry(Double.valueOf(this.negotiationSession.getUtilitySpace().getUtility(this.opponentbestbid))).getKey()).doubleValue();
        while (!((Bid)this.BSelector.getBidList().floorEntry(Double.valueOf(opbestvalue)).getValue()).equals(this.opponentbestbid)) {
          opbestvalue = ((Double)this.BSelector.getBidList().lowerEntry(Double.valueOf(opbestvalue)).getKey()).doubleValue();
        }
        this.opponentbestentry = this.BSelector.getBidList().floorEntry(Double.valueOf(opbestvalue));
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
    if (this.firstRound)
    {
      this.firstRound = (!this.firstRound);
      potentialNextBid = this.BSelector.getBidList().lastEntry();
      this.offerQueue.add(potentialNextBid);
    }
    else if ((this.offerQueue == null) || (this.offerQueue.isEmpty()))
    {
      TreeMap<Double, Bid> newBids = new TreeMap();
      
      potentialNextBid = this.BSelector.getBidList().lowerEntry(Double.valueOf(this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil()));
      newBids.put(potentialNextBid.getKey(), potentialNextBid.getValue());
      if (((Double)potentialNextBid.getKey()).doubleValue() < p)
      {
        int indexer = this.negotiationSession.getOwnBidHistory().size();
        indexer = (int)Math.floor(indexer * this.random100.nextDouble());
        newBids.remove(potentialNextBid.getKey());
        BidDetails selected = (BidDetails)this.negotiationSession.getOwnBidHistory().getHistory().get(indexer);
        newBids.put(Double.valueOf(selected.getMyUndiscountedUtil()), selected.getBid());
      }
      double firstUtil = ((Double)potentialNextBid.getKey()).doubleValue();
      Map.Entry<Double, Bid> addBid = this.BSelector.getBidList().lowerEntry(Double.valueOf(firstUtil));
      double addUtil = ((Double)addBid.getKey()).doubleValue();
      while ((firstUtil - addUtil < 0.01D) && (addUtil >= p))
      {
        newBids.put(Double.valueOf(addUtil), addBid.getValue());
        addBid = this.BSelector.getBidList().lowerEntry(Double.valueOf(addUtil));
        addUtil = ((Double)addBid.getKey()).doubleValue();
      }
      if (newBids.size() <= 4)
      {
        this.offerQueue.addAll(newBids.entrySet());
      }
      else
      {
        int addedSofar = 0;
        Map.Entry<Double, Bid> bestBid = null;
        while (addedSofar <= 4)
        {
          bestBid = newBids.lastEntry();
          if (!(this.opponentModel instanceof NoModel))
          {
            ArrayList<BidDetails> bids = new ArrayList();
            for (Map.Entry<Double, Bid> entry : newBids.entrySet()) {
              bids.add(new BidDetails((Bid)entry.getValue(), ((Double)entry.getKey()).doubleValue(), -1.0D));
            }
            BidDetails selectedBid = this.omStrategy.getBid(bids);
            try
            {
              bestBid = new MyEntry(Double.valueOf(this.negotiationSession.getUtilitySpace().getUtility(selectedBid.getBid())), selectedBid.getBid());
            }
            catch (Exception e)
            {
              e.printStackTrace();
            }
          }
          this.offerQueue.add(bestBid);
          
          newBids.remove(bestBid.getKey());
          addedSofar++;
        }
      }
      if (((Double)((Map.Entry)this.offerQueue.getFirst()).getKey()).doubleValue() < ((Double)this.opponentbestentry.getKey()).doubleValue()) {
        this.offerQueue.addFirst(this.opponentbestentry);
      }
    }
    if ((this.offerQueue.isEmpty()) || (this.offerQueue == null))
    {
      Bid bestBid1 = this.negotiationSession.getUtilitySpace().getDomain().getRandomBid(this.random200);
      BidDetails opponentLastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
      try
      {
        if ((opponentLastBid != null) && 
          (this.negotiationSession.getUtilitySpace().getUtility(bestBid1) <= this.negotiationSession.getUtilitySpace().getUtility(opponentLastBid.getBid()))) {
          return null;
        }
        BidDetails offer = new BidDetails(bestBid1, this.negotiationSession.getUtilitySpace().getUtility(bestBid1), this.negotiationSession.getTime());
        if (offer.getMyUndiscountedUtil() < ((HardHeadedSAS)this.helper).getLowestYetUtility()) {
          ((HardHeadedSAS)this.helper).setLowestYetUtility(offer.getMyUndiscountedUtil());
        }
        this.nextBid = offer;
        return offer;
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else
    {
      Map.Entry<Double, Bid> toOffer = (Map.Entry)this.offerQueue.remove();
      

      BidDetails offer = new BidDetails((Bid)toOffer.getValue(), ((Double)toOffer.getKey()).doubleValue(), this.negotiationSession.getTime());
      if (offer.getMyUndiscountedUtil() < ((HardHeadedSAS)this.helper).getLowestYetUtility()) {
        try
        {
          ((HardHeadedSAS)this.helper).setLowestYetUtility(this.negotiationSession.getUtilitySpace().getUtility(offer.getBid()));
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
      try
      {
        this.nextBid = offer;
        return this.nextBid;
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return null;
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
  
  public double get_p()
  {
    double time = this.negotiationSession.getTime();
    
    double p = 1.0D;
    double step_point = this.discountF;
    double tempMax = this.maxUtil;
    double tempMin = this.minUtil;
    double tempE = this.e;
    double ignoreDiscountThreshold = 0.9D;
    if (step_point >= ignoreDiscountThreshold)
    {
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow(time / step_point, 1.0D / this.e);
      p = this.minUtil + (1.0D - Fa) * (this.maxUtil - this.minUtil);
    }
    else if (time <= step_point)
    {
      tempE = this.e / step_point;
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow(time / step_point, 1.0D / tempE);
      tempMin += Math.abs(tempMax - tempMin) * step_point;
      p = tempMin + (1.0D - Fa) * (tempMax - tempMin);
    }
    else
    {
      tempE = 30.0D;
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow((time - step_point) / (1.0D - step_point), 1.0D / tempE);
      tempMax = tempMin + Math.abs(tempMax - tempMin) * step_point;
      p = tempMin + (1.0D - Fa) * (tempMax - tempMin);
    }
    return p;
  }
  
  private class MyEntry<K, V>
    implements Map.Entry<K, V>
  {
    private final K key;
    private V value;
    
    public MyEntry(V key)
    {
      this.key = key;
      this.value = value;
    }
    
    public K getKey()
    {
      return (K)this.key;
    }
    
    public V getValue()
    {
      return (V)this.value;
    }
    
    public V setValue(V value)
    {
      V old = this.value;
      this.value = value;
      return old;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.HardHeaded_Offering
 * JD-Core Version:    0.7.1
 */