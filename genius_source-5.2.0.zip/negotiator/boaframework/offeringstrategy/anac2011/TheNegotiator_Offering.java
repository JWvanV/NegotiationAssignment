package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2011.TheNegotiatorSAS;
import negotiator.utility.UtilitySpace;

public class TheNegotiator_Offering
  extends OfferingStrategy
{
  private final double RANDOM_MOVE = 0.300000011920929D;
  private Random random100;
  private Random random200;
  private final boolean TEST_EQUIVALENCE = false;
  
  public void init(NegotiationSession negoSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel)) {
      model = new NoModel();
    }
    this.negotiationSession = negoSession;
    this.opponentModel = model;
    this.omStrategy = oms;
    



    this.random100 = new Random();
    this.random200 = new Random();
    
    this.helper = new TheNegotiatorSAS(negoSession);
  }
  
  public BidDetails determineNextBid()
  {
    double time = this.negotiationSession.getTime();
    double threshold = ((TheNegotiatorSAS)this.helper).calculateThreshold(time);
    ((TheNegotiatorSAS)this.helper).getPhase();
    this.nextBid = determineOffer(((TheNegotiatorSAS)this.helper).getPhase(), threshold);
    return this.nextBid;
  }
  
  public BidDetails determineOffer(int phase, double threshold)
  {
    Bid bid = null;
    double upperThreshold = getUpperThreshold(threshold, 0.2D);
    if (phase == 1)
    {
      if (this.random100.nextDouble() > 0.300000011920929D) {
        bid = getOwnBidBetween(threshold, upperThreshold);
      } else {
        bid = getOwnBidBetween(upperThreshold - 1.E-005D, 1.1D);
      }
    }
    else
    {
      bid = getBestPartnerBids(threshold);
      if (bid == null) {
        if (this.random100.nextDouble() > 0.300000011920929D) {
          bid = getOwnBidBetween(threshold, upperThreshold);
        } else {
          bid = getOwnBidBetween(upperThreshold - 1.E-005D, 1.1D);
        }
      }
    }
    try
    {
      return new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  public double getUpperThreshold(double threshold, double percentage)
  {
    int boundary = 0;
    while ((boundary < ((TheNegotiatorSAS)this.helper).getPossibleBids().size()) && (((BidDetails)((TheNegotiatorSAS)this.helper).getPossibleBids().get(boundary)).getMyUndiscountedUtil() >= threshold)) {
      boundary++;
    }
    if (boundary > 0) {
      boundary--;
    }
    int index = boundary - (int)Math.ceil(percentage * boundary);
    
    double utility = ((BidDetails)((TheNegotiatorSAS)this.helper).getPossibleBids().get(index)).getMyUndiscountedUtil();
    return utility;
  }
  
  public Bid getOwnBidBetween(double lowerThres, double upperThres)
  {
    return getOwnBidBetween(lowerThres, upperThres, 0);
  }
  
  public Bid getOwnBidBetween(double lowerThres, double upperThres, int counter)
  {
    int lB = 0;
    int uB = 0;
    Bid bid = null;
    for (int i = 0; i < ((TheNegotiatorSAS)this.helper).getPossibleBids().size(); i++)
    {
      double util = ((BidDetails)((TheNegotiatorSAS)this.helper).getPossibleBids().get(i)).getMyUndiscountedUtil();
      if (util > upperThres) {
        uB++;
      }
      if (util >= lowerThres) {
        lB++;
      }
    }
    if (lB == uB)
    {
      if (counter == 1) {
        return ((BidDetails)((TheNegotiatorSAS)this.helper).getPossibleBids().get(0)).getBid();
      }
      bid = getOwnBidBetween(lowerThres, 1.1D, 1);
    }
    else
    {
      if (lB > 0) {
        lB--;
      }
      if (uB + 1 <= lB) {
        uB++;
      }
      if (!(this.opponentModel instanceof NoModel))
      {
        ArrayList<BidDetails> temp = ((TheNegotiatorSAS)this.helper).getPossibleBids();
        temp = new ArrayList(temp.subList(uB, lB + 1));
        BidDetails bidToOffer = this.omStrategy.getBid(temp);
        bid = bidToOffer.getBid();
      }
      else
      {
        int result = uB + (int)(this.random200.nextDouble() * (lB - uB) + 0.5D);
        
        bid = ((BidDetails)((TheNegotiatorSAS)this.helper).getPossibleBids().get(result)).getBid();
      }
    }
    try
    {
      this.nextBid = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bid;
  }
  
  public Bid getBestPartnerBids(double threshold)
  {
    ArrayList<BidDetails> temp = (ArrayList)new ArrayList(this.negotiationSession.getOpponentBidHistory().getHistory()).clone();
    


    Collections.sort(temp);
    
    Bid bid = null;
    
    int count = 0;
    while ((count < temp.size()) && (((BidDetails)temp.get(count)).getMyUndiscountedUtil() >= threshold)) {
      count++;
    }
    if (count > 0) {
      if (!(this.opponentModel instanceof NoModel)) {
        bid = this.omStrategy.getBid(temp).getBid();
      } else {
        bid = ((BidDetails)temp.get(this.random200.nextInt(count))).getBid();
      }
    }
    return bid;
  }
  
  public BidDetails determineOpeningBid()
  {
    this.nextBid = determineNextBid();
    return this.nextBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.TheNegotiator_Offering
 * JD-Core Version:    0.7.1
 */