package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2011.AgentK2SAS;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class AgentK2_Offering
  extends OfferingStrategy
{
  private Random random200;
  private Random random300;
  private final boolean TEST_EQUIVALENCE = false;
  private SortedOutcomeSpace outcomespace;
  
  public void init(NegotiationSession domainKnow, OpponentModel model, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel)) {
      model = new NoModel();
    }
    super.init(domainKnow, model, omStrategy, parameters);
    this.helper = new AgentK2SAS(this.negotiationSession);
    




    this.random200 = new Random();
    this.random300 = new Random();
    if (!(this.opponentModel instanceof NoModel)) {
      this.outcomespace = new SortedOutcomeSpace(this.negotiationSession.getUtilitySpace());
    }
  }
  
  public BidDetails determineNextBid()
  {
    if (this.negotiationSession.getOpponentBidHistory().getHistory().size() > 0) {
      ((AgentK2SAS)this.helper).calculateAcceptProbability();
    }
    ArrayList<BidDetails> bidTemp = new ArrayList();
    for (Bid bid : ((AgentK2SAS)this.helper).getOfferedBidMap().keySet())
    {
      double bidUtil = ((Double)((AgentK2SAS)this.helper).getOfferedBidMap().get(bid)).doubleValue();
      if (bidUtil > ((AgentK2SAS)this.helper).getTarget()) {
        bidTemp.add(new BidDetails(bid, bidUtil, this.negotiationSession.getTime()));
      }
    }
    int size = bidTemp.size();
    if (size > 0)
    {
      if ((this.opponentModel instanceof NoModel))
      {
        int sindex = (int)Math.floor(this.random200.nextDouble() * size);
        this.nextBid = ((BidDetails)bidTemp.get(sindex));
      }
      else
      {
        this.nextBid = this.omStrategy.getBid(bidTemp);
      }
    }
    else
    {
      double searchUtil = 0.0D;
      if ((this.opponentModel instanceof NoModel)) {
        try
        {
          int loop = 0;
          while (searchUtil < ((AgentK2SAS)this.helper).getBidTarget())
          {
            if (loop > 500)
            {
              ((AgentK2SAS)this.helper).decrementBidTarget(0.01D);
              loop = 0;
            }
            this.nextBid = searchBid();
            searchUtil = this.nextBid.getMyUndiscountedUtil();
            loop++;
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      } else {
        this.nextBid = this.omStrategy.getBid(this.outcomespace, ((AgentK2SAS)this.helper).getBidTarget());
      }
    }
    return this.nextBid;
  }
  
  private BidDetails searchBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.negotiationSession.getUtilitySpace().getDomain().getIssues();
    
    BidDetails bid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int optionIndex = this.random300.nextInt(lIssueDiscrete
          .getNumberOfValues());
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete
          .getValue(optionIndex));
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = this.random300.nextInt(lIssueReal
          .getNumberOfDiscretizationSteps() - 1);
        values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal
          .getLowerBound() + 
          
          (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal
          

          .getNumberOfDiscretizationSteps()));
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        
        int optionIndex2 = lIssueInteger.getLowerBound() + this.random300.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
          .getLowerBound());
        values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
      }
    }
    Bid newBid = new Bid(this.negotiationSession.getUtilitySpace().getDomain(), values);
    bid = new BidDetails(newBid, this.negotiationSession.getUtilitySpace().getUtility(newBid), this.negotiationSession.getTime());
    return bid;
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.AgentK2_Offering
 * JD-Core Version:    0.7.1
 */