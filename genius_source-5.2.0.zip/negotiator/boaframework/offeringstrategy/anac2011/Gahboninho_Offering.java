package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2011.GahboninhoSAS;
import negotiator.boaframework.sharedagentstate.anac2011.gahboninho.GahboninhoOM;
import negotiator.boaframework.sharedagentstate.anac2011.gahboninho.IssueManager;
import negotiator.utility.UtilitySpace;

public class Gahboninho_Offering
  extends OfferingStrategy
{
  final int PlayerCount = 8;
  private boolean WereBidsFiltered = false;
  private int RoundCount = 0;
  private SortedOutcomeSpace outcomespace;
  private int TotalFirstActions = 40;
  
  public void init(NegotiationSession domainKnow, OpponentModel model, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel)) {
      model = new NoModel();
    }
    super.init(domainKnow, model, omStrategy, parameters);
    this.helper = new GahboninhoSAS(this.negotiationSession);
    if (!(this.opponentModel instanceof NoModel)) {
      this.outcomespace = new SortedOutcomeSpace(this.negotiationSession.getUtilitySpace());
    }
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
  
  public BidDetails determineNextBid()
  {
    BidDetails previousOpponentBid = null;
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    int histSize = this.negotiationSession.getOpponentBidHistory().getHistory().size();
    if (histSize >= 2) {
      previousOpponentBid = (BidDetails)this.negotiationSession.getOpponentBidHistory().getHistory().get(histSize - 1);
    }
    double threshold = -1.0D;
    if (opponentBid != null)
    {
      if (previousOpponentBid != null) {
        try
        {
          ((GahboninhoSAS)this.helper).getIssueManager().ProcessOpponentBid(opponentBid.getBid());
          ((GahboninhoSAS)this.helper).getOpponentModel().UpdateImportance(opponentBid.getBid());
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      } else {
        try
        {
          ((GahboninhoSAS)this.helper).getIssueManager().learnBids(opponentBid.getBid());
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
      threshold = ((GahboninhoSAS)this.helper).getIssueManager().GetMinimumUtilityToAccept();
      ((GahboninhoSAS)this.helper).getIssueManager().setMinimumUtilForAcceptance(threshold);
    }
    try
    {
      this.RoundCount += 1;
      if ((!this.WereBidsFiltered) && ((this.negotiationSession.getTime() > ((GahboninhoSAS)this.helper).getIssueManager().GetDiscountFactor() * 0.9D) || (this.negotiationSession.getTime() + 3.0D * ((GahboninhoSAS)this.helper).getIssueManager().getBidsCreationTime().doubleValue() > 1.0D)))
      {
        this.WereBidsFiltered = true;
        
        int DesiredBidcount = (int)(this.RoundCount * (1.0D - this.negotiationSession.getTime()));
        if (((GahboninhoSAS)this.helper).getIssueManager().getBids().size() > 200) {
          ((GahboninhoSAS)this.helper).getIssueManager().setBids(((GahboninhoSAS)this.helper).getOpponentModel().FilterBids(((GahboninhoSAS)this.helper).getIssueManager().getBids(), DesiredBidcount));
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if (previousOpponentBid == null)
    {
      try
      {
        ((GahboninhoSAS)this.helper).getIssueManager().AddMyBidToStatistics(((GahboninhoSAS)this.helper).getIssueManager().getMaxBid());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      Bid maxBid = ((GahboninhoSAS)this.helper).getIssueManager().getMaxBid();
      try
      {
        return new BidDetails(maxBid, this.negotiationSession.getUtilitySpace().getUtility(maxBid), this.negotiationSession.getTime());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    Bid myBid;
    if ((((GahboninhoSAS)this.helper).getFirstActions() >= 0) && (this.negotiationSession.getTime() < 0.15D))
    {
      double utilDecrease = 0.07499999999999996D / this.TotalFirstActions;
      
      Bid myBid = ((GahboninhoSAS)this.helper).getIssueManager().GenerateBidWithAtleastUtilityOf(0.925D + utilDecrease * ((GahboninhoSAS)this.helper).getFirstActions());
      
      ((GahboninhoSAS)this.helper).decrementFirstActions();
    }
    else
    {
      myBid = ((GahboninhoSAS)this.helper).getIssueManager().GenerateBidWithAtleastUtilityOf(((GahboninhoSAS)this.helper).getIssueManager().GetNextRecommendedOfferUtility());
      if (((GahboninhoSAS)this.helper).getIssueManager().getInFrenzy() == true) {
        myBid = ((GahboninhoSAS)this.helper).getIssueManager().getBestEverOpponentBid();
      }
    }
    try
    {
      double utility = this.negotiationSession.getUtilitySpace().getUtility(myBid);
      if (!(this.opponentModel instanceof NoModel))
      {
        BidDetails selectedBid = this.omStrategy.getBid(this.outcomespace, utility);
        ((GahboninhoSAS)this.helper).getIssueManager().AddMyBidToStatistics(selectedBid.getBid());
        return selectedBid;
      }
      ((GahboninhoSAS)this.helper).getIssueManager().AddMyBidToStatistics(myBid);
      return new BidDetails(myBid, utility, this.negotiationSession.getTime());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.Gahboninho_Offering
 * JD-Core Version:    0.7.1
 */