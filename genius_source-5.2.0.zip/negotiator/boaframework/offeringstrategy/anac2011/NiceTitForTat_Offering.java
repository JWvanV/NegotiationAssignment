package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.opponentmodel.ScalableBayesianModel;
import negotiator.boaframework.sharedagentstate.anac2011.NiceTitForTatSAS;
import negotiator.utility.UtilitySpace;

public class NiceTitForTat_Offering
  extends OfferingStrategy
{
  private static final double TIME_USED_TO_DETERMINE_OPPONENT_STARTING_POINT = 0.01D;
  private double myNashUtility;
  private double initialGap;
  private long DOMAINSIZE;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  
  public void init(NegotiationSession negotiationSession, OpponentModel om, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((om instanceof DefaultModel))
    {
      om = new ScalableBayesianModel();
      om.init(negotiationSession, null);
      oms.setOpponentModel(om);
    }
    initializeAgent(negotiationSession, om, oms);
  }
  
  public void initializeAgent(NegotiationSession negoSession, OpponentModel om, OMStrategy oms)
  {
    this.negotiationSession = negoSession;
    this.opponentModel = om;
    
    this.omStrategy = oms;
    this.DOMAINSIZE = negoSession.getUtilitySpace().getDomain().getNumberOfPossibleBids();
    this.helper = new NiceTitForTatSAS(negoSession);
    


    this.random100 = new Random();
  }
  
  public BidDetails determineOpeningBid()
  {
    try
    {
      return this.negotiationSession.getMaxBidinDomain();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  public BidDetails determineNextBid()
  {
    Bid opponentLastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid();
    if (!(this.opponentModel instanceof NoModel)) {
      if (this.omStrategy.canUpdateOM()) {
        updateMyNashUtility();
      }
    }
    double myUtilityOfOpponentLastBid = getUtility(opponentLastBid);
    double maximumOfferedUtilityByOpponent = this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getMyUndiscountedUtil();
    double minUtilityOfOpponentFirstBids = getMinimumUtilityOfOpponentFirstBids(myUtilityOfOpponentLastBid);
    


    double opponentConcession = maximumOfferedUtilityByOpponent - minUtilityOfOpponentFirstBids;
    
    double opponentConcedeFactor = Math.min(1.0D, opponentConcession / (this.myNashUtility - minUtilityOfOpponentFirstBids));
    double myConcession = opponentConcedeFactor * (1.0D - this.myNashUtility);
    
    double myCurrentTargetUtility = 1.0D - myConcession;
    
    this.initialGap = (1.0D - minUtilityOfOpponentFirstBids);
    
    double gapToNash = Math.max(0.0D, myCurrentTargetUtility - this.myNashUtility);
    


    double bonus = getBonus();
    double tit = bonus * gapToNash;
    
    myCurrentTargetUtility -= tit;
    


    ArrayList<BidDetails> myBids = new ArrayList(getBidsOfUtility(myCurrentTargetUtility));
    

    Bid bestBid = null;
    Bid myBid;
    Bid myBid;
    if (!(this.opponentModel instanceof NoModel))
    {
      bestBid = getBestBidForOpponent(myBids);
      myBid = makeAppropriate(bestBid);
    }
    else
    {
      myBid = getBestBidForSelf(myBids);
    }
    try
    {
      this.nextBid = new BidDetails(myBid, this.negotiationSession.getUtilitySpace().getUtility(myBid), this.negotiationSession.getTime());
      return this.nextBid;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  private double getMinimumUtilityOfOpponentFirstBids(double myUtilityOfOpponentLastBid)
  {
    ArrayList<BidDetails> firstBidList = ((NiceTitForTatSAS)this.helper).filterBetweenTime(0.0D, 0.01D);
    BidHistory firstBids = new BidHistory(firstBidList);
    double firstBidsMinUtility;
    double firstBidsMinUtility;
    if (firstBids.size() == 0) {
      firstBidsMinUtility = this.negotiationSession.getOpponentBidHistory().getFirstBidDetails().getMyUndiscountedUtil();
    } else {
      firstBidsMinUtility = firstBids.getWorstBidDetails().getMyUndiscountedUtil();
    }
    return firstBidsMinUtility;
  }
  
  private double getBonus()
  {
    double discountFactor = this.negotiationSession.getDiscountFactor();
    if ((discountFactor <= 0.0D) || (discountFactor >= 1.0D)) {
      discountFactor = 1.0D;
    }
    double discountBonus = 0.5D - 0.4D * discountFactor;
    boolean isBigDomain = this.DOMAINSIZE > 3000L;
    
    double timeBonus = 0.0D;
    double time = this.negotiationSession.getTime();
    double minTime = 0.91D;
    if (isBigDomain) {
      minTime = 0.85D;
    }
    if (time > minTime) {
      timeBonus = Math.min(1.0D, 20.0D * (time - minTime));
    }
    double bonus = Math.max(discountBonus, timeBonus);
    if (bonus < 0.0D) {
      bonus = 0.0D;
    }
    if (bonus > 1.0D) {
      bonus = 1.0D;
    }
    return bonus;
  }
  
  private void updateMyNashUtility()
  {
    BidSpace bs = null;
    this.myNashUtility = 0.7D;
    try
    {
      double nashMultiplier = getNashMultiplier(this.initialGap);
      if (this.DOMAINSIZE < 200000L)
      {
        bs = new BidSpace(this.negotiationSession.getUtilitySpace(), this.opponentModel.getOpponentUtilitySpace(), true, true);
        

        BidPoint nash = bs.getNash();
        if ((nash != null) && (nash.getUtilityA() != null)) {
          this.myNashUtility = nash.getUtilityA().doubleValue();
        }
      }
      this.myNashUtility *= nashMultiplier;
      if (this.myNashUtility > 1.0D) {
        this.myNashUtility = 1.0D;
      }
      if (this.myNashUtility < 0.5D) {
        this.myNashUtility = 0.5D;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private double getNashMultiplier(double gap)
  {
    double mult = 1.4D - 0.6D * gap;
    if (mult < 0.0D) {
      mult = 0.0D;
    }
    return mult;
  }
  
  private List<BidDetails> getBidsOfUtility(double target)
  {
    if (target > 1.0D) {
      target = 1.0D;
    }
    double min = target * 0.98D;
    double max = target + 0.04D;
    do
    {
      max += 0.01D;
      List<BidDetails> bids = getBidsOfUtility(min, max);
      int size = bids.size();
      if ((size > 1) || ((max >= 1.0D) && (size > 0))) {
        return bids;
      }
    } while (max <= 1.0D);
    ArrayList<BidDetails> best = new ArrayList();
    Bid maxBid = this.negotiationSession.getMaxBidinDomain().getBid();
    try
    {
      best.add(new BidDetails(maxBid, this.negotiationSession.getUtilitySpace().getUtility(maxBid)));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return best;
  }
  
  private List<BidDetails> getBidsOfUtility(double lowerBound, double upperBound)
  {
    int limit = 2;
    
    List<BidDetails> bidsInRange = new ArrayList();
    BidIterator myBidIterator = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
    while (myBidIterator.hasNext())
    {
      Bid b = myBidIterator.next();
      try
      {
        double util = this.negotiationSession.getUtilitySpace().getUtility(b);
        if ((util >= lowerBound) && (util <= upperBound)) {
          bidsInRange.add(new BidDetails(b, util));
        }
        if ((((NiceTitForTatSAS)this.helper).isDomainBig()) && (bidsInRange.size() >= 2)) {
          return bidsInRange;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bidsInRange;
  }
  
  private Bid getBestBidForOpponent(ArrayList<BidDetails> bids)
  {
    return this.omStrategy.getBid(bids).getBid();
  }
  
  private Bid getBestBidForSelf(ArrayList<BidDetails> bids)
  {
    Bid maxBid = ((BidDetails)bids.get(0)).getBid();
    for (int i = 0; i < bids.size(); i++) {
      try
      {
        if (this.negotiationSession.getUtilitySpace().getUtility(((BidDetails)bids.get(i)).getBid()) > this.negotiationSession.getUtilitySpace().getUtility(maxBid)) {
          maxBid = ((BidDetails)bids.get(i)).getBid();
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return maxBid;
  }
  
  private Bid makeAppropriate(Bid myPlannedBid)
  {
    BidDetails bestBidByOpponent = this.negotiationSession.getOpponentBidHistory().getBestBidDetails();
    
    double bestUtilityByOpponent = getUtility(bestBidByOpponent.getBid());
    double myPlannedUtility = getUtility(myPlannedBid);
    if (bestUtilityByOpponent >= myPlannedUtility) {
      return bestBidByOpponent.getBid();
    }
    return myPlannedBid;
  }
  
  public double getUtility(Bid bid)
  {
    return this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(bid, this.negotiationSession.getTimeline().getTime());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.NiceTitForTat_Offering
 * JD-Core Version:    0.7.1
 */