package negotiator.boaframework.offeringstrategy.anac2011;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.BidIterator;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.BidList;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.BidWrapper;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.OpponentModeler;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.ValueDecrease;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.ValueModeler;
import negotiator.boaframework.offeringstrategy.anac2011.valuemodelagent.ValueSeperatedBids;
import negotiator.boaframework.sharedagentstate.anac2011.ValueModelAgentSAS;
import negotiator.utility.UtilitySpace;

public class ValueModelAgent_Offering
  extends OfferingStrategy
{
  private ValueModeler opponentUtilModel = null;
  private BidList allBids = null;
  private BidList approvedBids = null;
  private BidList iteratedBids = null;
  private Bid myLastBid = null;
  private int bidCount;
  private BidList opponentBids;
  private BidList ourBids;
  private OpponentModeler opponent;
  private double lowestAcceptable;
  private double lowestApproved;
  private double opponentStartbidUtil;
  private Bid opponentMaxBid;
  private double myMaximumUtility;
  private int amountOfApproved;
  private double noChangeCounter;
  private boolean retreatMode;
  private double concessionInOurUtility;
  private double concessionInTheirUtility;
  private ValueSeperatedBids seperatedBids;
  private final boolean TEST_EQUIVALENCE = false;
  Random random100;
  Random random200;
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.opponentModel = model;
    this.omStrategy = oms;
    this.helper = new ValueModelAgentSAS();
    this.opponentUtilModel = null;
    this.allBids = null;
    this.approvedBids = null;
    this.bidCount = 0;
    this.opponentBids = new BidList();
    this.ourBids = new BidList();
    this.iteratedBids = new BidList();
    this.seperatedBids = new ValueSeperatedBids();
    this.lowestAcceptable = 0.7D;
    this.lowestApproved = 1.0D;
    this.amountOfApproved = 0;
    this.myMaximumUtility = 1.0D;
    this.noChangeCounter = 0.0D;
    this.retreatMode = false;
    this.concessionInOurUtility = 0.0D;
    this.concessionInTheirUtility = 0.0D;
    




    this.random100 = new Random();
    this.random200 = new Random();
  }
  
  private void bidSelected(BidWrapper bid)
  {
    bid.sentByUs = true;
    this.ourBids.addIfNew(bid);
    this.myLastBid = bid.bid;
    if (this.opponentUtilModel != null) {
      this.seperatedBids.bidden(bid.bid, this.bidCount);
    }
  }
  
  private void bidSelectedByOpponent(Bid bid)
  {
    BidWrapper opponentBid = new BidWrapper(bid, this.negotiationSession.getUtilitySpace(), this.myMaximumUtility);
    
    opponentBid.lastSentBid = this.bidCount;
    opponentBid.sentByThem = true;
    if (this.opponentBids.addIfNew(opponentBid)) {
      this.noChangeCounter = 0.0D;
    } else {
      this.noChangeCounter += 1.0D;
    }
    try
    {
      double opponentUtil = this.negotiationSession.getUtilitySpace().getUtility(bid) / this.myMaximumUtility;
      if (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() < opponentUtil)
      {
        ((ValueModelAgentSAS)this.helper).setOpponentMaxBidUtil(opponentUtil);
        this.opponentMaxBid = bid;
      }
      if (this.opponentUtilModel.initialized)
      {
        double concession = opponentUtil - this.opponentStartbidUtil;
        if (concession > this.concessionInOurUtility) {
          this.concessionInOurUtility = concession;
        }
        ValueDecrease val = this.opponentUtilModel.utilityLoss(opponentBid.bid);
        
        concession = val.getDecrease();
        if (concession > this.concessionInTheirUtility) {
          this.concessionInTheirUtility = concession;
        }
        this.seperatedBids.bidden(bid, this.bidCount);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  private boolean setApprovedThreshold(double threshold, boolean clear)
  {
    if (clear)
    {
      this.approvedBids.bids.clear();
      this.seperatedBids.clear();
    }
    int i;
    if (clear) {
      i = 0;
    }
    for (int i = this.amountOfApproved; i < this.allBids.bids.size(); i++)
    {
      if (((BidWrapper)this.allBids.bids.get(i)).ourUtility < threshold) {
        break;
      }
      this.approvedBids.bids.add(this.allBids.bids.get(i));
      this.seperatedBids.addApproved((BidWrapper)this.allBids.bids.get(i));
    }
    this.lowestApproved = threshold;
    ((ValueModelAgentSAS)this.helper).setLowestApprovedInitial(threshold);
    boolean added = this.amountOfApproved != i;
    this.amountOfApproved = i;
    return added;
  }
  
  public BidDetails determineNextBid()
  {
    Bid opponentBid = null;
    BidDetails offer = null;
    try
    {
      if (this.allBids == null)
      {
        this.allBids = new BidList();
        this.approvedBids = new BidList();
        this.opponentUtilModel = new ValueModeler();
        this.seperatedBids.init(this.negotiationSession.getUtilitySpace(), this.opponentUtilModel);
        this.myMaximumUtility = this.negotiationSession.getUtilitySpace().getUtility(this.negotiationSession.getUtilitySpace().getMaxUtilityBid());
        BidIterator iter = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
        while (iter.hasNext())
        {
          Bid tmpBid = iter.next();
          try
          {
            BidWrapper wrap = new BidWrapper(tmpBid, this.negotiationSession.getUtilitySpace(), this.myMaximumUtility);
            
            this.allBids.bids.add(wrap);
          }
          catch (Exception ex)
          {
            BidWrapper wrap = new BidWrapper(tmpBid, this.negotiationSession.getUtilitySpace(), this.myMaximumUtility);
            
            this.allBids.bids.add(wrap);
          }
        }
        this.allBids.sortByOurUtil();
        





        setApprovedThreshold(0.98D, false);
        


        this.iteratedBids.bids.add(this.allBids.bids.get(0));
      }
      if (this.bidCount == 0)
      {
        offer = new BidDetails(((BidWrapper)this.allBids.bids.get(0)).bid, this.negotiationSession.getUtilitySpace().getUtility(((BidWrapper)this.allBids.bids.get(0)).bid));
        bidSelected((BidWrapper)this.allBids.bids.get(0));
      }
      if (this.negotiationSession.getOpponentBidHistory().size() > 0)
      {
        BidDetails lastBidByOpp = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
        opponentBid = lastBidByOpp.getBid();
        double opponentUtil = this.negotiationSession.getUtilitySpace().getUtility(opponentBid) / this.myMaximumUtility;
        

        ((ValueModelAgentSAS)this.helper).setOpponentUtil(opponentUtil);
        
        bidSelectedByOpponent(opponentBid);
        if (this.opponent == null)
        {
          this.opponentStartbidUtil = opponentUtil;
          this.opponent = new OpponentModeler(this.bidCount, this.negotiationSession.getUtilitySpace(), this.negotiationSession.getTimeline(), this.ourBids, this.opponentBids, this.opponentUtilModel, this.allBids);
          

          this.opponentUtilModel.initialize(this.negotiationSession.getUtilitySpace(), opponentBid);
          this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
        }
        else
        {
          this.opponent.tick();
          if (this.noChangeCounter == 0.0D)
          {
            double opponentExpectedBidValue = this.opponent.guessCurrentBidUtil();
            
            this.opponentUtilModel.assumeBidWorth(opponentBid, 1.0D - opponentExpectedBidValue, 0.02D);
          }
        }
        if ((this.negotiationSession.getTime() > 0.9D) && (this.negotiationSession.getTime() <= 0.96D)) {
          offer = chickenGame(0.039D, 0.0D, 0.7D);
        }
        if ((this.negotiationSession.getTime() > 0.96D) && (this.negotiationSession.getTime() <= 0.97D)) {
          offer = chickenGame(0.019D, 0.5D, 0.65D);
        }
        if ((this.negotiationSession.getTime() > 0.98D) && (this.negotiationSession.getTime() <= 0.99D))
        {
          ((ValueModelAgentSAS)this.helper).setLowestApprovedInitial(this.lowestApproved);
          if (this.bidCount % 5 == 0) {
            offer = exploreScan();
          } else {
            offer = bestScan();
          }
        }
        if ((this.negotiationSession.getTime() > 0.99D) && (this.negotiationSession.getTime() <= 0.995D)) {
          offer = chickenGame(0.004D, 0.8D, 0.6D);
        }
        if ((this.negotiationSession.getTime() > 0.995D) && (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() > 0.55D) && (opponentUtil < ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() * 0.99D)) {
          offer = new BidDetails(this.opponentMaxBid, this.negotiationSession.getUtilitySpace().getUtility(this.opponentMaxBid));
        }
        if (this.negotiationSession.getTime() > 0.995D) {
          offer = bestScan();
        }
        if (offer != null)
        {
          this.bidCount += 1;
          return offer;
        }
        ((ValueModelAgentSAS)this.helper).setLowestApproved(this.lowestApproved);
        if ((opponentUtil > this.lowestApproved * 0.99D) && (!this.negotiationSession.getUtilitySpace().isDiscounted()))
        {
          this.lowestApproved += 0.01D;
          setApprovedThreshold(this.lowestApproved, true);
          this.retreatMode = true;
        }
        if ((this.bidCount > 0) && (this.bidCount < 4))
        {
          offer = new BidDetails(((BidWrapper)this.allBids.bids.get(0)).bid, this.negotiationSession.getUtilitySpace().getUtility(((BidWrapper)this.allBids.bids.get(0)).bid));
          if (this.bidCount < this.allBids.bids.size()) {
            bidSelected((BidWrapper)this.allBids.bids.get(this.bidCount));
          }
        }
        if (this.bidCount >= 4)
        {
          double concession = opponentUtil - this.opponentStartbidUtil;
          





          double concession2 = 1.0D - this.opponent.guessCurrentBidUtil();
          double minConcession = concession < concession2 ? concession : concession2;
          
          minConcession = minConcessionMaker(minConcession, 1.0D - ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil());
          if (minConcession > 1.0D - this.lowestApproved)
          {
            if (this.lowestAcceptable > 1.0D - minConcession) {
              this.lowestApproved = this.lowestAcceptable;
            } else {
              this.lowestApproved = (1.0D - minConcession);
            }
            if (this.lowestApproved < ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil()) {
              this.lowestApproved = (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() + 0.001D);
            }
            if (setApprovedThreshold(this.lowestApproved, false)) {
              this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
            }
          }
          if (this.bidCount % 5 == 0) {
            offer = exploreScan();
          } else {
            offer = bestScan();
          }
        }
      }
      if (offer == null) {
        offer = this.negotiationSession.getOwnBidHistory().getLastBidDetails();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      ((ValueModelAgentSAS)this.helper).triggerSkipAcceptDueToCrash();
      if (this.myLastBid == null) {
        try
        {
          Bid maxBid = this.negotiationSession.getUtilitySpace().getMaxUtilityBid();
          return new BidDetails(maxBid, this.negotiationSession.getUtilitySpace().getUtility(maxBid));
        }
        catch (Exception e2)
        {
          e2.printStackTrace();
        }
      }
      try
      {
        return new BidDetails(this.myLastBid, this.negotiationSession.getUtilitySpace().getUtility(this.myLastBid));
      }
      catch (Exception e1)
      {
        e1.printStackTrace();
      }
    }
    this.bidCount += 1;
    return offer;
  }
  
  private BidDetails bestScan()
  {
    this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
    BidDetails toOffer = null;
    for (int i = 0; i < this.approvedBids.bids.size(); i++)
    {
      BidWrapper tempBid = (BidWrapper)this.approvedBids.bids.get(i);
      if (!tempBid.sentByUs)
      {
        try
        {
          toOffer = new BidDetails(tempBid.bid, this.negotiationSession.getUtilitySpace().getUtility(tempBid.bid));
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        bidSelected(tempBid);
        break;
      }
    }
    if (toOffer == null)
    {
      int maxIndex = this.approvedBids.bids.size() / 4;
      BidWrapper tempBid = (BidWrapper)this.approvedBids.bids.get((int)(this.random200.nextDouble() * maxIndex));
      try
      {
        toOffer = new BidDetails(tempBid.bid, this.negotiationSession.getUtilitySpace().getUtility(tempBid.bid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      bidSelected(tempBid);
    }
    return toOffer;
  }
  
  private BidDetails exploreScan()
  {
    BidDetails toOffer = null;
    BidWrapper tempBid = this.seperatedBids.explore(this.bidCount);
    if (tempBid != null)
    {
      try
      {
        toOffer = new BidDetails(tempBid.bid, this.negotiationSession.getUtilitySpace().getUtility(tempBid.bid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      bidSelected(tempBid);
    }
    else
    {
      toOffer = bestScan();
    }
    return toOffer;
  }
  
  private BidDetails chickenGame(double timeToGive, double concessionPortion, double acceptableThresh)
  {
    BidDetails toOffer = null;
    




    double concessionLeft = this.lowestApproved - ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil();
    double planedThresh = this.lowestApproved - concessionPortion * concessionLeft;
    if (acceptableThresh > planedThresh) {
      planedThresh = acceptableThresh;
    }
    setApprovedThreshold(planedThresh, false);
    this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
    
    ((ValueModelAgentSAS)this.helper).setPlanedThreshold(planedThresh);
    if (1.0D - this.negotiationSession.getTime() - timeToGive > 0.0D)
    {
      double time = (1.0D - this.negotiationSession.getTime() - timeToGive) * 180000.0D;
      try
      {
        Thread.sleep(Math.round(time));
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
    if ((this.retreatMode) || (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() >= planedThresh - 0.01D)) {
      try
      {
        toOffer = new BidDetails(this.opponentMaxBid, this.negotiationSession.getUtilitySpace().getUtility(this.opponentMaxBid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    } else {
      this.approvedBids.bids.get(0);
    }
    return toOffer;
  }
  
  double[] theirMaxUtilities = new double[21];
  double[] ourMinUtilities = new double[21];
  
  private double minConcessionMaker(double minConcession, double concessionLeft)
  {
    this.theirMaxUtilities[0] = this.opponentStartbidUtil;
    this.ourMinUtilities[0] = 1.0D;
    double t = this.negotiationSession.getTime();
    int tind = (int)(this.negotiationSession.getTime() * 20.0D) + 1;
    double segPortion = (t - (tind - 1) * 0.05D) / 0.05D;
    if (this.ourMinUtilities[tind] == 0.0D) {
      this.ourMinUtilities[tind] = 1.0D;
    }
    if (this.ourMinUtilities[(tind - 1)] == 0.0D) {
      this.ourMinUtilities[(tind - 1)] = this.lowestApproved;
    }
    if (this.lowestApproved < this.ourMinUtilities[tind]) {
      this.ourMinUtilities[tind] = this.lowestApproved;
    }
    if (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() > this.theirMaxUtilities[tind]) {
      this.theirMaxUtilities[tind] = ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil();
    }
    double d = this.negotiationSession.getDiscountFactor();
    double defaultVal = 1.0D - this.ourMinUtilities[(tind - 1)];
    if ((tind == 1) || (tind >= 19)) {
      return defaultVal;
    }
    if (this.ourMinUtilities[(tind - 2)] == 0.0D) {
      this.ourMinUtilities[(tind - 2)] = this.lowestApproved;
    }
    boolean theyMoved = this.theirMaxUtilities[tind] - this.theirMaxUtilities[(tind - 2)] > 0.01D;
    
    boolean weMoved = this.ourMinUtilities[(tind - 2)] - this.ourMinUtilities[(tind - 1)] > 0.0D;
    double returnVal = defaultVal;
    if (!this.negotiationSession.getUtilitySpace().isDiscounted())
    {
      if (tind > 2) {
        if (!weMoved) {
          if (!theyMoved) {
            if (tind <= 16)
            {
              returnVal = defaultVal + 0.02D;
              if (returnVal > minConcession * 2.0D / 3.0D) {
                returnVal = minConcession * 2.0D / 3.0D;
              }
            }
          }
        }
      }
      if ((tind > 16) && (!theyMoved))
      {
        returnVal = (concessionLeft - defaultVal) / (21 - tind) + defaultVal;
        if (returnVal > minConcession + 0.05D) {
          returnVal = minConcession + 0.05D;
        }
      }
    }
    else
    {
      double discountEstimate = d * 0.05D;
      double expectedRoundGain = this.theirMaxUtilities[(tind - 1)] - this.theirMaxUtilities[(tind - 2)] - discountEstimate;
      if (tind <= 16)
      {
        returnVal = defaultVal + 0.02D;
        if (defaultVal - expectedRoundGain > returnVal) {
          returnVal = defaultVal - expectedRoundGain;
        }
        if (returnVal > minConcession) {
          returnVal = minConcession;
        }
      }
      else
      {
        returnVal = (concessionLeft - defaultVal) / (21 - tind) + defaultVal;
      }
    }
    returnVal = defaultVal + (returnVal - defaultVal) * segPortion;
    return returnVal;
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2011.ValueModelAgent_Offering
 * JD-Core Version:    0.7.1
 */