package negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class BidSpace
{
  private static final boolean TEST_EQUIVALENCE = false;
  private Domain domain;
  ArrayList<Double> continuousWeights;
  double[] continuousPreference;
  double[] range;
  double[] offset;
  ArrayList<ContinuousSection> continuousSections;
  ValueDiscrete[][] discreteCombinations;
  ISSUETYPE[] issueTypes;
  ArrayList<Issue> issues;
  ArrayList<EvaluatorDiscrete> discreteEvaluators;
  ArrayList<EvaluatorReal> realEvaluators;
  ArrayList<EvaluatorInteger> integerEvaluators;
  private boolean continuousWeightsZero;
  private ArrayList<HashMap<ValueDiscrete, Double>> discreteEvaluationFunctions;
  private ArrayList<Double> discreteWeights;
  private double discountFactor;
  
  public ArrayList<Double> getContinuousWeights()
  {
    return this.continuousWeights;
  }
  
  public int getDiscreteCombinationsCount()
  {
    return this.discreteCombinations.length;
  }
  
  public boolean isContinuousWeightsZero()
  {
    return this.continuousWeightsZero;
  }
  
  public ArrayList<Double> getDiscreteWeights()
  {
    return this.discreteWeights;
  }
  
  public class EvaluatedDiscreteCombination
    implements Comparable<EvaluatedDiscreteCombination>
  {
    private ValueDiscrete[] discreteCombination;
    private double jointUtility;
    
    public ValueDiscrete[] getDiscreteCombination()
    {
      return this.discreteCombination;
    }
    
    public EvaluatedDiscreteCombination(ValueDiscrete[] discreteCombination, double jointUtility)
    {
      this.discreteCombination = discreteCombination;
      this.jointUtility = jointUtility;
    }
    
    public int compareTo(EvaluatedDiscreteCombination o)
    {
      return this.jointUtility == o.jointUtility ? 0 : this.jointUtility < o.jointUtility ? -1 : 1;
    }
  }
  
  public BidSpace(UtilitySpace space)
    throws Exception
  {
    this.domain = space.getDomain();
    
    this.discountFactor = space.getDiscountFactor();
    if (this.discountFactor >= 1.0D) {
      this.discountFactor = 0.0D;
    }
    this.issues = this.domain.getIssues();
    double[] weights = new double[this.issues.size()];
    this.issueTypes = new ISSUETYPE[this.issues.size()];
    
    this.discreteEvaluationFunctions = new ArrayList();
    this.discreteWeights = new ArrayList();
    
    ArrayList<ContinuousEvaluationFunction> continuousEvaluationFunctions = new ArrayList();
    this.continuousWeights = new ArrayList();
    this.continuousWeightsZero = true;
    ArrayList<Double> tmpContinuousPreference = new ArrayList();
    
    ArrayList<Double> tmpRange = new ArrayList();
    ArrayList<Double> tmpOffset = new ArrayList();
    
    this.realEvaluators = new ArrayList();
    this.integerEvaluators = new ArrayList();
    this.discreteEvaluators = new ArrayList();
    
    int i = 0;
    for (Issue issue : this.issues)
    {
      weights[i] = space.getWeight(issue.getNumber());
      this.issueTypes[i] = issue.getType();
      switch (this.issueTypes[i])
      {
      case DISCRETE: 
        IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
        List<ValueDiscrete> values = issueDiscrete.getValues();
        HashMap<ValueDiscrete, Double> evaluationFunction = new HashMap();
        EvaluatorDiscrete evaluatorDiscrete = (EvaluatorDiscrete)space.getEvaluator(issue.getNumber());
        this.discreteEvaluators.add(evaluatorDiscrete);
        for (ValueDiscrete value : values) {
          evaluationFunction.put(value, evaluatorDiscrete.getEvaluation(value));
        }
        this.discreteEvaluationFunctions.add(evaluationFunction);
        this.discreteWeights.add(Double.valueOf(space.getWeight(issue.getNumber())));
        break;
      case REAL: 
        EvaluatorReal evaluatorReal = (EvaluatorReal)space.getEvaluator(issue.getNumber());
        this.realEvaluators.add(evaluatorReal);
        
        tmpRange.add(Double.valueOf(evaluatorReal.getUpperBound() - evaluatorReal.getLowerBound()));
        tmpOffset.add(Double.valueOf(evaluatorReal.getLowerBound()));
        
        ArrayList<RealEvaluationSection> realSections = new ArrayList();
        switch (evaluatorReal.getFuncType())
        {
        case LINEAR: 
          double lb = normalise(evaluatorReal.getLowerBound(), evaluatorReal.getLowerBound(), evaluatorReal.getUpperBound());
          double ub = normalise(evaluatorReal.getUpperBound(), evaluatorReal.getLowerBound(), evaluatorReal.getUpperBound());
          RealEvaluationSection res = new RealEvaluationSection(lb, evaluatorReal.getEvaluation(evaluatorReal.getLowerBound()).doubleValue(), ub, evaluatorReal.getEvaluation(evaluatorReal.getUpperBound()).doubleValue());
          
          realSections.add(res);
          tmpContinuousPreference.add(Double.valueOf(res.getTopPoint()));
          break;
        case TRIANGULAR: 
          double lb = normalise(evaluatorReal.getLowerBound(), evaluatorReal.getLowerBound(), evaluatorReal.getUpperBound());
          double tp = normalise(evaluatorReal.getTopParam(), evaluatorReal.getLowerBound(), evaluatorReal.getUpperBound());
          double ub = normalise(evaluatorReal.getUpperBound(), evaluatorReal.getLowerBound(), evaluatorReal.getUpperBound());
          realSections.add(new RealEvaluationSection(lb, evaluatorReal.getEvaluation(evaluatorReal.getLowerBound()).doubleValue(), tp, evaluatorReal.getEvaluation(evaluatorReal.getTopParam()).doubleValue()));
          
          realSections.add(new RealEvaluationSection(tp, evaluatorReal.getEvaluation(evaluatorReal.getTopParam()).doubleValue(), ub, evaluatorReal.getEvaluation(evaluatorReal.getUpperBound()).doubleValue()));
          
          tmpContinuousPreference.add(Double.valueOf(tp));
          break;
        }
        continuousEvaluationFunctions.add(new ContinuousEvaluationFunction(realSections, space.getWeight(issue.getNumber())));
        if (space.getWeight(issue.getNumber()) > 0.0D) {
          this.continuousWeightsZero = false;
        }
        this.continuousWeights.add(Double.valueOf(space.getWeight(issue.getNumber())));
        break;
      case INTEGER: 
        EvaluatorInteger evaluatorInteger = (EvaluatorInteger)space.getEvaluator(issue.getNumber());
        this.integerEvaluators.add(evaluatorInteger);
        
        tmpRange.add(Double.valueOf(evaluatorInteger.getUpperBound() - evaluatorInteger.getLowerBound()));
        tmpOffset.add(Double.valueOf(evaluatorInteger.getLowerBound()));
        
        ArrayList<IntegerEvaluationSection> integerSections = new ArrayList();
        switch (evaluatorInteger.getFuncType())
        {
        case LINEAR: 
          int lb = normalise(evaluatorInteger.getLowerBound(), evaluatorInteger.getLowerBound(), evaluatorInteger.getUpperBound());
          int ub = normalise(evaluatorInteger.getUpperBound(), evaluatorInteger.getLowerBound(), evaluatorInteger.getUpperBound());
          IntegerEvaluationSection ies = new IntegerEvaluationSection(lb, evaluatorInteger.getEvaluation(evaluatorInteger.getLowerBound()).doubleValue(), ub, evaluatorInteger.getEvaluation(evaluatorInteger.getUpperBound()).doubleValue());
          
          integerSections.add(ies);
          tmpContinuousPreference.add(Double.valueOf(ies.getTopPoint()));
          break;
        }
        continuousEvaluationFunctions.add(new ContinuousEvaluationFunction(integerSections, space.getWeight(issue.getNumber())));
        if (space.getWeight(issue.getNumber()) > 0.0D) {
          this.continuousWeightsZero = false;
        }
        this.continuousWeights.add(Double.valueOf(space.getWeight(issue.getNumber())));
      }
      i++;
    }
    this.range = new double[tmpRange.size()];
    for (i = 0; i < this.range.length; i++) {
      this.range[i] = ((Double)tmpRange.get(i)).doubleValue();
    }
    this.offset = new double[tmpOffset.size()];
    for (i = 0; i < this.offset.length; i++) {
      this.offset[i] = ((Double)tmpOffset.get(i)).doubleValue();
    }
    this.continuousPreference = new double[tmpContinuousPreference.size()];
    for (i = 0; i < this.continuousPreference.length; i++) {
      this.continuousPreference[i] = ((Double)tmpContinuousPreference.get(i)).doubleValue();
    }
    this.discreteCombinations = BidSpaceDiscrete.getDiscreteCombinations(this.discreteEvaluationFunctions, this.discreteWeights);
    

    this.continuousSections = BidSpaceReal.getContinuousCombinations(continuousEvaluationFunctions, this.continuousWeights);
  }
  
  public double getBeta(ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory, double time, double utility0, double utility1)
  {
    return ConcessionUtils.getBeta(bestOpponentBidUtilityHistory, time, this.discountFactor, utility0, utility1);
  }
  
  public double getBeta(ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory, double time, double utility0, double utility1, double minDiscounting, double minBeta, double maxBeta, double defaultBeta, double ourTime, double opponentTime)
  {
    return ConcessionUtils.getBeta(bestOpponentBidUtilityHistory, time, this.discountFactor, utility0, utility1, minDiscounting, minBeta, maxBeta, defaultBeta, ourTime, opponentTime);
  }
  
  private double normalise(double value, double lowerBound, double upperBound)
  {
    return (value - lowerBound) / (upperBound - lowerBound);
  }
  
  private int normalise(int value, double lowerBound, double upperBound)
  {
    return (int)normalise(value, lowerBound, upperBound);
  }
  
  private double[] getPointOnLine(double utility, double[] normal, double utilityA, double[] pointA, double utilityB, double[] pointB)
  {
    if (utilityA == utilityB) {
      throw new AssertionError("utilityA must not equal utilityB");
    }
    double m = (utility - utilityA) / (utilityB - utilityA);
    
    double[] pointX = new double[normal.length];
    for (int i = 0; i < normal.length; i++) {
      pointA[i] += m * (pointB[i] - pointA[i]);
    }
    return pointX;
  }
  
  public ArrayList<BidDetails> Project(double[] pointToProject, double utility, int limit, UtilitySpace utilitySpace, OpponentModel opponentModel)
  {
    ArrayList<BidDetails> bids = new ArrayList();
    if (this.discreteCombinations.length == 0)
    {
      ArrayList<double[]> tmpPoints = new ArrayList();
      for (ContinuousSection continuousSection : this.continuousSections) {
        Project(tmpPoints, pointToProject, utility, continuousSection, null, this.range);
      }
      for (double[] point : getClosestPoints(tmpPoints, pointToProject)) {
        addUniqueBid(bids, createBid(point, null), utilitySpace);
      }
    }
    else
    {
      ValueDiscrete[][] bestCombinations = getBestCombinations(this.discreteCombinations, limit, this.continuousPreference, utilitySpace, opponentModel);
      ValueDiscrete[] discreteCombination;
      for (discreteCombination : bestCombinations)
      {
        ArrayList<double[]> tmpPoints = new ArrayList();
        if (this.continuousWeightsZero)
        {
          if (evaluate(discreteCombination, this.discreteEvaluationFunctions, this.discreteWeights) >= utility) {
            Project(tmpPoints, pointToProject, 0.0D, null, null, null);
          }
        }
        else {
          for (ContinuousSection continuousSection : this.continuousSections) {
            Project(tmpPoints, pointToProject, utility - evaluate(discreteCombination, this.discreteEvaluationFunctions, this.discreteWeights), continuousSection, discreteCombination, this.range);
          }
        }
        for (double[] point : getClosestPoints(tmpPoints, pointToProject)) {
          addUniqueBid(bids, createBid(point, discreteCombination), utilitySpace);
        }
      }
    }
    return bids;
  }
  
  private double evaluate(ValueDiscrete[] discreteCombination, ArrayList<HashMap<ValueDiscrete, Double>> discreteEvaluationFunctions, ArrayList<Double> discreteWeights)
  {
    double value = 0.0D;
    for (int j = 0; j < discreteCombination.length; j++) {
      value += ((Double)discreteWeights.get(j)).doubleValue() * ((Double)((HashMap)discreteEvaluationFunctions.get(j)).get(discreteCombination[j])).doubleValue();
    }
    return value;
  }
  
  private ValueDiscrete[][] getBestCombinations(ValueDiscrete[][] discreteCombinations, int limit, double[] continuousPreference, UtilitySpace utilitySpace, OpponentModel opponentModel)
  {
    if ((limit == 0) || (limit >= discreteCombinations.length)) {
      return discreteCombinations;
    }
    List<EvaluatedDiscreteCombination> options = new ArrayList();
    
    boolean noModel = opponentModel instanceof NoModel;
    for (ValueDiscrete[] discreteCombination : discreteCombinations)
    {
      Bid b = createBid(continuousPreference, discreteCombination);
      double jointUtility = 0.0D;
      try
      {
        if (!noModel) {
          jointUtility = utilitySpace.getUtility(b) + opponentModel.getBidEvaluation(b);
        } else {
          jointUtility = utilitySpace.getUtility(b);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      options.add(new EvaluatedDiscreteCombination(discreteCombination, jointUtility));
    }
    Collections.sort(options);
    options = options.subList(options.size() - limit, options.size());
    ValueDiscrete[][] bestCombinations = new ValueDiscrete[limit][discreteCombinations[0].length];
    int i = 0;
    for (EvaluatedDiscreteCombination edc : options)
    {
      bestCombinations[i] = edc.getDiscreteCombination();
      i++;
    }
    return bestCombinations;
  }
  
  private void Project(ArrayList<double[]> points, double[] pointToProject, double utility, ContinuousSection continuousSection, ValueDiscrete[] discreteCombination, double[] range)
  {
    if (continuousSection == null)
    {
      addUniquePoint(points, pointToProject);
      return;
    }
    double[] pointA = continuousSection.getKnownPoint1();
    double[] pointB = continuousSection.getKnownPoint2();
    
    double utilityA = continuousSection.getEvalKnownPoint1();
    double utilityB = continuousSection.getEvalKnownPoint2();
    
    double[] pointOnLine = getPointOnLine(utility, continuousSection.getNormal(), utilityA, pointA, utilityB, pointB);
    double[] projectedPoint = Project(pointToProject, continuousSection.getNormal(), pointOnLine);
    if (WithinConstraints(projectedPoint, continuousSection.getMinBounds(), continuousSection.getMaxBounds()))
    {
      addUniquePoint(points, projectedPoint);
    }
    else
    {
      projectedPoint = getEndPoint(continuousSection.getMinBounds(), continuousSection.getMaxBounds(), continuousSection.getNormal(), utility, discreteCombination, pointToProject, utilityA, pointA, utilityB, pointB, range);
      if (projectedPoint != null) {
        addUniquePoint(points, projectedPoint);
      }
    }
  }
  
  private double[] Project(double[] pointToProject, double[] normal, double[] pointOnLine)
  {
    if (pointToProject.length != normal.length) {
      throw new AssertionError("Lengths of pointToProject and normal do not match");
    }
    if (pointOnLine.length != normal.length) {
      throw new AssertionError("Lengths of pointOnLine and normal do not match");
    }
    int dimensions = pointToProject.length;
    
    double[] projectedPoint = new double[dimensions];
    double suma = 0.0D;
    double sumb = 0.0D;
    double sumc = 0.0D;
    for (int i = 0; i < dimensions; i++)
    {
      suma += normal[i] * pointOnLine[i];
      sumb += normal[i] * pointToProject[i];
      sumc += normal[i] * normal[i];
    }
    double sum = (suma - sumb) / sumc;
    for (int i = 0; i < dimensions; i++) {
      pointToProject[i] += sum * normal[i];
    }
    return projectedPoint;
  }
  
  private void addUniquePoint(ArrayList<double[]> points, double[] point)
  {
    for (double[] p : points) {
      if (p.equals(point)) {
        return;
      }
    }
    points.add(point);
  }
  
  private void addUniqueBid(ArrayList<BidDetails> bids, Bid bid, UtilitySpace space)
  {
    for (BidDetails b : bids) {
      if (b.getBid().equals(bid)) {
        return;
      }
    }
    try
    {
      bids.add(new BidDetails(bid, space.getUtility(bid), -1.0D));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private double[] getEndPoint(double[] min, double[] max, double[] normal, double utility, ValueDiscrete[] discreteCombination, double[] target, double utilityA, double[] pointA, double utilityB, double[] pointB, double[] range)
  {
    if (min.length != normal.length) {
      throw new AssertionError("Lengths of min and normal do not match");
    }
    if (max.length != normal.length) {
      throw new AssertionError("Lengths of max and normal do not match");
    }
    if (pointA.length != normal.length) {
      throw new AssertionError("Lengths of pointA and normal do not match");
    }
    if (pointB.length != normal.length) {
      throw new AssertionError("Lengths of pointB and normal do not match");
    }
    if (target.length != normal.length) {
      throw new AssertionError("Lengths of target and normal do not match");
    }
    int dimension = normal.length;
    
    double[] pointOnLine = getHillClimbStartPoint(min, max, normal, utility, discreteCombination, target, utilityA, pointA, utilityB, pointB);
    if (pointOnLine == null) {
      return null;
    }
    if (!WithinConstraints(pointOnLine, min, max)) {
      throw new AssertionError("Get Intersection fail");
    }
    for (int precision = 1; precision < 5; precision++) {
      for (;;)
      {
        double step = Math.pow(0.1D, precision);
        ArrayList<double[]> nearbyPointsOnLine = new ArrayList();
        nearbyPointsOnLine.add(pointOnLine);
        Double[] nearbyPoint = new Double[dimension];
        for (int shiftDimension = 0; shiftDimension < dimension; shiftDimension++) {
          for (int unknownDimension = 0; unknownDimension < dimension; unknownDimension++) {
            if (shiftDimension != unknownDimension)
            {
              for (int i = 0; i < dimension; i++) {
                nearbyPoint[i] = Double.valueOf(pointOnLine[i]);
              }
              nearbyPoint[unknownDimension] = null;
              
              i = nearbyPoint;int i = shiftDimension;(i[i] = Double.valueOf(i[i].doubleValue() + step * range[shiftDimension]));
              double[] proposedPoint = getIntersection(nearbyPoint, normal, pointOnLine);
              if (WithinConstraints(proposedPoint, min, max)) {
                nearbyPointsOnLine.add(proposedPoint);
              }
              i = nearbyPoint;i = shiftDimension;(i[i] = Double.valueOf(i[i].doubleValue() - 2.0D * step * range[shiftDimension]));
              proposedPoint = getIntersection(nearbyPoint, normal, pointOnLine);
              if (WithinConstraints(proposedPoint, min, max)) {
                nearbyPointsOnLine.add(proposedPoint);
              }
            }
          }
        }
        ArrayList<double[]> closestPoints = getClosestPoints(nearbyPointsOnLine, target);
        if (closestPoints.size() == 0) {
          break;
        }
        double[] closestPoint = (double[])closestPoints.get((int)Math.random() * closestPoints.size());
        if (getDistance(closestPoint, target) == getDistance(pointOnLine, target)) {
          break;
        }
        pointOnLine = closestPoint;
      }
    }
    return pointOnLine;
  }
  
  private double[] getHillClimbStartPoint(double[] min, double[] max, double[] normal, double utility, ValueDiscrete[] discreteCombination, double[] target, double utilityA, double[] pointA, double utilityB, double[] pointB)
  {
    if (min.length != normal.length) {
      throw new AssertionError("Lengths of min and normal do not match");
    }
    if (max.length != normal.length) {
      throw new AssertionError("Lengths of max and normal do not match");
    }
    if (pointA.length != normal.length) {
      throw new AssertionError("Lengths of pointA and normal do not match");
    }
    if (pointB.length != normal.length) {
      throw new AssertionError("Lengths of pointB and normal do not match");
    }
    if (target.length != normal.length) {
      throw new AssertionError("Lengths of target and normal do not match");
    }
    ArrayList<Double[]> bounds = getBounds(min, max);
    
    ArrayList<double[]> endPoints = new ArrayList();
    
    double[] pointOnLine = getPointOnLine(utility, normal, utilityA, pointA, utilityB, pointB);
    for (Double[] bound : bounds)
    {
      double[] endPoint = getIntersection(bound, normal, pointOnLine);
      if (WithinConstraints(endPoint, min, max)) {
        endPoints.add(endPoint);
      }
    }
    ArrayList<double[]> closestPoints = getClosestPoints(endPoints, target);
    if (closestPoints.size() == 0) {
      return null;
    }
    return (double[])closestPoints.get((int)Math.random() * closestPoints.size());
  }
  
  private ArrayList<double[]> getClosestPoints(ArrayList<double[]> endPoints, double[] target)
  {
    double closestDistance = Double.MAX_VALUE;
    for (double[] endPoint : endPoints)
    {
      double distance = getDistance(endPoint, target);
      closestDistance = Math.min(closestDistance, distance);
    }
    ArrayList<double[]> closestEndPoints = new ArrayList();
    for (double[] endPoint : endPoints) {
      if (getDistance(endPoint, target) == closestDistance) {
        closestEndPoints.add(endPoint);
      }
    }
    return closestEndPoints;
  }
  
  private double getDistance(double[] pointA, double[] pointB)
  {
    if (pointA.length != pointB.length) {
      throw new AssertionError("Lengths of pointA and pointB do not match");
    }
    if (pointA.length != this.range.length) {
      throw new AssertionError("Lengths of pointA and range do not match");
    }
    double distance = 0.0D;
    for (int i = 0; i < pointB.length; i++) {
      distance += Math.pow(pointA[i] - pointB[i], 2.0D);
    }
    return Math.sqrt(distance);
  }
  
  private Bid createBid(double[] point, ValueDiscrete[] discreteCombination)
  {
    HashMap<Integer, Value> bidInternals = new HashMap();
    int continuousPos = 0;
    int discretePos = 0;
    for (int i = 0; i < this.issueTypes.length; i++) {
      if (this.issueTypes[i] == ISSUETYPE.REAL)
      {
        bidInternals.put(Integer.valueOf(((Issue)this.issues.get(i)).getNumber()), new ValueReal(point[continuousPos] * this.range[continuousPos] + this.offset[continuousPos]));
        continuousPos++;
      }
      else if (this.issueTypes[i] == ISSUETYPE.INTEGER)
      {
        bidInternals.put(Integer.valueOf(((Issue)this.issues.get(i)).getNumber()), new ValueInteger((int)Math.round(point[continuousPos] * this.range[continuousPos] + this.offset[continuousPos])));
        
        continuousPos++;
      }
      else if (this.issueTypes[i] == ISSUETYPE.DISCRETE)
      {
        bidInternals.put(Integer.valueOf(((Issue)this.issues.get(i)).getNumber()), discreteCombination[discretePos]);
        discretePos++;
      }
    }
    try
    {
      return new Bid(this.domain, bidInternals);
    }
    catch (Exception e) {}
    return null;
  }
  
  private double[] getIntersection(Double[] bound, double[] normal, double[] pointOnLine)
  {
    if (bound.length != normal.length) {
      throw new AssertionError("Lengths of bound and normal do not match");
    }
    int dimensions = normal.length;
    
    double c = 0.0D;
    for (int i = 0; i < dimensions; i++) {
      c += normal[i] * pointOnLine[i];
    }
    int unknown = -1;
    double sum = 0.0D;
    double[] intersection = new double[dimensions];
    for (int i = 0; i < dimensions; i++) {
      if (bound[i] == null)
      {
        unknown = i;
      }
      else
      {
        sum += bound[i].doubleValue() * normal[i];
        intersection[i] = bound[i].doubleValue();
      }
    }
    if (unknown < 0) {
      throw new AssertionError("bound has no unknown");
    }
    intersection[unknown] = ((c - sum) / normal[unknown]);
    
    return intersection;
  }
  
  private ArrayList<Double[]> getBounds(double[] min, double[] max)
  {
    if (min.length != max.length) {
      throw new AssertionError("Lengths of min and max do not match");
    }
    int dimensions = min.length;
    
    ArrayList<Double[]> bounds = new ArrayList();
    
    int boundCount = dimensions * (int)Math.pow(2.0D, dimensions - 1);
    for (int i = 0; i < boundCount; i++)
    {
      int dimension = (int)Math.floor(i / (boundCount / dimensions));
      Double[] bound = new Double[dimensions];
      for (int j = 0; j < dimensions; j++) {
        if (j != dimension) {
          if (j < dimension) {
            bound[j] = Double.valueOf((i & 1 << j) == 0 ? min[j] : max[j]);
          } else {
            bound[j] = Double.valueOf((i & 1 << j - 1) == 0 ? min[j] : max[j]);
          }
        }
      }
      bounds.add(bound);
    }
    return bounds;
  }
  
  private boolean WithinConstraints(double[] point, double[] min, double[] max)
  {
    if (min.length != point.length) {
      throw new AssertionError("Lengths of min and point do not match");
    }
    if (max.length != point.length) {
      throw new AssertionError("Lengths of max and point do not match");
    }
    for (int i = 0; i < point.length; i++) {
      if ((point[i] < min[i]) || (point[i] > max[i])) {
        return false;
      }
    }
    return true;
  }
  
  public static ArrayList<int[]> getCombinationValues(int[] space)
  {
    ArrayList<int[]> combinationValues = new ArrayList();
    if (space.length == 1) {
      return combinationValues;
    }
    for (int i = 0; i < space[(space.length - 1)]; i++)
    {
      int[] combination = new int[space.length - 1];
      for (int j = 0; j < combination.length; j++) {
        combination[j] = ((int)Math.floor(i / space[j] % (space[(j + 1)] / space[j])));
      }
      combinationValues.add(combination);
    }
    return combinationValues;
  }
  
  public double[] getPoint(Bid bid)
  {
    double[] point = new double[this.continuousWeights.size()];
    int i = 0;
    int j = 0;
    for (ISSUETYPE issueType : this.issueTypes)
    {
      if (issueType == ISSUETYPE.REAL)
      {
        try
        {
          ValueReal valueReal = (ValueReal)bid.getValue(((Issue)this.issues.get(j)).getNumber());
          point[i] = ((valueReal.getValue() - this.offset[i]) / this.range[i]);
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        i++;
      }
      if (issueType == ISSUETYPE.INTEGER)
      {
        try
        {
          ValueInteger valueInteger = (ValueInteger)bid.getValue(((Issue)this.issues.get(j)).getNumber());
          point[i] = ((valueInteger.getValue() - this.offset[i]) / this.range[i]);
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        i++;
      }
      j++;
    }
    return point;
  }
  
  public Bid getMaxUtilityBid()
  {
    int discreteIssues = 0;
    int continuousIssues = 0;
    for (int i = 0; i < this.issueTypes.length; i++) {
      switch (this.issueTypes[i])
      {
      case DISCRETE: 
        discreteIssues++;
        break;
      case REAL: 
      case INTEGER: 
        continuousIssues++;
      }
    }
    int discreteCount = 0;
    int realCount = 0;
    int integerCount = 0;
    
    ValueDiscrete[] discreteCombination = new ValueDiscrete[discreteIssues];
    double[] continuousValues = new double[continuousIssues];
    for (Issue issue : this.issues) {
      switch (issue.getType())
      {
      case DISCRETE: 
        IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
        List<ValueDiscrete> values = issueDiscrete.getValues();
        double maxEval = 0.0D;
        ValueDiscrete maxValue = null;
        for (ValueDiscrete value : values) {
          try
          {
            double tmpEval = ((EvaluatorDiscrete)this.discreteEvaluators.get(discreteCount)).getEvaluation(value).doubleValue();
            if (tmpEval > maxEval)
            {
              maxEval = tmpEval;
              maxValue = value;
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
        discreteCombination[discreteCount] = maxValue;
        discreteCount++;
        break;
      case REAL: 
        EvaluatorReal realEvaluator = (EvaluatorReal)this.realEvaluators.get(realCount);
        switch (realEvaluator.getFuncType())
        {
        case LINEAR: 
          if (realEvaluator.getEvaluation(realEvaluator.getLowerBound()).doubleValue() < realEvaluator.getEvaluation(realEvaluator.getUpperBound()).doubleValue()) {
            continuousValues[(realCount + integerCount)] = 1.0D;
          } else {
            continuousValues[(realCount + integerCount)] = 0.0D;
          }
          break;
        case TRIANGULAR: 
          continuousValues[(realCount + integerCount)] = normalise(realEvaluator.getTopParam(), realEvaluator.getLowerBound(), realEvaluator.getUpperBound());
        }
        realCount++;
        break;
      case INTEGER: 
        EvaluatorInteger integerEvaluator = (EvaluatorInteger)this.integerEvaluators.get(integerCount);
        switch (integerEvaluator.getFuncType())
        {
        case LINEAR: 
          if (integerEvaluator.getEvaluation(integerEvaluator.getLowerBound()).doubleValue() < integerEvaluator.getEvaluation(integerEvaluator.getUpperBound()).doubleValue()) {
            continuousValues[(realCount + integerCount)] = 1.0D;
          } else {
            continuousValues[(realCount + integerCount)] = 0.0D;
          }
          break;
        }
        integerCount++;
      }
    }
    return createBid(continuousValues, discreteCombination);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.BidSpace
 * JD-Core Version:    0.7.1
 */