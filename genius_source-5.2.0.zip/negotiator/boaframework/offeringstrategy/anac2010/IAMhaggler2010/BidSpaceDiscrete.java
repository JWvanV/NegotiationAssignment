package negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.issue.ValueDiscrete;

public class BidSpaceDiscrete
{
  public static ValueDiscrete[][] getDiscreteCombinations(ArrayList<HashMap<ValueDiscrete, Double>> discreteEvaluationFunctions, ArrayList<Double> discreteWeights)
  {
    return getDiscrete(getDiscreteCombinationValues(discreteEvaluationFunctions), discreteEvaluationFunctions, discreteWeights);
  }
  
  private static ValueDiscrete[][] getDiscrete(ArrayList<int[]> discreteCombinationValues, ArrayList<HashMap<ValueDiscrete, Double>> discreteEvaluationFunctions, ArrayList<Double> discreteWeights)
  {
    ValueDiscrete[][] result = new ValueDiscrete[discreteCombinationValues.size()][discreteEvaluationFunctions.size()];
    
    int i = 0;
    for (int[] discreteCombinationValue : discreteCombinationValues)
    {
      for (int j = 0; j < discreteEvaluationFunctions.size(); j++) {
        result[i][j] = ((ValueDiscrete)((HashMap)discreteEvaluationFunctions.get(j)).keySet().toArray()[discreteCombinationValue[j]]);
      }
      i++;
    }
    return result;
  }
  
  private static ArrayList<int[]> getDiscreteCombinationValues(ArrayList<HashMap<ValueDiscrete, Double>> discreteEvaluationFunctions)
  {
    int[] space = new int[discreteEvaluationFunctions.size() + 1];
    space[0] = 1;
    int i = 0;
    for (HashMap<ValueDiscrete, Double> discreteEvaluationFunction : discreteEvaluationFunctions)
    {
      i++;
      space[i] = (space[(i - 1)] * discreteEvaluationFunction.size());
    }
    return BidSpace.getCombinationValues(space);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.BidSpaceDiscrete
 * JD-Core Version:    0.7.1
 */