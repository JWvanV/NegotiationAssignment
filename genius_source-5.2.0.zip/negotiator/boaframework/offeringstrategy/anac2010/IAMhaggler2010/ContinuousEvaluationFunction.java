package negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010;

import java.util.ArrayList;

public class ContinuousEvaluationFunction<T extends ContinuousEvaluationSection>
{
  protected double weight;
  protected ArrayList<T> sections;
  
  public ContinuousEvaluationFunction(ArrayList<T> sections, double weight)
  {
    this.sections = sections;
    this.weight = weight;
  }
  
  public int getSectionCount()
  {
    return this.sections.size();
  }
  
  public ContinuousEvaluationSection getSection(int sectionNo)
  {
    return (ContinuousEvaluationSection)this.sections.get(sectionNo);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.ContinuousEvaluationFunction
 * JD-Core Version:    0.7.1
 */