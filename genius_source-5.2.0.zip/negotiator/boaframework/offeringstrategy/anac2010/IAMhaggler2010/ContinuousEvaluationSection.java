package negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010;

public abstract class ContinuousEvaluationSection
{
  protected double evalLowerBound;
  protected double evalUpperBound;
  protected double lowerBound;
  protected double upperBound;
  
  public abstract double getNormal(double paramDouble);
  
  public double getEvalLowerBound()
  {
    return this.evalLowerBound;
  }
  
  public double getEvalUpperBound()
  {
    return this.evalUpperBound;
  }
  
  public double getLowerBound()
  {
    return this.lowerBound;
  }
  
  public double getUpperBound()
  {
    return this.upperBound;
  }
  
  public double getTopPoint()
  {
    if (this.evalLowerBound < this.evalUpperBound) {
      return this.upperBound;
    }
    return this.lowerBound;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.ContinuousEvaluationSection
 * JD-Core Version:    0.7.1
 */