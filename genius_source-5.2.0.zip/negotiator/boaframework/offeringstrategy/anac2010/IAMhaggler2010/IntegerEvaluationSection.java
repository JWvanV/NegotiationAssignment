package negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010;

public class IntegerEvaluationSection
  extends ContinuousEvaluationSection
{
  public IntegerEvaluationSection(int lowerBound, double evalLowerBound, int upperBound, double evalUpperBound)
  {
    this.lowerBound = lowerBound;
    this.evalLowerBound = evalLowerBound;
    this.upperBound = upperBound;
    this.evalUpperBound = evalUpperBound;
  }
  
  private double getNormalPart(double weight, int lowerBound, double evalLowerBound, int upperBound, double evalUpperBound)
  {
    if (lowerBound >= upperBound) {
      throw new AssertionError("lowerBound cannot be greater than or equal to upperBound");
    }
    if ((evalLowerBound != 0.0D) && (evalUpperBound != 0.0D)) {
      throw new AssertionError("evalLowerBound or evalUpperBound must be zero");
    }
    if ((evalLowerBound != 1.0D) && (evalUpperBound != 1.0D)) {
      throw new AssertionError("evalLowerBound or evalUpperBound must be one");
    }
    if (evalUpperBound > evalLowerBound) {
      return weight / (upperBound - lowerBound);
    }
    return -weight / (upperBound - lowerBound);
  }
  
  public double getNormal(double weight)
  {
    return getNormalPart(weight, (int)this.lowerBound, this.evalLowerBound, (int)this.upperBound, this.evalUpperBound);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.IntegerEvaluationSection
 * JD-Core Version:    0.7.1
 */