package negotiator.boaframework.offeringstrategy.anac2010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.opponentmodel.SmithFrequencyModel;
import negotiator.boaframework.opponentmodel.agentsmith.Bounds;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public class AgentSmith_Offering
  extends OfferingStrategy
{
  private static final double sTimeMargin = 0.9444444444444444D;
  private static final double sUtilyMargin = 0.7D;
  private static double UTILITY_THRESHOLD = 0.7D;
  private int fIndex;
  
  public AgentSmith_Offering() {}
  
  public AgentSmith_Offering(NegotiationSession negoSession, OpponentModel om, OMStrategy oms)
  {
    initializeAgent(negoSession, om, oms);
  }
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel))
    {
      model = new SmithFrequencyModel();
      model.init(negotiationSession, null);
      oms.setOpponentModel(model);
    }
    initializeAgent(negotiationSession, model, oms);
  }
  
  public void initializeAgent(NegotiationSession negoSession, OpponentModel om, OMStrategy oms)
  {
    this.negotiationSession = negoSession;
    this.opponentModel = om;
    this.omStrategy = oms;
    this.fIndex = 0;
  }
  
  public BidDetails determineNextBid()
  {
    double time = this.negotiationSession.getTime();
    Bid bid2Offer = null;
    try
    {
      if (time >= 0.9444444444444444D)
      {
        BidDetails lastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
        if (lastBid.getMyUndiscountedUtil() < 0.7D) {
          this.nextBid = this.negotiationSession.getOpponentBidHistory().getBestBidDetails();
        }
      }
      else
      {
        bid2Offer = getMostOptimalBid();
        this.nextBid = new BidDetails(bid2Offer, this.negotiationSession.getUtilitySpace().getUtility(bid2Offer), this.negotiationSession.getTime());
      }
    }
    catch (Exception e) {}
    return this.nextBid;
  }
  
  public BidDetails determineOpeningBid()
  {
    return this.negotiationSession.getMaxBidinDomain();
  }
  
  public Bid getMostOptimalBid()
  {
    ArrayList<Bid> allBids = getSampledBidList();
    
    ArrayList<Bid> removeMe = new ArrayList();
    for (int i = 0; i < allBids.size(); i++) {
      try
      {
        if (this.negotiationSession.getUtilitySpace().getUtility((Bid)allBids.get(i)) < UTILITY_THRESHOLD) {
          removeMe.add(allBids.get(i));
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    allBids.removeAll(removeMe);
    if ((this.opponentModel instanceof NoModel))
    {
      Bid bid = (Bid)allBids.get(this.fIndex);
      this.fIndex += 1;
      return bid;
    }
    Comparator<Bid> lComparator = new BidComparator(this.negotiationSession.getUtilitySpace());
    

    ArrayList<Bid> sortedAllBids = allBids;
    Collections.sort(sortedAllBids, lComparator);
    
    Bid lBid = (Bid)sortedAllBids.get(this.fIndex);
    if (this.fIndex < sortedAllBids.size() - 1) {
      this.fIndex += 1;
    }
    return lBid;
  }
  
  private ArrayList<Bid> getSampledBidList()
  {
    ArrayList<Bid> lBids = new ArrayList();
    ArrayList<Issue> lIssues = this.negotiationSession.getIssues();
    HashMap<Integer, Bounds> lBounds = Bounds.getIssueBounds(lIssues);
    

    HashMap<Integer, Value> lBidValues = new HashMap();
    for (Issue lIssue : lIssues)
    {
      Bounds b = (Bounds)lBounds.get(Integer.valueOf(lIssue.getNumber()));
      Value v = Bounds.getIssueValue(lIssue, b.getLower());
      lBidValues.put(Integer.valueOf(lIssue.getNumber()), v);
    }
    try
    {
      lBids.add(new Bid(this.negotiationSession.getUtilitySpace().getDomain(), lBidValues));
    }
    catch (Exception e) {}
    for (Issue lIssue : lIssues)
    {
      ArrayList<Bid> lTempBids = new ArrayList();
      Bounds b = (Bounds)lBounds.get(Integer.valueOf(lIssue.getNumber()));
      for (Bid lTBid : lBids) {
        for (double i = b.getLower(); i < b.getUpper(); i += b.getStepSize())
        {
          HashMap<Integer, Value> lNewBidValues = getBidValues(lTBid);
          lNewBidValues.put(Integer.valueOf(lIssue.getNumber()), Bounds.getIssueValue(lIssue, i));
          try
          {
            Bid iBid = new Bid(this.negotiationSession.getUtilitySpace().getDomain(), lNewBidValues);
            lTempBids.add(iBid);
          }
          catch (Exception e) {}
        }
      }
      lBids = lTempBids;
    }
    ArrayList<Bid> lToDestroy = new ArrayList();
    for (Bid lBid : lBids) {
      try
      {
        if (this.negotiationSession.getUtilitySpace().getUtility(lBid) < UTILITY_THRESHOLD) {
          lToDestroy.add(lBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    for (Bid lBid : lToDestroy) {
      lBids.remove(lBid);
    }
    return lBids;
  }
  
  private HashMap<Integer, Value> getBidValues(Bid pBid)
  {
    HashMap<Integer, Value> lNewBidValues = new HashMap();
    for (Issue lIssue : this.negotiationSession.getUtilitySpace().getDomain().getIssues()) {
      try
      {
        lNewBidValues.put(Integer.valueOf(lIssue.getNumber()), pBid.getValue(lIssue.getNumber()));
      }
      catch (Exception e) {}
    }
    return lNewBidValues;
  }
  
  public class BidComparator
    implements Comparator<Bid>
  {
    private UtilitySpace space;
    
    public BidComparator(UtilitySpace mySpace)
    {
      this.space = mySpace;
    }
    
    public int compare(Bid b1, Bid b2)
    {
      return getMeasure(b2) > getMeasure(b1) ? -1 : 1;
    }
    
    public double getMeasure(Bid b1)
    {
      double a = 0.0D;
      try
      {
        a = 1.0D - this.space.getUtility(b1);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      double b = 1.0D - AgentSmith_Offering.this.opponentModel.getBidEvaluation(b1);
      
      double alpha = Math.atan(b / a);
      
      return a + b + 1.570796326794897D / alpha * 0.5D * 3.141592653589793D;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.AgentSmith_Offering
 * JD-Core Version:    0.7.1
 */