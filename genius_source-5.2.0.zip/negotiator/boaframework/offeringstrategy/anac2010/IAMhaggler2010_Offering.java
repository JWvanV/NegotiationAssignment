package negotiator.boaframework.offeringstrategy.anac2010;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.BidSpace;
import negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.ConcessionFunction;
import negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.Pair;
import negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.SpecialTimeConcessionFunction;
import negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010.TimeConcessionFunction;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.IAMhagglerBayesianModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.utility.UtilitySpace;

public class IAMhaggler2010_Offering
  extends OfferingStrategy
{
  private double lowestTarget = 1.0D;
  private final double minDiscounting = 0.1D;
  private final double minBeta = 0.01D;
  private double maxBeta = 2.0D;
  private double defaultBeta = 1.0D;
  private final double hardHeadTarget = 0.8D;
  protected ConcessionFunction cf;
  protected ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory;
  private Bid bestOpponentBid;
  private double bestOpponentUtility;
  protected double utility0 = 0.0D;
  protected final double utility1 = 0.95D;
  protected static double MAXIMUM_ASPIRATION = 0.9D;
  protected BidSpace bidSpace;
  protected BidDetails myLastBid = null;
  protected Bid opponentPreviousBid = null;
  protected final double acceptMultiplier = 1.02D;
  protected boolean opponentIsHardHead;
  
  public void init(NegotiationSession negoSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel))
    {
      model = new IAMhagglerBayesianModel();
      model.init(negoSession, null);
      oms.setOpponentModel(model);
    }
    this.opponentModel = model;
    
    this.omStrategy = oms;
    this.negotiationSession = negoSession;
    this.bestOpponentBidUtilityHistory = new ArrayList();
    this.cf = new TimeConcessionFunction(1.0D, 0.0D);
    this.myLastBid = null;
    try
    {
      this.bidSpace = new BidSpace(this.negotiationSession.getUtilitySpace());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.opponentIsHardHead = true;
    int discreteCombinationCount = this.bidSpace.getDiscreteCombinationsCount();
    if (this.bidSpace.isContinuousWeightsZero())
    {
      this.defaultBeta = Math.min(0.5D, Math.max(0.0625D, discreteCombinationCount * 0.001D));
      if (this.negotiationSession.getUtilitySpace().isDiscounted()) {
        this.maxBeta = ((2.0D + 4.0D * Math.min(0.5D, this.negotiationSession.getUtilitySpace().getDiscountFactor())) * this.defaultBeta);
      } else {
        this.maxBeta = (2.0D + 4.0D * this.defaultBeta);
      }
    }
  }
  
  protected double getTargetUtility(double myUtility, double oppntUtility)
  {
    double currentTime = this.negotiationSession.getTime() * this.negotiationSession.getTimeline().getTotalTime() * 1000.0D;
    
    double beta = this.bidSpace.getBeta(this.bestOpponentBidUtilityHistory, this.negotiationSession.getTime(), this.utility0, 0.95D, 0.1D, 0.01D, this.maxBeta, this.defaultBeta, currentTime, currentTime);
    
    this.cf = new SpecialTimeConcessionFunction(beta, this.defaultBeta, 0.5D);
    
    double target = 0.0D;
    try
    {
      target = getConcession(this.negotiationSession.getUtilitySpace().getUtility(this.negotiationSession.getOwnBidHistory().getFirstBidDetails().getBid()));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.lowestTarget = Math.min(target, this.lowestTarget);
    if (this.opponentIsHardHead) {
      return Math.max(0.8D, this.lowestTarget);
    }
    return this.lowestTarget;
  }
  
  private void storeDataPoint(double utility)
  {
    double time = this.negotiationSession.getTime();
    
    this.bestOpponentBidUtilityHistory.add(new Pair(Double.valueOf(utility), Double.valueOf(time)));
  }
  
  private BidDetails handleOffer(Bid opponentBid)
    throws Exception
  {
    Bid chosenAction = null;
    if (this.myLastBid == null)
    {
      Bid b = proposeInitialBid();
      this.myLastBid = new BidDetails(b, this.negotiationSession.getUtilitySpace().getUtility(b), this.negotiationSession.getTime());
      chosenAction = b;
    }
    else
    {
      Bid plannedBid = proposeNextBid(opponentBid);
      chosenAction = plannedBid;
      
      this.opponentPreviousBid = opponentBid;
    }
    return new BidDetails(chosenAction, this.negotiationSession.getUtilitySpace().getUtility(chosenAction), this.negotiationSession.getTime());
  }
  
  protected Bid proposeInitialBid()
  {
    Bid bid = null;
    try
    {
      bid = this.bidSpace.getMaxUtilityBid();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bid;
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
  }
  
  protected Bid proposeNextBid(Bid opponentBid)
  {
    BidDetails opponentHisBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    if (opponentHisBid != null) {
      try
      {
        if ((this.opponentIsHardHead) && (this.negotiationSession.getOpponentBidHistory().size() > 0) && 
          (Math.abs(this.negotiationSession.getUtilitySpace().getUtility(this.negotiationSession.getOpponentBidHistory().getFirstBidDetails().getBid()) - opponentHisBid.getMyUndiscountedUtil()) > 0.02D)) {
          this.opponentIsHardHead = false;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    double myUtility = 0.0D;double opponentUtility = 0.0D;
    try
    {
      myUtility = this.negotiationSession.getUtilitySpace().getUtility(this.myLastBid.getBid());
      opponentUtility = this.negotiationSession.getUtilitySpace().getUtility(opponentBid);
      if (this.opponentPreviousBid == null) {
        this.utility0 = opponentUtility;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double targetUtility = getTargetUtility(myUtility, opponentUtility);
    Bid nextBid = getTradeOffExhaustive(targetUtility, opponentBid, 1000);
    
    return nextBid;
  }
  
  private double getConcession(double startUtility)
  {
    double currentTime = this.negotiationSession.getTimeline().getCurrentTime() * 1000.0D;
    double totalTime = this.negotiationSession.getTimeline().getTotalTime() * 1000.0D;
    return this.cf.getConcession(startUtility, Math.round(currentTime), totalTime);
  }
  
  private Bid getBestBid(Bid opponentBid)
  {
    try
    {
      double utility = this.negotiationSession.getUtilitySpace().getUtility(opponentBid);
      if (utility >= this.bestOpponentUtility)
      {
        this.bestOpponentUtility = utility;
        this.bestOpponentBid = opponentBid;
      }
      storeDataPoint(this.bestOpponentUtility);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return this.bestOpponentBid;
  }
  
  private Bid getTradeOffExhaustive(double ourUtility, Bid opponentBid, int count)
  {
    Bid bestBidOpp = getBestBid(opponentBid);
    if (this.bestOpponentUtility * 1.02D >= ourUtility) {
      return bestBidOpp;
    }
    ArrayList<BidDetails> bids = this.bidSpace.Project(this.bidSpace.getPoint(this.bestOpponentBid), ourUtility, count, this.negotiationSession.getUtilitySpace(), this.opponentModel);
    if (bids.size() == 0) {
      return getTradeOffExhaustive(ourUtility, opponentBid, count + 10000);
    }
    Bid bestBid = null;
    if ((this.opponentModel instanceof NoModel))
    {
      Random random = new Random();
      bestBid = ((BidDetails)bids.get(random.nextInt(bids.size()))).getBid();
    }
    else
    {
      bestBid = this.omStrategy.getBid(bids).getBid();
    }
    return bestBid;
  }
  
  public BidDetails determineNextBid()
  {
    BidDetails chosenAction = null;
    if (this.myLastBid == null)
    {
      Bid bid = proposeInitialBid();
      try
      {
        chosenAction = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else
    {
      try
      {
        chosenAction = handleOffer(this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    this.myLastBid = chosenAction;
    
    return chosenAction;
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMhaggler2010_Offering
 * JD-Core Version:    0.7.1
 */