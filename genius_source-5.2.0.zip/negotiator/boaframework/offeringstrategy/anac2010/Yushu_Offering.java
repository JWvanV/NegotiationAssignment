package negotiator.boaframework.offeringstrategy.anac2010;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.BidIterator;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2010.YushuSAS;
import negotiator.utility.UtilitySpace;

public class Yushu_Offering
  extends OfferingStrategy
{
  BidDetails suggestBid = null;
  BidDetails maxUtilBid = null;
  private double highPosUtil;
  Random random200;
  private final boolean TEST_EQUIVALENCE = false;
  
  public void init(NegotiationSession domainKnow, OpponentModel model, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel)) {
      model = new NoModel();
    }
    super.init(domainKnow, model, omStrategy, parameters);
    
    this.maxUtilBid = this.negotiationSession.getMaxBidinDomain();
    this.helper = new YushuSAS(this.negotiationSession);
    this.highPosUtil = this.negotiationSession.getMaxBidinDomain().getMyUndiscountedUtil();
    


    this.random200 = new Random();
  }
  
  public BidDetails determineOpeningBid()
  {
    if (this.negotiationSession.getOpponentBidHistory().size() > 0) {
      ((YushuSAS)this.helper).updateBelief(this.negotiationSession.getOpponentBidHistory().getLastBidDetails());
    }
    ((YushuSAS)this.helper).setPreviousTime(this.negotiationSession.getTime());
    this.nextBid = this.maxUtilBid;
    return this.nextBid;
  }
  
  public BidDetails determineNextBid()
  {
    ((YushuSAS)this.helper).updateBelief(this.negotiationSession.getOpponentBidHistory().getLastBidDetails());
    
    BidDetails myLastBid = this.negotiationSession.getOwnBidHistory().getLastBidDetails();
    double targetUtility;
    double targetUtility;
    if (myLastBid == null) {
      targetUtility = 1.0D;
    } else {
      targetUtility = ((YushuSAS)this.helper).calculateTargetUtility();
    }
    this.suggestBid = ((YushuSAS)this.helper).getSuggestBid();
    if (this.suggestBid != null) {
      this.nextBid = this.suggestBid;
    } else if (targetUtility >= this.highPosUtil) {
      this.nextBid = this.maxUtilBid;
    } else {
      try
      {
        this.nextBid = getNextBid(targetUtility);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return this.nextBid;
  }
  
  private BidDetails getNextBid(double targetuti)
    throws Exception
  {
    BidDetails potentialBid = null;
    double maxdiff = Double.MAX_VALUE;
    double tempmaxdiff = Double.MAX_VALUE;
    BidDetails tempnextBid = null;
    
    LinkedList<BidDetails> candidates = new LinkedList();
    
    BidIterator bidsIter = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
    while (bidsIter.hasNext())
    {
      Bid bid = bidsIter.next();
      BidDetails tmpBid = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
      double vlowbound;
      double vlowbound;
      if (((YushuSAS)this.helper).getRoundLeft() > 30.0D) {
        vlowbound = Math.max(((BidDetails)((YushuSAS)this.helper).getBestTenBids().get(0)).getMyUndiscountedUtil(), targetuti);
      } else {
        vlowbound = 0.96D * targetuti;
      }
      if ((tmpBid.getMyUndiscountedUtil() > vlowbound) && (tmpBid.getMyUndiscountedUtil() < 1.08D * targetuti)) {
        candidates.add(tmpBid);
      }
      double currentdiff = Math.abs(tmpBid.getMyUndiscountedUtil() - targetuti);
      if (currentdiff < tempmaxdiff)
      {
        tempmaxdiff = currentdiff;
        tempnextBid = tmpBid;
      }
      if (((currentdiff < maxdiff ? 1 : 0) & (tmpBid.getMyUndiscountedUtil() > targetuti ? 1 : 0)) != 0)
      {
        maxdiff = currentdiff;
        potentialBid = tmpBid;
      }
    }
    if (this.negotiationSession.getOwnBidHistory().size() > 10)
    {
      candidates.add(potentialBid);
      if ((this.opponentModel instanceof NoModel))
      {
        int indexc = (int)(this.random200.nextDouble() * candidates.size());
        potentialBid = (BidDetails)candidates.get(indexc);
      }
      else
      {
        potentialBid = this.omStrategy.getBid(candidates);
      }
    }
    if (potentialBid == null) {
      potentialBid = tempnextBid;
    }
    return potentialBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.Yushu_Offering
 * JD-Core Version:    0.7.1
 */