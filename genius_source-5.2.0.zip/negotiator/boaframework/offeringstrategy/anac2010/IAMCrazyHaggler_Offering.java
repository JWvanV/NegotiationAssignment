package negotiator.boaframework.offeringstrategy.anac2010;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;
import misc.Range;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.utility.UtilitySpace;

public class IAMCrazyHaggler_Offering
  extends OfferingStrategy
{
  private double breakoff = 0.9D;
  private Random random100;
  private final boolean TEST_EQUIVALENCE = false;
  
  public void init(NegotiationSession domainKnow, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    initializeAgent(domainKnow, model, oms);
    if ((parameters != null) && (parameters.get("b") != null)) {
      this.breakoff = ((Double)parameters.get("b")).doubleValue();
    }
  }
  
  private void initializeAgent(NegotiationSession negoSession, OpponentModel model, OMStrategy oms)
  {
    if ((model instanceof DefaultModel)) {
      model = new NoModel();
    }
    this.negotiationSession = negoSession;
    this.opponentModel = model;
    this.omStrategy = oms;
    if (negoSession.getDiscountFactor() == 0.0D) {
      this.breakoff = 0.95D;
    }
    this.random100 = new Random();
    if (!(this.opponentModel instanceof NoModel))
    {
      SortedOutcomeSpace space = new SortedOutcomeSpace(this.negotiationSession.getUtilitySpace());
      
      this.negotiationSession.setOutcomeSpace(space);
    }
  }
  
  public BidDetails determineOpeningBid()
  {
    return determineNextBid();
  }
  
  public BidDetails determineNextBid()
  {
    if ((this.opponentModel instanceof NoModel))
    {
      Bid bid = null;
      try
      {
        do
        {
          bid = this.negotiationSession.getUtilitySpace().getDomain().getRandomBid(this.random100);
        } while (this.negotiationSession.getUtilitySpace().getUtility(bid) <= this.breakoff);
        this.nextBid = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else
    {
      this.nextBid = this.omStrategy.getBid(this.negotiationSession.getOutcomeSpace(), new Range(this.breakoff, 1.1D));
    }
    return this.nextBid;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("b", new BigDecimal(0.9D), "Minimum utility"));
    
    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.IAMCrazyHaggler_Offering
 * JD-Core Version:    0.7.1
 */