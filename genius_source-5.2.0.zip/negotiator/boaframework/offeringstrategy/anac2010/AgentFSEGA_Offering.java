package negotiator.boaframework.offeringstrategy.anac2010;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.BidIterator;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.opponentmodel.DefaultModel;
import negotiator.boaframework.opponentmodel.FSEGABayesianModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.utility.UtilitySpace;

public class AgentFSEGA_Offering
  extends OfferingStrategy
{
  private static final double MIN_ALLOWED_UTILITY = 0.5D;
  private static final double SIGMA = 0.01D;
  private static final double SIGMA_MAX = 0.5D;
  private final boolean TEST_EQUIVALENCE = false;
  private double elapsedTimeNorm;
  private ArrayList<Bid> leftBids;
  private SortedOutcomeSpace outcomeSpace;
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((model instanceof DefaultModel))
    {
      model = new FSEGABayesianModel();
      model.init(negotiationSession, null);
      oms.setOpponentModel(model);
    }
    initializeAgent(negotiationSession, model, oms);
  }
  
  private void initializeAgent(NegotiationSession negoSession, OpponentModel model, OMStrategy oms)
  {
    this.negotiationSession = negoSession;
    this.omStrategy = oms;
    this.opponentModel = model;
    if ((!(model instanceof NoModel)) && (!(model instanceof FSEGABayesianModel))) {
      this.outcomeSpace = new SortedOutcomeSpace(negoSession.getUtilitySpace());
    }
    BidIterator bIterCount = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
    

    double[] nrBids = { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D };
    while (bIterCount.hasNext())
    {
      Bid tmpBid = bIterCount.next();
      try
      {
        double utility = this.negotiationSession.getUtilitySpace().getUtility(tmpBid);
        if ((utility > 1.0D) && (utility > 0.9D)) {
          nrBids[0] += 1.0D;
        } else if ((utility <= 0.9D) && (utility > 0.8D)) {
          nrBids[1] += 1.0D;
        } else if ((utility <= 0.8D) && (utility > 0.7D)) {
          nrBids[2] += 1.0D;
        } else if ((utility <= 0.7D) && (utility > 0.6D)) {
          nrBids[3] += 1.0D;
        } else if (utility >= 0.5D) {
          nrBids[4] += 1.0D;
        }
      }
      catch (Exception e) {}
    }
    try
    {
      Thread.sleep(1000L);
    }
    catch (Exception e) {}
    double arrayBidCount = 0.0D;
    int iMin = 0;
    do
    {
      arrayBidCount = nrBids[iMin];
      iMin++;
    } while ((arrayBidCount == 0.0D) && (iMin < 5));
    BidIterator bIter = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
    
    this.leftBids = new ArrayList();
    while (bIter.hasNext())
    {
      Bid tmpBid = bIter.next();
      try
      {
        if (this.negotiationSession.getUtilitySpace().getUtility(tmpBid) >= 0.9D - 0.1D * iMin) {
          this.leftBids.add(tmpBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    Collections.sort(this.leftBids, new ReverseBidComparator(this.negotiationSession.getUtilitySpace()));
  }
  
  public BidDetails determineOpeningBid()
  {
    try
    {
      return initialOffer();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  public BidDetails determineNextBid()
  {
    this.elapsedTimeNorm = this.negotiationSession.getTime();
    int timeCase;
    int timeCase;
    if (this.elapsedTimeNorm < 0.85D)
    {
      timeCase = 0;
    }
    else
    {
      int timeCase;
      if (this.elapsedTimeNorm < 0.95D) {
        timeCase = 1;
      } else {
        timeCase = 2;
      }
    }
    if (this.negotiationSession.getOwnBidHistory().getLastBidDetails() != null) {
      try
      {
        Bid bid = getNextBid(timeCase);
        double bidUtil = this.negotiationSession.getUtilitySpace().getUtility(bid);
        this.nextBid = new BidDetails(bid, bidUtil, this.negotiationSession.getTime());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    if ((!(this.opponentModel instanceof NoModel)) && (!(this.opponentModel instanceof FSEGABayesianModel))) {
      try
      {
        this.nextBid = this.omStrategy.getBid(this.outcomeSpace, this.negotiationSession.getUtilitySpace().getUtility(this.nextBid.getBid()));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return this.nextBid;
  }
  
  private BidDetails initialOffer()
    throws Exception
  {
    this.nextBid = this.negotiationSession.getMaxBidinDomain();
    return this.negotiationSession.getMaxBidinDomain();
  }
  
  private Bid getNextBid(int pTimeCase)
    throws Exception
  {
    switch (pTimeCase)
    {
    case 0: 
      return getSmartBid(pTimeCase);
    case 1: 
      return getSmartBid(1);
    }
    return getSmartBid(2);
  }
  
  private Bid getSmartBid(int pTimeCase)
  {
    double currentOpponentUtility = 0.0D;
    double lastOpponentUtility = 0.0D;
    




    Bid nextBest = null;
    Bid theBest = null;
    if (this.leftBids.size() > 0)
    {
      theBest = (Bid)this.leftBids.get(0);
      try
      {
        myBestUtil = this.negotiationSession.getUtilitySpace().getUtility(theBest);
      }
      catch (Exception e)
      {
        double myBestUtil = 1.0D;
      }
      nextBest = theBest;
    }
    else
    {
      return this.negotiationSession.getOwnBidHistory().getLastBidDetails().getBid();
    }
    double myBestUtil;
    Bid lNext = null;
    
    double minUtilAllowed = Math.max(0.98D * Math.exp(Math.log(0.52D) * this.elapsedTimeNorm), 0.5D);
    double minArrayUtility = 0.0D;
    try
    {
      minArrayUtility = this.negotiationSession.getUtilitySpace().getUtility((Bid)this.leftBids.get(this.leftBids.size() - 1));
    }
    catch (Exception e) {}
    if ((minArrayUtility > minUtilAllowed + 0.01D) || (minArrayUtility > myBestUtil - 0.01D))
    {
      BidIterator bIter = new BidIterator(this.negotiationSession.getUtilitySpace().getDomain());
      for (Bid tmpBid = bIter.next(); bIter.hasNext(); tmpBid = bIter.next()) {
        try
        {
          double tmpBidUtil = this.negotiationSession.getUtilitySpace().getUtility(tmpBid);
          if ((tmpBidUtil > 0.5D) && (tmpBidUtil < minArrayUtility) && (tmpBidUtil > Math.min(minUtilAllowed, myBestUtil) - 0.1D)) {
            this.leftBids.add(tmpBid);
          }
        }
        catch (Exception e) {}
      }
      Collections.sort(this.leftBids, new ReverseBidComparator(this.negotiationSession.getUtilitySpace()));
    }
    if (this.leftBids.size() > 1)
    {
      lNext = (Bid)this.leftBids.get(1);
    }
    else
    {
      this.leftBids.remove(nextBest);
      return nextBest;
    }
    double myNextUtility;
    try
    {
      myNextUtility = this.negotiationSession.getUtilitySpace().getUtility(lNext);
    }
    catch (Exception e)
    {
      myNextUtility = 0.0D;
    }
    double lowerAcceptableUtilLimit;
    double lowerAcceptableUtilLimit;
    if (pTimeCase == 2)
    {
      lowerAcceptableUtilLimit = myBestUtil - Math.exp(Math.log(0.5D) / (0.05D * this.negotiationSession.getTimeline().getTotalTime()));
    }
    else
    {
      double lowerAcceptableUtilLimit;
      if (pTimeCase == 0) {
        lowerAcceptableUtilLimit = Math.max(myBestUtil - 0.01D, minUtilAllowed);
      } else {
        lowerAcceptableUtilLimit = Math.min(myBestUtil - 0.01D, minUtilAllowed);
      }
    }
    Iterator<Bid> lbi = this.leftBids.iterator();
    if (this.leftBids.size() > 1)
    {
      lbi.next();
      lbi.next();
    }
    else
    {
      return this.negotiationSession.getOwnBidHistory().getLastBidDetails().getBid();
    }
    while ((myNextUtility > lowerAcceptableUtilLimit) && (myNextUtility <= minUtilAllowed))
    {
      if (pTimeCase == 0) {
        try
        {
          if (myNextUtility < this.negotiationSession.getUtilitySpace().getUtility(this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid()))
          {
            nextBest = this.negotiationSession.getOwnBidHistory().getLastBidDetails().getBid();
            break;
          }
        }
        catch (Exception e) {}
      }
      try
      {
        currentOpponentUtility = this.opponentModel.getBidEvaluation(lNext);
      }
      catch (Exception e)
      {
        currentOpponentUtility = 0.0D;
      }
      if (currentOpponentUtility > lastOpponentUtility)
      {
        lastOpponentUtility = currentOpponentUtility;
        nextBest = lNext;
      }
      if (!lbi.hasNext()) {
        break;
      }
      lNext = (Bid)lbi.next();
      try
      {
        myNextUtility = this.negotiationSession.getUtilitySpace().getUtility(lNext);
      }
      catch (Exception e)
      {
        myNextUtility = 0.0D;
      }
    }
    try
    {
      if (this.negotiationSession.getUtilitySpace().getUtility(nextBest) <= minUtilAllowed) {
        return this.negotiationSession.getOwnBidHistory().getLastBidDetails().getBid();
      }
    }
    catch (Exception e) {}
    this.leftBids.remove(nextBest);
    



    return nextBest;
  }
  
  private class ReverseBidComparator
    implements Comparator<Bid>
  {
    private UtilitySpace usp;
    
    public ReverseBidComparator(UtilitySpace pUsp)
    {
      this.usp = pUsp;
    }
    
    public int compare(Bid b1, Bid b2)
    {
      try
      {
        double u1 = this.usp.getUtility(b1);
        double u2 = this.usp.getUtility(b2);
        if (u1 > u2) {
          return -1;
        }
        if (u1 < u2) {
          return 1;
        }
        return 0;
      }
      catch (Exception e) {}
      return -1;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.anac2010.AgentFSEGA_Offering
 * JD-Core Version:    0.7.1
 */