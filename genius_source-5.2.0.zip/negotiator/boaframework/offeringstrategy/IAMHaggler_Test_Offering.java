package negotiator.boaframework.offeringstrategy;

import Jama.Matrix;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.DiscreteTimeline;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OMStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.offeringstrategy.anac2011.iamhaggler2011.RandomBidCreator;
import negotiator.boaframework.opponentmodel.IAMHagglerOpponentConcessionModel;
import negotiator.tournament.TournamentConfiguration;

public class IAMHaggler_Test_Offering
  extends OfferingStrategy
{
  private IAMHagglerOpponentConcessionModel concessionModel;
  protected RandomBidCreator bidCreator;
  private int amountOfSamples;
  private BidDetails MAX_UTILITY_BID;
  private Matrix variances;
  private Matrix means;
  
  public IAMHaggler_Test_Offering() {}
  
  public IAMHaggler_Test_Offering(NegotiationSession negoSession, OpponentModel model, OMStrategy oms)
    throws Exception
  {
    init(negoSession, model, oms, null);
  }
  
  public void init(NegotiationSession negotiationSession, OpponentModel opponentModel, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negotiationSession, opponentModel, omStrategy, parameters);
    this.negotiationSession = negotiationSession;
    double amountOfRegressions;
    double amountOfRegressions;
    if (parameters.containsKey("r"))
    {
      amountOfRegressions = ((Double)parameters.get("r")).doubleValue();
    }
    else
    {
      amountOfRegressions = 10.0D;
      System.out.println("Using default " + amountOfRegressions + " for amount of regressions.");
    }
    if (parameters.containsKey("s"))
    {
      double value = ((Double)parameters.get("s")).doubleValue();
      this.amountOfSamples = ((int)value);
    }
    else
    {
      this.amountOfSamples = (TournamentConfiguration.getIntegerOption("deadline", 10) / 2);
      
      System.out.println("Using default " + this.amountOfSamples + " for amount of samples.");
    }
    this.concessionModel = new IAMHagglerOpponentConcessionModel((int)amountOfRegressions, negotiationSession.getUtilitySpace(), this.amountOfSamples);
    

    this.bidCreator = new RandomBidCreator();
    this.MAX_UTILITY_BID = negotiationSession.getMaxBidinDomain();
    SortedOutcomeSpace outcomespace = new SortedOutcomeSpace(negotiationSession.getUtilitySpace());
    
    negotiationSession.setOutcomeSpace(outcomespace);
  }
  
  public BidDetails determineOpeningBid()
  {
    if (!this.negotiationSession.getOpponentBidHistory().isEmpty())
    {
      double myUndiscountedUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      

      double time = this.negotiationSession.getTime();
      this.concessionModel.updateModel(myUndiscountedUtil, time);
      System.out.println("IAMHagglerOpponentConcessionModel initialized with u = " + myUndiscountedUtil + ", t = " + time);
    }
    return this.MAX_UTILITY_BID;
  }
  
  public BidDetails determineNextBid()
  {
    double myUndiscountedUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    
    double time = this.negotiationSession.getTime();
    int round = ((DiscreteTimeline)this.negotiationSession.getTimeline()).getRound();
    
    this.concessionModel.updateModel(myUndiscountedUtil, time);
    
    this.variances = this.concessionModel.getVariance();
    this.means = this.concessionModel.getMeans();
    if (this.negotiationSession.getTime() > 0.5D)
    {
      StringWriter variancesWriter = new StringWriter();
      PrintWriter variancesPrintWriter = new PrintWriter(variancesWriter);
      this.variances.print(variancesPrintWriter, 10, 4);
      System.out.println("variances: " + variancesWriter.getBuffer().toString());
      

      StringWriter meanWriter = new StringWriter();
      PrintWriter meanPrintWriter = new PrintWriter(meanWriter);
      this.means.print(meanPrintWriter, 10, 4);
      System.out.println("means: " + meanWriter.getBuffer().toString());
    }
    return this.MAX_UTILITY_BID;
  }
  
  public Matrix getMeans()
  {
    return this.means;
  }
  
  public Matrix getVariances()
  {
    return this.variances;
  }
  
  public int getAmountOfSamples()
  {
    return this.amountOfSamples;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("r", new BigDecimal(36.0D), "Amount of regressions"));
    
    set.add(new BOAparameter("s", new BigDecimal(100.0D), "Amount of time samples"));
    

    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.offeringstrategy.IAMHaggler_Test_Offering
 * JD-Core Version:    0.7.1
 */