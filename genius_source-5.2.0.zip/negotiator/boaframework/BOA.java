package negotiator.boaframework;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import negotiator.NegotiationResult;

public abstract class BOA
{
  protected NegotiationSession negotiationSession;
  
  public void init(NegotiationSession negotiationSession)
  {
    this.negotiationSession = negotiationSession;
  }
  
  public Set<BOAparameter> getParameters()
  {
    return new HashSet();
  }
  
  public void endSession(NegotiationResult result) {}
  
  public abstract void storeData(Serializable paramSerializable);
  
  public abstract Serializable loadData();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.BOA
 * JD-Core Version:    0.7.1
 */