package negotiator.boaframework;

public enum Actions
{
  Accept,  Reject,  Break;
  
  private Actions() {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.Actions
 * JD-Core Version:    0.7.1
 */