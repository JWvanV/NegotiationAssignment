package negotiator.boaframework;

import java.io.Serializable;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import negotiator.boaframework.repository.BOAagentRepository;
import negotiator.boaframework.repository.BOArepItem;

public class BOAcomponent
  implements Serializable
{
  private static final long serialVersionUID = 9055936213274664445L;
  private String classname;
  private ComponentsEnum type;
  private HashMap<String, BigDecimal> parametervalues;
  
  public BOAcomponent(String classname, ComponentsEnum type, HashMap<String, BigDecimal> values)
  {
    if (values == null) {
      throw new NullPointerException("values==null");
    }
    this.classname = classname;
    this.type = type;
    this.parametervalues = values;
  }
  
  public BOAcomponent(String classname, ComponentsEnum type)
  {
    this.classname = classname;
    this.type = type;
    this.parametervalues = new HashMap();
  }
  
  public void addParameter(String name, BigDecimal value)
  {
    this.parametervalues.put(name, value);
  }
  
  public String getClassname()
  {
    return this.classname;
  }
  
  public ComponentsEnum getType()
  {
    return this.type;
  }
  
  public HashMap<String, Double> getParameters()
  {
    return decreaseAccuracy(this.parametervalues);
  }
  
  public HashMap<String, BigDecimal> getFullParameters()
  {
    return this.parametervalues;
  }
  
  private HashMap<String, Double> decreaseAccuracy(HashMap<String, BigDecimal> parameters)
  {
    Iterator<Map.Entry<String, BigDecimal>> it = parameters.entrySet().iterator();
    
    HashMap<String, Double> map = new HashMap();
    while (it.hasNext())
    {
      Map.Entry<String, BigDecimal> pairs = (Map.Entry)it.next();
      
      map.put(pairs.getKey(), Double.valueOf(((BigDecimal)pairs.getValue()).doubleValue()));
    }
    return map;
  }
  
  public String toString()
  {
    String params = "";
    if (this.parametervalues.size() > 0)
    {
      ArrayList<String> keys = new ArrayList(this.parametervalues.keySet());
      
      Collections.sort(keys);
      params = "{";
      for (int i = 0; i < keys.size(); i++)
      {
        params = params + (String)keys.get(i) + "=" + ((BigDecimal)this.parametervalues.get(keys.get(i))).doubleValue();
        if (i < keys.size() - 1) {
          params = params + ", ";
        }
      }
      params = params + "}";
    }
    String shortType = "unknown";
    switch (this.type)
    {
    case BIDDINGSTRATEGY: 
      shortType = "bs";
      break;
    case ACCEPTANCESTRATEGY: 
      shortType = "as";
      break;
    case OPPONENTMODEL: 
      shortType = "om";
      break;
    case OMSTRATEGY: 
      shortType = "oms";
    }
    return shortType + ": " + this.classname + " " + params;
  }
  
  public Set<BOAparameter> getOriginalParameters()
    throws MalformedURLException, InstantiationException, IllegalAccessException, ClassNotFoundException
  {
    return getRepItem().getInstance().getParameters();
  }
  
  private BOArepItem getRepItem()
  {
    BOAagentRepository repo = BOAagentRepository.getInstance();
    switch (this.type)
    {
    case ACCEPTANCESTRATEGY: 
      return repo.getAcceptanceStrategyRepItem(this.classname);
    case BIDDINGSTRATEGY: 
      return repo.getBiddingStrategyRepItem(this.classname);
    case OMSTRATEGY: 
      return repo.getOpponentModelStrategyRepItem(this.classname);
    case OPPONENTMODEL: 
      return repo.getOpponentModelRepItem(this.classname);
    }
    throw new IllegalStateException("BOAcomponent with unknown type encountered:" + this.type);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.BOAcomponent
 * JD-Core Version:    0.7.1
 */