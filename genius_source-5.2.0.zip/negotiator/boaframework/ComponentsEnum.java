package negotiator.boaframework;

public enum ComponentsEnum
{
  BIDDINGSTRATEGY,  ACCEPTANCESTRATEGY,  OPPONENTMODEL,  OMSTRATEGY,  UNKNOWN;
  
  private ComponentsEnum() {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.ComponentsEnum
 * JD-Core Version:    0.7.1
 */