package negotiator.boaframework;

import java.io.Serializable;
import java.util.HashMap;
import negotiator.bidding.BidDetails;

public abstract class OfferingStrategy
  extends BOA
{
  protected BidDetails nextBid;
  protected OpponentModel opponentModel;
  protected OMStrategy omStrategy;
  protected SharedAgentState helper;
  protected boolean endNegotiation;
  
  public void init(NegotiationSession negotiationSession, OpponentModel opponentModel, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negotiationSession);
    this.opponentModel = opponentModel;
    this.omStrategy = omStrategy;
    this.endNegotiation = false;
  }
  
  public abstract BidDetails determineOpeningBid();
  
  public abstract BidDetails determineNextBid();
  
  public BidDetails getNextBid()
  {
    return this.nextBid;
  }
  
  public void setNextBid(BidDetails nextBid)
  {
    this.nextBid = nextBid;
  }
  
  public SharedAgentState getHelper()
  {
    return this.helper;
  }
  
  public boolean isEndNegotiation()
  {
    return this.endNegotiation;
  }
  
  public final void storeData(Serializable object)
  {
    this.negotiationSession.setData(ComponentsEnum.BIDDINGSTRATEGY, object);
  }
  
  public final Serializable loadData()
  {
    return this.negotiationSession.getData(ComponentsEnum.BIDDINGSTRATEGY);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.OfferingStrategy
 * JD-Core Version:    0.7.1
 */