package negotiator.boaframework;

import java.io.Serializable;

public class BOAagentInfo
  implements Serializable
{
  private static final long serialVersionUID = 2868410344415899340L;
  private BOAcomponent offeringStrategy;
  private BOAcomponent acceptanceStrategy;
  private BOAcomponent opponentModel;
  private BOAcomponent omStrategy;
  
  public BOAagentInfo(BOAcomponent bs, BOAcomponent as, BOAcomponent om, BOAcomponent oms)
  {
    this.offeringStrategy = bs;
    this.acceptanceStrategy = as;
    this.opponentModel = om;
    this.omStrategy = oms;
  }
  
  public BOAcomponent getOfferingStrategy()
  {
    return this.offeringStrategy;
  }
  
  public BOAcomponent getAcceptanceStrategy()
  {
    return this.acceptanceStrategy;
  }
  
  public BOAcomponent getOpponentModel()
  {
    return this.opponentModel;
  }
  
  public BOAcomponent getOMStrategy()
  {
    return this.omStrategy;
  }
  
  public String getName()
  {
    return toString();
  }
  
  public String toString()
  {
    String result = this.offeringStrategy + " " + this.acceptanceStrategy + " " + this.opponentModel + " " + this.omStrategy;
    
    return result;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.BOAagentInfo
 * JD-Core Version:    0.7.1
 */