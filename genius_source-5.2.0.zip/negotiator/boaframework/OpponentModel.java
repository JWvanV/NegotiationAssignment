package negotiator.boaframework;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.protocol.BilateralAtomicNegotiationSession;
import negotiator.utility.UtilitySpace;

public abstract class OpponentModel
  extends BOA
{
  protected UtilitySpace opponentUtilitySpace;
  private boolean cleared;
  
  public void init(NegotiationSession negotiationSession, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negotiationSession);
    
    this.opponentUtilitySpace = new UtilitySpace(negotiationSession.getUtilitySpace());
    this.cleared = false;
  }
  
  public void init(NegotiationSession negotiationSession)
  {
    this.negotiationSession = negotiationSession;
    
    this.opponentUtilitySpace = new UtilitySpace(negotiationSession.getUtilitySpace());
    this.cleared = false;
  }
  
  public void updateModel(Bid opponentBid)
  {
    updateModel(opponentBid, this.negotiationSession.getTime());
  }
  
  public abstract void updateModel(Bid paramBid, double paramDouble);
  
  public double getBidEvaluation(Bid bid)
  {
    try
    {
      return this.opponentUtilitySpace.getUtility(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return -1.0D;
  }
  
  public UtilitySpace getOpponentUtilitySpace()
  {
    return this.opponentUtilitySpace;
  }
  
  public void setOpponentUtilitySpace(BilateralAtomicNegotiationSession fNegotiation) {}
  
  public void setOpponentUtilitySpace(UtilitySpace opponentUtilitySpace) {}
  
  public double getWeight(Issue issue)
  {
    return this.opponentUtilitySpace.getWeight(issue.getNumber());
  }
  
  public double[] getIssueWeights()
  {
    double[] estimatedIssueWeights = new double[this.negotiationSession.getUtilitySpace().getDomain().getIssues().size()];
    int i = 0;
    for (Issue issue : this.negotiationSession.getUtilitySpace().getDomain()
      .getIssues())
    {
      estimatedIssueWeights[i] = getWeight(issue);
      i++;
    }
    return estimatedIssueWeights;
  }
  
  public void cleanUp()
  {
    this.negotiationSession = null;
    this.cleared = true;
  }
  
  public boolean isCleared()
  {
    return this.cleared;
  }
  
  public String getName()
  {
    return "Default";
  }
  
  public final void storeData(Serializable object)
  {
    this.negotiationSession.setData(ComponentsEnum.OPPONENTMODEL, object);
  }
  
  public final Serializable loadData()
  {
    return this.negotiationSession.getData(ComponentsEnum.OPPONENTMODEL);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.OpponentModel
 * JD-Core Version:    0.7.1
 */