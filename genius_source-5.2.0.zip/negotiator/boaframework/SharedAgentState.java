package negotiator.boaframework;

public abstract class SharedAgentState
{
  protected String NAME;
  
  public String getName()
  {
    return this.NAME;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.SharedAgentState
 * JD-Core Version:    0.7.1
 */