package negotiator.boaframework;

import java.io.Serializable;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;
import negotiator.issue.Issue;
import negotiator.utility.UtilitySpace;

public class NegotiationSession
{
  protected OutcomeSpace outcomeSpace;
  protected BidHistory opponentBidHistory;
  protected BidHistory ownBidHistory;
  protected Domain domain;
  protected UtilitySpace utilitySpace;
  protected Timeline timeline;
  private SessionData sessionData;
  
  protected NegotiationSession() {}
  
  public NegotiationSession(SessionData sessionData, UtilitySpace utilitySpace, Timeline timeline)
  {
    this(sessionData, utilitySpace, timeline, null);
  }
  
  public NegotiationSession(SessionData sessionData, UtilitySpace utilitySpace, Timeline timeline, OutcomeSpace outcomeSpace)
  {
    this.sessionData = sessionData;
    this.utilitySpace = utilitySpace;
    this.timeline = timeline;
    this.domain = utilitySpace.getDomain();
    this.opponentBidHistory = new BidHistory();
    this.ownBidHistory = new BidHistory();
    this.outcomeSpace = outcomeSpace;
    sessionData = new SessionData();
  }
  
  public BidHistory getOpponentBidHistory()
  {
    return this.opponentBidHistory;
  }
  
  public BidHistory getOwnBidHistory()
  {
    return this.ownBidHistory;
  }
  
  public double getDiscountFactor()
  {
    return this.utilitySpace.getDiscountFactor();
  }
  
  public ArrayList<Issue> getIssues()
  {
    return this.domain.getIssues();
  }
  
  public Timeline getTimeline()
  {
    return this.timeline;
  }
  
  public double getTime()
  {
    return this.timeline.getTime();
  }
  
  public Domain getDomain()
  {
    if (this.utilitySpace != null) {
      return this.utilitySpace.getDomain();
    }
    return null;
  }
  
  public UtilitySpace getUtilitySpace()
  {
    return this.utilitySpace;
  }
  
  public OutcomeSpace getOutcomeSpace()
  {
    return this.outcomeSpace;
  }
  
  public void setOutcomeSpace(OutcomeSpace outcomeSpace)
  {
    this.outcomeSpace = outcomeSpace;
  }
  
  public BidDetails getMaxBidinDomain()
  {
    BidDetails maxBid = null;
    if (this.outcomeSpace == null) {
      try
      {
        Bid maximumBid = this.utilitySpace.getMaxUtilityBid();
        maxBid = new BidDetails(maximumBid, this.utilitySpace.getUtility(maximumBid), -1.0D);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    } else {
      maxBid = this.outcomeSpace.getMaxBidPossible();
    }
    return maxBid;
  }
  
  public BidDetails getMinBidinDomain()
  {
    BidDetails minBid = null;
    if (this.outcomeSpace == null) {
      try
      {
        Bid minimumBidBid = this.utilitySpace.getMinUtilityBid();
        minBid = new BidDetails(minimumBidBid, this.utilitySpace.getUtility(minimumBidBid), -1.0D);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    } else {
      minBid = this.outcomeSpace.getMinBidPossible();
    }
    return minBid;
  }
  
  public void setData(ComponentsEnum component, Serializable data)
  {
    this.sessionData.setData(component, data);
  }
  
  public Serializable getData(ComponentsEnum component)
  {
    return this.sessionData.getData(component);
  }
  
  public double getDiscountedUtility(Bid bid, double time)
  {
    return this.utilitySpace.getUtilityWithDiscount(bid, time);
  }
  
  public SessionData getSessionData()
  {
    return this.sessionData;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.NegotiationSession
 * JD-Core Version:    0.7.1
 */