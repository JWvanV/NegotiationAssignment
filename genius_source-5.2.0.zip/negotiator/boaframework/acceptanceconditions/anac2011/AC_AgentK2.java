package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.HashMap;
import java.util.Random;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.AgentK2SAS;

public class AC_AgentK2
  extends AcceptanceStrategy
{
  private Random random100;
  private boolean activeHelper = false;
  private final boolean TEST_EQUIVALENCE = false;
  
  public AC_AgentK2() {}
  
  public AC_AgentK2(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy os)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.offeringStrategy = os;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("AgentK2")))
    {
      this.helper = new AgentK2SAS(negotiationSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((AgentK2SAS)this.offeringStrategy.getHelper());
    }
    this.random100 = new Random();
  }
  
  public Actions determineAcceptability()
  {
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    if (opponentBid != null)
    {
      double p;
      double p;
      if (this.activeHelper) {
        p = ((AgentK2SAS)this.helper).calculateAcceptProbability();
      } else {
        p = ((AgentK2SAS)this.helper).getAcceptProbability();
      }
      if (p > this.random100.nextDouble()) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_AgentK2
 * JD-Core Version:    0.7.1
 */