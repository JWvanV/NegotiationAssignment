package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.sharedagentstate.anac2011.ValueModelAgentSAS;

public class AC_ValueModelAgent
  extends AcceptanceStrategy
{
  public AC_ValueModelAgent() {}
  
  public AC_ValueModelAgent(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy os)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.offeringStrategy = os;
    if ((os.getHelper() instanceof ValueModelAgentSAS)) {
      this.helper = os.getHelper();
    } else {
      this.helper = new ValueModelAgentSAS();
    }
  }
  
  public Actions determineAcceptability()
  {
    boolean skip = ((ValueModelAgentSAS)this.helper).shouldSkipAcceptDueToCrash();
    if (this.negotiationSession.getOpponentBidHistory().size() > 0)
    {
      if ((!skip) && (this.negotiationSession.getTime() > 0.98D) && (this.negotiationSession.getTime() <= 0.99D) && 
        (((ValueModelAgentSAS)this.helper).getOpponentUtil() >= ((ValueModelAgentSAS)this.helper).getLowestApprovedInitial() - 0.01D)) {
        return Actions.Accept;
      }
      if ((!skip) && (this.negotiationSession.getTime() > 0.995D) && (((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() > 0.55D) && 
        (((ValueModelAgentSAS)this.helper).getOpponentUtil() >= ((ValueModelAgentSAS)this.helper).getOpponentMaxBidUtil() * 0.99D)) {
        return Actions.Accept;
      }
      if ((!skip) && (((ValueModelAgentSAS)this.helper).getOpponentUtil() > ((ValueModelAgentSAS)this.helper).getLowestApproved()) && ((this.negotiationSession.getDiscountFactor() > 0.02D) || (((ValueModelAgentSAS)this.helper).getOpponentUtil() > 0.975D))) {
        return Actions.Accept;
      }
      if ((!skip) && (this.negotiationSession.getTime() > 0.9D) && 
        (((ValueModelAgentSAS)this.helper).getOpponentUtil() >= ((ValueModelAgentSAS)this.helper).getPlannedThreshold() - 0.01D)) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_ValueModelAgent
 * JD-Core Version:    0.7.1
 */