package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.TheNegotiatorSAS;

public class AC_TheNegotiator
  extends AcceptanceStrategy
{
  public AC_TheNegotiator() {}
  
  public AC_TheNegotiator(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("TheNegotiator"))) {
      this.helper = new TheNegotiatorSAS(this.negotiationSession);
    } else {
      this.helper = ((TheNegotiatorSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    Actions decision = Actions.Reject;
    double utility = 0.0D;
    try
    {
      if (this.negotiationSession.getOpponentBidHistory().getHistory().size() > 0) {
        utility = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    int phase = ((TheNegotiatorSAS)this.helper).calculateCurrentPhase(this.negotiationSession.getTime());
    int movesLeft = ((TheNegotiatorSAS)this.helper).calculateMovesLeft();
    double threshold = ((TheNegotiatorSAS)this.helper).calculateThreshold(this.negotiationSession.getTime());
    if (phase < 3)
    {
      if (utility >= threshold) {
        decision = Actions.Accept;
      }
    }
    else if (movesLeft >= 15)
    {
      if (utility >= threshold) {
        decision = Actions.Accept;
      }
    }
    else if (movesLeft < 15) {
      decision = Actions.Accept;
    }
    return decision;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_TheNegotiator
 * JD-Core Version:    0.7.1
 */