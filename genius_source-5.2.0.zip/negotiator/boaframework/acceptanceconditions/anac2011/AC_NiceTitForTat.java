package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.NiceTitForTatSAS;
import negotiator.utility.UtilitySpace;

public class AC_NiceTitForTat
  extends AcceptanceStrategy
{
  public AC_NiceTitForTat() {}
  
  public AC_NiceTitForTat(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("NiceTitForTat"))) {
      this.helper = new NiceTitForTatSAS(this.negotiationSession);
    } else {
      this.helper = ((NiceTitForTatSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    if (isAcceptable())
    {
      BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
      
      double offeredUtility = opponentBid.getMyUndiscountedUtil();
      double now = this.negotiationSession.getTime();
      double timeLeft = 1.0D - now;
      
      BidHistory recentBids = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(now - timeLeft, now);
      int expectedBids = recentBids.size();
      
      BidDetails bestBid = this.negotiationSession.getOpponentBidHistory().getBestBidDetails();
      double bestBidUtility = bestBid.getMyUndiscountedUtil();
      if ((expectedBids <= 1) || (bestBidUtility <= offeredUtility)) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
  
  public boolean isAcceptable()
  {
    double time = this.negotiationSession.getTime();
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    BidDetails myNextBid = this.offeringStrategy.getNextBid();
    try
    {
      if (this.negotiationSession.getUtilitySpace().getUtility(opponentBid.getBid()) >= myNextBid.getMyUndiscountedUtil()) {
        return true;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if (time < 0.98D) {
      return false;
    }
    double offeredUndiscountedUtility = opponentBid.getMyUndiscountedUtil();
    double now = time;
    double timeLeft = 1.0D - now;
    

    ArrayList<BidDetails> recentBids = ((NiceTitForTatSAS)this.helper).filterBetweenTime(now - timeLeft, now);
    int recentBidsSize = recentBids.size();
    int enoughBidsToCome = 10;
    if (((NiceTitForTatSAS)this.helper).isDomainBig()) {
      enoughBidsToCome = 40;
    }
    if (recentBidsSize > enoughBidsToCome) {
      return false;
    }
    double window = timeLeft;
    ArrayList<BidDetails> recentBetterBids = ((NiceTitForTatSAS)this.helper).filterBetween(offeredUndiscountedUtility, 1.0D, now - window, now);
    int n = recentBetterBids.size();
    double p = timeLeft / window;
    if (p > 1.0D) {
      p = 1.0D;
    }
    double pAllMiss = Math.pow(1.0D - p, n);
    if (n == 0) {
      pAllMiss = 1.0D;
    }
    double pAtLeastOneHit = 1.0D - pAllMiss;
    
    double avg = getAverageUtility(recentBetterBids);
    
    double expectedUtilOfWaitingForABetterBid = pAtLeastOneHit * avg;
    if (offeredUndiscountedUtility > expectedUtilOfWaitingForABetterBid) {
      return true;
    }
    return false;
  }
  
  public double getAverageUtility(ArrayList<BidDetails> list)
  {
    int size = list.size();
    if (size == 0) {
      return 0.0D;
    }
    double totalUtil = 0.0D;
    for (BidDetails b : list) {
      totalUtil += b.getMyUndiscountedUtil();
    }
    return totalUtil / size;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_NiceTitForTat
 * JD-Core Version:    0.7.1
 */