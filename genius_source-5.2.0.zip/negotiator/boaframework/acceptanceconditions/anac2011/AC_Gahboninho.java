package negotiator.boaframework.acceptanceconditions.anac2011;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.GahboninhoSAS;
import negotiator.boaframework.sharedagentstate.anac2011.gahboninho.GahboninhoOM;
import negotiator.boaframework.sharedagentstate.anac2011.gahboninho.IssueManager;

public class AC_Gahboninho
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private boolean done = false;
  
  public AC_Gahboninho() {}
  
  public AC_Gahboninho(NegotiationSession negotiationSession, OfferingStrategy offeringStrategy)
  {
    initializeAgent(negotiationSession, offeringStrategy);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    System.out.println("offering: " + strat);
    
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negoSession, OfferingStrategy strat)
  {
    this.negotiationSession = negoSession;
    System.out.println("negotiationSession: " + this.negotiationSession);
    
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() != null) && (this.offeringStrategy.getHelper().getName().equals("Gahboninho")))
    {
      this.helper = this.offeringStrategy.getHelper();
    }
    else
    {
      this.helper = new GahboninhoSAS(this.negotiationSession);
      this.activeHelper = true;
    }
  }
  
  public Actions determineAcceptability()
  {
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    if (this.activeHelper) {
      if (this.negotiationSession.getOpponentBidHistory().getHistory().size() < 2) {
        try
        {
          ((GahboninhoSAS)this.helper).getIssueManager().ProcessOpponentBid(opponentBid.getBid());
          ((GahboninhoSAS)this.helper).getOpponentModel().UpdateImportance(opponentBid.getBid());
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      } else {
        try
        {
          if (!this.done)
          {
            ((GahboninhoSAS)this.helper).getIssueManager().learnBids(opponentBid.getBid());
            this.done = true;
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
    if ((((GahboninhoSAS)this.helper).getFirstActions() > 0) && (opponentBid != null) && 
      (opponentBid.getMyUndiscountedUtil() > 0.95D)) {
      return Actions.Accept;
    }
    if ((opponentBid != null) && (opponentBid.getMyUndiscountedUtil() >= ((GahboninhoSAS)this.helper).getIssueManager().getMinimumUtilForAcceptance())) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_Gahboninho
 * JD-Core Version:    0.7.1
 */