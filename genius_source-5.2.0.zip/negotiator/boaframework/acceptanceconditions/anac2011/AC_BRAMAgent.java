package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.BRAMAgentSAS;
import negotiator.utility.UtilitySpace;

public class AC_BRAMAgent
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private BidDetails bestBid;
  private Bid worstBid;
  
  public AC_BRAMAgent() {}
  
  public AC_BRAMAgent(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.bestBid = negoSession.getMaxBidinDomain();
    this.worstBid = negoSession.getUtilitySpace().getMinUtilityBid();
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("BRAMAgent")))
    {
      this.helper = new BRAMAgentSAS(this.negotiationSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((BRAMAgentSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    double offeredUtility = this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid(), this.negotiationSession.getTime());
    double threshold;
    double threshold;
    if (this.activeHelper) {
      threshold = ((BRAMAgentSAS)this.helper).getNewThreshold(this.worstBid, this.bestBid.getBid());
    } else {
      threshold = ((BRAMAgentSAS)this.helper).getThreshold();
    }
    double nextBidDiscounted = this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(this.offeringStrategy.getNextBid().getBid(), this.negotiationSession.getTime());
    if ((offeredUtility >= threshold) || ((this.offeringStrategy.getNextBid() != null) && (offeredUtility >= nextBidDiscounted))) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_BRAMAgent
 * JD-Core Version:    0.7.1
 */