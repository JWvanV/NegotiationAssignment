package negotiator.boaframework.acceptanceconditions.anac2011;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.HardHeadedSAS;

public class AC_HardHeaded
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private double prevUtil = 1.0D;
  private double lowestOfferBidUtil = 1.0D;
  
  public AC_HardHeaded() {}
  
  public AC_HardHeaded(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("HardHeaded")))
    {
      this.helper = new HardHeadedSAS(negoSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((HardHeadedSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    BidDetails opponentsLastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    if (this.activeHelper)
    {
      this.prevUtil = ((HardHeadedSAS)this.helper).getLowestUtilityYet();
    }
    else
    {
      if (this.lowestOfferBidUtil != this.prevUtil) {
        this.prevUtil = this.lowestOfferBidUtil;
      }
      this.lowestOfferBidUtil = ((HardHeadedSAS)this.helper).getLowestYetUtility();
    }
    double util = 0.0D;
    try
    {
      util = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if ((opponentsLastBid != null) && (
      (opponentsLastBid.getMyUndiscountedUtil() > this.prevUtil) || 
      (util <= opponentsLastBid.getMyUndiscountedUtil()))) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2011.AC_HardHeaded
 * JD-Core Version:    0.7.1
 */