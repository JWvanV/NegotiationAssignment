package negotiator.boaframework.acceptanceconditions.anac2010;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_AgentSmith
  extends AcceptanceStrategy
{
  private final double ACCEPT_MARGIN = 0.9D;
  
  public AC_AgentSmith() {}
  
  public AC_AgentSmith(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
  }
  
  public Actions determineAcceptability()
  {
    BidDetails lastOpponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    BidDetails lastOwnBid = this.negotiationSession.getOwnBidHistory().getLastBidDetails();
    if ((lastOpponentBid != null) && (lastOwnBid != null)) {
      if ((lastOpponentBid.getMyUndiscountedUtil() > 0.9D) || (lastOpponentBid.getMyUndiscountedUtil() >= lastOwnBid.getMyUndiscountedUtil())) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2010.AC_AgentSmith
 * JD-Core Version:    0.7.1
 */