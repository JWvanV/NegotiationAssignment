package negotiator.boaframework.acceptanceconditions.anac2010;

import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_AgentFSEGA
  extends AcceptanceStrategy
{
  private double maxUtilInDomain;
  
  public AC_AgentFSEGA() {}
  
  public AC_AgentFSEGA(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.maxUtilInDomain = this.negotiationSession.getMaxBidinDomain().getMyUndiscountedUtil();
  }
  
  public Actions determineAcceptability()
  {
    if ((this.negotiationSession.getOpponentBidHistory().getHistory().isEmpty()) || 
      (this.negotiationSession.getOwnBidHistory().getHistory().isEmpty())) {
      return Actions.Reject;
    }
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    double lastMyBidUtil = this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    if ((lastOpponentBidUtil * 1.03D >= lastMyBidUtil) || (lastOpponentBidUtil > nextMyBidUtil) || (lastOpponentBidUtil == this.maxUtilInDomain)) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2010.AC_AgentFSEGA
 * JD-Core Version:    0.7.1
 */