package negotiator.boaframework.acceptanceconditions.anac2010;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_IAMcrazyHaggler
  extends AcceptanceStrategy
{
  private double maximum_aspiration = 0.85D;
  private final double acceptMultiplier = 1.02D;
  
  public AC_IAMcrazyHaggler() {}
  
  public AC_IAMcrazyHaggler(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if (this.negotiationSession.getDiscountFactor() == 0.0D) {
      this.maximum_aspiration = 0.9D;
    }
  }
  
  public Actions determineAcceptability()
  {
    if ((this.negotiationSession.getOpponentBidHistory() != null) && (this.negotiationSession.getOwnBidHistory().getLastBidDetails() != null))
    {
      double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      double lastMyBidUtil = this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      if ((lastOpponentBidUtil * 1.02D > lastMyBidUtil) || 
        (lastOpponentBidUtil * 1.02D > this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) || (lastOpponentBidUtil * 1.02D > this.maximum_aspiration)) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2010.AC_IAMcrazyHaggler
 * JD-Core Version:    0.7.1
 */