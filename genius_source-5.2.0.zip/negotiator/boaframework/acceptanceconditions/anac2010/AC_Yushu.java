package negotiator.boaframework.acceptanceconditions.anac2010;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2010.YushuSAS;

public class AC_Yushu
  extends AcceptanceStrategy
{
  private double roundleft;
  
  public AC_Yushu() {}
  
  public AC_Yushu(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("Yushu"))) {
      this.helper = new YushuSAS(this.negotiationSession);
    } else {
      this.helper = ((YushuSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    BidDetails myBid = this.negotiationSession.getOwnBidHistory().getLastBidDetails();
    this.roundleft = ((YushuSAS)this.helper).getRoundLeft();
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("Yushu"))) {
      ((YushuSAS)this.helper).updateBelief(opponentBid);
    }
    BidDetails suggestedBid = ((YushuSAS)this.helper).getSuggestBid();
    double acceptableUtil = ((YushuSAS)this.helper).getAcceptableUtil();
    if (opponentBid != null)
    {
      double targetUtil;
      double targetUtil;
      if (myBid == null)
      {
        targetUtil = 1.0D;
      }
      else
      {
        double targetUtil;
        if ((this.offeringStrategy.getHelper() != null) && (this.offeringStrategy.getHelper().getName().equals("Yushu"))) {
          targetUtil = ((YushuSAS)this.helper).getTargetUtil();
        } else {
          targetUtil = ((YushuSAS)this.helper).calculateTargetUtility();
        }
      }
      if (((opponentBid.getMyUndiscountedUtil() >= targetUtil ? 1 : 0) | (opponentBid.getMyUndiscountedUtil() >= acceptableUtil ? 1 : 0)) != 0)
      {
        if ((suggestedBid == null) || (this.roundleft < 8.0D)) {
          return Actions.Accept;
        }
        if ((suggestedBid != null) && (this.roundleft > 8.0D) && 
          (suggestedBid.getMyUndiscountedUtil() <= opponentBid.getMyUndiscountedUtil())) {
          return Actions.Accept;
        }
      }
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2010.AC_Yushu
 * JD-Core Version:    0.7.1
 */