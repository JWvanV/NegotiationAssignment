package negotiator.boaframework.acceptanceconditions.anac2010;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2010.NozomiSAS;
import negotiator.issue.Issue;
import negotiator.issue.IssueReal;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.UtilitySpace;

public class AC_Nozomi
  extends AcceptanceStrategy
{
  private double maxUtilityOfPartnerBid = 0.0D;
  private int measureT = 1;
  private int continuousKeep = 0;
  private BidDetails maxBid;
  
  public AC_Nozomi() {}
  
  public AC_Nozomi(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("Nozomi"))) {
      this.helper = new NozomiSAS(this.negotiationSession, this.offeringStrategy.getNextBid());
    } else {
      this.helper = ((NozomiSAS)this.offeringStrategy.getHelper());
    }
    this.maxBid = this.negotiationSession.getMaxBidinDomain();
    try
    {
      ((NozomiSAS)this.helper).setRestoreBid(this.negotiationSession.getUtilitySpace().getMaxUtilityBid());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public Actions determineAcceptability()
  {
    try
    {
      BidDetails prevBid = this.negotiationSession.getOwnBidHistory().getLastBidDetails();
      BidDetails partnerBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
      double prevUtility;
      double prevUtility;
      if (!this.negotiationSession.getOwnBidHistory().getHistory().isEmpty()) {
        prevUtility = this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      } else {
        prevUtility = 1.0D;
      }
      double offeredUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      double time = this.negotiationSession.getTime();
      
      ArrayList<BidDetails> list = (ArrayList)this.negotiationSession.getOpponentBidHistory().getHistory();
      BidHistory historyList = new BidHistory((ArrayList)list.clone());
      BidDetails lastBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
      historyList.getHistory().remove(lastBid);
      if (!historyList.getHistory().isEmpty()) {
        this.maxUtilityOfPartnerBid = historyList.getBestBidDetails().getMyUndiscountedUtil();
      }
      if (this.maxUtilityOfPartnerBid > ((NozomiSAS)this.helper).getMaxCompromiseUtility()) {
        ((NozomiSAS)this.helper).setMaxCompromiseUtility(this.maxUtilityOfPartnerBid);
      }
      if (((NozomiSAS)this.helper).getMaxCompromiseUtility() > this.maxBid.getMyUndiscountedUtil() * 0.95D) {
        ((NozomiSAS)this.helper).setMaxCompromiseUtility(this.maxBid.getMyUndiscountedUtil() * 0.95D);
      }
      if ((this.continuousKeep <= 0) && 
        (this.helper != this.offeringStrategy.getHelper())) {
        ((NozomiSAS)this.helper).updateRestoreBid(this.offeringStrategy.getNextBid().getBid());
      }
      if (time > this.measureT * 3.0D)
      {
        if (this.helper != this.offeringStrategy.getHelper()) {
          ((NozomiSAS)this.helper).checkCompromise(time);
        }
        this.measureT += 1;
      }
      if ((this.negotiationSession.getOwnBidHistory().getLastBidDetails() != null) && (this.offeringStrategy.getNextBid().getMyUndiscountedUtil() == this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil())) {
        this.continuousKeep += 1;
      } else {
        this.continuousKeep = 0;
      }
      if (offeredUtil > this.maxUtilityOfPartnerBid)
      {
        ((NozomiSAS)this.helper).setMaxUtilityPartnerBidDetails(partnerBid);
        this.maxUtilityOfPartnerBid = offeredUtil;
        ((NozomiSAS)this.helper).setUpdateMaxPartnerUtility(true);
      }
      if ((offeredUtil > this.maxBid.getMyUndiscountedUtil() * 0.95D) || (offeredUtil >= prevUtility)) {
        return Actions.Accept;
      }
      ArrayList<Issue> issues = this.negotiationSession.getIssues();
      
      double evalGap = 0.0D;
      for (Issue issue : issues)
      {
        int issueID = issue.getNumber();
        switch (issue.getType())
        {
        case REAL: 
          IssueReal issueReal = (IssueReal)issue;
          ValueReal valueReal = (ValueReal)prevBid.getBid().getValue(issueID);
          ValueReal partnerValueReal = (ValueReal)partnerBid.getBid().getValue(issueID);
          double gap = Math.abs(valueReal.getValue() - partnerValueReal.getValue());
          if (gap > (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) {
            evalGap += 0.5D;
          }
          break;
        default: 
          if ((prevBid != null) && (!prevBid.getBid().getValue(issueID).equals(partnerBid.getBid().getValue(issueID)))) {
            evalGap += 0.5D;
          }
          break;
        }
        Evaluator eval = this.negotiationSession.getUtilitySpace().getEvaluator(issueID);
        try
        {
          evalGap += Math.abs(eval.getEvaluation(this.negotiationSession.getUtilitySpace(), prevBid.getBid(), issueID).doubleValue() - eval.getEvaluation(this.negotiationSession.getUtilitySpace(), partnerBid.getBid(), issueID).doubleValue());
        }
        catch (Exception e)
        {
          evalGap += 1.0D;
        }
        evalGap += 0.5D;
      }
      evalGap /= 2.0D * issues.size();
      if (time < 0.5D)
      {
        if ((this.negotiationSession.getOpponentBidHistory().getLastBidDetails() != null) && (offeredUtil > ((NozomiSAS)this.helper).getMaxCompromiseUtility()) && (offeredUtil >= this.maxUtilityOfPartnerBid))
        {
          double acceptCoefficient = -0.1D * time + 1.0D;
          if ((evalGap < 0.3D) && (offeredUtil > prevUtility * acceptCoefficient)) {
            return Actions.Accept;
          }
        }
      }
      else if (time < 0.8D)
      {
        if ((this.negotiationSession.getOpponentBidHistory().getLastBidDetails() != null) && (offeredUtil > ((NozomiSAS)this.helper).getMaxCompromiseUtility() * 0.95D) && (offeredUtil > this.maxUtilityOfPartnerBid * 0.95D))
        {
          double diffMyBidAndOffered = prevUtility - offeredUtil;
          if (diffMyBidAndOffered < 0.0D) {
            diffMyBidAndOffered = 0.0D;
          }
          double acceptCoefficient = -0.16D * (time - 0.5D) + 0.95D;
          if ((evalGap < 0.35D) && (offeredUtil > prevUtility * acceptCoefficient)) {
            return Actions.Accept;
          }
        }
      }
      else if ((this.negotiationSession.getOpponentBidHistory().getLastBidDetails() != null) && (offeredUtil > ((NozomiSAS)this.helper).getPrevMaxCompromiseUtility() * 0.9D) && (offeredUtil > this.maxUtilityOfPartnerBid * 0.95D))
      {
        double restoreEvalGap = 0.0D;
        for (Issue issue : issues)
        {
          int issueID = issue.getNumber();
          switch (issue.getType())
          {
          case REAL: 
            IssueReal issueReal = (IssueReal)issue;
            ValueReal valueReal = (ValueReal)((NozomiSAS)this.helper).getPrevRestoreBid().getValue(issueID);
            ValueReal partnerValueReal = (ValueReal)partnerBid.getBid().getValue(issueID);
            double gap = Math.abs(valueReal.getValue() - partnerValueReal.getValue());
            if (gap > (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) {
              restoreEvalGap += 0.5D;
            }
            break;
          default: 
            if (!((NozomiSAS)this.helper).getPrevRestoreBid().getValue(issueID).equals(partnerBid.getBid().getValue(issueID))) {
              restoreEvalGap += 0.5D;
            }
            break;
          }
          Evaluator eval = this.negotiationSession.getUtilitySpace().getEvaluator(issueID);
          try
          {
            restoreEvalGap += Math.abs(eval.getEvaluation(this.negotiationSession.getUtilitySpace(), prevBid.getBid(), issueID).doubleValue() - eval.getEvaluation(this.negotiationSession.getUtilitySpace(), partnerBid.getBid(), issueID).doubleValue());
          }
          catch (Exception e)
          {
            restoreEvalGap += 1.0D;
          }
          restoreEvalGap += 0.5D;
        }
        restoreEvalGap /= 2.0D * issues.size();
        
        double threshold = 0.4D;
        if (time > 0.9D) {
          threshold = 0.5D;
        }
        if ((restoreEvalGap <= threshold) || (evalGap <= threshold)) {
          return Actions.Accept;
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      return Actions.Reject;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2010.AC_Nozomi
 * JD-Core Version:    0.7.1
 */