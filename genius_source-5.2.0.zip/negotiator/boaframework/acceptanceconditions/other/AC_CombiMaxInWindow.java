package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiMaxInWindow
  extends AcceptanceStrategy
{
  private double time;
  
  public AC_CombiMaxInWindow() {}
  
  public AC_CombiMaxInWindow(NegotiationSession negoSession, OfferingStrategy strat, double t)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if (parameters.get("t") != null) {
      this.time = ((Double)parameters.get("t")).doubleValue();
    } else {
      throw new Exception("Parameters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[t: " + this.time + "]";
  }
  
  public Actions determineAcceptability()
  {
    if (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() >= this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getTime() < this.time) {
      return Actions.Reject;
    }
    double offeredUndiscountedUtility = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    double now = this.negotiationSession.getTime();
    double timeLeft = 1.0D - now;
    

    double window = timeLeft;
    
    BidHistory recentBids = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(now - window, now);
    double max;
    double max;
    if (recentBids.size() > 0) {
      max = recentBids.getBestBidDetails().getMyUndiscountedUtil();
    } else {
      max = 0.0D;
    }
    double expectedUtilOfWaitingForABetterBid = max;
    if (offeredUndiscountedUtility >= expectedUtilOfWaitingForABetterBid) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("t", new BigDecimal(0.98D), "Time t after which the agent may accept"));
    

    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiMaxInWindow
 * JD-Core Version:    0.7.1
 */