package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_Const
  extends AcceptanceStrategy
{
  private double constant;
  
  public AC_Const() {}
  
  public AC_Const(NegotiationSession negoSession, double c)
  {
    this.negotiationSession = negoSession;
    this.constant = c;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    if (parameters.get("c") != null) {
      this.constant = ((Double)parameters.get("c")).doubleValue();
    } else {
      throw new Exception("Constant \"c\" for the threshold was not set.");
    }
  }
  
  public String printParameters()
  {
    return "[c: " + this.constant + "]";
  }
  
  public Actions determineAcceptability()
  {
    BidDetails opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    if (opponentBid.getMyUndiscountedUtil() > this.constant) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("c", new BigDecimal(0.9D), "If utility of opponent's bid greater than c, then accept"));
    

    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_Const
 * JD-Core Version:    0.7.1
 */