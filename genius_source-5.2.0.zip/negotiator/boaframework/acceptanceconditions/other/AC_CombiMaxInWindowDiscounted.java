package negotiator.boaframework.acceptanceconditions.other;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiMaxInWindowDiscounted
  extends AcceptanceStrategy
{
  private double time;
  
  public AC_CombiMaxInWindowDiscounted() {}
  
  public AC_CombiMaxInWindowDiscounted(NegotiationSession negoSession, OfferingStrategy strat, double t)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if (parameters.get("t") != null) {
      this.time = ((Double)parameters.get("t")).doubleValue();
    } else {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[t: " + this.time + "]";
  }
  
  public Actions determineAcceptability()
  {
    if (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() >= this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getTime() < this.time) {
      return Actions.Reject;
    }
    BidDetails opponentLastOffer = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    double offeredDiscountedUtility = this.negotiationSession.getDiscountedUtility(opponentLastOffer.getBid(), opponentLastOffer.getTime());
    double now = this.negotiationSession.getTime();
    double timeLeft = 1.0D - now;
    

    double window = timeLeft;
    BidHistory recentBids = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(now - window, now);
    double max;
    double max;
    if (recentBids.size() > 0)
    {
      BidDetails maxDiscountedBidDetail = recentBids.getBestDiscountedBidDetails(this.negotiationSession.getUtilitySpace());
      max = this.negotiationSession.getDiscountedUtility(maxDiscountedBidDetail.getBid(), maxDiscountedBidDetail.getTime());
    }
    else
    {
      max = 0.0D;
    }
    double expectedUtilOfWaitingForABetterBid = max;
    if (offeredDiscountedUtility >= expectedUtilOfWaitingForABetterBid) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiMaxInWindowDiscounted
 * JD-Core Version:    0.7.1
 */