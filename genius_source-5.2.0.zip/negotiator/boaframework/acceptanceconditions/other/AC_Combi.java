package negotiator.boaframework.acceptanceconditions.other;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_Combi
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  private double time;
  
  public AC_Combi() {}
  
  public AC_Combi(NegotiationSession negoSession, OfferingStrategy strat, double a, double b, double t, double c)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.a = a;
    this.b = b;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    if ((parameters.get("c") != null) && (parameters.get("t") != null))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
      this.time = ((Double)parameters.get("t")).doubleValue();
    }
    else
    {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[a: " + this.a + " b: " + this.b + " t: " + this.time + "]";
  }
  
  public Actions determineAcceptability()
  {
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    if ((this.a * lastOpponentBidUtil + this.b >= nextMyBidUtil) || (this.negotiationSession.getTime() >= this.time)) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_Combi
 * JD-Core Version:    0.7.1
 */