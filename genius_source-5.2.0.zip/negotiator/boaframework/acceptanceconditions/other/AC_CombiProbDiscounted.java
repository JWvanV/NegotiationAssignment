package negotiator.boaframework.acceptanceconditions.other;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiProbDiscounted
  extends AcceptanceStrategy
{
  private double time;
  
  public AC_CombiProbDiscounted() {}
  
  public AC_CombiProbDiscounted(NegotiationSession negoSession, OfferingStrategy strat, double t)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    if (parameters.get("t") != null) {
      this.time = ((Double)parameters.get("t")).doubleValue();
    } else {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[t: " + this.time + "]";
  }
  
  public Actions determineAcceptability()
  {
    if (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() >= this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getTime() < this.time) {
      return Actions.Reject;
    }
    BidDetails opponentLastOffer = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    double offeredDiscountedUtility = this.negotiationSession.getDiscountedUtility(opponentLastOffer.getBid(), opponentLastOffer.getTime());
    double now = this.negotiationSession.getTime();
    double timeLeft = 1.0D - now;
    

    BidHistory recentBids = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(now - timeLeft, now);
    
    int remainingBids = recentBids.size();
    if (remainingBids > 10) {
      return Actions.Reject;
    }
    double window = timeLeft;
    
    BidHistory recentBetterBids = this.negotiationSession.getOpponentBidHistory().discountedFilterBetween(offeredDiscountedUtility, 1.0D, now - window, now, this.negotiationSession.getUtilitySpace());
    
    int n = recentBetterBids.size();
    double p = timeLeft / window;
    if (p > 1.0D) {
      p = 1.0D;
    }
    double pAllMiss = Math.pow(1.0D - p, n);
    if (n == 0) {
      pAllMiss = 1.0D;
    }
    double pAtLeastOneHit = 1.0D - pAllMiss;
    
    double avg = recentBetterBids.getAverageDiscountedUtility(this.negotiationSession.getUtilitySpace());
    
    double expectedUtilOfWaitingForABetterBid = pAtLeastOneHit * avg;
    if (offeredDiscountedUtility > expectedUtilOfWaitingForABetterBid) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiProbDiscounted
 * JD-Core Version:    0.7.1
 */