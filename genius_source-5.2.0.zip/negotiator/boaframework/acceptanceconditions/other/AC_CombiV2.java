package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiV2
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  private double c;
  private double d;
  private double time;
  
  public AC_CombiV2() {}
  
  public AC_CombiV2(NegotiationSession negoSession, OfferingStrategy strat, double a, double b, double t, double c, double d)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.a = a;
    this.b = b;
    this.c = c;
    this.d = d;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((parameters.get("a") != null) || (parameters.get("b") != null) || ((parameters.get("c") != null) && (parameters.get("t") != null)))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
      this.c = ((Double)parameters.get("c")).doubleValue();
      this.d = ((Double)parameters.get("d")).doubleValue();
      this.time = ((Double)parameters.get("t")).doubleValue();
    }
    else
    {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[a: " + this.a + " b: " + this.b + " t: " + this.time + " c: " + this.c + " d: " + this.d + "]";
  }
  
  public Actions determineAcceptability()
  {
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    if (lastOpponentBidUtil > this.d) {
      return Actions.Accept;
    }
    if ((this.negotiationSession.getDiscountFactor() != 0.0D) && (this.c < this.negotiationSession.getDiscountFactor()))
    {
      if (this.a * lastOpponentBidUtil + this.b >= nextMyBidUtil) {
        return Actions.Accept;
      }
    }
    else if ((this.a * lastOpponentBidUtil + this.b >= nextMyBidUtil) && (this.negotiationSession.getTime() >= this.time)) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Multiplier"));
    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Constant"));
    set.add(new BOAparameter("c", new BigDecimal(0.8D), "Threshold discount"));
    set.add(new BOAparameter("d", new BigDecimal(0.95D), "Threshold"));
    set.add(new BOAparameter("t", new BigDecimal(0.99D), "Time"));
    
    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiV2
 * JD-Core Version:    0.7.1
 */