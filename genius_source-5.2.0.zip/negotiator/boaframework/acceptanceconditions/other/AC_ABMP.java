package negotiator.boaframework.acceptanceconditions.other;

import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;

public class AC_ABMP
  extends AcceptanceStrategy
{
  private static final double UTIlITYGAPSIZE = 0.05D;
  
  public AC_ABMP() {}
  
  public AC_ABMP(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public Actions determineAcceptability()
  {
    Actions decision = Actions.Reject;
    if (this.negotiationSession.getOwnBidHistory().getLastBidDetails() != null) {
      if (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() >= this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil() - 0.05D) {
        decision = Actions.Accept;
      }
    }
    return decision;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_ABMP
 * JD-Core Version:    0.7.1
 */