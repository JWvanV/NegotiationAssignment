package negotiator.boaframework.acceptanceconditions.other;

import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiMax
  extends AcceptanceStrategy
{
  private double time;
  
  public AC_CombiMax() {}
  
  public AC_CombiMax(NegotiationSession negoSession, OfferingStrategy strat, double time)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.time = time;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    if (parameters.get("t") != null) {
      this.time = ((Double)parameters.get("t")).doubleValue();
    } else {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[t: " + this.time + "]";
  }
  
  public Actions determineAcceptability()
  {
    if (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() >= this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getTime() < this.time) {
      return Actions.Reject;
    }
    double offeredUndiscountedUtility = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    double bestUtil = this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getMyUndiscountedUtil();
    if (offeredUndiscountedUtility >= bestUtil) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiMax
 * JD-Core Version:    0.7.1
 */