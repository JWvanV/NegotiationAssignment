package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_Previous
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  
  public AC_Previous() {}
  
  public AC_Previous(NegotiationSession negoSession, double alpha, double beta)
  {
    this.negotiationSession = negoSession;
    this.a = alpha;
    this.b = beta;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    if ((parameters.get("a") != null) || (parameters.get("b") != null))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
    }
    else
    {
      throw new Exception("Parameters were not set.");
    }
  }
  
  public String printParameters()
  {
    String str = "[a: " + this.a + " b: " + this.b + "]";
    return str;
  }
  
  public Actions determineAcceptability()
  {
    if (!this.negotiationSession.getOwnBidHistory().getHistory().isEmpty())
    {
      double opponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      
      double ownLastBidUtil = this.negotiationSession.getOwnBidHistory().getLastBidDetails().getMyUndiscountedUtil();
      if (this.a * opponentBidUtil + this.b >= ownLastBidUtil) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Accept when the opponent's utility * a + b is greater than the utility of our previous bid"));
    


    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Accept when the opponent's utility * a + b is greater than the utility of our previous bid"));
    



    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_Previous
 * JD-Core Version:    0.7.1
 */