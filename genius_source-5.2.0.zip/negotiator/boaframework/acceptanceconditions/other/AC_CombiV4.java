package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiV4
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  private double c;
  private double d;
  private double e;
  private boolean discountedDomain;
  
  public AC_CombiV4() {}
  
  public AC_CombiV4(NegotiationSession negoSession, OfferingStrategy strat, double a, double b, double c, double d, double e)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.a = a;
    this.b = b;
    this.c = c;
    this.d = d;
    this.e = e;
    if ((this.negotiationSession.getDiscountFactor() < 1.E-005D) || (this.negotiationSession.getDiscountFactor() > e)) {
      this.discountedDomain = false;
    } else {
      this.discountedDomain = true;
    }
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((parameters.get("a") != null) || (parameters.get("b") != null) || ((parameters.get("c") != null) && (parameters.get("d") != null) && (parameters.get("e") != null)))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
      this.c = ((Double)parameters.get("c")).doubleValue();
      this.d = ((Double)parameters.get("d")).doubleValue();
      this.e = ((Double)parameters.get("e")).doubleValue();
      if ((this.negotiationSession.getDiscountFactor() < 1.E-005D) || (this.negotiationSession.getDiscountFactor() > this.e)) {
        this.discountedDomain = false;
      } else {
        this.discountedDomain = true;
      }
    }
    else
    {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[a: " + this.a + " b: " + this.b + " c: " + this.c + " d: " + this.d + " e: " + this.e + "]";
  }
  
  public Actions determineAcceptability()
  {
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    

    double target = 0.0D;
    if (!this.discountedDomain) {
      target = this.a * lastOpponentBidUtil + this.b;
    } else {
      target = this.c * lastOpponentBidUtil + this.d;
    }
    if (target > 1.0D) {
      target = 1.0D;
    }
    if (target >= nextMyBidUtil) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Multiplier"));
    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Constant"));
    set.add(new BOAparameter("c", new BigDecimal(1.0D), "Multiplier discount"));
    
    set.add(new BOAparameter("d", new BigDecimal(0.0D), "Constant discount"));
    set.add(new BOAparameter("e", new BigDecimal(0.8D), "Threshold discount"));
    
    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiV4
 * JD-Core Version:    0.7.1
 */