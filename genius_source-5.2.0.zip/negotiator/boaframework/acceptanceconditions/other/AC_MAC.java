package negotiator.boaframework.acceptanceconditions.other;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_MAC
  extends Multi_AcceptanceCondition
{
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.outcomes = new ArrayList();
    this.ACList = new ArrayList();
    for (int a = 0; a < 2; a++) {
      for (int b = 0; b < 3; b++) {
        for (int c = 0; c < 3; c++) {
          for (int d = 0; d < 4; d++) {
            this.ACList.add(new AC_CombiV4(this.negotiationSession, this.offeringStrategy, 1.0D + 0.05D * a, 0.0D + 0.05D * b, 1.0D + 0.05D * c, 0.0D + 0.05D * d, 0.95D));
          }
        }
      }
    }
    for (int e = 0; e < 5; e++) {
      this.ACList.add(new AC_CombiMaxInWindow(this.negotiationSession, this.offeringStrategy, 0.95D + e * 0.01D));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_MAC
 * JD-Core Version:    0.7.1
 */