package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_CombiV3
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  private double c;
  private double time;
  
  public AC_CombiV3() {}
  
  public AC_CombiV3(NegotiationSession negoSession, OfferingStrategy strat, double a, double b, double t, double c)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.a = a;
    this.b = b;
    this.c = c;
    this.time = t;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((parameters.get("a") != null) || (parameters.get("b") != null) || ((parameters.get("c") != null) && (parameters.get("t") != null)))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
      this.c = ((Double)parameters.get("c")).doubleValue();
      this.time = ((Double)parameters.get("t")).doubleValue();
    }
    else
    {
      throw new Exception("Paramaters were not correctly set");
    }
  }
  
  public String printParameters()
  {
    return "[a: " + this.a + " b: " + this.b + " t: " + this.time + " c: " + this.c + "]";
  }
  
  public Actions determineAcceptability()
  {
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    

    double target = this.a * nextMyBidUtil + this.b;
    if (target > 1.0D) {
      target = 1.0D;
    }
    if (lastOpponentBidUtil >= target) {
      return Actions.Accept;
    }
    if ((this.negotiationSession.getTime() > this.time) && (lastOpponentBidUtil > this.c)) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Multiplier"));
    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Constant"));
    set.add(new BOAparameter("c", new BigDecimal(0.95D), "Threshold"));
    set.add(new BOAparameter("t", new BigDecimal(0.99D), "Time"));
    
    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_CombiV3
 * JD-Core Version:    0.7.1
 */