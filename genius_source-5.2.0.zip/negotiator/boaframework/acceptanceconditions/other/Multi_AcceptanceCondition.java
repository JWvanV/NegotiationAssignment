package negotiator.boaframework.acceptanceconditions.other;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.analysis.BidPointTime;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.OutcomeTuple;

public class Multi_AcceptanceCondition
  extends AcceptanceStrategy
{
  protected ArrayList<AcceptanceStrategy> ACList;
  protected ArrayList<OutcomeTuple> outcomes;
  private boolean firstTime = false;
  private boolean startingAgent = false;
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.outcomes = new ArrayList();
    this.ACList = new ArrayList();
  }
  
  public Actions determineAcceptability()
  {
    if ((!this.firstTime) && (this.negotiationSession.getOpponentBidHistory().size() == this.negotiationSession.getOwnBidHistory().size())) {
      this.startingAgent = true;
    }
    ArrayList<AcceptanceStrategy> acceptors = new ArrayList();
    for (AcceptanceStrategy a : this.ACList)
    {
      Bid lastOpponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid();
      String name = a.getClass().getSimpleName() + " " + printParameters(a);
      double time = this.negotiationSession.getTime();
      if (a.determineAcceptability().equals(Actions.Accept))
      {
        System.out.println(name + " accepted Bid" + " Util: " + this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil());
        OutcomeTuple outcome;
        OutcomeTuple outcome;
        if (this.startingAgent) {
          outcome = new OutcomeTuple(lastOpponentBid, name, time, this.negotiationSession.getOwnBidHistory().size(), this.negotiationSession.getOpponentBidHistory().size(), "accept", "agentA");
        } else {
          outcome = new OutcomeTuple(lastOpponentBid, name, time, this.negotiationSession.getOpponentBidHistory().size(), this.negotiationSession.getOwnBidHistory().size(), "accept", "agentB");
        }
        this.outcomes.add(outcome);
        acceptors.add(a);
      }
      else if (a.determineAcceptability().equals(Actions.Break))
      {
        OutcomeTuple outcome = new OutcomeTuple(lastOpponentBid, name, time, this.negotiationSession.getOwnBidHistory().size(), this.negotiationSession.getOpponentBidHistory().size(), "breakoff", "");
        this.outcomes.add(outcome);
        acceptors.add(a);
      }
    }
    this.ACList.removeAll(acceptors);
    if (this.ACList.isEmpty()) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public ArrayList<OutcomeTuple> getOutcomes()
  {
    return this.outcomes;
  }
  
  public ArrayList<AcceptanceStrategy> getACList()
  {
    return this.ACList;
  }
  
  public String printParameters(AcceptanceStrategy a)
  {
    return a.printParameters();
  }
  
  public String printParameters()
  {
    return null;
  }
  
  public boolean isMAC()
  {
    return true;
  }
  
  public void remainingACAccept(Bid lastBid, double time, ArrayList<BidPointTime> fAgentABids, ArrayList<BidPointTime> fAgentBBids, String acceptedBy)
  {
    ArrayList<AcceptanceStrategy> acceptors = new ArrayList();
    for (AcceptanceStrategy strat : this.ACList)
    {
      String name = strat.getClass().getSimpleName() + " " + printParameters(strat);
      OutcomeTuple tuple = new OutcomeTuple(lastBid, name, time, fAgentABids.size(), fAgentBBids.size(), "accept", acceptedBy);
      this.outcomes.add(tuple);
      acceptors.add(strat);
    }
    this.ACList.removeAll(acceptors);
  }
  
  public void remainingAC(String type)
  {
    ArrayList<AcceptanceStrategy> acceptors = new ArrayList();
    for (AcceptanceStrategy strat : this.ACList)
    {
      String name = strat.getClass().getSimpleName() + " " + printParameters(strat);
      OutcomeTuple tuple = new OutcomeTuple(null, name, 1.0D, -1, -1, type, "");
      this.outcomes.add(tuple);
      acceptors.add(strat);
    }
    this.ACList.removeAll(acceptors);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.Multi_AcceptanceCondition
 * JD-Core Version:    0.7.1
 */