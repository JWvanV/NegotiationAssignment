package negotiator.boaframework.acceptanceconditions.other;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;

public class AC_Next
  extends AcceptanceStrategy
{
  private double a;
  private double b;
  
  public AC_Next() {}
  
  public AC_Next(NegotiationSession negoSession, OfferingStrategy strat, double alpha, double beta)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.a = alpha;
    this.b = beta;
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((parameters.get("a") != null) || (parameters.get("b") != null))
    {
      this.a = ((Double)parameters.get("a")).doubleValue();
      this.b = ((Double)parameters.get("b")).doubleValue();
    }
    else
    {
      this.a = 1.0D;
      this.b = 0.0D;
    }
  }
  
  public String printParameters()
  {
    String str = "[a: " + this.a + " b: " + this.b + "]";
    return str;
  }
  
  public Actions determineAcceptability()
  {
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    
    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    if (this.a * lastOpponentBidUtil + this.b >= nextMyBidUtil) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Accept when the opponent's utility * a + b is greater than the utility of our current bid"));
    


    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Accept when the opponent's utility * a + b is greater than the utility of our current bid"));
    



    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_Next
 * JD-Core Version:    0.7.1
 */