package negotiator.boaframework.acceptanceconditions.other;

import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;

public class AC_True
  extends AcceptanceStrategy
{
  public Actions determineAcceptability()
  {
    return Actions.Accept;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.other.AC_True
 * JD-Core Version:    0.7.1
 */