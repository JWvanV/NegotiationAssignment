package negotiator.boaframework.acceptanceconditions.anac2013;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.NegotiationResult;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.boaframework.offeringstrategy.anac2013.inoxAgent.SaveHelper;
import negotiator.utility.UtilitySpace;

public class AC_InoxAgent
  extends AcceptanceStrategy
{
  private double discountFactor;
  private double medianutil;
  private double lastTime = 0.0D;
  private ArrayList<Double> timeList = new ArrayList();
  private boolean medianDecided = false;
  private boolean realmedian = true;
  private double prevRes = 0.0D;
  private int prevNegos = 0;
  private int roundsLeft = Integer.MAX_VALUE;
  
  public AC_InoxAgent() {}
  
  public AC_InoxAgent(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel oppModel)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.opponentModel = oppModel;
    this.discountFactor = this.negotiationSession.getDiscountFactor();
    
    Serializable oldData = loadData();
    if (oldData != null)
    {
      SaveHelper prevData = (SaveHelper)oldData;
      this.medianutil = prevData.getResult();
      this.prevRes = prevData.getResult();
      this.prevNegos = prevData.getNumber();
      this.realmedian = false;
    }
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel oppModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.opponentModel = oppModel;
    this.discountFactor = this.negotiationSession.getDiscountFactor();
    if (this.discountFactor == 0.0D) {
      this.discountFactor = 1.0D;
    }
    Serializable oldData = loadData();
    if (oldData != null)
    {
      SaveHelper prevData = (SaveHelper)oldData;
      this.medianutil = prevData.getResult();
      this.prevRes = prevData.getResult();
      this.prevNegos = prevData.getNumber();
      this.realmedian = false;
    }
  }
  
  public Actions determineAcceptability()
  {
    if ((!this.medianDecided) || ((this.roundsLeft <= 4) && (!this.realmedian)))
    {
      SortedOutcomeSpace outcomespace = new SortedOutcomeSpace(this.negotiationSession.getUtilitySpace());
      int opplocation = outcomespace.getIndexOfBidNearUtility(this.negotiationSession.getOpponentBidHistory().getFirstBidDetails().getMyUndiscountedUtil());
      List<BidDetails> alloutcomes = outcomespace.getAllOutcomes();
      this.medianutil = ((BidDetails)alloutcomes.get((int)Math.floor(opplocation / 2.0D))).getMyUndiscountedUtil();
      this.medianDecided = true;
    }
    double time = this.negotiationSession.getTime();
    updateRoundsLeft(time);
    

    double nextMyBidUtil = 1.0D;
    if (this.negotiationSession.getOwnBidHistory().getWorstBidDetails() != null) {
      nextMyBidUtil = this.negotiationSession.getDiscountedUtility(this.negotiationSession.getOwnBidHistory().getWorstBidDetails().getBid(), time);
    }
    double lastOpponentBidUtil = this.negotiationSession.getDiscountedUtility(this.negotiationSession.getOpponentBidHistory().getLastBid(), time);
    if (nextMyBidUtil < this.negotiationSession.getUtilitySpace().getReservationValueWithDiscount(time)) {
      return Actions.Break;
    }
    if (nextMyBidUtil <= lastOpponentBidUtil + 0.05D * (1.0D - this.discountFactor)) {
      return Actions.Accept;
    }
    if (lastOpponentBidUtil >= acceptUtil(time)) {
      return Actions.Accept;
    }
    if ((!this.realmedian) && (this.medianutil * Math.pow(this.discountFactor, time) < this.negotiationSession.getUtilitySpace().getReservationValueUndiscounted())) {
      return Actions.Break;
    }
    return Actions.Reject;
  }
  
  public double acceptUtil(double t)
  {
    double finalVal = this.negotiationSession.getDiscountedUtility(this.negotiationSession.getOpponentBidHistory().getBestDiscountedBidDetails(this.negotiationSession.getUtilitySpace()).getBid(), t);
    finalVal = Math.max(Math.max(finalVal, this.negotiationSession.getUtilitySpace().getReservationValueWithDiscount(t)), this.medianutil * Math.pow(this.discountFactor, t));
    if (this.roundsLeft < 8) {
      return finalVal;
    }
    double startVal = Math.pow(this.discountFactor, t);
    double power = 27.0D;
    if (this.discountFactor != 1.0D) {
      power = power * 0.3D * this.discountFactor;
    }
    double ut = startVal - (startVal - finalVal) * Math.pow(t, power);
    return ut;
  }
  
  private void updateRoundsLeft(double t)
  {
    this.timeList.add(Double.valueOf(t - this.lastTime));
    this.lastTime = t;
    if (this.timeList.size() >= 10)
    {
      if (this.timeList.size() > 10) {
        this.timeList.remove(0);
      }
      double sum = 0.0D;
      for (int i = 0; i < this.timeList.size(); i++) {
        sum += ((Double)this.timeList.get(i)).doubleValue();
      }
      this.roundsLeft = ((int)((1.0D - t) * this.timeList.size() / sum));
    }
  }
  
  public void endNegotiation(NegotiationResult result)
  {
    if (result.isAgreement())
    {
      double saveRes = (this.prevRes * this.prevNegos + result.getMyDiscountedUtility()) / (this.prevNegos + 1);
      storeData(new SaveHelper(saveRes, this.prevNegos + 1));
    }
    else
    {
      double saveRes = (this.prevRes * this.prevNegos + this.medianutil) / (this.prevNegos + 1);
      storeData(new SaveHelper(saveRes, this.prevNegos + 1));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2013.AC_InoxAgent
 * JD-Core Version:    0.7.1
 */