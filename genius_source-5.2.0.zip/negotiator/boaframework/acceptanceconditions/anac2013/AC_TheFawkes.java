package negotiator.boaframework.acceptanceconditions.anac2013;

import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.OutcomeSpace;
import negotiator.boaframework.opponentmodel.TheFawkes_OM;

public final class AC_TheFawkes
  extends AcceptanceStrategy
{
  private TheFawkes_OM OM;
  private double minimumAcceptable;
  
  public void init(NegotiationSession nSession, OfferingStrategy biddingStrategy, OpponentModel oppModel, HashMap<String, Double> params)
    throws Exception
  {
    super.init(nSession, biddingStrategy, oppModel, params);
    this.OM = ((TheFawkes_OM)oppModel);
    
    List<BidDetails> allBids = nSession.getOutcomeSpace().getAllOutcomes();
    double total = 0.0D;
    for (BidDetails bid : allBids) {
      total += bid.getMyUndiscountedUtil();
    }
    this.minimumAcceptable = (total / allBids.size());
  }
  
  public Actions determineAcceptability()
  {
    BidDetails lastOpponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
    double lastOpponentBidUtility = lastOpponentBid.getMyUndiscountedUtil();
    BidDetails myNextBid = this.offeringStrategy.determineNextBid();
    double myNextBidUtility = myNextBid.getMyUndiscountedUtil();
    if (lastOpponentBidUtility < this.minimumAcceptable) {
      return Actions.Reject;
    }
    if (lastOpponentBidUtility >= myNextBidUtility) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getTime() >= 1.0D - this.OM.getMaxOpponentBidTimeDiff())
    {
      double time = this.negotiationSession.getTime();
      BidDetails bestOpponentBid = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(time - this.OM.getMaxOpponentBidTimeDiff() * 10.0D, time).getBestBidDetails();
      double bestOpponentBidUtility = bestOpponentBid.getMyUndiscountedUtil();
      if (lastOpponentBidUtility >= bestOpponentBidUtility) {
        return Actions.Accept;
      }
      return Actions.Reject;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2013.AC_TheFawkes
 * JD-Core Version:    0.7.1
 */