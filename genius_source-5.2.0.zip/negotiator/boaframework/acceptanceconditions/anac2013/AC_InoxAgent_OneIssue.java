package negotiator.boaframework.acceptanceconditions.anac2013;

import java.util.HashMap;
import java.util.List;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.utility.UtilitySpace;

public class AC_InoxAgent_OneIssue
  extends AcceptanceStrategy
{
  private double discountFactor;
  private double medianutil;
  private boolean medianDecided = false;
  
  public AC_InoxAgent_OneIssue() {}
  
  public AC_InoxAgent_OneIssue(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel oppModel)
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.opponentModel = oppModel;
    this.discountFactor = this.negotiationSession.getDiscountFactor();
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel oppModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.opponentModel = oppModel;
    this.discountFactor = this.negotiationSession.getDiscountFactor();
    if (this.discountFactor == 0.0D) {
      this.discountFactor = 1.0D;
    }
  }
  
  public Actions determineAcceptability()
  {
    if (!this.medianDecided)
    {
      SortedOutcomeSpace outcomespace = new SortedOutcomeSpace(this.negotiationSession.getUtilitySpace());
      int opplocation = outcomespace.getIndexOfBidNearUtility(this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getMyUndiscountedUtil());
      List<BidDetails> alloutcomes = outcomespace.getAllOutcomes();
      this.medianutil = ((BidDetails)alloutcomes.get((int)Math.floor(opplocation / 2.0D))).getMyUndiscountedUtil();
      this.medianDecided = true;
    }
    double time = this.negotiationSession.getTime();
    
    double lastOpponentBidUtil = this.negotiationSession.getDiscountedUtility(this.negotiationSession.getOpponentBidHistory().getLastBid(), time);
    if (lastOpponentBidUtil >= this.medianutil * Math.pow(this.discountFactor, time)) {
      return Actions.Accept;
    }
    if (this.negotiationSession.getUtilitySpace().getReservationValueUndiscounted() >= this.medianutil * Math.pow(this.discountFactor, time)) {
      return Actions.Break;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2013.AC_InoxAgent_OneIssue
 * JD-Core Version:    0.7.1
 */