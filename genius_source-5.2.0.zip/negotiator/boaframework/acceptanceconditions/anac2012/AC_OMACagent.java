package negotiator.boaframework.acceptanceconditions.anac2012;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.utility.UtilitySpace;

public class AC_OMACagent
  extends AcceptanceStrategy
{
  private double discount = 1.0D;
  private UtilitySpace utilitySpace;
  public double discountThreshold = 0.845D;
  
  public AC_OMACagent() {}
  
  public AC_OMACagent(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.utilitySpace = negoSession.getUtilitySpace();
    if ((this.utilitySpace.getDiscountFactor() <= 1.0D) && (this.utilitySpace.getDiscountFactor() > 0.0D)) {
      this.discount = this.utilitySpace.getDiscountFactor();
    }
  }
  
  public Actions determineAcceptability()
  {
    Bid partnerBid = this.negotiationSession.getOpponentBidHistory().getLastBid();
    double time = this.negotiationSession.getTime();
    if (this.discount < this.discountThreshold)
    {
      if (bidAlreadyMade(partnerBid))
      {
        System.out.println("Decoupled accept1");
        return Actions.Accept;
      }
    }
    else if (time > 0.97D) {
      if (bidAlreadyMade(partnerBid))
      {
        System.out.println("Decoupled accept2");
        return Actions.Accept;
      }
    }
    double myOfferedUtil = this.negotiationSession.getDiscountedUtility(this.offeringStrategy.getNextBid().getBid(), time);
    double offeredUtilFromOpponent = this.negotiationSession.getDiscountedUtility(this.negotiationSession.getOpponentBidHistory().getLastBid(), time);
    try
    {
      if (isAcceptable(offeredUtilFromOpponent, myOfferedUtil, time, partnerBid)) {
        return Actions.Accept;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return Actions.Reject;
  }
  
  private boolean isAcceptable(double offeredUtilFromOpponent, double myOfferedUtil, double time, Bid oppBid)
    throws Exception
  {
    if (offeredUtilFromOpponent >= myOfferedUtil) {
      return true;
    }
    return false;
  }
  
  public boolean bidAlreadyMade(Bid a)
  {
    boolean result = false;
    for (int i = 0; i < this.negotiationSession.getOwnBidHistory().size(); i++) {
      if (a.equals(((BidDetails)this.negotiationSession.getOwnBidHistory().getHistory().get(i)).getBid())) {
        result = true;
      }
    }
    return result;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_OMACagent
 * JD-Core Version:    0.7.1
 */