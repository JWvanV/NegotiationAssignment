package negotiator.boaframework.acceptanceconditions.anac2012;

import java.io.PrintStream;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.BOAparameter;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.utility.UtilitySpace;

public class AC_TheNegotiatorReloaded
  extends AcceptanceStrategy
{
  private double aNext;
  private double bNext;
  private double aNextDiscount;
  private double bNextDiscount;
  private double time;
  private double constant;
  private boolean discountMode = false;
  private boolean highDiscount = false;
  private final double DISCOUNT_CONSTANT = 0.95D;
  private final boolean PANIC_PHASE = true;
  
  public AC_TheNegotiatorReloaded() {}
  
  public AC_TheNegotiatorReloaded(NegotiationSession negoSession, OfferingStrategy strat, double a, double b, double ad, double bd, double c, double t)
  {
    this.aNext = a;
    this.bNext = b;
    this.aNextDiscount = ad;
    this.bNextDiscount = bd;
    this.constant = c;
    this.time = t;
    
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    if ((parameters.get("a") != null) || (parameters.get("b") != null) || (parameters.get("ad") != null) || (parameters.get("bd") != null) || (parameters.get("c") != null) || (parameters.get("t") != null))
    {
      this.aNext = ((Double)parameters.get("a")).doubleValue();
      this.bNext = ((Double)parameters.get("b")).doubleValue();
      this.aNextDiscount = ((Double)parameters.get("ad")).doubleValue();
      this.bNextDiscount = ((Double)parameters.get("bd")).doubleValue();
      this.constant = ((Double)parameters.get("c")).doubleValue();
      this.time = ((Double)parameters.get("t")).doubleValue();
    }
    else
    {
      throw new Exception("Parameters were not correctly set");
    }
    initializeAgent(negoSession, strat);
    System.out.println("Domain size: " + negoSession.getDomain().getNumberOfPossibleBids());
  }
  
  private void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy strat)
  {
    this.negotiationSession = negotiationSession;
    this.offeringStrategy = strat;
    if ((negotiationSession.getDiscountFactor() > 0.001D) && (negotiationSession.getDiscountFactor() < 0.95D))
    {
      this.discountMode = true;
      if (negotiationSession.getDiscountFactor() <= 0.4D) {
        this.highDiscount = true;
      }
    }
  }
  
  public String printParameters()
  {
    return "[a: " + this.aNext + " b: " + this.bNext + "ad: " + this.aNextDiscount + " bd: " + this.bNextDiscount + " time: " + this.time + " constant: " + this.constant + "]";
  }
  
  public Actions determineAcceptability()
  {
    double now = this.negotiationSession.getTime();
    double nextMyBidUtil = this.offeringStrategy.getNextBid().getMyUndiscountedUtil();
    
    double nextMyBidDiscountedUtil = this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(this.offeringStrategy.getNextBid().getBid(), now);
    

    double lastOpponentBidUtil = this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil();
    
    double currentRV = this.negotiationSession.getUtilitySpace().getReservationValueWithDiscount(now);
    if (nextMyBidDiscountedUtil <= currentRV) {
      return Actions.Break;
    }
    if (lastOpponentBidUtil >= this.constant) {
      return Actions.Accept;
    }
    if (!this.discountMode)
    {
      if (this.aNext * lastOpponentBidUtil + this.bNext >= nextMyBidUtil) {
        return Actions.Accept;
      }
    }
    else
    {
      if ((this.highDiscount) && (currentRV > 0.85D)) {
        return Actions.Break;
      }
      if (this.aNextDiscount * lastOpponentBidUtil + this.bNextDiscount >= nextMyBidUtil) {
        return Actions.Accept;
      }
    }
    if ((this.discountMode) && (now > this.time))
    {
      double window = 1.0D - now;
      BidHistory recentBids = this.negotiationSession.getOpponentBidHistory().filterBetweenTime(now - window, now);
      double max;
      double max;
      if (recentBids.size() > 0) {
        max = recentBids.getBestBidDetails().getMyUndiscountedUtil();
      } else {
        max = 0.5D;
      }
      double expectedUtilOfWaitingForABetterBid = max;
      if (lastOpponentBidUtil >= expectedUtilOfWaitingForABetterBid) {
        return Actions.Accept;
      }
    }
    return Actions.Reject;
  }
  
  public Set<BOAparameter> getParameters()
  {
    Set<BOAparameter> set = new HashSet();
    set.add(new BOAparameter("a", new BigDecimal(1.0D), "Scaling factor for AC_next when no discount"));
    
    set.add(new BOAparameter("b", new BigDecimal(0.0D), "Constant factor for AC_next when no discount"));
    
    set.add(new BOAparameter("ad", new BigDecimal(1.05D), "Scaling factor for AC_next when discount"));
    
    set.add(new BOAparameter("bd", new BigDecimal(0.0D), "Constant factor for AC_next when discount"));
    
    set.add(new BOAparameter("c", new BigDecimal(0.98D), "Constant specifying utility threshold"));
    
    set.add(new BOAparameter("t", new BigDecimal(0.99D), "Time after which AC_max is used"));
    

    return set;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_TheNegotiatorReloaded
 * JD-Core Version:    0.7.1
 */