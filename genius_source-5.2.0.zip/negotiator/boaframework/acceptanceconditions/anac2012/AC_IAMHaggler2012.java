package negotiator.boaframework.acceptanceconditions.anac2012;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.utility.UtilitySpace;

public class AC_IAMHaggler2012
  extends AcceptanceStrategy
{
  private UtilitySpace utilitySpace;
  private double acceptMultiplier = 1.02D;
  private double MAXIMUM_ASPIRATION = 0.9D;
  
  public AC_IAMHaggler2012() {}
  
  public AC_IAMHaggler2012(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negoSession, strat, opponentModel, parameters);
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy os)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.utilitySpace = negotiationSession.getUtilitySpace();
    this.offeringStrategy = os;
  }
  
  public Actions determineAcceptability()
  {
    Bid opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBid();
    Bid myLastBid = this.negotiationSession.getOwnBidHistory().getLastBid();
    if ((opponentBid == null) || (myLastBid == null)) {
      return Actions.Reject;
    }
    try
    {
      if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.utilitySpace.getUtility(myLastBid)) {
        return Actions.Accept;
      }
      if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.MAXIMUM_ASPIRATION) {
        return Actions.Accept;
      }
      if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.offeringStrategy.getNextBid().getMyUndiscountedUtil()) {
        return Actions.Accept;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_IAMHaggler2012
 * JD-Core Version:    0.7.1
 */