package negotiator.boaframework.acceptanceconditions.anac2012;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2011.BRAMAgentSAS;
import negotiator.utility.UtilitySpace;

public class AC_BRAMAgent2
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private BidDetails bestBid;
  private Bid worstBid;
  private UtilitySpace utilitySpace;
  
  public AC_BRAMAgent2() {}
  
  public AC_BRAMAgent2(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    this.bestBid = negoSession.getMaxBidinDomain();
    this.worstBid = negoSession.getUtilitySpace().getMinUtilityBid();
    this.utilitySpace = negoSession.getUtilitySpace();
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("BRAMAgent")))
    {
      this.helper = new BRAMAgentSAS(this.negotiationSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((BRAMAgentSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    double offeredUtility = this.utilitySpace.getUtilityWithDiscount(this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getBid(), this.negotiationSession.getTime());
    double threshold;
    double threshold;
    if (this.activeHelper) {
      threshold = ((BRAMAgentSAS)this.helper).getNewThreshold(this.worstBid, this.bestBid.getBid());
    } else {
      threshold = ((BRAMAgentSAS)this.helper).getThreshold();
    }
    if (offeredUtility >= threshold) {
      return Actions.Accept;
    }
    if (offeredUtility >= this.utilitySpace.getUtilityWithDiscount(this.offeringStrategy.getNextBid().getBid(), this.negotiationSession.getTime())) {
      return Actions.Accept;
    }
    if ((offeredUtility < this.utilitySpace.getReservationValueWithDiscount(this.negotiationSession.getTimeline())) && (this.negotiationSession.getTime() > 0.9833333333333333D) && 
      (this.utilitySpace.getReservationValueWithDiscount(this.negotiationSession.getTimeline()) > this.utilitySpace.getUtilityWithDiscount(this.offeringStrategy.getNextBid().getBid(), this.negotiationSession.getTimeline()))) {
      return Actions.Break;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_BRAMAgent2
 * JD-Core Version:    0.7.1
 */