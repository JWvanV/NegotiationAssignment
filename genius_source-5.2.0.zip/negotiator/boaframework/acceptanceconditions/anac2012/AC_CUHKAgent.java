package negotiator.boaframework.acceptanceconditions.anac2012;

import agents.anac.y2012.CUHKAgent.OpponentBidHistory;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2012.CUHKAgentSAS;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class AC_CUHKAgent
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private double reservationValue;
  private UtilitySpace utilitySpace;
  private double discountingFactor;
  private double previousTime;
  private Actions nextAction;
  private BidDetails opponentBid = null;
  private double maximumOfBid;
  private OpponentBidHistory opponentBidHistory;
  private double minimumUtilityThreshold;
  private double concedeToDiscountingFactor_original;
  private double minConcedeToDiscountingFactor;
  private ArrayList<ArrayList<Bid>> bidsBetweenUtility;
  private Bid bid_maximum_utility;
  private Random random;
  private final boolean TEST_EQUIVALENCE = true;
  
  public AC_CUHKAgent() {}
  
  public AC_CUHKAgent(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy os)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.offeringStrategy = os;
    
    this.previousTime = 0.0D;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("CUHKAgent")))
    {
      this.helper = new CUHKAgentSAS(negotiationSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((CUHKAgentSAS)this.offeringStrategy.getHelper());
    }
    this.utilitySpace = negotiationSession.getUtilitySpace();
    this.reservationValue = 0.0D;
    if (this.utilitySpace.getReservationValue().doubleValue() > 0.0D) {
      this.reservationValue = this.utilitySpace.getReservationValue().doubleValue();
    }
    this.discountingFactor = 1.0D;
    if ((this.utilitySpace.getDiscountFactor() <= 1.0D) && (this.utilitySpace.getDiscountFactor() > 0.0D)) {
      this.discountingFactor = this.utilitySpace.getDiscountFactor();
    }
    if (this.activeHelper) {
      try
      {
        this.maximumOfBid = this.utilitySpace.getDomain().getNumberOfPossibleBids();
        this.opponentBidHistory = new OpponentBidHistory();
        this.bidsBetweenUtility = new ArrayList();
        this.bid_maximum_utility = this.utilitySpace.getMaxUtilityBid();
        this.minConcedeToDiscountingFactor = 0.08D;
        chooseUtilityThreshold();
        calculateBidsBetweenUtility();
        chooseConcedeToDiscountingDegree();
        
        this.opponentBidHistory.initializeDataStructures(this.utilitySpace.getDomain());
        ((CUHKAgentSAS)this.helper).setTimeLeftAfter(negotiationSession.getTimeline().getCurrentTime());
        

        this.random = new Random(100L);
      }
      catch (Exception e)
      {
        System.out.println("initialization error" + e.getMessage());
      }
    }
  }
  
  public Actions determineAcceptability()
  {
    if (this.activeHelper) {
      this.nextAction = activeDetermineAcceptability();
    } else {
      this.nextAction = regularDetermineAcceptability();
    }
    return this.nextAction;
  }
  
  private Actions activeDetermineAcceptability()
  {
    this.nextAction = Actions.Reject;
    try
    {
      double currentTime = this.negotiationSession.getTime();
      ((CUHKAgentSAS)this.helper).addTimeInterval(currentTime - this.previousTime);
      this.previousTime = currentTime;
      

      ((CUHKAgentSAS)this.helper).setTimeLeftBefore(this.negotiationSession.getTimeline().getCurrentTime());
      if (this.negotiationSession.getOpponentBidHistory().size() >= 1)
      {
        this.opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
        
        this.opponentBidHistory.updateOpponentModel(this.opponentBid.getBid(), this.utilitySpace.getDomain(), this.utilitySpace);
        updateConcedeDegree();
        if (!this.negotiationSession.getOwnBidHistory().isEmpty()) {
          if (((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, true) > 10)
          {
            System.out.println("test2: " + ((CUHKAgentSAS)this.helper).isConcedeToOpponent());
            if (((CUHKAgentSAS)this.helper).isConcedeToOpponent() == true)
            {
              ((CUHKAgentSAS)this.helper).setToughAgent(true);
              ((CUHKAgentSAS)this.helper).setConcedeToOpponent(false);
            }
            else
            {
              ((CUHKAgentSAS)this.helper).setToughAgent(false);
            }
          }
          else if ((this.negotiationSession.getTimeline().getTime() > 0.9985000000000001D) && (((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, true) < 5))
          {
            if (((this.offeringStrategy.getNextBid().getMyUndiscountedUtil() >= 0.85D) || 
            



              (((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, true) >= 2)) || 
              







              (((CUHKAgentSAS)this.helper).isToughAgent() == true))
            {
              this.nextAction = Actions.Accept;
              System.out.println("the opponent is tough and the deadline is approching thus we accept the offer");
            }
          }
        }
      }
      ((CUHKAgentSAS)this.helper).setTimeLeftAfter(this.negotiationSession.getTimeline().getCurrentTime());
      ((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, false);
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      System.out.println(((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, false));
    }
    return this.nextAction;
  }
  
  private Actions regularDetermineAcceptability()
  {
    if (this.activeHelper)
    {
      double currentTime = this.negotiationSession.getTime();
      ((CUHKAgentSAS)this.helper).addTimeInterval(currentTime - this.previousTime);
      this.previousTime = currentTime;
      if (((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(true, true) > 10) {
        if (((CUHKAgentSAS)this.helper).isConcedeToOpponent() == true)
        {
          ((CUHKAgentSAS)this.helper).setToughAgent(true);
          ((CUHKAgentSAS)this.helper).setConcedeToOpponent(false);
        }
        else
        {
          ((CUHKAgentSAS)this.helper).setToughAgent(false);
        }
      }
    }
    Bid opponentBid = this.negotiationSession.getOpponentBidHistory().getLastBid();
    
    Bid bid = this.offeringStrategy.getNextBid().getBid();
    int roundsLeft;
    int roundsLeft;
    if (this.activeHelper) {
      roundsLeft = ((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(true, true);
    } else {
      roundsLeft = ((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, true);
    }
    if (roundsLeft > 10)
    {
      Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(opponentBid, bid));
      Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
      if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
      {
        System.out.println("accept the offer");
        return Actions.Accept;
      }
      if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
      {
        System.out.println("we determine to terminate the negotiation");
        return Actions.Break;
      }
      if ((IsAccept.booleanValue()) && (IsTerminate.booleanValue())) {
        try
        {
          if (this.utilitySpace.getUtility(opponentBid) > this.reservationValue)
          {
            System.out.println("we accept the offer RANDOMLY");
            return Actions.Accept;
          }
          System.out.println("we determine to terminate the negotiation RANDOMLY");
          return Actions.Break;
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
    else
    {
      if (this.activeHelper) {
        roundsLeft = ((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(true, true);
      } else {
        roundsLeft = ((CUHKAgentSAS)this.helper).estimateTheRoundsLeft(false, true);
      }
      if ((this.negotiationSession.getTime() > 0.9985000000000001D) && (roundsLeft < 5))
      {
        Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(opponentBid, bid));
        Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
        if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
        {
          System.out.println("accept the offer");
          return Actions.Accept;
        }
        if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
        {
          System.out.println("we determine to terminate the negotiation");
          return Actions.Break;
        }
        if ((IsTerminate.booleanValue()) && (IsAccept.booleanValue()))
        {
          try
          {
            if (this.utilitySpace.getUtility(opponentBid) > this.reservationValue)
            {
              System.out.println("we accept the offer RANDOMLY");
              return Actions.Accept;
            }
            System.out.println("we determine to terminate the negotiation RANDOMLY");
            return Actions.Break;
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
        else if (((CUHKAgentSAS)this.helper).isToughAgent() == true)
        {
          System.out.println("the opponent is tough and the deadline is approching thus we accept the offer");
          return Actions.Accept;
        }
      }
      else
      {
        Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(opponentBid, bid));
        Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
        if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
        {
          System.out.println("accept the offer");
          return Actions.Accept;
        }
        if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
        {
          System.out.println("we determine to terminate the negotiation");
          return Actions.Break;
        }
        if ((IsAccept.booleanValue()) && (IsTerminate.booleanValue())) {
          try
          {
            if (this.utilitySpace.getUtility(opponentBid) > this.reservationValue)
            {
              System.out.println("we accept the offer RANDOMLY");
              return Actions.Accept;
            }
            System.out.println("we determine to terminate the negotiation RANDOMLY");
            return Actions.Break;
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
    }
    return Actions.Reject;
  }
  
  private boolean AcceptOpponentOffer(Bid opponentBid, Bid ownBid)
  {
    double currentUtility = 0.0D;
    double nextRoundUtility = 0.0D;
    double maximumUtility = 0.0D;
    ((CUHKAgentSAS)this.helper).setConcedeToOpponent(false);
    try
    {
      currentUtility = this.utilitySpace.getUtility(opponentBid);
      if (this.activeHelper) {
        maximumUtility = this.utilitySpace.getUtility(this.utilitySpace.getMaxUtilityBid());
      } else {
        maximumUtility = ((CUHKAgentSAS)this.helper).getMaximumUtility();
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method AcceptOpponentOffer part 1");
    }
    try
    {
      nextRoundUtility = this.utilitySpace.getUtility(ownBid);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method AcceptOpponentOffer part 2");
    }
    if ((currentUtility >= ((CUHKAgentSAS)this.helper).getUtilitythreshold()) || (currentUtility >= nextRoundUtility)) {
      return true;
    }
    double predictMaximumUtility = maximumUtility * this.discountingFactor;
    
    double currentMaximumUtility = this.utilitySpace.getUtilityWithDiscount(this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getBid(), this.negotiationSession.getTimeline());
    if ((currentMaximumUtility > predictMaximumUtility) && (this.negotiationSession.getTime() > ((CUHKAgentSAS)this.helper).getConcedeToDiscountingFactor())) {
      try
      {
        if (this.utilitySpace.getUtility(opponentBid) >= this.utilitySpace.getUtility(this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getBid()) - 0.01D)
        {
          System.out.println("he offered me " + currentMaximumUtility + " we predict we can get at most " + predictMaximumUtility + "we concede now to avoid lower payoff due to conflict");
          return true;
        }
        ((CUHKAgentSAS)this.helper).setConcedeToOpponent(true);
        return false;
      }
      catch (Exception e)
      {
        System.out.println("exception in Method AcceptOpponentOffer");
        return true;
      }
    }
    if (currentMaximumUtility > ((CUHKAgentSAS)this.helper).getUtilitythreshold() * Math.pow(this.discountingFactor, this.negotiationSession.getTime())) {
      try
      {
        if (this.utilitySpace.getUtility(opponentBid) >= this.utilitySpace.getUtility(this.negotiationSession.getOpponentBidHistory().getBestBidDetails().getBid()) - 0.01D) {
          return true;
        }
        System.out.println("test" + this.utilitySpace.getUtility(opponentBid) + ((CUHKAgentSAS)this.helper).getUtilitythreshold());
        ((CUHKAgentSAS)this.helper).setConcedeToOpponent(true);
        return false;
      }
      catch (Exception e)
      {
        System.out.println("exception in Method AcceptOpponentOffer");
        return true;
      }
    }
    return false;
  }
  
  private boolean TerminateCurrentNegotiation(Bid ownBid)
  {
    double currentUtility = 0.0D;
    double nextRoundUtility = 0.0D;
    double maximumUtility = 0.0D;
    ((CUHKAgentSAS)this.helper).setConcedeToOpponent(false);
    try
    {
      currentUtility = this.reservationValue;
      nextRoundUtility = this.utilitySpace.getUtility(ownBid);
      maximumUtility = ((CUHKAgentSAS)this.helper).getMaximumUtility();
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method TerminateCurrentNegotiation part 1");
    }
    if ((currentUtility >= ((CUHKAgentSAS)this.helper).getUtilitythreshold()) || (currentUtility >= nextRoundUtility)) {
      return true;
    }
    double predictMaximumUtility = maximumUtility * this.discountingFactor;
    double currentMaximumUtility = this.utilitySpace.getReservationValueWithDiscount(this.negotiationSession.getTimeline());
    if ((currentMaximumUtility > predictMaximumUtility) && (this.negotiationSession.getTime() > ((CUHKAgentSAS)this.helper).getConcedeToDiscountingFactor())) {
      return true;
    }
    return false;
  }
  
  private void chooseUtilityThreshold()
  {
    double discountingFactor = this.discountingFactor;
    if (discountingFactor >= 0.9D) {
      this.minimumUtilityThreshold = 0.0D;
    } else {
      this.minimumUtilityThreshold = 0.0D;
    }
  }
  
  private void chooseConcedeToDiscountingDegree()
  {
    double alpha = 0.0D;
    double beta = 1.5D;
    if (this.discountingFactor > 0.75D) {
      beta = 1.8D;
    } else if (this.discountingFactor > 0.5D) {
      beta = 1.5D;
    } else {
      beta = 1.2D;
    }
    alpha = Math.pow(this.discountingFactor, beta);
    ((CUHKAgentSAS)this.helper).setConcedeToDiscountingFactor(this.minConcedeToDiscountingFactor + (1.0D - this.minConcedeToDiscountingFactor) * alpha);
    this.concedeToDiscountingFactor_original = ((CUHKAgentSAS)this.helper).getConcedeToDiscountingFactor();
    System.out.println("concedeToDiscountingFactor is " + ((CUHKAgentSAS)this.helper).getConcedeToDiscountingFactor() + "current time is " + this.negotiationSession.getTimeline().getTime());
  }
  
  private void calculateBidsBetweenUtility()
  {
    BidIterator myBidIterator = new BidIterator(this.utilitySpace.getDomain());
    try
    {
      double maximumUtility = ((CUHKAgentSAS)this.helper).getMaximumUtility();
      double minUtility = this.minimumUtilityThreshold;
      int maximumRounds = (int)((maximumUtility - minUtility) / 0.01D);
      for (int i = 0; i < maximumRounds; i++)
      {
        ArrayList<Bid> BidList = new ArrayList();
        
        this.bidsBetweenUtility.add(BidList);
      }
      ((ArrayList)this.bidsBetweenUtility.get(maximumRounds - 1)).add(this.bid_maximum_utility);
      

      int limits = 0;
      if (this.maximumOfBid < 20000.0D) {
        while (myBidIterator.hasNext())
        {
          Bid b = myBidIterator.next();
          for (int i = 0; i < maximumRounds; i++) {
            if ((this.utilitySpace.getUtility(b) <= (i + 1) * 0.01D + minUtility) && (this.utilitySpace.getUtility(b) >= i * 0.01D + minUtility))
            {
              ((ArrayList)this.bidsBetweenUtility.get(i)).add(b);
              break;
            }
          }
        }
      }
      while (limits <= 20000)
      {
        Bid b = RandomSearchBid();
        for (int i = 0; i < maximumRounds; i++) {
          if ((this.utilitySpace.getUtility(b) <= (i + 1) * 0.01D + minUtility) && (this.utilitySpace.getUtility(b) >= i * 0.01D + minUtility))
          {
            ((ArrayList)this.bidsBetweenUtility.get(i)).add(b);
            break;
          }
        }
        limits++;
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in calculateBidsBetweenUtility()");
      e.printStackTrace();
    }
  }
  
  private Bid RandomSearchBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Bid bid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int optionIndex = this.random.nextInt(lIssueDiscrete.getNumberOfValues());
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
        
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = this.random.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
        values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
        

        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        int optionIndex2 = lIssueInteger.getLowerBound() + this.random.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
        values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported");
      }
    }
    bid = new Bid(this.utilitySpace.getDomain(), values);
    return bid;
  }
  
  private void updateConcedeDegree()
  {
    double gama = 10.0D;
    double weight = 0.1D;
    double opponnetToughnessDegree = this.opponentBidHistory.getConcessionDegree();
    
    ((CUHKAgentSAS)this.helper).setConcedeToDiscountingFactor(this.concedeToDiscountingFactor_original + weight * (1.0D - this.concedeToDiscountingFactor_original) * Math.pow(opponnetToughnessDegree, gama));
    if (((CUHKAgentSAS)this.helper).getConcedeToDiscountingFactor() >= 1.0D) {
      ((CUHKAgentSAS)this.helper).setConcedeToDiscountingFactor(1.0D);
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_CUHKAgent
 * JD-Core Version:    0.7.1
 */