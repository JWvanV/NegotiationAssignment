package negotiator.boaframework.acceptanceconditions.anac2012;

import agents.anac.y2012.AgentLG.OpponentBids;
import java.util.HashMap;
import negotiator.BidHistory;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.boaframework.sharedagentstate.anac2012.AgentLGSAS;
import negotiator.utility.UtilitySpace;

public class AC_AgentLG
  extends AcceptanceStrategy
{
  private boolean activeHelper = false;
  private OpponentBids opponentsBid;
  
  public AC_AgentLG() {}
  
  public AC_AgentLG(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    init(negoSession, strat, null, null);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.offeringStrategy = strat;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("AgentLR")))
    {
      this.opponentsBid = new OpponentBids(negoSession.getUtilitySpace());
      this.helper = new AgentLGSAS(this.negotiationSession, this.opponentsBid, new NoModel(), null);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((AgentLGSAS)this.offeringStrategy.getHelper());
    }
  }
  
  public Actions determineAcceptability()
  {
    if (this.activeHelper) {
      this.opponentsBid.addBid(this.negotiationSession.getOpponentBidHistory().getLastBid());
    }
    double time = this.negotiationSession.getTime();
    if (this.negotiationSession.getOwnBidHistory().isEmpty()) {
      return Actions.Reject;
    }
    double myUtility = this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(this.negotiationSession.getOwnBidHistory().getLastBidDetails().getBid(), time);
    
    double opponentUtility = this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(this.negotiationSession.getOpponentBidHistory().getLastBid(), time);
    if ((opponentUtility >= myUtility * 0.99D) || ((time > 0.999D) && (opponentUtility >= myUtility * 0.9D)) || 
      (((AgentLGSAS)this.helper).getMyBidsMinUtility(time) <= opponentUtility)) {
      return Actions.Accept;
    }
    return Actions.Reject;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_AgentLG
 * JD-Core Version:    0.7.1
 */