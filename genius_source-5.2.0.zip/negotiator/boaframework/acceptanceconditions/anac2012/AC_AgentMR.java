package negotiator.boaframework.acceptanceconditions.anac2012;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.Actions;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.SharedAgentState;
import negotiator.boaframework.sharedagentstate.anac2012.AgentMRSAS;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class AC_AgentMR
  extends AcceptanceStrategy
{
  private boolean EQUIVALENCE_TEST = true;
  private Random random100;
  private ArrayList<Double> observationUtility = new ArrayList();
  private HashMap<Bid, Double> bidTables = new HashMap();
  private static boolean firstOffer;
  private static boolean forecastTime = true;
  private static boolean discountFactor;
  private static double offereMaxUtility;
  private int currentBidNumber = 0;
  private UtilitySpace utilitySpace;
  private boolean alreadyDone = false;
  private Actions nextAction;
  private boolean activeHelper = false;
  private static final double MINIMUM_ACCEPT_P = 0.965D;
  
  public AC_AgentMR() {}
  
  public AC_AgentMR(NegotiationSession negoSession, OfferingStrategy strat)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void init(NegotiationSession negoSession, OfferingStrategy strat, OpponentModel opponentModel, HashMap<String, Double> parameters)
    throws Exception
  {
    initializeAgent(negoSession, strat);
  }
  
  public void initializeAgent(NegotiationSession negotiationSession, OfferingStrategy os)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.offeringStrategy = os;
    if ((this.offeringStrategy.getHelper() == null) || (!this.offeringStrategy.getHelper().getName().equals("AgentMR")))
    {
      this.helper = new AgentMRSAS(negotiationSession);
      this.activeHelper = true;
    }
    else
    {
      this.helper = ((AgentMRSAS)this.offeringStrategy.getHelper());
    }
    if (discountFactor)
    {
      ((AgentMRSAS)this.helper).setSigmoidGain(-3.0D);
      ((AgentMRSAS)this.helper).setPercent(0.55D);
    }
    else
    {
      ((AgentMRSAS)this.helper).setSigmoidGain(-5.0D);
      ((AgentMRSAS)this.helper).setPercent(0.7D);
    }
    if (this.activeHelper)
    {
      firstOffer = true;
      try
      {
        this.utilitySpace = negotiationSession.getUtilitySpace();
        getDiscountFactor();
        getReservationFactor();
        
        Bid b = negotiationSession.getMaxBidinDomain().getBid();
        this.bidTables.put(b, Double.valueOf(getUtility(b)));
        ((AgentMRSAS)this.helper).getBidRunk().add(b);
        if (this.EQUIVALENCE_TEST) {
          this.random100 = new Random(100L);
        } else {
          this.random100 = new Random();
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public Actions determineAcceptability()
  {
    if (this.activeHelper) {
      this.nextAction = activeDetermineAcceptability();
    } else {
      this.nextAction = regularDetermineAcceptability();
    }
    return this.nextAction;
  }
  
  private Actions activeDetermineAcceptability()
  {
    this.nextAction = Actions.Reject;
    if (this.negotiationSession.getOpponentBidHistory().getHistory().isEmpty())
    {
      if (!this.alreadyDone)
      {
        ((AgentMRSAS)this.helper).updateMinimumBidUtility(0.0D);
        this.alreadyDone = true;
      }
      return Actions.Reject;
    }
    try
    {
      BidDetails partnerBid;
      BidDetails partnerBid;
      if (firstOffer) {
        partnerBid = (BidDetails)this.negotiationSession.getOpponentBidHistory().getHistory().get(0);
      } else {
        partnerBid = this.negotiationSession.getOpponentBidHistory().getLastBidDetails();
      }
      double time = this.negotiationSession.getTime();
      double offeredutil;
      double offeredutil;
      if (discountFactor) {
        offeredutil = getUtility(partnerBid.getBid()) * (1.0D / Math.pow(this.negotiationSession.getUtilitySpace().getDiscountFactor(), time));
      } else {
        offeredutil = getUtility(partnerBid.getBid());
      }
      if (firstOffer)
      {
        offereMaxUtility = offeredutil;
        ((AgentMRSAS)this.helper).setFirstOffereUtility(offeredutil);
        
        this.observationUtility.add(Double.valueOf(offeredutil));
        if (offeredutil > 0.5D) {
          ((AgentMRSAS)this.helper).setP(0.9D);
        } else {
          ((AgentMRSAS)this.helper).setP(0.8D);
        }
        firstOffer = !firstOffer;
      }
      ((AgentMRSAS)this.helper).updateMinimumBidUtility(time);
      if (offeredutil > offereMaxUtility)
      {
        offereMaxUtility = offeredutil;
        
        this.observationUtility.add(Double.valueOf(offeredutil));
        if ((time > 0.5D) && (!discountFactor)) {
          newupdateSigmoidFunction();
        }
      }
      if ((time > 0.5D) && (forecastTime))
      {
        updateSigmoidFunction();
        forecastTime = !forecastTime;
      }
      double P = Paccept(offeredutil, time);
      if ((P > 0.965D) || (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() > ((AgentMRSAS)this.helper).getMinimumBidUtility()) || 
        (((AgentMRSAS)this.helper).getBidRunk().contains(this.negotiationSession.getOpponentBidHistory().getLastBid())))
      {
        this.nextAction = Actions.Accept;
      }
      else if (offeredutil > ((AgentMRSAS)this.helper).getMinimumOffereDutil())
      {
        HashMap<Bid, Double> getBids = getBidTable(1);
        if (getBids.size() >= 1)
        {
          this.currentBidNumber = 0;
          ((AgentMRSAS)this.helper).getBidRunk().clear();
          this.bidTables = getBids;
          sortBid(getBids);
        }
        else
        {
          getBids = getBidTable(2);
          if (getBids.size() >= 1)
          {
            sortBid(getBids);
            Bid maxBid = getMaxBidUtility(getBids);
            this.currentBidNumber = ((AgentMRSAS)this.helper).getBidRunk().indexOf(maxBid);
          }
        }
        if (this.currentBidNumber + 1 < ((AgentMRSAS)this.helper).getBidRunk().size()) {
          this.currentBidNumber += 1;
        }
      }
      else
      {
        HashMap<Bid, Double> getBids = getBidTable(2);
        if (getBids.size() >= 1)
        {
          sortBid(getBids);
          Bid maxBid = getMaxBidUtility(getBids);
          this.currentBidNumber = ((AgentMRSAS)this.helper).getBidRunk().indexOf(maxBid);
        }
        if (this.currentBidNumber + 1 < ((AgentMRSAS)this.helper).getBidRunk().size()) {
          this.currentBidNumber += 1;
        } else {
          this.currentBidNumber = 0;
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return this.nextAction;
  }
  
  private Actions regularDetermineAcceptability()
  {
    if (!this.negotiationSession.getOpponentBidHistory().isEmpty())
    {
      double offeredutil = this.negotiationSession.getOpponentBidHistory().getFirstBidDetails().getMyUndiscountedUtil();
      ((AgentMRSAS)this.helper).setFirstOffereUtility(offeredutil);
    }
    try
    {
      if (this.negotiationSession.getOpponentBidHistory().isEmpty()) {
        return Actions.Reject;
      }
      double P = Paccept(this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil(), this.negotiationSession.getTime());
      if (this.activeHelper) {
        ((AgentMRSAS)this.helper).updateMinimumBidUtility(this.negotiationSession.getTime());
      }
      if ((P > 0.965D) || (this.negotiationSession.getOpponentBidHistory().getLastBidDetails().getMyUndiscountedUtil() > ((AgentMRSAS)this.helper).getMinimumBidUtility()) || 
        (((AgentMRSAS)this.helper).getBidRunk().contains(this.negotiationSession.getOpponentBidHistory().getLastBid()))) {
        return Actions.Accept;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return Actions.Reject;
  }
  
  private double getUtility(Bid bid)
  {
    return this.negotiationSession.getUtilitySpace().getUtilityWithDiscount(bid, this.negotiationSession.getTimeline());
  }
  
  private void getReservationFactor()
  {
    if (this.utilitySpace.getReservationValue() != null) {
      ((AgentMRSAS)this.helper).setReservation(this.utilitySpace.getReservationValue().doubleValue());
    }
  }
  
  private void getDiscountFactor()
  {
    discountFactor = this.utilitySpace.isDiscounted();
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
  
  private void newupdateSigmoidFunction()
  {
    double latestObservation = ((Double)this.observationUtility.get(this.observationUtility.size() - 1)).doubleValue();
    double concessionPercent = Math.abs(latestObservation - ((AgentMRSAS)this.helper).getFirstOffereUtility()) / (1.0D - ((AgentMRSAS)this.helper).getFirstOffereUtility());
    double modPercent = Math.abs(((AgentMRSAS)this.helper).getMinimumOffereDutil() - ((AgentMRSAS)this.helper).getFirstOffereUtility()) / (1.0D - ((AgentMRSAS)this.helper).getFirstOffereUtility());
    if (modPercent < concessionPercent) {
      ((AgentMRSAS)this.helper).setPercent(concessionPercent);
    }
  }
  
  private void updateSigmoidFunction()
  {
    int observationSize = this.observationUtility.size();
    double latestObservation = ((Double)this.observationUtility.get(observationSize - 1)).doubleValue();
    double concessionPercent = Math.abs(latestObservation - ((AgentMRSAS)this.helper).getFirstOffereUtility()) / (1.0D - ((AgentMRSAS)this.helper).getFirstOffereUtility());
    if (discountFactor)
    {
      if ((concessionPercent < 0.2D) || (observationSize < 3))
      {
        ((AgentMRSAS)this.helper).setPercent(0.35D);
        ((AgentMRSAS)this.helper).setSigmoidGain(-2.0D);
      }
      else
      {
        ((AgentMRSAS)this.helper).setPercent(0.45D);
      }
    }
    else if ((concessionPercent < 0.2D) || (observationSize < 3))
    {
      ((AgentMRSAS)this.helper).setPercent(0.5D);
      ((AgentMRSAS)this.helper).setSigmoidGain(-4.0D);
    }
    else if (concessionPercent > 0.6D)
    {
      ((AgentMRSAS)this.helper).setPercent(0.8D);
      ((AgentMRSAS)this.helper).setSigmoidGain(-6.0D);
    }
    else
    {
      ((AgentMRSAS)this.helper).setPercent(0.6D);
    }
  }
  
  private HashMap<Bid, Double> getBidTable(int flag)
    throws Exception
  {
    HashMap<Bid, Double> getBids = new HashMap();
    

    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Bid standardBid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        for (ValueDiscrete value : lIssueDiscrete.getValues())
        {
          if (flag == 0) {
            standardBid = this.utilitySpace.getMaxUtilityBid();
          } else if (flag == 1) {
            standardBid = this.negotiationSession.getOpponentBidHistory().getLastBid();
          } else {
            standardBid = (Bid)((AgentMRSAS)this.helper).getBidRunk().get(this.currentBidNumber);
          }
          standardBid = clone(standardBid);
          standardBid.setValue(lIssue.getNumber(), value);
          double utility = getUtility(standardBid);
          if ((utility > ((AgentMRSAS)this.helper).getMinimumBidUtility()) && 
            (!((AgentMRSAS)this.helper).getBidRunk().contains(standardBid))) {
            getBids.put(standardBid, Double.valueOf(utility));
          }
        }
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = this.random100.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
        Value pValue = new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps());
        standardBid.setValue(lIssueReal.getNumber(), pValue);
        double utility = getUtility(standardBid);
        getBids.put(standardBid, Double.valueOf(utility));
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        int optionIndex2 = lIssueInteger.getLowerBound() + this.random100.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
        Value pValue2 = new ValueInteger(optionIndex2);
        standardBid.setValue(lIssueInteger.getNumber(), pValue2);
        double utility2 = getUtility(standardBid);
        getBids.put(standardBid, Double.valueOf(utility2));
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by AgentMR");
      }
    }
    return getBids;
  }
  
  private void sortBid(HashMap<Bid, Double> getBids)
  {
    for (Bid bid : getBids.keySet())
    {
      this.bidTables.put(bid, Double.valueOf(getUtility(bid)));
      ((AgentMRSAS)this.helper).getBidRunk().add(bid);
    }
    if (!this.EQUIVALENCE_TEST) {
      Collections.sort(((AgentMRSAS)this.helper).getBidRunk(), new Comparator()
      {
        public int compare(Bid o1, Bid o2)
        {
          return (int)Math.ceil(-(((Double)AC_AgentMR.this.bidTables.get(o1)).doubleValue() - ((Double)AC_AgentMR.this.bidTables.get(o2)).doubleValue()));
        }
      });
    }
  }
  
  private Bid getMaxBidUtility(HashMap<Bid, Double> bidTable)
  {
    Double maxBidUtility = Double.valueOf(0.0D);
    Bid maxBid = null;
    for (Bid b : bidTable.keySet()) {
      if (getUtility(b) > maxBidUtility.doubleValue())
      {
        maxBidUtility = Double.valueOf(getUtility(b));
        maxBid = b;
      }
    }
    return maxBid;
  }
  
  private Bid clone(Bid source)
    throws Exception
  {
    HashMap<Integer, Value> hash = new HashMap();
    for (Issue i : this.utilitySpace.getDomain().getIssues()) {
      hash.put(Integer.valueOf(i.getNumber()), source.getValue(i.getNumber()));
    }
    return new Bid(this.utilitySpace.getDomain(), hash);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.acceptanceconditions.anac2012.AC_AgentMR
 * JD-Core Version:    0.7.1
 */