package negotiator.boaframework;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import misc.Range;
import negotiator.bidding.BidDetails;

public abstract class OMStrategy
  extends BOA
{
  protected OpponentModel model;
  private final double RANGE_INCREMENT = 0.01D;
  private final int EXPECTED_BIDS_IN_WINDOW = 100;
  private final double INITIAL_WINDOW_RANGE = 0.01D;
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, HashMap<String, Double> parameters)
    throws Exception
  {
    super.init(negotiationSession);
    this.model = model;
  }
  
  public void init(NegotiationSession negotiationSession, OpponentModel model)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.model = model;
  }
  
  public abstract BidDetails getBid(List<BidDetails> paramList);
  
  public BidDetails getBid(OutcomeSpace space, Range range)
  {
    List<BidDetails> bids = space.getBidsinRange(range);
    if (bids.size() == 0)
    {
      if (range.getUpperbound() < 1.01D)
      {
        range.increaseUpperbound(0.01D);
        return getBid(space, range);
      }
      this.negotiationSession.setOutcomeSpace(space);
      return this.negotiationSession.getMaxBidinDomain();
    }
    return getBid(bids);
  }
  
  public void setOpponentModel(OpponentModel model)
  {
    this.model = model;
  }
  
  public BidDetails getBid(SortedOutcomeSpace space, double targetUtility)
  {
    Range range = new Range(targetUtility, targetUtility + 0.01D);
    
    List<BidDetails> bids = space.getBidsinRange(range);
    if (bids.size() < 100)
    {
      if (range.getUpperbound() < 1.01D)
      {
        range.increaseUpperbound(0.01D);
        return getBid(space, range);
      }
      return getBid(bids);
    }
    return getBid(bids);
  }
  
  public abstract boolean canUpdateOM();
  
  public final void storeData(Serializable object) {}
  
  public final Serializable loadData()
  {
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.boaframework.OMStrategy
 * JD-Core Version:    0.7.1
 */