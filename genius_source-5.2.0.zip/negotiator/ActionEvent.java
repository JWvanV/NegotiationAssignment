package negotiator;

import negotiator.actions.Action;

public class ActionEvent
{
  Agent actor;
  Action act;
  int round;
  long elapsedMilliseconds;
  double normalizedUtilityA;
  double normalizedUtilityB;
  String errorRemarks;
  
  public ActionEvent(Agent actorP, Action actP, int roundP, long elapsed, double utilA, double utilB, String remarks)
  {
    this.actor = actorP;
    this.act = actP;
    this.round = roundP;
    this.elapsedMilliseconds = elapsed;
    this.normalizedUtilityA = utilA;
    this.normalizedUtilityB = utilB;
    this.errorRemarks = remarks;
  }
  
  public String toString()
  {
    return "ActionEvent[" + this.actor + "," + this.act + "," + this.round + "," + this.elapsedMilliseconds + "," + this.normalizedUtilityA + "," + this.normalizedUtilityB + "," + this.errorRemarks + "]";
  }
  
  public double getUtilA()
  {
    return this.normalizedUtilityA;
  }
  
  public double getUtilB()
  {
    return this.normalizedUtilityB;
  }
  
  public String getAgentAsString()
  {
    String a = "" + this.actor.getClass();
    if (a.substring(0, 12).equals("class agents")) {
      return a.substring(13);
    }
    return a.substring(6);
  }
  
  public int getRound()
  {
    return this.round;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.ActionEvent
 * JD-Core Version:    0.7.1
 */