package negotiator;

import java.io.PrintStream;

public class DiscreteTimeline
  extends Timeline
{
  private int totalRounds;
  protected int cRound;
  
  public DiscreteTimeline(int totalRounds)
  {
    this.totalRounds = (totalRounds + 1);
    this.hasDeadline = true;
    this.cRound = 1;
  }
  
  public void printRoundElapsed()
  {
    System.out.println("Elapsed Rounds: " + this.cRound);
  }
  
  public void printTime()
  {
    System.out.println("t = " + getTime());
  }
  
  public double getTime()
  {
    double t = this.cRound / this.totalRounds;
    if (t > 1.0D) {
      t = 1.0D;
    }
    return t;
  }
  
  public void increment()
  {
    this.cRound += 1;
  }
  
  public void setcRound(int cRound)
  {
    this.cRound = cRound;
  }
  
  public void pause() {}
  
  public void resume() {}
  
  public double getTotalTime()
  {
    return this.totalRounds;
  }
  
  public int getRound()
  {
    return this.cRound;
  }
  
  public int getRoundsLeft()
  {
    return this.totalRounds - this.cRound - 1;
  }
  
  public int getTotalRounds()
  {
    return this.totalRounds;
  }
  
  public int getOwnTotalRounds()
  {
    return (int)Math.floor(getTotalRounds() / 2);
  }
  
  public int getOwnRoundsLeft()
  {
    return (int)Math.floor(getRoundsLeft() / 2);
  }
  
  public Timeline.Type getType()
  {
    return Timeline.Type.Rounds;
  }
  
  public double getCurrentTime()
  {
    return this.cRound;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.DiscreteTimeline
 * JD-Core Version:    0.7.1
 */