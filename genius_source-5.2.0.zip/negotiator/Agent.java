package negotiator;

import java.io.PrintStream;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import negotiator.actions.Action;
import negotiator.exceptions.Warning;
import negotiator.protocol.BilateralAtomicNegotiationSession;
import negotiator.tournament.TournamentRunner;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.DataObjects;
import negotiator.utility.UtilitySpace;

public abstract class Agent
{
  private AgentID agentID;
  private String fName = null;
  public UtilitySpace utilitySpace;
  @Deprecated
  public Date startTime;
  @Deprecated
  public Integer totalTime;
  public Timeline timeline;
  public int sessionNr;
  public int sessionsTotal;
  public BilateralAtomicNegotiationSession fNegotiation;
  @Deprecated
  protected HashMap<AgentParameterVariable, AgentParamValue> parametervalues;
  protected StrategyParameters strategyParameters;
  private static DataObjects dataObjects = new DataObjects("DataObjects");
  
  public Agent()
  {
    this.strategyParameters = new StrategyParameters();
  }
  
  public String getVersion()
  {
    return "unknown";
  }
  
  public void init() {}
  
  public final void internalInit(int sessionNr, int sessionsTotal, Date startTimeP, Integer totalTimeP, Timeline timeline, UtilitySpace us, HashMap<AgentParameterVariable, AgentParamValue> params)
  {
    this.startTime = startTimeP;
    this.totalTime = totalTimeP;
    this.timeline = timeline;
    this.sessionNr = sessionNr;
    this.sessionsTotal = sessionsTotal;
    this.utilitySpace = us;
    this.parametervalues = params;
    if ((this.parametervalues != null) && (!this.parametervalues.isEmpty())) {
      System.out.println("Agent " + getName() + " initted with parameters " + this.parametervalues);
    }
  }
  
  public void ReceiveMessage(Action opponentAction) {}
  
  public abstract Action chooseAction();
  
  public String getName()
  {
    return this.fName;
  }
  
  @Deprecated
  public HashMap<AgentParameterVariable, AgentParamValue> getParameterValues()
  {
    return this.parametervalues;
  }
  
  public final void setName(String pName)
  {
    if (this.fName == null) {
      this.fName = pName;
    }
  }
  
  public double getUtility(Bid bid)
  {
    return this.utilitySpace.getUtilityWithDiscount(bid, this.timeline);
  }
  
  public void sleep(double fraction)
  {
    if (this.timeline.getType().equals(Timeline.Type.Time))
    {
      long sleep = (this.timeline.getTotalTime() * 1000.0D * fraction);
      try
      {
        Thread.sleep(sleep);
      }
      catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public boolean isUIAgent()
  {
    return false;
  }
  
  public void endSession(NegotiationResult dUtil) {}
  
  public AgentID getAgentID()
  {
    return this.agentID;
  }
  
  public void setAgentID(AgentID value)
  {
    this.agentID = value;
  }
  
  public StrategyParameters getStrategyParameters()
  {
    return this.strategyParameters;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getDefault();
  }
  
  public void parseStrategyParameters(String variables)
    throws Exception
  {
    if (variables != null)
    {
      String[] vars = variables.split(";");
      for (String var : vars)
      {
        String[] expression = var.split("=");
        if (expression.length == 2) {
          this.strategyParameters.addVariable(expression[0], expression[1]);
        } else {
          throw new Exception("Expected variablename and result but got " + expression.length + " elements. " + "Correct in XML or overload the method.");
        }
      }
    }
  }
  
  public int getSessionNumber()
  {
    return this.sessionNr;
  }
  
  public int getSessionsTotal()
  {
    return this.sessionsTotal;
  }
  
  protected final boolean saveSessionData(Serializable dataToSave)
  {
    String agentClassName = getUniqueIdentifier();
    try
    {
      String prefProfName = this.utilitySpace.getFileName();
      return dataObjects.saveData(dataToSave, agentClassName, prefProfName);
    }
    catch (Exception e)
    {
      new Warning("Exception during saving data for agent " + agentClassName + " : " + e.getMessage());
      e.printStackTrace();
    }
    return false;
  }
  
  protected String getUniqueIdentifier()
  {
    return getClass().getName();
  }
  
  protected final Serializable loadSessionData()
  {
    String agentClassName = getUniqueIdentifier();
    try
    {
      String prefProfName = this.utilitySpace.getFileName();
      return dataObjects.loadData(agentClassName, prefProfName);
    }
    catch (Exception e)
    {
      new Warning("Exception during loading data for agent " + agentClassName + " : " + e.getMessage());
      e.printStackTrace();
    }
    return null;
  }
  
  public static boolean restartDataObjectsFolder(Object sender)
  {
    if ((sender instanceof TournamentRunner)) {
      return dataObjects.restartFolder();
    }
    return false;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Agent
 * JD-Core Version:    0.7.1
 */