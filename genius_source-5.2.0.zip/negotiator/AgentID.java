package negotiator;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class AgentID
{
  @XmlAttribute
  String ID;
  
  public AgentID() {}
  
  public AgentID(String id)
  {
    this.ID = id;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (this.ID == null ? 0 : this.ID.hashCode());
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    AgentID other = (AgentID)obj;
    if (this.ID == null)
    {
      if (other.ID != null) {
        return false;
      }
    }
    else if (!this.ID.equals(other.ID)) {
      return false;
    }
    return true;
  }
  
  public String toString()
  {
    return this.ID;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.AgentID
 * JD-Core Version:    0.7.1
 */