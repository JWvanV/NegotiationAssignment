package negotiator;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlElement;

class Temp
{
  @XmlElement(name="issue")
  public List<Item> entry = new ArrayList();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Temp
 * JD-Core Version:    0.7.1
 */