package negotiator;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import negotiator.issue.Value;

class MyMapAdapter
  extends XmlAdapter<Temp, Map<Integer, Value>>
{
  public Temp marshal(Map<Integer, Value> arg0)
    throws Exception
  {
    Temp temp = new Temp();
    for (Map.Entry<Integer, Value> entry : arg0.entrySet()) {
      temp.entry.add(new Item((Integer)entry.getKey(), (Value)entry.getValue()));
    }
    return temp;
  }
  
  public Map<Integer, Value> unmarshal(Temp arg0)
    throws Exception
  {
    Map<Integer, Value> map = new HashMap();
    for (Item item : arg0.entry) {
      map.put(item.key, item.value);
    }
    return map;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.MyMapAdapter
 * JD-Core Version:    0.7.1
 */