package negotiator;

import java.util.ArrayList;
import negotiator.xml.SimpleElement;

public class ArrayListXML<E>
  extends ArrayList<E>
  implements XMLable
{
  private static final long serialVersionUID = 2308241807299226296L;
  
  ArrayListXML(ArrayList<E> l)
  {
    super(l);
  }
  
  public SimpleElement toXML()
  {
    SimpleElement xmlist = new SimpleElement("ArrayList");
    int N = size();
    xmlist.setAttribute("size", "" + N);
    for (int i = 0; i < N; i++)
    {
      SimpleElement elt = new SimpleElement("ArrayListElement");
      elt.setAttribute("index", String.valueOf(i));
      E e = get(i);
      if (!(e instanceof XMLable)) {
        throw new ClassCastException("Element of ArrayListXML at position " + i + " is not XMLable");
      }
      elt.addChildElement(((XMLable)e).toXML());
      xmlist.addChildElement(elt);
    }
    return xmlist;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.ArrayListXML
 * JD-Core Version:    0.7.1
 */