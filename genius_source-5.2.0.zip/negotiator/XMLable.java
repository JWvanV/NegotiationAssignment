package negotiator;

import negotiator.xml.SimpleElement;

public abstract interface XMLable
{
  public abstract SimpleElement toXML();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.XMLable
 * JD-Core Version:    0.7.1
 */