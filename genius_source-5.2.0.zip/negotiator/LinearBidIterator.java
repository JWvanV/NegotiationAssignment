package negotiator;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import negotiator.issue.Issue;
import negotiator.utility.UtilitySpace;

public class LinearBidIterator
  extends BidIterator
{
  private List<Issue> sortedIssues;
  
  public LinearBidIterator(Domain domain, final UtilitySpace space, double maxUtil, double minUtil)
  {
    super(domain);
    this.sortedIssues = new LinkedList();
    
    this.sortedIssues.addAll(space.getDomain().getIssues());
    Collections.sort(this.sortedIssues, new Comparator()
    {
      public int compare(Issue o1, Issue o2)
      {
        if (space.getWeight(o1.getNumber()) > space.getWeight(o2.getNumber())) {
          return 0;
        }
        return 1;
      }
    });
  }
  
  public boolean hasNext()
  {
    return super.hasNext();
  }
  
  public Bid next()
  {
    return super.next();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.LinearBidIterator
 * JD-Core Version:    0.7.1
 */