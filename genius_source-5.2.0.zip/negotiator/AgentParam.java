package negotiator;

public class AgentParam
{
  public String agentclass;
  public String name;
  public Double min;
  public Double max;
  static final long serialVersionUID = 0L;
  
  public AgentParam(String agentclassP, String nameP, Double minP, Double maxP)
  {
    this.agentclass = agentclassP;
    this.name = nameP;
    this.min = minP;
    this.max = maxP;
  }
  
  public boolean equals(Object o)
  {
    if (!(o instanceof AgentParam)) {
      return false;
    }
    AgentParam ap = (AgentParam)o;
    return (ap.agentclass.equals(this.agentclass)) && (ap.name.equals(this.name));
  }
  
  public String toString()
  {
    return this.agentclass + ":" + this.name;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.AgentParam
 * JD-Core Version:    0.7.1
 */