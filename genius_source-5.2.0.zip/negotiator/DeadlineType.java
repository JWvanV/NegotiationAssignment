package negotiator;

public enum DeadlineType
{
  TIME,  ROUND;
  
  private DeadlineType() {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.DeadlineType
 * JD-Core Version:    0.7.1
 */