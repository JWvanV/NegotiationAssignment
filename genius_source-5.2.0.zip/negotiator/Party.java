package negotiator;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.actions.Action;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.UtilitySpace;

public abstract class Party
{
  protected AgentID partyID;
  protected UtilitySpace utilitySpace;
  protected HashMap<AgentParameterVariable, AgentParamValue> parametervalues;
  protected ArrayList<Integer> partyListenerIndices;
  protected Random randomnr;
  private DeadlineType deadlineType;
  private int totalRoundOrTime;
  private Timeline timeline;
  private int round;
  private int sessionNo;
  
  public Party()
  {
    this.partyListenerIndices = new ArrayList();
    setRound(1);
  }
  
  public static String getVersion()
  {
    return "unknown";
  }
  
  public AgentID getPartyID()
  {
    return this.partyID;
  }
  
  public void setPartyID(AgentID partyID)
  {
    this.partyID = partyID;
  }
  
  public UtilitySpace getUtilitySpace()
  {
    return this.utilitySpace;
  }
  
  public void setUtilitySpace(UtilitySpace utilitySpace)
  {
    this.utilitySpace = utilitySpace;
  }
  
  public HashMap<AgentParameterVariable, AgentParamValue> getParametervalues()
  {
    return this.parametervalues;
  }
  
  public void setParametervalues(HashMap<AgentParameterVariable, AgentParamValue> parametervalues)
  {
    this.parametervalues = parametervalues;
  }
  
  public void init()
  {
    this.randomnr = new Random(getSessionNo());
  }
  
  public final void internalInit(int sessionNo, DeadlineType deadlineType, int totalRoundOrTime, UtilitySpace us, HashMap<AgentParameterVariable, AgentParamValue> params)
  {
    setSessionNo(sessionNo);
    setDeadlineType(deadlineType);
    setTotalRoundOrTime(totalRoundOrTime);
    this.utilitySpace = us;
    this.parametervalues = params;
    setRound(1);
    System.out.println("Party " + getPartyID() + " initted with parameters " + this.parametervalues);
  }
  
  public void cleanUp() {}
  
  public double getUtility(Bid bid)
  {
    try
    {
      return this.utilitySpace.getUtility(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  public double getUtilityWithDiscount(Bid bid)
  {
    return this.utilitySpace.getUtilityWithDiscount(bid, this.timeline);
  }
  
  public abstract void ReceiveMessage(Action paramAction);
  
  public abstract Action chooseAction(ArrayList<Class> paramArrayList);
  
  public ArrayList<Integer> getPartyListenerIndices()
  {
    return this.partyListenerIndices;
  }
  
  public void setPartyListenerIndices(ArrayList<Integer> partyListenerIndices)
  {
    this.partyListenerIndices = partyListenerIndices;
  }
  
  public void addPartyListenerIndex(int index)
  {
    this.partyListenerIndices.add(new Integer(index));
  }
  
  public int getSessionNo()
  {
    return this.sessionNo;
  }
  
  public void setSessionNo(int sessionNo)
  {
    this.sessionNo = sessionNo;
  }
  
  public int getTotalRoundOrTime()
  {
    return this.totalRoundOrTime;
  }
  
  public void setTotalRoundOrTime(int totalRoundOrTime)
  {
    this.totalRoundOrTime = totalRoundOrTime;
  }
  
  public DeadlineType getDeadlineType()
  {
    return this.deadlineType;
  }
  
  public void setDeadlineType(DeadlineType deadlineType)
  {
    this.deadlineType = deadlineType;
  }
  
  public Timeline getTimeline()
  {
    return this.timeline;
  }
  
  public void setTimeline(Timeline timeline)
  {
    this.timeline = timeline;
  }
  
  public int getRound()
  {
    return this.round;
  }
  
  public void setRound(int round)
  {
    this.round = round;
  }
  
  protected Value getRandomValue(Issue currentIssue)
    throws Exception
  {
    Value currentValue = null;
    switch (currentIssue.getType())
    {
    case DISCRETE: 
      IssueDiscrete lIssueDiscrete = (IssueDiscrete)currentIssue;
      int index = this.randomnr.nextInt(lIssueDiscrete.getNumberOfValues());
      currentValue = lIssueDiscrete.getValue(index);
      break;
    case REAL: 
      IssueReal lIssueReal = (IssueReal)currentIssue;
      int index = this.randomnr.nextInt(lIssueReal.getNumberOfDiscretizationSteps());
      currentValue = new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lIssueReal.getNumberOfDiscretizationSteps() * index);
      break;
    case INTEGER: 
      IssueInteger lIssueInteger = (IssueInteger)currentIssue;
      int index = this.randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound() + 1);
      currentValue = new ValueInteger(lIssueInteger.getLowerBound() + index);
      break;
    default: 
      throw new Exception("issue type " + currentIssue.getType() + " not supported");
    }
    int index;
    return currentValue;
  }
  
  protected Bid generateRandomBid()
    throws Exception
  {
    Bid randomBid = null;
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    for (Issue currentIssue : issues) {
      values.put(Integer.valueOf(currentIssue.getNumber()), getRandomValue(currentIssue));
    }
    randomBid = new Bid(this.utilitySpace.getDomain(), values);
    
    return randomBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     negotiator.Party
 * JD-Core Version:    0.7.1
 */