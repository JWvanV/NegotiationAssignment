package agents.qoagent;

public class AgentTools
{
  AutomatedAgent agent = null;
  
  public AgentTools(AutomatedAgent agent)
  {
    this.agent = agent;
  }
  
  public void acceptMessage(String sOriginalMessage)
  {
    String sAcceptMsg = this.agent.formatMessage(6, sOriginalMessage);
    



    AutomatedAgentDelayedMessageThread delayedMessageThread = new AutomatedAgentDelayedMessageThread(this.agent, sAcceptMsg);
    delayedMessageThread.start();
  }
  
  public void rejectMessage(String sOriginalMessage)
  {
    String sRejectMsg = this.agent.formatMessage(7, sOriginalMessage);
    



    AutomatedAgentDelayedMessageThread delayedMessageThread = new AutomatedAgentDelayedMessageThread(this.agent, sRejectMsg);
    delayedMessageThread.start();
  }
  
  public void sendMessage(int nMessageType, int[] currentAgreementIdx)
  {
    String sMessage = getMessageByIndices(currentAgreementIdx);
    sMessage = this.agent.formatMessage(nMessageType, sMessage);
    



    AutomatedAgentDelayedMessageThread delayedMessageThread = new AutomatedAgentDelayedMessageThread(this.agent, sMessage, this.agent.getCurrentTurn());
    delayedMessageThread.start();
  }
  
  public void optOut()
  {
    String sMessage = this.agent.formatMessage(8, "");
    this.agent.printMessageToServer(sMessage);
  }
  
  public void sendMessage(int nMessageType, String sMessage)
  {
    sMessage = this.agent.formatMessage(nMessageType, sMessage);
    



    AutomatedAgentDelayedMessageThread delayedMessageThread = new AutomatedAgentDelayedMessageThread(this.agent, sMessage, this.agent.getCurrentTurn());
    delayedMessageThread.start();
  }
  
  public void sendOffer(String sOffer)
  {
    setSendOfferFlag(true);
    sendMessage(3, sOffer);
  }
  
  public void sendQuery(int[] currentAgreementIdx)
  {
    setSendOfferFlag(true);
    sendMessage(5, currentAgreementIdx);
  }
  
  public void sendPromise(int[] currentAgreementIdx)
  {
    setSendOfferFlag(true);
    sendMessage(4, currentAgreementIdx);
  }
  
  public void sendCounterOffers(int[] currentAgreementIdx)
  {
    setSendOfferFlag(true);
    sendMessage(9, currentAgreementIdx);
  }
  
  public void sendComment(String sMessage)
  {
    sMessage = this.agent.formatMessage(2, sMessage);
    this.agent.printMessageToServer(sMessage);
  }
  
  public void sendThreat(String sMessage)
  {
    sMessage = this.agent.formatMessage(1, sMessage);
    this.agent.printMessageToServer(sMessage);
  }
  
  public int getTurnsNumber()
  {
    return this.agent.getMaxTurns();
  }
  
  public int getCurrentTurn()
  {
    return this.agent.getCurrentTurn();
  }
  
  public double getAgreementValue(AutomatedAgentType agentType, int[] CurrentAgreementIdx, int nCurrentTurn)
  {
    return agentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
  }
  
  public String getBestAgreementStr(AutomatedAgentType agentType)
  {
    return agentType.getBestAgreementStr();
  }
  
  public double getBestAgreementValue(AutomatedAgentType agentType)
  {
    return agentType.getBestAgreementValue();
  }
  
  public String getWorstAgreementStr(AutomatedAgentType agentType)
  {
    return agentType.getWorstAgreementStr();
  }
  
  public double getWorstAgreementValue(AutomatedAgentType agentType)
  {
    return agentType.getWorstAgreementValue();
  }
  
  public void setBestAgreementValue(AutomatedAgentType agentType, double value)
  {
    agentType.setBestAgreementValue(value);
  }
  
  public void setBestAgreementIndices(AutomatedAgentType agentType, int[] currentAgreementIdx)
  {
    agentType.setBestAgreementIndices(currentAgreementIdx);
  }
  
  public void setWorstAgreementValue(AutomatedAgentType agentType, double value)
  {
    agentType.setWorstAgreementValue(value);
  }
  
  public void setWorstAgreementIndices(AutomatedAgentType agentType, int[] currentAgreementIdx)
  {
    agentType.setWorstAgreementIndices(currentAgreementIdx);
  }
  
  public void initializeBestAgreement(AutomatedAgentType agentType)
  {
    agentType.setBestAgreementValue(-9999.0D);
    agentType.initializeBestAgreementIndices();
  }
  
  public void initializeWorstAgreement(AutomatedAgentType agentType)
  {
    agentType.setWorstAgreementValue(9999.0D);
    agentType.initializeWorstAgreementIndices();
  }
  
  public double getAgreementTimeEffect(AutomatedAgentType agentType)
  {
    return agentType.getAgreementTypeEffect();
  }
  
  public double getSQValue(AutomatedAgentType agentType)
  {
    return agentType.getSQValue();
  }
  
  public double getOptOutValue(AutomatedAgentType agentType)
  {
    return agentType.getOptOutValue();
  }
  
  public int getTotalAgreements(AutomatedAgentType agentType)
  {
    return agentType.getTotalAgreements();
  }
  
  public void setAutomatedAgentType(String side)
  {
    this.agent.setAgentType(side, 0);
  }
  
  public String getAgentSide()
  {
    return this.agent.getAgentSide();
  }
  
  public String getSelectedOffer()
  {
    String sAutomatedAgentAgreement = this.agent.getAutomatedAgentAgreement();
    
    return sAutomatedAgentAgreement;
  }
  
  public double getSelectedOfferValue()
  {
    String sAutomatedAgentAgreement = this.agent.getAutomatedAgentAgreement();
    
    int[] nextAgreementIndices = new int[20];
    nextAgreementIndices = this.agent.getAgreementIndices(sAutomatedAgentAgreement);
    
    double dNextAgreementValue = this.agent.getAgreementValue(nextAgreementIndices);
    
    return dNextAgreementValue;
  }
  
  public double getAcceptedAgreementsValue()
  {
    int[] previousAcceptedAgreementsIndices = new int[20];
    previousAcceptedAgreementsIndices = this.agent.getPreviousAcceptedAgreementsIndices();
    
    double dAcceptedAgreementValue = this.agent.getAgreementValue(previousAcceptedAgreementsIndices);
    
    return dAcceptedAgreementValue;
  }
  
  public int[] getAcceptedAgreementIdx()
  {
    int[] previousAcceptedAgreementsIndices = new int[20];
    previousAcceptedAgreementsIndices = this.agent.getPreviousAcceptedAgreementsIndices();
    
    return previousAcceptedAgreementsIndices;
  }
  
  public void calculateNextTurnOffer()
  {
    this.agent.calculateNextTurnOffer();
  }
  
  public double getNextTurnOfferValue()
  {
    double dAutomatedAgentNextOfferValueForAgent = this.agent.getNextTurnAutomatedAgentOfferValue();
    return dAutomatedAgentNextOfferValueForAgent;
  }
  
  public void getNextAgreement(int totalIssuesNum, int[] currentAgreementIdx, int[] maxIssueValues)
  {
    boolean bFinishUpdate = false;
    for (int k = totalIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
      if (currentAgreementIdx[k] + 1 >= maxIssueValues[k])
      {
        currentAgreementIdx[k] = 0;
      }
      else
      {
        currentAgreementIdx[k] += 1;
        bFinishUpdate = true;
      }
    }
  }
  
  public AutomatedAgentType getNextTurnSideAgentType(String sideName, int type)
  {
    AutomatedAgentType agentType = null;
    agentType = this.agent.getNextTurnSideAgentType(sideName, type);
    return agentType;
  }
  
  public AutomatedAgentType getCurrentTurnSideAgentType(String sideName, int type)
  {
    AutomatedAgentType agentType = null;
    agentType = this.agent.getCurrentTurnSideAgentType(sideName, type);
    return agentType;
  }
  
  public double getNextTurnAutomatedAgentValue()
  {
    return this.agent.getNextTurnAutomatedAgentValue();
  }
  
  public double getCurrentTurnAutomatedAgentValue()
  {
    return this.agent.getCurrentTurnAutomatedAgentValue();
  }
  
  public void setCurrentTurnAutomatedAgentValue(double agreementValue)
  {
    this.agent.setCurrentTurnAutomatedAgentValue(agreementValue);
  }
  
  public void setNextTurnAutomatedAgentSelectedValue(double agreementValue)
  {
    this.agent.setNextTurnAutomatedAgentSelectedValue(agreementValue);
  }
  
  public void setNextTurnOpponentSelectedValue(double agreementValue)
  {
    this.agent.setNextTurnOpponentSelectedValue(agreementValue);
  }
  
  public void setCurrentTurnOpponentSelectedValue(double agreementValue)
  {
    this.agent.setCurrentTurnOpponentSelectedValue(agreementValue);
  }
  
  public void setNextTurnAgreementString(String agreementStr)
  {
    this.agent.setNextTurnAgreementString(agreementStr);
  }
  
  public void setCurrentTurnAgreementString(String agreementStr)
  {
    this.agent.setCurrentTurnAgreementString(agreementStr);
  }
  
  public void setNextTurnOpponentType(int type)
  {
    this.agent.setNextTurnOpponentType(type);
  }
  
  public void calculateResponse(int messageType, int[] currentAgreementIdx, String message)
  {
    this.agent.calculateResponse(messageType, currentAgreementIdx, message);
  }
  
  public String getMessageByIndices(int[] currentAgreementIdx)
  {
    return this.agent.getAgreementStr(currentAgreementIdx);
  }
  
  public int[] getMessageIndicesByMessage(String currentAgreementStr)
  {
    return this.agent.getAgreementIndices(currentAgreementStr);
  }
  
  public double getAgreementValue(int[] currentAgreementIdx)
  {
    double dAgreementValue = this.agent.getAgreementValue(currentAgreementIdx);
    return dAgreementValue;
  }
  
  public double getSecondPerTurn()
  {
    return this.agent.getSecondsForTurn();
  }
  
  public int getTotalIssues(AutomatedAgentType agentType)
  {
    return agentType.getIssuesNum();
  }
  
  public int getMaxValuePerIssue(AutomatedAgentType agentType, int issueNum)
  {
    return agentType.getMaxIssueValue(issueNum);
  }
  
  public boolean getSendOfferFlag()
  {
    return this.agent.getSendOfferFlag();
  }
  
  public void setSendOfferFlag(boolean flag)
  {
    this.agent.setSendOfferFlag(flag);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AgentTools
 * JD-Core Version:    0.7.1
 */