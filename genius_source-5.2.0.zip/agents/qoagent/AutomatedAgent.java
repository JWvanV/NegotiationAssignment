package agents.qoagent;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class AutomatedAgent
{
  public static final String SIDE_A_NAME = "SIDE_A";
  public static final String SIDE_B_NAME = "SIDE_B";
  static final String AGENT_NAME = "Automated_Agent";
  static final String AGENT_ID = "000000";
  private String m_sAgentSide;
  private String m_sAgentName;
  private String m_sAgentId;
  private String m_sLogFileName;
  private String m_sOppAgentId;
  private int m_nMaxTurns;
  private int m_nCurrentTurn;
  private int m_nMsgId;
  private int m_nPortNum;
  private boolean m_bHasOpponent;
  private long m_lSecondsForTurn;
  private AgentTools m_agentTools = null;
  private AbstractAutomatedAgent m_abstractAgent = null;
  private AutomatedAgentMessages m_messages;
  public AutomatedAgentGameTime m_gtStopTurn;
  public AutomatedAgentGameTime m_gtStopNeg;
  private AutomatedAgentsCore m_AgentCore;
  private AutomatedAgentType m_AgentType;
  private AutomatedAgentType m_AgentTypeNextTurn;
  private int[] m_PreviosAcceptedOffer;
  private boolean m_bSendOffer = true;
  
  public AutomatedAgent() {}
  
  public AutomatedAgent(String sSide, int nPortNum, String sName, String sId)
  {
    this.m_bSendOffer = true;
    this.m_agentTools = new AgentTools(this);
    this.m_abstractAgent = new AbstractAutomatedAgent(this.m_agentTools);
    
    this.m_sLogFileName = "";
    
    this.m_PreviosAcceptedOffer = new int[20];
    for (int i = 0; i < 20; i++) {
      this.m_PreviosAcceptedOffer[i] = -1;
    }
    if (sName.equals("")) {
      sName = "Automated_Agent";
    }
    if (sId.equals("")) {
      sId = "000000";
    }
    this.m_messages = new AutomatedAgentMessages(this, this.m_agentTools, this.m_abstractAgent);
    
    this.m_sAgentSide = sSide;
    this.m_nPortNum = nPortNum;
    this.m_sAgentName = sName;
    this.m_sAgentId = sId;
    
    setHasOpponent(false, null);
    setMaxTurns(0);
    setCurrentTurn(1);
    
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy.H.mm.ss");
    Date now = new Date();
    String sNow = formatter.format(now);
    
    this.m_sLogFileName = ("logs\\AutomatedAgentData" + sNow + ".log");
    
    this.m_AgentCore = new AutomatedAgentsCore(this.m_sLogFileName, sNow, this.m_agentTools, this.m_abstractAgent);
    



    this.m_agentTools.setAutomatedAgentType(this.m_sAgentSide);
    


    this.m_AgentType.calculateValues(this.m_abstractAgent, this.m_nCurrentTurn);
    this.m_AgentTypeNextTurn = this.m_AgentType;
    this.m_AgentTypeNextTurn.calculateValues(this.m_abstractAgent, this.m_nCurrentTurn + 1);
    
    this.m_AgentCore.initGenerateAgreement(this.m_AgentType);
  }
  
  public AutomatedAgentType getAgentType()
  {
    return this.m_AgentType;
  }
  
  public void setAgentType(String side, int type)
  {
    if (side.equals("SIDE_B")) {
      switch (type)
      {
      case 1: 
        this.m_AgentType = this.m_AgentCore.getSideBShortTermType();
        break;
      case 0: 
        this.m_AgentType = this.m_AgentCore.getSideBLongTermType();
        break;
      case 2: 
        this.m_AgentType = this.m_AgentCore.getSideBCompromiseType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::setAgentType(129)]");
        break;
      }
    } else if (side.equals("SIDE_A")) {
      switch (type)
      {
      case 1: 
        this.m_AgentType = this.m_AgentCore.getSideAShortTermType();
        break;
      case 0: 
        this.m_AgentType = this.m_AgentCore.getSideALongTermType();
        break;
      case 2: 
        this.m_AgentType = this.m_AgentCore.getSideACompromiseType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::setAgentType(129)]");
      }
    }
  }
  
  public String getAgentName()
  {
    return this.m_sAgentName;
  }
  
  public String getAgentSide()
  {
    return this.m_sAgentSide;
  }
  
  public String getAgentId()
  {
    return this.m_sAgentId;
  }
  
  public void receivedMessage(String sMessage)
  {
    String sParsedMsg = this.m_messages.parseMessage(sMessage);
    String sRegister;
    if (sParsedMsg.equals("nak"))
    {
      setMsgId(1);
      generateId();
      sRegister = this.m_messages.formatMessage(0, this.m_sAgentId);
    }
  }
  
  public void printMessageToServer(String sMessage)
  {
    System.out.println("Agent tries to send a message to the server:" + sMessage);
  }
  
  public void endNegotiation() {}
  
  public int getPort()
  {
    return this.m_nPortNum;
  }
  
  public void setHasOpponent(boolean bHasOpponent, String sOppId)
  {
    this.m_bHasOpponent = bHasOpponent;
    if (this.m_bHasOpponent)
    {
      setOpponentAgentId(sOppId);
      try
      {
        PrintWriter bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
        bw.println("AutomatedAgent Side: " + this.m_sAgentSide);
        bw.println("Opponent ID: " + sOppId);
        bw.close();
      }
      catch (IOException e)
      {
        System.out.println("[AA]ERROR----Error opening logfile: " + e.getMessage() + " [AutomatedAgent::setHasOpponent(266)]");
        System.err.println("[AA]ERROR----Error opening logfile: " + e.getMessage() + " [AutomatedAgent::setHasOpponent(266)]");
      }
    }
    else
    {
      setOpponentAgentId("");
    }
  }
  
  public void setOpponentAgentId(String sOppId)
  {
    this.m_sOppAgentId = sOppId;
  }
  
  public String getOpponentAgentId()
  {
    return this.m_sOppAgentId;
  }
  
  public void setSecondsForTurn(long lSeconds)
  {
    this.m_lSecondsForTurn = lSeconds;
  }
  
  public long getSecondsForTurn()
  {
    return this.m_lSecondsForTurn;
  }
  
  public String getSupportMediator()
  {
    return "no";
  }
  
  public int getMaxTurns()
  {
    return this.m_nMaxTurns;
  }
  
  public void setMaxTurns(int nMaxTurns)
  {
    this.m_nMaxTurns = nMaxTurns;
  }
  
  public int getCurrentTurn()
  {
    return this.m_nCurrentTurn;
  }
  
  public void setCurrentTurn(int nCurrentTurn)
  {
    this.m_nCurrentTurn = nCurrentTurn;
  }
  
  public void incrementCurrentTurn()
  {
    this.m_nCurrentTurn += 1;
    updateAgreementsValues();
    
    calculateAgreement();
  }
  
  public void calculateAgreement()
  {
    this.m_AgentCore.calculateAgreement(this.m_AgentType, this.m_nCurrentTurn);
  }
  
  public void updateAgreementsValues()
  {
    this.m_AgentType.calculateValues(this.m_abstractAgent, this.m_nCurrentTurn);
    this.m_AgentTypeNextTurn.calculateValues(this.m_abstractAgent, this.m_nCurrentTurn + 1);
    
    this.m_AgentCore.updateAgreementsValues(this.m_nCurrentTurn);
  }
  
  public int getMsgId()
  {
    return this.m_nMsgId;
  }
  
  public void setMsgId(int nMsgId)
  {
    this.m_nMsgId = nMsgId;
  }
  
  public void incrementMsgId()
  {
    this.m_nMsgId += 1;
  }
  
  public void generateId()
  {
    Random rn = new Random();
    
    int nRandomAgentId = rn.nextInt();
    nRandomAgentId = Math.abs(nRandomAgentId);
    

    String sAgentId = new Integer(nRandomAgentId).toString();
    this.m_sAgentId = sAgentId;
  }
  
  public int[] getAgreementIndices(String sAgreementStr)
  {
    return this.m_AgentType.getAgreementIndices(sAgreementStr);
  }
  
  public void saveAcceptedMsg(String sMessage)
  {
    this.m_PreviosAcceptedOffer = getAgreementIndices(sMessage);
    if (this.m_PreviosAcceptedOffer == null) {
      this.m_PreviosAcceptedOffer = new int[20];
    }
  }
  
  public void calculateResponse(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage)
  {
    for (int i = 0; i < 20; i++) {
      if (CurrentAgreementIdx[i] == -1) {
        CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
      } else if (this.m_AgentType.isIssueValueNoAgreement(i, CurrentAgreementIdx[i])) {
        if (this.m_PreviosAcceptedOffer[i] != -1) {
          CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
        }
      }
    }
    this.m_abstractAgent.calculateResponse(nMessageType, CurrentAgreementIdx, sOriginalMessage);
  }
  
  public String getAutomatedAgentAgreement()
  {
    String sAgreement = this.m_AgentCore.getAutomatedAgentAgreement();
    return sAgreement;
  }
  
  public String formatMessage(int message, String sMessage)
  {
    String formattedMessage = this.m_messages.formatMessage(message, sMessage);
    return formattedMessage;
  }
  
  public double getAgreementValue(int[] agreementIndices)
  {
    double agreementValue = this.m_AgentType.getAgreementValue(agreementIndices, this.m_nCurrentTurn);
    return agreementValue;
  }
  
  public int[] getPreviousAcceptedAgreementsIndices()
  {
    return this.m_PreviosAcceptedOffer;
  }
  
  public void calculateNextTurnOffer()
  {
    this.m_AgentCore.calculateNextTurnAgreement(this.m_AgentTypeNextTurn, this.m_nCurrentTurn + 1);
  }
  
  public double getNextTurnAutomatedAgentOfferValue()
  {
    double dAutomatedAgentNextOfferValueForAgent = this.m_AgentCore.getNextTurnAutomatedAgentUtilityValue();
    return dAutomatedAgentNextOfferValueForAgent;
  }
  
  public AutomatedAgentType getNextTurnSideAgentType(String sideName, int type)
  {
    AutomatedAgentType agentType = null;
    if (sideName.equals("SIDE_A"))
    {
      switch (type)
      {
      case 2: 
        agentType = this.m_AgentCore.getSideACompromiseNextTurnType();
        break;
      case 0: 
        agentType = this.m_AgentCore.getSideALongTermNextTurnType();
        break;
      case 1: 
        agentType = this.m_AgentCore.getSideAShortTermNextTurnType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::getNextTurnSideAgentType(585)]");
        break;
      }
    }
    else if (sideName.equals("SIDE_B"))
    {
      switch (type)
      {
      case 2: 
        agentType = this.m_AgentCore.getSideBCompromiseNextTurnType();
        break;
      case 0: 
        agentType = this.m_AgentCore.getSideBLongTermNextTurnType();
        break;
      case 1: 
        agentType = this.m_AgentCore.getSideBShortTermNextTurnType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::getNextTurnSideAgentType(600)]");
        break;
      }
    }
    else
    {
      System.out.println("[AA]Agent type is unknown [AutomatedAgent::getNextTurnSideAgentType(604)]");
      System.err.println("[AA]Agent type is unknown [AutomatedAgent::getNextTurnSideAgentType(604)]");
      return null;
    }
    return agentType;
  }
  
  public AutomatedAgentType getCurrentTurnSideAgentType(String sideName, int type)
  {
    AutomatedAgentType agentType = null;
    if (sideName.equals("SIDE_A"))
    {
      switch (type)
      {
      case 2: 
        agentType = this.m_AgentCore.getSideACompromiseType();
        break;
      case 0: 
        agentType = this.m_AgentCore.getSideALongTermType();
        break;
      case 1: 
        agentType = this.m_AgentCore.getSideAShortTermType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::getCurrentTurnSideAgentType(622)]");
        break;
      }
    }
    else if (sideName.equals("SIDE_B"))
    {
      switch (type)
      {
      case 2: 
        agentType = this.m_AgentCore.getSideBCompromiseType();
        break;
      case 0: 
        agentType = this.m_AgentCore.getSideBLongTermType();
        break;
      case 1: 
        agentType = this.m_AgentCore.getSideBShortTermType();
        break;
      default: 
        System.err.println("[AA]ERROR----Wrong type for agent: " + type + " [AutomatedAgent::getCurrentTurnSideAgentType(637)]");
        break;
      }
    }
    else
    {
      System.out.println("[AA]Agent type is unknown [AutomatedAgent::getCurrentTurnSideAgentType(642)]");
      System.err.println("[AA]Agent type is unknown [AutomatedAgent::getCurrentTurnSideAgentType(642)]");
      return null;
    }
    return agentType;
  }
  
  public double getNextTurnAutomatedAgentValue()
  {
    return this.m_AgentCore.getNextTurnAutomatedAgentValue();
  }
  
  public double getCurrentTurnAutomatedAgentValue()
  {
    return this.m_AgentCore.getCurrentTurnAutomatedAgentValue();
  }
  
  public void setNextTurnAutomatedAgentValue(double value)
  {
    this.m_AgentCore.setNextTurnAutomatedAgentValue(value);
  }
  
  public void setCurrentTurnAutomatedAgentValue(double value)
  {
    this.m_AgentCore.setCurrentTurnAutomatedAgentValue(value);
  }
  
  public void setNextTurnAutomatedAgentSelectedValue(double agreementValue)
  {
    this.m_AgentCore.setNextTurnAutomatedAgentSelectedValue(agreementValue);
  }
  
  public void setNextTurnOpponentSelectedValue(double agreementValue)
  {
    this.m_AgentCore.setNextTurnOpponentSelectedValue(agreementValue);
  }
  
  public void setCurrentTurnOpponentSelectedValue(double agreementValue)
  {
    this.m_AgentCore.setCurrentTurnOpponentSelectedValue(agreementValue);
  }
  
  public void setNextTurnAgreementString(String agreementStr)
  {
    this.m_AgentCore.setNextTurnAgreementString(agreementStr);
  }
  
  public void setCurrentTurnAgreementString(String agreementStr)
  {
    this.m_AgentCore.setCurrentTurnAgreementString(agreementStr);
  }
  
  public void setNextTurnOpponentType(int type)
  {
    this.m_AgentCore.setNextTurnOpponentType(type);
  }
  
  public String getAgreementStr(int[] currentAgreementIdx)
  {
    return this.m_AgentType.getAgreementStr(currentAgreementIdx);
  }
  
  public String getBestAgreementStr()
  {
    return this.m_AgentType.getBestAgreementStr();
  }
  
  public double getBestAgreementValue()
  {
    return this.m_AgentType.getBestAgreementValue(this.m_nCurrentTurn);
  }
  
  public String getWorstAgreementStr()
  {
    return this.m_AgentType.getWorstAgreementStr();
  }
  
  public double getWorstAgreementValue()
  {
    return this.m_AgentType.getWorstAgreementValue(this.m_nCurrentTurn);
  }
  
  public double getStatusQuoValue()
  {
    return this.m_AgentType.getSQValue();
  }
  
  public double getOptingOutValue()
  {
    return this.m_AgentType.getOptOutValue();
  }
  
  public int getTotalAgreementsNum()
  {
    return this.m_AgentType.getTotalAgreements();
  }
  
  public int getTotalIssues()
  {
    return this.m_AgentType.getIssuesNum();
  }
  
  public boolean getSendOfferFlag()
  {
    return this.m_bSendOffer;
  }
  
  public void setSendOfferFlag(boolean flag)
  {
    this.m_bSendOffer = flag;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AutomatedAgent
 * JD-Core Version:    0.7.1
 */