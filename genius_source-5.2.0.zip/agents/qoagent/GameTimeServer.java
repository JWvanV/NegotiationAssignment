package agents.qoagent;

import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JLabel;
import javax.swing.JPanel;

class GameTimeServer
  extends JPanel
  implements Runnable
{
  private static final long serialVersionUID = 1L;
  private Agent m_agent;
  private int m_nMaxTurn;
  private boolean m_bIsTurn;
  private long m_nTime;
  private JLabel m_lTime;
  private boolean m_bRun;
  private boolean m_bCountUp;
  private String m_strStartTime;
  private int m_nStartSeconds;
  private int m_nStartMinutes;
  private int m_nStartHours;
  
  public GameTimeServer(boolean bCountUp, int nHours, int nMinutes, int nSeconds, Agent agent, boolean bTurnOrNeg, int nMaxTurn)
  {
    this.m_nMaxTurn = nMaxTurn;
    this.m_agent = agent;
    this.m_bIsTurn = bTurnOrNeg;
    this.m_bCountUp = bCountUp;
    this.m_bRun = false;
    if (!bCountUp)
    {
      this.m_nStartMinutes = nMinutes;
      this.m_nStartSeconds = nSeconds;
      this.m_nStartHours = nHours;
      


      this.m_nTime = (nHours * 3600 + nMinutes * 60 + nSeconds);
      String sec;
      String sec;
      if (this.m_nTime % 60L < 10L) {
        sec = "0" + this.m_nTime % 60L;
      } else {
        sec = this.m_nTime % 60L + "";
      }
      String min;
      String min;
      if (this.m_nTime / 60L % 60L < 10L) {
        min = "0" + this.m_nTime / 60L % 60L;
      } else {
        min = this.m_nTime / 60L % 60L + "";
      }
      String hour;
      String hour;
      if (this.m_nTime / 3600L < 10L) {
        hour = "0" + this.m_nTime / 3600L;
      } else {
        hour = this.m_nTime / 3600L + "";
      }
      this.m_strStartTime = (hour + ":" + min + ":" + sec);
    }
    else
    {
      this.m_nStartSeconds = 0;
      this.m_nStartMinutes = 0;
      this.m_nStartHours = 0;
      this.m_strStartTime = "00:00";
      this.m_nTime = 0L;
    }
    this.m_lTime = new JLabel(this.m_strStartTime);
    add(this.m_lTime);
  }
  
  public GameTimeServer()
  {
    this.m_bCountUp = true;
    this.m_bRun = false;
    this.m_nTime = 0L;
    this.m_strStartTime = "00:00:00";
    
    this.m_lTime = new JLabel(this.m_strStartTime);
    add(this.m_lTime);
  }
  
  public void run()
  {
    while (this.m_bRun)
    {
      try
      {
        Thread.sleep(1000L);
        if (this.m_bCountUp) {
          this.m_nTime += 1L;
        } else {
          this.m_nTime -= 1L;
        }
      }
      catch (Exception e)
      {
        System.out.println("ERROR----" + e.getMessage() + " [GameTimeServer::run(135)]");
        System.err.println("ERROR----" + e.getMessage() + " [GameTimeServer::run(135)]");
      }
      String sec;
      String sec;
      if (this.m_nTime % 60L < 10L) {
        sec = "0" + this.m_nTime % 60L;
      } else {
        sec = this.m_nTime % 60L + "";
      }
      String min;
      String min;
      if (this.m_nTime / 60L % 60L < 10L) {
        min = "0" + this.m_nTime / 60L % 60L;
      } else {
        min = this.m_nTime / 60L % 60L + "";
      }
      String hour;
      String hour;
      if (this.m_nTime / 3600L < 10L) {
        hour = "0" + this.m_nTime / 3600L;
      } else {
        hour = this.m_nTime / 3600L + "";
      }
      String t = hour + ":" + min + ":" + sec;
      this.m_lTime.setText(t);
      if (this.m_nTime == 0L) {
        stopRunning();
      }
    }
  }
  
  public void stopRunning()
  {
    this.m_bRun = false;
    
    int nCurrentTurn = this.m_agent.getCurrentTurn();
    try
    {
      Socket socket = this.m_agent.getSocket();
      
      PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
      if (this.m_bIsTurn)
      {
        out.println("type endTurn");
        System.out.println("COMM-------[Agent " + this.m_agent.getId() + "] " + "->type endTurn " + nCurrentTurn);
        System.err.println("COMM-------[Agent " + this.m_agent.getId() + "] " + "->type endTurn " + nCurrentTurn);
      }
      else if (this.m_agent.getSide().equals("Mediator"))
      {
        try
        {
          Thread.sleep(2000L);
        }
        catch (Exception e) {}
      }
    }
    catch (IOException e)
    {
      System.out.println("ERROR----[Agent " + this.m_agent.getId() + "] " + "Can't write to socket: " + e.getMessage() + " [GameTimeServer::stopRunning(208)]");
      System.err.println("ERROR----[Agent " + this.m_agent.getId() + "] " + "Can't write to socket: " + e.getMessage() + " [GameTimeServer::stopRunning(208)]");
    }
    if ((this.m_bIsTurn) && (nCurrentTurn < this.m_nMaxTurn - 1))
    {
      this.m_agent.incrementCurrentTurn();
      
      newGame();
      this.m_bRun = true;
    }
    else if ((this.m_bIsTurn) && (nCurrentTurn == this.m_nMaxTurn - 1))
    {
      this.m_agent.incrementCurrentTurn();
    }
  }
  
  public void newGame()
  {
    this.m_lTime.setText(this.m_strStartTime);
    this.m_bRun = true;
    this.m_nTime = (this.m_nStartHours * 3600 + this.m_nStartMinutes * 60 + this.m_nStartSeconds);
  }
  
  public JLabel getTimeLabel()
  {
    return this.m_lTime;
  }
  
  public void setRunMethod(boolean bCountUp)
  {
    this.m_bCountUp = bCountUp;
  }
  
  public void setRun(boolean bRun)
  {
    this.m_bRun = bRun;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.GameTimeServer
 * JD-Core Version:    0.7.1
 */