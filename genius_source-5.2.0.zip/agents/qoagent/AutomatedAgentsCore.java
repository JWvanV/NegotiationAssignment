package agents.qoagent;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class AutomatedAgentsCore
{
  public static final String COMMENT_CHAR_STR = "#";
  public static final String ISSUE_HEADER_STR = "!";
  public static final String ISSUE_SEPARATOR_STR = "*";
  public static final String VALUES_UTILITY_SEPARATOR_STR = " ";
  public static final String VALUES_NAMES_SEPARATOR_STR = "~";
  public static final String GENERAL_DATA_SEPARATOR_STR = "@";
  public static final String TIME_EFFECT_STR = "Time-Effect";
  public static final String OPT_OUT_STR = "Opt-Out";
  public static final String STATUS_QUO_STR = "Status-Quo";
  public static final int TIME_EFFECT_IND = 0;
  public static final int OPT_OUT_IND = 1;
  public static final int STATUS_QUO_IND = 2;
  public static final int GENERAL_VALUES_NUM = 3;
  public static final int LONG_TERM_TYPE_IDX = 0;
  public static final int SHORT_TERM_TYPE_IDX = 1;
  public static final int COMPROMISE_TYPE_IDX = 2;
  public static final int AGENT_TYPES_NUM = 3;
  private static final String SIDE_B_COMPROMISE_UTILITY_FILE = "utilitySide_BCompromise.txt";
  private static final String SIDE_B_SHORT_TERM_UTILITY_FILE = "utilitySide_BShortTerm.txt";
  private static final String SIDE_B_LONG_TERM_UTILITY_FILE = "utilitySide_BLongTerm.txt";
  private static final String SIDE_A_COMPROMISE_UTILITY_FILE = "utilitySide_ACompromise.txt";
  private static final String SIDE_A_SHORT_TERM_UTILITY_FILE = "utilitySide_AShortTerm.txt";
  private static final String SIDE_A_LONG_TERM_UTILITY_FILE = "utilitySide_ALongTerm.txt";
  private static final String SIDE_B_COMPROMISE_NAME = "SIDE_B_COMPROMISE";
  private static final String SIDE_B_LONG_TERM_NAME = "SIDE_B_LONG_TERM";
  private static final String SIDE_B_SHORT_TERM_NAME = "SIDE_B_SHORT_TERM";
  private static final String SIDE_A_COMPROMISE_NAME = "SIDE_A_COMPROMISE";
  private static final String SIDE_A_LONG_TERM_NAME = "SIDE_A_LONG_TERM";
  private static final String SIDE_A_SHORT_TERM_NAME = "SIDE_A_SHORT_TERM";
  private ArrayList<AutomatedAgentType> m_SideA_AgentTypesList;
  private ArrayList<AutomatedAgentType> m_SideB_AgentTypesList;
  private ArrayList<AutomatedAgentType> m_SideA_AgentTypesNextTurnList;
  private ArrayList<AutomatedAgentType> m_SideB_AgentTypesNextTurnList;
  private AutomatedAgentType m_CurrentAgentType;
  private AutomatedAgentType m_CurrentAgentNextTurnType;
  private int m_nNextTurnOppType;
  private String m_sLogFileName;
  private AutomatedAgentGenerateAgreement m_GenerateAgreement;
  private AgentTools agentTools = null;
  private AbstractAutomatedAgent abstractAgent = null;
  
  public class AutomatedAgentGenerateAgreement
  {
    private double m_dAutomatedAgentValue;
    private double m_dNextTurnAutomatedAgentValue;
    private double m_dOppSelectedValue;
    private double m_dAgentSelectedNextTurnValue;
    private double m_dOppSelectedNextTurnValue;
    private String m_sAgreement;
    private String m_sNextTurnAgreement;
    
    public AutomatedAgentGenerateAgreement()
    {
      this.m_dAutomatedAgentValue = -9999.0D;
      this.m_dNextTurnAutomatedAgentValue = -9999.0D;
      AutomatedAgentsCore.this.m_nNextTurnOppType = -1;
      this.m_sAgreement = "";
      this.m_sNextTurnAgreement = "";
    }
    
    public void calculateAgreement(AutomatedAgentType agentType, int nCurrentTurn, boolean bCalcForNextTurn)
    {
      if (bCalcForNextTurn) {
        AutomatedAgentsCore.this.m_CurrentAgentNextTurnType = agentType;
      } else {
        AutomatedAgentsCore.this.m_CurrentAgentType = agentType;
      }
      if (AutomatedAgentsCore.this.m_CurrentAgentType.isTypeOf(1))
      {
        calculateOfferAgainstOpponent("SIDE_A", nCurrentTurn, bCalcForNextTurn);
      }
      else if (AutomatedAgentsCore.this.m_CurrentAgentType.isTypeOf(0))
      {
        calculateOfferAgainstOpponent("SIDE_B", nCurrentTurn, bCalcForNextTurn);
      }
      else
      {
        System.out.println("[AA]Agent type is unknown [AutomatedAgentsCore::calculateAgreement(204)]");
        System.err.println("[AA]Agent type is unknown [AutomatedAgentsCore::calculateAgreement(204)]");
      }
    }
    
    public void calculateOfferAgainstOpponent(String sOpponentType, int nCurrentTurn, boolean bCalcForNextTurn)
    {
      this.m_dAutomatedAgentValue = -9999.0D;
      this.m_dNextTurnAutomatedAgentValue = -9999.0D;
      AutomatedAgentsCore.this.m_nNextTurnOppType = -1;
      if (bCalcForNextTurn) {
        AutomatedAgentsCore.this.abstractAgent.calculateOfferAgainstOpponent(AutomatedAgentsCore.this.m_CurrentAgentNextTurnType, sOpponentType, nCurrentTurn);
      } else {
        AutomatedAgentsCore.this.abstractAgent.calculateOfferAgainstOpponent(AutomatedAgentsCore.this.m_CurrentAgentType, sOpponentType, nCurrentTurn);
      }
    }
    
    public String getSelectedAutomatedAgentAgreementStr()
    {
      return this.m_sAgreement;
    }
    
    public double getNextTurnAgentAutomatedAgentUtilityValue()
    {
      return this.m_dAgentSelectedNextTurnValue;
    }
    
    public String getNextTurnAutomatedAgentAgreement()
    {
      return this.m_sNextTurnAgreement;
    }
    
    public double getNextTurnOpponentAutomatedAgentUtilityValue()
    {
      return this.m_dOppSelectedNextTurnValue;
    }
    
    public int getNextTurnOpponentType()
    {
      return AutomatedAgentsCore.this.m_nNextTurnOppType;
    }
    
    public void setNextTurnOpponentType(int type)
    {
      AutomatedAgentsCore.this.m_nNextTurnOppType = type;
    }
    
    class AutomatedAgentCombinedAgreement
    {
      public double m_dAgentAgreementValue;
      public double m_dOpponentAgreementValue;
      public String m_sAgreement;
      
      AutomatedAgentCombinedAgreement() {}
    }
  }
  
  public AutomatedAgentsCore(String sFileName, String sNow, AgentTools agentTools, AbstractAutomatedAgent abstractAgent)
  {
    setAgentTools(agentTools);
    setAbstractAgent(abstractAgent);
    this.m_CurrentAgentNextTurnType = null;
    this.m_SideA_AgentTypesNextTurnList = new ArrayList();
    this.m_SideB_AgentTypesNextTurnList = new ArrayList();
    
    this.m_sLogFileName = sFileName;
    
    this.m_CurrentAgentType = null;
    
    this.m_SideA_AgentTypesList = new ArrayList();
    this.m_SideB_AgentTypesList = new ArrayList();
    for (int i = 0; i < 3; i++)
    {
      this.m_SideA_AgentTypesList.add(i, new AutomatedAgentType());
      this.m_SideB_AgentTypesList.add(i, new AutomatedAgentType());
      
      this.m_SideA_AgentTypesNextTurnList.add(i, new AutomatedAgentType());
      this.m_SideB_AgentTypesNextTurnList.add(i, new AutomatedAgentType());
    }
    createSideALongTermType();
    createSideAShortTermType();
    createSideACompromiseType();
    
    createSideBLongTermType();
    createSideBShortTermType();
    createSideBCompromiseType();
  }
  
  public AutomatedAgentType getSideALongTermType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesList.get(0);
  }
  
  public AutomatedAgentType getSideAShortTermType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesList.get(1);
  }
  
  public AutomatedAgentType getSideACompromiseType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesList.get(2);
  }
  
  public AutomatedAgentType getSideBLongTermType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesList.get(0);
  }
  
  public AutomatedAgentType getSideBShortTermType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesList.get(1);
  }
  
  public AutomatedAgentType getSideBCompromiseType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesList.get(2);
  }
  
  public AutomatedAgentType getSideALongTermNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesNextTurnList.get(0);
  }
  
  public AutomatedAgentType getSideAShortTermNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesNextTurnList.get(1);
  }
  
  public AutomatedAgentType getSideACompromiseNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideA_AgentTypesNextTurnList.get(2);
  }
  
  public AutomatedAgentType getSideBLongTermNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesNextTurnList.get(0);
  }
  
  public AutomatedAgentType getSideBShortTermNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesNextTurnList.get(1);
  }
  
  public AutomatedAgentType getSideBCompromiseNextTurnType()
  {
    return (AutomatedAgentType)this.m_SideB_AgentTypesNextTurnList.get(2);
  }
  
  private void createSideBCompromiseType()
  {
    AutomatedAgentType compromiseType = new AutomatedAgentType();
    compromiseType.setAgentType(1);
    
    String sFileName = "utilitySide_BCompromise.txt";
    
    createAgentTypeFromFile(sFileName, compromiseType);
    
    compromiseType.setName("SIDE_B_COMPROMISE");
    this.m_SideB_AgentTypesList.set(2, compromiseType);
    
    AutomatedAgentType agentTypeNextTurn = compromiseType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideB_AgentTypesNextTurnList.set(2, agentTypeNextTurn);
  }
  
  private void createSideBShortTermType()
  {
    AutomatedAgentType shortTermType = new AutomatedAgentType();
    shortTermType.setAgentType(1);
    
    String sFileName = "utilitySide_BShortTerm.txt";
    
    createAgentTypeFromFile(sFileName, shortTermType);
    
    shortTermType.setName("SIDE_B_SHORT_TERM");
    this.m_SideB_AgentTypesList.set(1, shortTermType);
    
    AutomatedAgentType agentTypeNextTurn = shortTermType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideB_AgentTypesNextTurnList.set(1, agentTypeNextTurn);
  }
  
  private void createSideBLongTermType()
  {
    AutomatedAgentType longTermType = new AutomatedAgentType();
    longTermType.setAgentType(1);
    
    String sFileName = "utilitySide_BLongTerm.txt";
    
    createAgentTypeFromFile(sFileName, longTermType);
    
    longTermType.setName("SIDE_B_LONG_TERM");
    this.m_SideB_AgentTypesList.set(0, longTermType);
    
    AutomatedAgentType agentTypeNextTurn = longTermType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideB_AgentTypesNextTurnList.set(0, agentTypeNextTurn);
  }
  
  private void createSideACompromiseType()
  {
    AutomatedAgentType compromiseType = new AutomatedAgentType();
    compromiseType.setAgentType(0);
    
    String sFileName = "utilitySide_ACompromise.txt";
    
    createAgentTypeFromFile(sFileName, compromiseType);
    
    compromiseType.setName("SIDE_A_COMPROMISE");
    
    this.m_SideA_AgentTypesList.set(2, compromiseType);
    
    AutomatedAgentType agentTypeNextTurn = compromiseType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideA_AgentTypesNextTurnList.set(2, agentTypeNextTurn);
  }
  
  private void createSideAShortTermType()
  {
    AutomatedAgentType shortTermType = new AutomatedAgentType();
    shortTermType.setAgentType(0);
    
    String sFileName = "utilitySide_AShortTerm.txt";
    
    createAgentTypeFromFile(sFileName, shortTermType);
    
    shortTermType.setName("SIDE_A_SHORT_TERM");
    this.m_SideA_AgentTypesList.set(1, shortTermType);
    
    AutomatedAgentType agentTypeNextTurn = shortTermType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideA_AgentTypesNextTurnList.set(1, agentTypeNextTurn);
  }
  
  private void createSideALongTermType()
  {
    AutomatedAgentType longTermType = new AutomatedAgentType();
    longTermType.setAgentType(0);
    
    String sFileName = "utilitySide_ALongTerm.txt";
    
    createAgentTypeFromFile(sFileName, longTermType);
    
    longTermType.setName("SIDE_A_LONG_TERM");
    this.m_SideA_AgentTypesList.set(0, longTermType);
    
    AutomatedAgentType agentTypeNextTurn = longTermType;
    

    agentTypeNextTurn.calculateValues(this.abstractAgent, 2);
    this.m_SideA_AgentTypesNextTurnList.set(0, agentTypeNextTurn);
  }
  
  private void createAgentTypeFromFile(String sFileName, AutomatedAgentType agentType)
  {
    BufferedReader br = null;
    

    double[] dGeneralValues = new double[3];
    

    dGeneralValues[0] = 0.0D;
    dGeneralValues[2] = -9999.0D;
    dGeneralValues[1] = -9999.0D;
    try
    {
      br = new BufferedReader(new FileReader(sFileName));
      
      String line = br.readLine();
      while (line != null) {
        if (line.startsWith("#"))
        {
          line = br.readLine();
        }
        else
        {
          line = readUtilityDetails(br, line, agentType.m_fullUtility.lstUtilityDetails, dGeneralValues);
          
          agentType.m_fullUtility.dTimeEffect = dGeneralValues[0];
          agentType.m_fullUtility.dStatusQuoValue = dGeneralValues[2];
          agentType.m_fullUtility.dOptOutValue = dGeneralValues[1];
        }
      }
      agentType.calculateValues(this.abstractAgent, 1);
      
      br.close();
    }
    catch (FileNotFoundException e)
    {
      System.out.println("[AA]Error reading " + sFileName + ": " + e.getMessage() + " [AutomatedAgentsCore::createAgentTypeFromFile(1059)]");
      System.err.println("[AA]Error reading " + sFileName + ": " + e.getMessage() + " [AutomatedAgentsCore::createAgentTypeFromFile(1059)]");
      e.printStackTrace();
      System.exit(1);
    }
    catch (IOException e1)
    {
      System.out.println("[AA]Error reading from " + sFileName + ": " + e1.getMessage() + " [AutomatedAgentsCore::createAgentTypeFromFile(1065)]");
      System.err.println("[AA]Error reading from " + sFileName + ": " + e1.getMessage() + " [AutomatedAgentsCore::createAgentTypeFromFile(105659)]");
      e1.printStackTrace();
      System.exit(1);
    }
  }
  
  public String readUtilityDetails(BufferedReader br, String line, ArrayList<UtilityDetails> lstUtilityDetails, double[] dGeneralValues)
  {
    UtilityDetails utilityDetails = null;
    
    StringTokenizer st = new StringTokenizer(line);
    
    String sTitle = st.nextToken();
    if (sTitle.equals("@"))
    {
      String sType = st.nextToken();
      
      String sValue = st.nextToken();
      Double dTemp = new Double(sValue);
      if (sType.equals("Time-Effect")) {
        dGeneralValues[0] = dTemp.doubleValue();
      }
      if (sType.equals("Status-Quo")) {
        dGeneralValues[2] = dTemp.doubleValue();
      }
      if (sType.equals("Opt-Out")) {
        dGeneralValues[1] = dTemp.doubleValue();
      }
      try
      {
        line = br.readLine();
      }
      catch (IOException e)
      {
        System.out.println("[AA]IOException: Error reading file: " + e.getMessage() + " [AutomatedAgentsCore::readUtilityDetails(1105)]");
        System.err.println("[AA]IOException: Error reading file: " + e.getMessage() + " [AutomatedAgentsCore::readUtilityDetails(1105)]");
      }
    }
    else if (sTitle.equals("!"))
    {
      utilityDetails = new UtilityDetails();
      



      sTitle = line.substring(1);
      sTitle.trim();
      
      utilityDetails.sTitle = sTitle;
      try
      {
        do
        {
          line = br.readLine();
        } while ((line != null) && (line.startsWith("#")));
        while ((line != null) && (!line.startsWith("!")))
        {
          UtilityIssue utilityIssue = new UtilityIssue();
          utilityIssue.sAttributeName = line.substring(0, line.indexOf("*"));
          String sTemp = line.substring(line.indexOf("*") + 1);
          utilityIssue.sSide = sTemp.substring(0, sTemp.indexOf("*"));
          sTemp = sTemp.substring(sTemp.indexOf("*") + 1);
          utilityIssue.dAttributeWeight = new Double(sTemp).doubleValue();
          do
          {
            line = br.readLine();
          } while ((line != null) && (line.startsWith("#")));
          if ((line != null) && (!line.startsWith("!")))
          {
            String sUtilityLine;
            do
            {
              sUtilityLine = br.readLine();
            } while ((sUtilityLine != null) && (sUtilityLine.startsWith("#")));
            String sTimeEffectLine = "";
            
            StringTokenizer stUtilities = null;
            StringTokenizer stTimeEffect = null;
            if ((sUtilityLine != null) && (!sUtilityLine.startsWith("!")))
            {
              stUtilities = new StringTokenizer(sUtilityLine, " ");
              do
              {
                sTimeEffectLine = br.readLine();
              } while ((sTimeEffectLine != null) && (sTimeEffectLine.startsWith("#")));
              if ((sTimeEffectLine != null) && (!sTimeEffectLine.startsWith("!"))) {
                stTimeEffect = new StringTokenizer(sTimeEffectLine);
              }
            }
            StringTokenizer stValues = new StringTokenizer(line, "~");
            while (stValues.hasMoreTokens())
            {
              UtilityValue utilityValue = new UtilityValue();
              
              utilityValue.sValue = stValues.nextToken();
              if ((stUtilities != null) && (stUtilities.hasMoreTokens())) {
                utilityValue.dUtility = new Double(stUtilities.nextToken()).doubleValue();
              }
              if ((stTimeEffect != null) && (stTimeEffect.hasMoreTokens())) {
                utilityValue.dTimeEffect = new Double(stTimeEffect.nextToken()).doubleValue();
              }
              utilityIssue.lstUtilityValues.add(utilityValue);
            }
            do
            {
              line = br.readLine();
            } while ((line != null) && (line.startsWith("#")));
            if ((line != null) && (!line.startsWith("!")))
            {
              StringTokenizer stExp = new StringTokenizer(line);
              int i = 0;
              while (stExp.hasMoreTokens()) {
                if (i < 6)
                {
                  UtilityIssue tmp677_675 = utilityIssue;tmp677_675.sExplanation = (tmp677_675.sExplanation + stExp.nextToken() + " ");
                  i++;
                }
                else
                {
                  UtilityIssue tmp718_716 = utilityIssue;tmp718_716.sExplanation = (tmp718_716.sExplanation + "\n" + stExp.nextToken() + " ");
                  i = 0;
                }
              }
              do
              {
                line = br.readLine();
              } while ((line != null) && (line.startsWith("#")));
            }
          }
          utilityDetails.lstUtilityIssues.add(utilityIssue);
        }
      }
      catch (IOException e)
      {
        System.out.println("[AA]IOException: Error reading file: " + e.getMessage() + " [AutomatedAgentsCore::readUtilityDetails(1225)]");
        System.err.println("[AA]IOException: Error reading file: " + e.getMessage() + " [AutomatedAgentsCore::readUtilityDetails(1225)]");
      }
      lstUtilityDetails.add(utilityDetails);
    }
    return line;
  }
  
  public void updateAgreementsValues(int nTimePeriod)
  {
    AutomatedAgentType agentType = null;
    AutomatedAgentType agentTypeNextTurn = null;
    for (int i = 0; i < 3; i++)
    {
      agentType = (AutomatedAgentType)this.m_SideA_AgentTypesList.get(i);
      agentType.calculateValues(this.abstractAgent, nTimePeriod);
      this.m_SideA_AgentTypesList.set(i, agentType);
      
      agentTypeNextTurn = agentType;
      agentTypeNextTurn.calculateValues(this.abstractAgent, nTimePeriod + 1);
      this.m_SideA_AgentTypesNextTurnList.set(i, agentTypeNextTurn);
      
      agentType = (AutomatedAgentType)this.m_SideB_AgentTypesList.get(i);
      agentType.calculateValues(this.abstractAgent, nTimePeriod);
      this.m_SideB_AgentTypesList.set(i, agentType);
      
      agentTypeNextTurn = agentType;
      agentTypeNextTurn.calculateValues(this.abstractAgent, nTimePeriod + 1);
      this.m_SideB_AgentTypesNextTurnList.set(i, agentTypeNextTurn);
    }
  }
  
  public void initGenerateAgreement(AutomatedAgentType agentType)
  {
    this.m_CurrentAgentType = agentType;
    
    this.m_GenerateAgreement = new AutomatedAgentGenerateAgreement();
  }
  
  public void calculateAgreement(AutomatedAgentType agentType, int nCurrentTurn)
  {
    this.m_GenerateAgreement.calculateAgreement(agentType, nCurrentTurn, false);
  }
  
  public String getAutomatedAgentAgreement()
  {
    return this.m_GenerateAgreement.getSelectedAutomatedAgentAgreementStr();
  }
  
  public void calculateNextTurnAgreement(AutomatedAgentType agentType, int nNextTurn)
  {
    this.m_GenerateAgreement.calculateAgreement(agentType, nNextTurn, true);
  }
  
  public double getNextTurnAutomatedAgentUtilityValue()
  {
    return this.m_GenerateAgreement.getNextTurnAgentAutomatedAgentUtilityValue();
  }
  
  public String getNextTurnAutomatedAgentAgreement()
  {
    return this.m_GenerateAgreement.getNextTurnAutomatedAgentAgreement();
  }
  
  public double getNextTurnOpponentAutomatedAgentUtilityValue()
  {
    return this.m_GenerateAgreement.getNextTurnOpponentAutomatedAgentUtilityValue();
  }
  
  public AutomatedAgentType getNextTurnOpponentType()
  {
    AutomatedAgentType opponentNextTurnType = null;
    int nOppType = this.m_GenerateAgreement.getNextTurnOpponentType();
    if (this.m_CurrentAgentType.isTypeOf(1)) {
      switch (nOppType)
      {
      case 2: 
        opponentNextTurnType = getSideACompromiseNextTurnType();
        break;
      case 0: 
        opponentNextTurnType = getSideALongTermNextTurnType();
        break;
      case 1: 
        opponentNextTurnType = getSideAShortTermNextTurnType();
        break;
      default: 
        System.out.println("[AA]Agent type is unknown [AutomatedAgentsCore::getNextTurnOpponentType(1310)]");
        System.err.println("[AA]Agent type is unknown [AutomatedAgentsCore::getNextTurnOpponentType(1310)]");
        break;
      }
    } else if (this.m_CurrentAgentType.isTypeOf(0)) {
      switch (nOppType)
      {
      case 2: 
        opponentNextTurnType = getSideBCompromiseNextTurnType();
        break;
      case 0: 
        opponentNextTurnType = getSideBLongTermNextTurnType();
        break;
      case 1: 
        opponentNextTurnType = getSideBShortTermNextTurnType();
        break;
      default: 
        System.out.println("[AA]Agent type is unknown [AutomatedAgentsCore::getNextTurnOpponentType(1329)]");
        System.err.println("[AA]Agent type is unknown [AutomatedAgentsCore::getNextTurnOpponentType(1329)]");
      }
    }
    return opponentNextTurnType;
  }
  
  public void setAgentTools(AgentTools agentTools)
  {
    this.agentTools = agentTools;
  }
  
  public void setAbstractAgent(AbstractAutomatedAgent abstractAgent)
  {
    this.abstractAgent = abstractAgent;
  }
  
  public double getNextTurnAutomatedAgentValue()
  {
    return this.m_GenerateAgreement.m_dNextTurnAutomatedAgentValue;
  }
  
  public double getCurrentTurnAutomatedAgentValue()
  {
    return this.m_GenerateAgreement.m_dAutomatedAgentValue;
  }
  
  public void setNextTurnAutomatedAgentValue(double agreementValue)
  {
    this.m_GenerateAgreement.m_dNextTurnAutomatedAgentValue = agreementValue;
  }
  
  public void setCurrentTurnAutomatedAgentValue(double agreementValue)
  {
    this.m_GenerateAgreement.m_dAutomatedAgentValue = agreementValue;
  }
  
  public void setNextTurnAutomatedAgentSelectedValue(double agreementValue)
  {
    this.m_GenerateAgreement.m_dAgentSelectedNextTurnValue = agreementValue;
  }
  
  public void setNextTurnOpponentSelectedValue(double agreementValue)
  {
    this.m_GenerateAgreement.m_dOppSelectedNextTurnValue = agreementValue;
  }
  
  public void setCurrentTurnOpponentSelectedValue(double agreementValue)
  {
    this.m_GenerateAgreement.m_dOppSelectedValue = agreementValue;
  }
  
  public void setNextTurnAgreementString(String agreementStr)
  {
    this.m_GenerateAgreement.m_sNextTurnAgreement = agreementStr;
  }
  
  public void setCurrentTurnAgreementString(String agreementStr)
  {
    this.m_GenerateAgreement.m_sAgreement = agreementStr;
  }
  
  public void setNextTurnOpponentType(int type)
  {
    this.m_GenerateAgreement.setNextTurnOpponentType(type);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AutomatedAgentsCore
 * JD-Core Version:    0.7.1
 */