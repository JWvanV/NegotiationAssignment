package agents.qoagent;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class AutomatedAgentType
{
  public static final String NOT_APPLICABLE_STR1 = "No agreement";
  public static final int VERY_SMALL_NUMBER = -9999;
  public static final int VERY_HIGH_NUMBER = 9999;
  public static final int MAX_ISSUES = 20;
  public static final int NO_VALUE = -1;
  public FullUtility m_fullUtility;
  private double m_dSQValue;
  private double m_dOptOutValue;
  private double m_dBestAgreementValue;
  private double m_dWorstAgreementValue;
  private int[] m_MaxIssueValues;
  private int[] m_BestAgreementIdx;
  private int[] m_WorstAgreementIdx;
  private int m_nTotalAgreements;
  private int m_nType;
  public static final int NO_TYPE = -1;
  public static final int SIDE_A_TYPE = 0;
  public static final int SIDE_B_TYPE = 1;
  private String m_sAgentName;
  
  public AutomatedAgentType()
  {
    this.m_nType = -1;
    this.m_sAgentName = "";
    
    this.m_dBestAgreementValue = -9999.0D;
    this.m_dWorstAgreementValue = 9999.0D;
    
    this.m_fullUtility = new FullUtility();
    
    this.m_BestAgreementIdx = new int[20];
    this.m_WorstAgreementIdx = new int[20];
    this.m_MaxIssueValues = new int[20];
    this.m_nTotalAgreements = 0;
    for (int i = 0; i < 20; i++)
    {
      this.m_BestAgreementIdx[i] = -1;
      this.m_WorstAgreementIdx[i] = -1;
      this.m_MaxIssueValues[i] = -1;
    }
    this.m_dSQValue = -9999.0D;
    this.m_dOptOutValue = -9999.0D;
  }
  
  public void setName(String sName)
  {
    this.m_sAgentName = sName;
  }
  
  public int getIssuesNum()
  {
    int nIssuesNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      nIssuesNum += utilityDetails.lstUtilityIssues.size();
    }
    return nIssuesNum;
  }
  
  public int getMaxIssueValue(int nIssueNum)
  {
    return this.m_MaxIssueValues[nIssueNum];
  }
  
  public int getTotalAgreements()
  {
    return this.m_nTotalAgreements;
  }
  
  public void setAgentType(int nType)
  {
    this.m_nType = nType;
  }
  
  public boolean isTypeOf(int nAgentType)
  {
    if (nAgentType == this.m_nType) {
      return true;
    }
    return false;
  }
  
  public double getSQValue()
  {
    return this.m_dSQValue;
  }
  
  public double getOptOutValue()
  {
    return this.m_dOptOutValue;
  }
  
  public double getBestAgreementValue(int nCurrentTurn)
  {
    return getAgreementValue(this.m_BestAgreementIdx, nCurrentTurn);
  }
  
  public String getBestAgreementStr()
  {
    return getAgreementStr(this.m_BestAgreementIdx);
  }
  
  public double getWorstAgreementValue(int nCurrentTurn)
  {
    return getAgreementValue(this.m_WorstAgreementIdx, nCurrentTurn);
  }
  
  public String getWorstAgreementStr()
  {
    return getAgreementStr(this.m_WorstAgreementIdx);
  }
  
  public double getAgreementValue(int[] CurrentAgreementIdx, int nCurrentTurn)
  {
    double dAttributeWeight = 0.0D;
    double dUtility = 0.0D;
    double dCurrentIssueValue = 0.0D;
    double dAgreementValue = 0.0D;
    
    boolean bAgreementHasValues = false;
    

    int nIssueNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
      {
        UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
        if (CurrentAgreementIdx[nIssueNum] != -1)
        {
          bAgreementHasValues = true;
          
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(CurrentAgreementIdx[nIssueNum]);
          
          dUtility = utilityValue.dUtility;
          



          dUtility += (nCurrentTurn - 1) * utilityValue.dTimeEffect;
        }
        else
        {
          dUtility = 0.0D;
        }
        dAttributeWeight = utilityIssue.dAttributeWeight;
        dCurrentIssueValue = dUtility * dAttributeWeight / 100.0D;
        dAgreementValue += dCurrentIssueValue;
        
        nIssueNum++;
      }
    }
    double dTimeEffect = this.m_fullUtility.dTimeEffect;
    dAgreementValue += dTimeEffect * (nCurrentTurn - 1) / 100.0D;
    if (!bAgreementHasValues) {
      dAgreementValue = -9999.0D;
    }
    return dAgreementValue;
  }
  
  public String getAgreementStr(int[] CurrentAgreementIdx)
  {
    String sAgreementStr = "";
    String sCurrentIssueName = "";
    String sCurrentIssueValue = "";
    

    int nIssueNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
      {
        UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
        if (CurrentAgreementIdx[nIssueNum] != -1)
        {
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(CurrentAgreementIdx[nIssueNum]);
          
          sCurrentIssueValue = utilityValue.sValue;
          sCurrentIssueName = utilityIssue.sAttributeName;
          
          sAgreementStr = sAgreementStr + sCurrentIssueValue + "*" + sCurrentIssueName + "*";
        }
        nIssueNum++;
      }
    }
    return sAgreementStr;
  }
  
  public boolean isIssueValueNoAgreement(int nIssueNum, int nIssueNumIdx)
  {
    String sIssueValue = getIssueValueStr(nIssueNum, nIssueNumIdx);
    if (sIssueValue.equals("No agreement")) {
      return true;
    }
    return false;
  }
  
  private String getIssueValueStr(int nIssueNum, int nIssueNumIdx)
  {
    String sIssueValueStr = "";
    

    int nCurrentIssueNum = 0;
    boolean bFound = false;
    for (int i = 0; (i < this.m_fullUtility.lstUtilityDetails.size()) && (!bFound); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++) {
        if (nCurrentIssueNum == nIssueNum)
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(nIssueNumIdx);
          
          sIssueValueStr = utilityValue.sValue;
          bFound = true;
        }
        else
        {
          nCurrentIssueNum++;
        }
      }
    }
    return sIssueValueStr;
  }
  
  public int[] getAgreementIndices(String sAgreementStr)
  {
    sAgreementStr = sAgreementStr.trim();
    
    int[] CurrentAgreementIdx = new int[20];
    for (int i = 0; i < 20; i++) {
      CurrentAgreementIdx[i] = -1;
    }
    int nIssueNum = 0;
    boolean bFoundIssue = false;boolean bFoundValue = false;
    String sCurrentIssueName = "";
    String sCurrentIssueValue = "";
    

    StringTokenizer st = new StringTokenizer(sAgreementStr, "*");
    while (st.hasMoreTokens())
    {
      sCurrentIssueValue = st.nextToken();
      if (!st.hasMoreTokens())
      {
        System.out.println("[AA]ERROR: Invalid agreement structure: " + sAgreementStr + " [AutomatedAgentType::getAgreementIndices(660)]");
        System.err.println("[AA]ERROR: Invalid agreement structure: " + sAgreementStr + " [AutomatedAgentType::getAgreementIndices(660)]");
        return null;
      }
      sCurrentIssueName = st.nextToken();
      

      nIssueNum = 0;
      bFoundIssue = false;
      bFoundValue = false;
      for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
      {
        UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
        for (int j = 0; (j < utilityDetails.lstUtilityIssues.size()) && (!bFoundIssue); j++)
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          if (utilityIssue.sAttributeName.equals(sCurrentIssueName))
          {
            bFoundIssue = true;
            for (int k = 0; (k < utilityIssue.lstUtilityValues.size()) && (!bFoundValue); k++)
            {
              UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(k);
              if (utilityValue.sValue.equals(sCurrentIssueValue))
              {
                bFoundValue = true;
                
                CurrentAgreementIdx[nIssueNum] = k;
              }
            }
          }
          nIssueNum++;
        }
      }
    }
    return CurrentAgreementIdx;
  }
  
  public void calculateValues(AbstractAutomatedAgent abstractAgent, int nCurrentTurn)
  {
    int nValuesNum = 0;
    if (this.m_nTotalAgreements == 0)
    {
      this.m_nTotalAgreements = 1;
      
      int nIssueNum = 0;
      for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
      {
        UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
        for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          
          nValuesNum = utilityIssue.lstUtilityValues.size();
          
          this.m_MaxIssueValues[nIssueNum] = nValuesNum;
          this.m_nTotalAgreements *= nValuesNum;
          
          nIssueNum++;
        }
      }
    }
    double dAgreementTimeEffect = this.m_fullUtility.dTimeEffect;
    this.m_dSQValue = this.m_fullUtility.dStatusQuoValue;
    this.m_dSQValue = ((this.m_dSQValue + dAgreementTimeEffect * (nCurrentTurn - 1)) / 100.0D);
    
    this.m_dOptOutValue = this.m_fullUtility.dOptOutValue;
    this.m_dOptOutValue = ((this.m_dOptOutValue + dAgreementTimeEffect * (nCurrentTurn - 1)) / 100.0D);
    

    abstractAgent.calculateValues(this, nCurrentTurn);
  }
  
  public double getBestAgreementValue()
  {
    return this.m_dBestAgreementValue;
  }
  
  public void setBestAgreementValue(double value)
  {
    this.m_dBestAgreementValue = value;
  }
  
  public double getWorstAgreementValue()
  {
    return this.m_dWorstAgreementValue;
  }
  
  public void setWorstAgreementValue(double value)
  {
    this.m_dWorstAgreementValue = value;
  }
  
  public void initializeBestAgreementIndices()
  {
    int nIssuesNum = getIssuesNum();
    for (int i = 0; i < nIssuesNum; i++) {
      this.m_BestAgreementIdx[i] = 0;
    }
  }
  
  public void initializeWorstAgreementIndices()
  {
    int nIssuesNum = getIssuesNum();
    for (int i = 0; i < nIssuesNum; i++) {
      this.m_WorstAgreementIdx[i] = 0;
    }
  }
  
  public double getAgreementTypeEffect()
  {
    return this.m_fullUtility.dTimeEffect;
  }
  
  public void setBestAgreementIndices(int[] currentAgreementIdx)
  {
    int nIssuesNum = getIssuesNum();
    for (int k = 0; k < nIssuesNum; k++) {
      this.m_BestAgreementIdx[k] = currentAgreementIdx[k];
    }
  }
  
  public void setWorstAgreementIndices(int[] currentAgreementIdx)
  {
    int nIssuesNum = getIssuesNum();
    for (int k = 0; k < nIssuesNum; k++) {
      this.m_WorstAgreementIdx[k] = currentAgreementIdx[k];
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AutomatedAgentType
 * JD-Core Version:    0.7.1
 */