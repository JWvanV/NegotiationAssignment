package agents.qoagent;

public class AbstractAutomatedAgent
{
  AgentTools agentTools = null;
  
  public AbstractAutomatedAgent() {}
  
  public AbstractAutomatedAgent(AgentTools agentTools)
  {
    this.agentTools = agentTools;
  }
  
  public void initialize(AutomatedAgentType agentType, String sOpponentType)
  {
    calculateOfferAgainstOpponent(agentType, sOpponentType, 1);
  }
  
  public void calculateResponse(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage)
  {
    double dOppOfferValueForAgent = -9999.0D;
    double dAutomatedAgentNextOfferValueForAgent = -9999.0D;
    

    dOppOfferValueForAgent = this.agentTools.getAgreementValue(CurrentAgreementIdx);
    

    double dAcceptedAgreementValue = this.agentTools.getAcceptedAgreementsValue();
    if (dAcceptedAgreementValue >= dOppOfferValueForAgent)
    {
      this.agentTools.rejectMessage(sOriginalMessage);
      return;
    }
    this.agentTools.calculateNextTurnOffer();
    dAutomatedAgentNextOfferValueForAgent = this.agentTools.getNextTurnOfferValue();
    if (dOppOfferValueForAgent >= dAutomatedAgentNextOfferValueForAgent)
    {
      this.agentTools.acceptMessage(sOriginalMessage);
      

      this.agentTools.setSendOfferFlag(false);
    }
    else
    {
      this.agentTools.acceptMessage(sOriginalMessage);
      

      this.agentTools.setSendOfferFlag(false);
    }
  }
  
  public void commentReceived(String sComment) {}
  
  public void threatReceived(String sThreat) {}
  
  public void opponentAgreed(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage) {}
  
  public void opponentRejected(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage) {}
  
  public void calculateOfferAgainstOpponent(AutomatedAgentType agentType, String sOpponentType, int nCurrentTurn)
  {
    double dCurrentAgentAgreementValue = -9999.0D;
    
    int totalIssuesNum = this.agentTools.getTotalIssues(agentType);
    int totalAgreementsNumber = this.agentTools.getTotalAgreements(agentType);
    
    int[] CurrentAgreementIdx = new int[totalIssuesNum];
    int[] MaxIssueValues = new int[totalIssuesNum];
    for (int i = 0; i < totalIssuesNum; i++)
    {
      CurrentAgreementIdx[i] = 0;
      MaxIssueValues[i] = this.agentTools.getMaxValuePerIssue(agentType, i);
    }
    AutomatedAgentType agentOpponentCompromise = null;
    AutomatedAgentType agentOpponentLongTerm = null;
    AutomatedAgentType agentOpponentShortTerm = null;
    
    agentOpponentCompromise = this.agentTools.getCurrentTurnSideAgentType(sOpponentType, 2);
    agentOpponentLongTerm = this.agentTools.getCurrentTurnSideAgentType(sOpponentType, 0);
    agentOpponentShortTerm = this.agentTools.getCurrentTurnSideAgentType(sOpponentType, 1);
    







    int[] OpponentLongTermIdx = new int[totalIssuesNum];
    double dOpponentLongTermAgreementValue = -9999.0D;
    
    double dAutomatedAgentAgreementValue = -9999.0D;
    for (int i = 0; i < totalAgreementsNumber; i++)
    {
      dAutomatedAgentAgreementValue = this.agentTools.getAgreementValue(agentType, CurrentAgreementIdx, nCurrentTurn);
      






      dOpponentLongTermAgreementValue = this.agentTools.getAgreementValue(agentOpponentLongTerm, CurrentAgreementIdx, nCurrentTurn);
      for (int j = 0; j < totalIssuesNum; j++) {
        OpponentLongTermIdx[j] = CurrentAgreementIdx[j];
      }
      this.agentTools.getNextAgreement(totalIssuesNum, CurrentAgreementIdx, MaxIssueValues);
    }
    if (dOpponentLongTermAgreementValue > this.agentTools.getCurrentTurnAutomatedAgentValue())
    {
      this.agentTools.setCurrentTurnAutomatedAgentValue(dOpponentLongTermAgreementValue);
      this.agentTools.setCurrentTurnOpponentSelectedValue(agentOpponentLongTerm.getAgreementValue(OpponentLongTermIdx, nCurrentTurn));
      this.agentTools.setCurrentTurnAgreementString(agentType.getAgreementStr(OpponentLongTermIdx));
    }
    double dNextAgreementValue = this.agentTools.getSelectedOfferValue();
    

    double dAcceptedAgreementValue = this.agentTools.getAcceptedAgreementsValue();
    if (dAcceptedAgreementValue >= dNextAgreementValue) {}
    String sOffer = this.agentTools.getSelectedOffer();
    this.agentTools.sendOffer(sOffer);
  }
  
  public void calculateValues(AutomatedAgentType agentType, int nCurrentTurn)
  {
    int nIssuesNum = this.agentTools.getTotalIssues(agentType);
    
    int[] CurrentAgreementIdx = new int[nIssuesNum];
    int[] MaxIssueValues = new int[nIssuesNum];
    
    int totalAgreementsNumber = this.agentTools.getTotalAgreements(agentType);
    for (int i = 0; i < nIssuesNum; i++)
    {
      CurrentAgreementIdx[i] = 0;
      MaxIssueValues[i] = this.agentTools.getMaxValuePerIssue(agentType, i);
    }
    double dAgreementValue = 0.0D;
    
    this.agentTools.initializeBestAgreement(agentType);
    this.agentTools.initializeWorstAgreement(agentType);
    



    double dAgreementTimeEffect = this.agentTools.getAgreementTimeEffect(agentType);
    double dStatusQuoValue = this.agentTools.getSQValue(agentType);
    double dOptOutValue = this.agentTools.getOptOutValue(agentType);
    for (int i = 0; i < totalAgreementsNumber; i++)
    {
      dAgreementValue = this.agentTools.getAgreementValue(agentType, CurrentAgreementIdx, nCurrentTurn);
      if (dAgreementValue > this.agentTools.getBestAgreementValue(agentType))
      {
        this.agentTools.setBestAgreementValue(agentType, dAgreementValue);
        

        this.agentTools.setBestAgreementIndices(agentType, CurrentAgreementIdx);
      }
      if (dAgreementValue < agentType.getWorstAgreementValue())
      {
        this.agentTools.setWorstAgreementValue(agentType, dAgreementValue);
        

        this.agentTools.setWorstAgreementIndices(agentType, CurrentAgreementIdx);
      }
      this.agentTools.getNextAgreement(nIssuesNum, CurrentAgreementIdx, MaxIssueValues);
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AbstractAutomatedAgent
 * JD-Core Version:    0.7.1
 */