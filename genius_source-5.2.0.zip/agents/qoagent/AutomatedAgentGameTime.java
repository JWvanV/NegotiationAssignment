package agents.qoagent;

public class AutomatedAgentGameTime
  implements Runnable
{
  private AutomatedAgent m_agent;
  private int m_nMaxTurn;
  private boolean m_bIsTurn;
  private long m_nTime;
  private boolean m_bRun;
  private boolean m_bCountUp;
  private int m_nStartSeconds;
  private int m_nStartMinutes;
  private int m_nStartHours;
  
  public AutomatedAgentGameTime(boolean bCountUp, int nHours, int nMinutes, int nSeconds, AutomatedAgent agent, boolean TurnOrNeg)
  {
    this.m_bIsTurn = TurnOrNeg;
    this.m_agent = agent;
    this.m_nMaxTurn = this.m_agent.getMaxTurns();
    this.m_bCountUp = bCountUp;
    this.m_bRun = false;
    if (!bCountUp)
    {
      this.m_nStartMinutes = nMinutes;
      this.m_nStartSeconds = nSeconds;
      this.m_nStartHours = nHours;
      
      this.m_nTime = (nHours * 3600 + nMinutes * 60 + nSeconds);
    }
    else
    {
      this.m_nStartSeconds = 0;
      this.m_nStartMinutes = 0;
      this.m_nStartHours = 0;
      this.m_nTime = 0L;
    }
  }
  
  public void SetTime(boolean bCountUp, int nHours, int nMinutes, int nSeconds, boolean TurnOrNeg)
  {
    this.m_bIsTurn = TurnOrNeg;
    this.m_bCountUp = bCountUp;
    this.m_bRun = false;
    if (!bCountUp)
    {
      this.m_nStartMinutes = nMinutes;
      this.m_nStartSeconds = nSeconds;
      this.m_nStartHours = nHours;
      
      this.m_nTime = (nHours * 3600 + nMinutes * 60 + nSeconds);
    }
    else
    {
      this.m_nStartSeconds = 0;
      this.m_nStartMinutes = 0;
      this.m_nStartHours = 0;
      this.m_nTime = 0L;
    }
  }
  
  public AutomatedAgentGameTime()
  {
    this.m_bCountUp = true;
    this.m_bRun = false;
    this.m_nTime = 0L;
  }
  
  public void run()
  {
    while (this.m_bRun)
    {
      try
      {
        Thread.sleep(1000L);
        if (this.m_bCountUp) {
          this.m_nTime += 1L;
        } else {
          this.m_nTime -= 1L;
        }
      }
      catch (Exception e) {}
      if (this.m_nTime == 0L) {
        stopRunning();
      }
    }
  }
  
  public void stopRunning()
  {
    this.m_bRun = false;
    
    int nCurrentTurn = this.m_agent.getCurrentTurn();
    if ((this.m_bIsTurn) && (nCurrentTurn < this.m_nMaxTurn))
    {
      newGame();
      this.m_bRun = true;
    }
  }
  
  public void newGame()
  {
    this.m_bRun = true;
    this.m_nTime = (this.m_nStartHours * 3600 + this.m_nStartMinutes * 60 + this.m_nStartSeconds);
  }
  
  public void setRunMethod(boolean bCountUp)
  {
    this.m_bCountUp = bCountUp;
  }
  
  public void setRun(boolean bRun)
  {
    this.m_bRun = bRun;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AutomatedAgentGameTime
 * JD-Core Version:    0.7.1
 */