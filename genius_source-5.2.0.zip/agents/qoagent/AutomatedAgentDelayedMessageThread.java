package agents.qoagent;

import java.io.PrintStream;

public class AutomatedAgentDelayedMessageThread
  extends Thread
{
  public static final long SLEEP_TIME_FACTOR = 3L;
  private String m_sOffer;
  private String m_sResponse;
  private int m_nCurrentTurn;
  private long m_lSleepTime;
  private AutomatedAgent m_agent;
  private int m_nMessageType = -1;
  public static final int NEW_OFFER_TYPE = 0;
  public static final int RESPONSE_TYPE = 1;
  public static final int NO_TYPE = -1;
  public static final long RESPONSE_SLEEP_TIME_MILLIS = 15000L;
  
  AutomatedAgentDelayedMessageThread(AutomatedAgent agent, String sOffer, int nCurrentTurn)
  {
    this.m_nMessageType = 0;
    this.m_agent = agent;
    this.m_sOffer = sOffer;
    this.m_nCurrentTurn = nCurrentTurn;
    

    long lSecondsPerTurn = this.m_agent.getSecondsForTurn();
    long lMillisPerTurn = lSecondsPerTurn * 1000L;
    
    this.m_lSleepTime = (lMillisPerTurn / 3L);
  }
  
  AutomatedAgentDelayedMessageThread(AutomatedAgent agent, String sResponse)
  {
    this.m_nMessageType = 1;
    this.m_agent = agent;
    this.m_sResponse = sResponse;
    

    this.m_lSleepTime = 15000L;
  }
  
  public void run()
  {
    try
    {
      sleep(this.m_lSleepTime);
    }
    catch (InterruptedException e)
    {
      e.printStackTrace();
      System.out.println("[AA]ERROR: Error during sleep" + e.getMessage() + " [AutomatedAgentDelayedMessageThread::run(35)]");
      System.err.println("[AA]ERROR: Error during sleep" + e.getMessage() + " [AutomatedAgentDelayedMessageThread::run(35)]");
    }
    if (this.m_nMessageType == 0)
    {
      boolean bSendOffer = this.m_agent.getSendOfferFlag();
      int nCurrentTurn = this.m_agent.getCurrentTurn();
      if (nCurrentTurn == this.m_nCurrentTurn) {
        if (bSendOffer) {
          this.m_agent.printMessageToServer(this.m_sOffer);
        }
      }
    }
    else if (this.m_nMessageType == 1)
    {
      this.m_agent.printMessageToServer(this.m_sResponse);
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent.AutomatedAgentDelayedMessageThread
 * JD-Core Version:    0.7.1
 */