package agents;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

class NegoProposeOffer
  extends NegoInfo
{
  NegoProposeOffer(Bid our, Bid opponent, UtilitySpace us)
    throws Exception
  {
    super(our, opponent, us);
  }
  
  private String[] colNames = { "Issue", "Offer" };
  
  public Component getValueAt(int row, int col)
  {
    switch (col)
    {
    case 0: 
      return super.getValueAt(row, col);
    case 1: 
      return super.getValueAt(row, 2);
    }
    return null;
  }
  
  public String getColumnName(int col)
  {
    return this.colNames[col];
  }
  
  public boolean isCellEditable(int row, int col)
  {
    return (col == 1) && (row < this.issues.size());
  }
  
  public int getColumnCount()
  {
    return 2;
  }
  
  public void actionPerformed(ActionEvent e)
  {
    fireTableCellUpdated(this.issues.size(), 1);
    fireTableCellUpdated(this.issues.size() + 1, 1);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.NegoProposeOffer
 * JD-Core Version:    0.7.1
 */