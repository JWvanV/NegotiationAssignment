package agents;

import negotiator.SupportedNegotiationSetting;

public class TimeDependentAgentLinear
  extends TimeDependentAgent
{
  public double getE()
  {
    return 1.0D;
  }
  
  public String getName()
  {
    return "Conceder Linear";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TimeDependentAgentLinear
 * JD-Core Version:    0.7.1
 */