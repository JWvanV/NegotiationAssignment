package agents;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.gui.chart.UtilityPlot;
import negotiator.utility.UtilitySpace;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;

public class EnterBidDialogExtended
  extends JDialog
{
  private NegoInfo negoinfo;
  private Action selectedAction;
  private UIAgentExtended agent;
  private JTextArea negotiationMessages = new JTextArea("NO MESSAGES YET");
  private JButton buttonAccept = new JButton(" Accept Opponent Bid ");
  private JButton buttonEnd = new JButton("End Negotiation");
  private JButton buttonBid = new JButton("       Do Bid       ");
  private JPanel buttonPanel = new JPanel();
  private JTable BidTable;
  private JTable BidHistoryTable;
  private HistoryInfo historyinfo;
  private ChartPanel chartPanel;
  private JPanel defaultChartPanel;
  private UtilityPlot plot;
  
  public EnterBidDialogExtended(UIAgentExtended agent, Frame parent, boolean modal, UtilitySpace us)
    throws Exception
  {
    super(parent, modal);
    this.agent = agent;
    this.negoinfo = new NegoInfo(null, null, us);
    this.historyinfo = new HistoryInfo(agent, null, null, us);
    initThePanel();
  }
  
  public void setUtilitySpace(UtilitySpace us)
  {
    this.negoinfo.utilitySpace = us;
    this.historyinfo.utilitySpace = us;
  }
  
  private void initThePanel()
  {
    if (this.negoinfo == null) {
      throw new NullPointerException("negoinfo is null");
    }
    Container pane = getContentPane();
    
    GridBagLayout gridbag = new GridBagLayout();
    GridBagConstraints c = new GridBagConstraints();
    
    pane.setLayout(gridbag);
    
    setDefaultCloseOperation(2);
    setTitle("Choose action for agent " + this.agent.getName());
    


    c.gridx = 0;
    c.gridy = 1;
    c.gridwidth = 2;
    c.fill = 2;
    c.insets = new Insets(0, 10, 0, 10);
    
    this.BidHistoryTable = new JTable(this.historyinfo);
    this.BidHistoryTable.setGridColor(Color.lightGray);
    
    this.BidHistoryTable.getColumnModel().getColumn(0).setMaxWidth(50);
    this.BidHistoryTable.getColumnModel().getColumn(2).setMaxWidth(50);
    this.BidHistoryTable.getColumnModel().getColumn(4).setMaxWidth(50);
    JPanel tablepaneHistory = new JPanel(new BorderLayout());
    tablepaneHistory.add(this.BidHistoryTable.getTableHeader(), "North");
    tablepaneHistory.add(this.BidHistoryTable, "Center");
    Border blackline = BorderFactory.createLineBorder(Color.black);
    TitledBorder title = BorderFactory.createTitledBorder(blackline, "History of Bids:");
    

    tablepaneHistory.setBorder(title);
    pane.add(tablepaneHistory, c);
    
    c.gridwidth = 1;
    c.gridheight = 4;
    c.gridx = 0;
    c.gridy = 2;
    c.insets = new Insets(10, 10, 10, 10);
    
    this.defaultChartPanel = new JPanel();
    title = BorderFactory.createTitledBorder(blackline, "Utilities of Bids per round:");
    
    this.defaultChartPanel.setBorder(title);
    pane.remove(this.defaultChartPanel);
    pane.add(this.defaultChartPanel, c);
    

    JPanel userInputPanel = new JPanel();
    userInputPanel.setLayout(new BoxLayout(userInputPanel, 1));
    title = BorderFactory.createTitledBorder(blackline, "Please place your bid:");
    
    userInputPanel.setBorder(title);
    this.negotiationMessages.setBackground(Color.lightGray);
    this.negotiationMessages.setEditable(false);
    userInputPanel.add(this.negotiationMessages);
    

    this.BidTable = new JTable(this.negoinfo);
    

    this.BidTable.setGridColor(Color.lightGray);
    this.BidTable.setRowHeight(18);
    JPanel tablepane = new JPanel(new BorderLayout());
    tablepane.add(this.BidTable.getTableHeader(), "North");
    tablepane.add(this.BidTable, "Center");
    userInputPanel.add(tablepane);
    

    this.buttonPanel.setLayout(new FlowLayout());
    this.buttonPanel.add(this.buttonEnd);
    this.buttonPanel.add(this.buttonAccept);
    this.buttonPanel.add(this.buttonBid);
    userInputPanel.add(this.buttonPanel);
    
    c.gridwidth = 1;
    c.gridheight = 1;
    c.gridx = 1;
    c.gridy = 3;
    c.weighty = 0.0D;
    c.fill = 2;
    c.insets = new Insets(10, 10, 10, 10);
    pane.add(userInputPanel, c);
    this.buttonBid.setSelected(true);
    

    this.buttonBid.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogExtended.this.buttonBidActionPerformed(evt);
      }
    });
    this.buttonEnd.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogExtended.this.buttonEndActionPerformed(evt);
      }
    });
    this.buttonAccept.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogExtended.this.buttonAcceptActionPerformed(evt);
      }
    });
    pack();
  }
  
  private Bid getBid()
  {
    Bid bid = null;
    try
    {
      bid = this.negoinfo.getBid();
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(null, "There is a problem with your bid: " + e.getMessage());
    }
    return bid;
  }
  
  private void buttonBidActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      this.selectedAction = new Offer(this.agent.getAgentID(), bid);
      setVisible(false);
    }
  }
  
  private void buttonAcceptActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      System.out.println("Accept performed");
      this.selectedAction = new Accept(this.agent.getAgentID());
      setVisible(false);
    }
  }
  
  private void buttonEndActionPerformed(ActionEvent evt)
  {
    System.out.println("End Negotiation performed");
    this.selectedAction = new EndNegotiation(this.agent.getAgentID());
    setVisible(false);
  }
  
  public Action askUserForAction(Action opponentAction, Bid myPreviousBid)
  {
    this.historyinfo.nrOfBids = this.agent.historyOfBids.size();
    this.negoinfo.opponentOldBid = null;
    if (opponentAction == null) {
      this.negotiationMessages.setText("Opponent did not send any action.");
    }
    if ((opponentAction instanceof Accept))
    {
      this.negotiationMessages.setText("Opponent accepted your last bid!");
      this.negoinfo.opponentOldBid = myPreviousBid;
    }
    if ((opponentAction instanceof EndNegotiation)) {
      this.negotiationMessages.setText("Opponent cancels the negotiation.");
    }
    if ((opponentAction instanceof Offer))
    {
      this.negotiationMessages.setText("Opponent proposes the following bid:");
      this.negoinfo.opponentOldBid = ((Offer)opponentAction).getBid();
    }
    try
    {
      this.negoinfo.setOurBid(myPreviousBid);
    }
    catch (Exception e)
    {
      System.out.println("error in askUserForAction:" + e.getMessage());e.printStackTrace();
    }
    this.BidTable.setDefaultRenderer(this.BidTable.getColumnClass(0), new MyCellRenderer(this.negoinfo));
    
    this.BidHistoryTable.setDefaultRenderer(this.BidHistoryTable.getColumnClass(0), new MyHistoryCellRenderer(this.historyinfo));
    
    this.BidHistoryTable.setAutoResizeMode(0);
    this.BidTable.setDefaultEditor(this.BidTable.getColumnClass(0), new MyCellEditor(this.negoinfo));
    
    int round = this.agent.bidCounter;
    System.out.println("round# " + round + "/" + this.agent.historyOfBids.size());
    

    double[][] myBidSeries = new double[2][round];
    double[][] oppBidSeries = new double[2][round];
    if (round > 0)
    {
      System.out.println(this.agent.historyOfBids.get(0));
      for (int i = 0; i < round; i++) {
        try
        {
          System.out.println("i " + i);
          Bid oppBid = ((NegoRoundData)this.agent.historyOfBids.get(i)).getOppentBid();
          Bid ourBid = ((NegoRoundData)this.agent.historyOfBids.get(i)).getOurBid();
          double utilOpp = 0.0D;
          double ourUtil = 0.0D;
          if (this.agent.utilitySpace != null)
          {
            if (oppBid != null) {
              utilOpp = this.agent.utilitySpace.getUtility(oppBid);
            }
            ourUtil = this.agent.utilitySpace.getUtility(ourBid);
          }
          else
          {
            System.out.println("agent.utilSpace=null");
          }
          myBidSeries[0][i] = (i + 1);
          myBidSeries[1][i] = ourUtil;
          
          oppBidSeries[0][i] = (i + 1);
          oppBidSeries[1][i] = utilOpp;
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
    if (this.defaultChartPanel.getComponents().length > 0) {
      this.defaultChartPanel.remove(this.chartPanel);
    }
    this.plot = new UtilityPlot(myBidSeries, oppBidSeries);
    JFreeChart chart = this.plot.getChart();
    this.chartPanel = new ChartPanel(chart);
    this.chartPanel.setPreferredSize(new Dimension(350, 350));
    this.defaultChartPanel.add(this.chartPanel);
    
    pack();
    repaint();
    setVisible(true);
    ((JComboBox)this.negoinfo.comboBoxes.get(0)).requestFocusInWindow();
    return this.selectedAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.EnterBidDialogExtended
 * JD-Core Version:    0.7.1
 */