package agents;

import agents.bayesianopponentmodel.BayesianOpponentModel;
import agents.bayesianopponentmodel.OpponentModel;
import agents.bayesianopponentmodel.OpponentModelUtilSpace;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Agent;
import negotiator.AgentParam;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.protocol.BilateralAtomicNegotiationSession;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.UtilitySpace;

public class BayesianAgentForAuction
  extends Agent
{
  protected Action messageOpponent;
  protected Bid myLastBid = null;
  protected Action myLastAction = null;
  protected Bid fOpponentPreviousBid = null;
  
  protected static enum ROLE
  {
    CENTER,  PROVIDER,  IRRELEVANT;
    
    private ROLE() {}
  }
  
  public static enum PHASE
  {
    FIRST_PHASE,  SECOND_PHASE;
    
    private PHASE() {}
  }
  
  protected static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  private static enum STRATEGY
  {
    SMART,  SERIAL,  RESPONSIVE,  RANDOM,  TIT_FOR_TAT,  AUCTION;
    
    private STRATEGY() {}
  }
  
  private STRATEGY fStrategy = STRATEGY.AUCTION;
  private boolean fMarketPreassure = false;
  protected int fSmartSteps;
  protected OpponentModel fOpponentModel;
  protected OpponentModel[] fOpponentModels = null;
  protected double CONCESSIONFACTOR = 0.04D;
  private static final double ALLOWED_UTILITY_DEVIATION = 0.01D;
  protected static final int NUMBER_OF_SMART_STEPS = 0;
  protected ArrayList<Bid> myPreviousBids;
  private boolean fDebug = false;
  protected PHASE fPhase = null;
  protected ROLE fRole;
  
  public String getVersion()
  {
    return "2.0";
  }
  
  public static ArrayList<AgentParam> getParameters()
  {
    ArrayList<AgentParam> parameters = new ArrayList();
    parameters.add(new AgentParam(BayesianAgentForAuction.class.getName(), "reservation", Double.valueOf(0.0D), Double.valueOf(1.0D)));
    
    parameters.add(new AgentParam(BayesianAgentForAuction.class.getName(), "starting_utility", Double.valueOf(0.0D), Double.valueOf(1.0D)));
    
    parameters.add(new AgentParam(BayesianAgentForAuction.class.getName(), "role", Double.valueOf(-1.0D), Double.valueOf(3.0D)));
    
    parameters.add(new AgentParam(BayesianAgentForAuction.class.getName(), "phase", Double.valueOf(-1.0D), Double.valueOf(1.0D)));
    
    parameters.add(new AgentParam(BayesianAgentForAuction.class.getName(), "opponent", Double.valueOf(-1.0D), Double.valueOf(1.0D)));
    
    return parameters;
  }
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastAction = null;
    this.fSmartSteps = 0;
    this.myPreviousBids = new ArrayList();
    this.fOpponentPreviousBid = null;
    if ((getParameterValues().isEmpty()) || (((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "phase", new Double(-1.0D), new Double(1.0D))))).getValue().doubleValue() < 0.0D)) {
      this.fPhase = PHASE.FIRST_PHASE;
    } else {
      this.fPhase = PHASE.SECOND_PHASE;
    }
    if (getParameterValues().isEmpty())
    {
      this.fRole = ROLE.IRRELEVANT;
    }
    else if (((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "role", Double.valueOf(-1.0D), Double.valueOf(3.0D))))).getValue().doubleValue() < 0.0D)
    {
      this.fRole = ROLE.PROVIDER;
    }
    else if (((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "role", Double.valueOf(-1.0D), Double.valueOf(3.0D))))).getValue().doubleValue() < 2.0D)
    {
      this.fRole = ROLE.CENTER;
      this.CONCESSIONFACTOR = 0.06D;
    }
    else
    {
      this.fRole = ROLE.IRRELEVANT;
    }
    if ((this.fPhase == PHASE.FIRST_PHASE) && (this.fOpponentModels == null)) {
      prepareOpponentModel();
    }
    if (this.fRole == ROLE.CENTER)
    {
      int index = Double.valueOf(((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "opponent", Double.valueOf(-1.0D), Double.valueOf(1.0D))))).getValue().doubleValue()).intValue();
      




      this.fOpponentModel = this.fOpponentModels[index];
    }
  }
  
  protected void prepareOpponentModel()
  {
    this.fOpponentModels = new BayesianOpponentModel[2];
    this.fOpponentModels[0] = new BayesianOpponentModel(this.utilitySpace);
    this.fOpponentModels[1] = new BayesianOpponentModel(this.utilitySpace);
    this.fOpponentModel = this.fOpponentModels[0];
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.messageOpponent = opponentAction;
  }
  
  protected Action proposeInitialBid()
    throws Exception
  {
    Bid lBid = null;
    switch (this.fRole)
    {
    case CENTER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getMaxUtilityBid();
        break;
      case SECOND_PHASE: 
        double lSecondBest = ((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "reservation", Double.valueOf(0.0D), Double.valueOf(1.0D))))).getValue().doubleValue();
        


        lBid = getTradeOff(lSecondBest);
      }
      break;
    case PROVIDER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        double lReservationValue = this.utilitySpace.getReservationValue().doubleValue();
        lBid = getTradeOff(lReservationValue);
        break;
      case SECOND_PHASE: 
        lBid = getMaxUtilityBid();
      }
      break;
    case IRRELEVANT: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getMaxUtilityBid();
        break;
      case SECOND_PHASE: 
        double lSecondBest = ((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "starting_utility", Double.valueOf(0.0D), Double.valueOf(1.0D))))).getValue().doubleValue();
        


        lBid = getTradeOff(lSecondBest);
      }
      break;
    }
    this.fSmartSteps = 0;
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  protected Bid getNextBidAuction(Bid pOppntBid)
    throws Exception
  {
    if (pOppntBid == null) {
      throw new NullPointerException("pOpptBid=null");
    }
    if (this.myLastBid == null) {
      throw new Exception("myLastBid==null");
    }
    log("Get next bid ...");
    Bid lBid = null;
    switch (this.fRole)
    {
    case CENTER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
        break;
      case SECOND_PHASE: 
        double lSecondBest = ((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "reservation", Double.valueOf(0.0D), Double.valueOf(1.0D))))).getValue().doubleValue();
        


        lBid = getTradeOff(lSecondBest);
      }
      break;
    case PROVIDER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        double lReservationValue = this.utilitySpace.getReservationValue().doubleValue();
        lBid = getTradeOff(lReservationValue);
        break;
      case SECOND_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
      }
      break;
    case IRRELEVANT: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
        break;
      case SECOND_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
      }
      break;
    }
    return lBid;
  }
  
  private Bid getNextBid(Bid pOppntBid)
    throws Exception
  {
    if (pOppntBid == null) {
      throw new NullPointerException("pOpptBid=null");
    }
    if (this.myLastBid == null) {
      throw new Exception("myLastBid==null");
    }
    log("Get next bid ...");
    
    BidSpace bs = new BidSpace(this.utilitySpace, new OpponentModelUtilSpace(this.fOpponentModel), true, true);
    



    double opponentConcession = 0.0D;
    if (this.fOpponentPreviousBid == null)
    {
      opponentConcession = 0.0D;
    }
    else
    {
      double opponentUtil = this.fOpponentModel.getNormalizedUtility(pOppntBid);
      
      double opponentFirstBidUtil = this.fOpponentModel.getNormalizedUtility((Bid)this.fOpponentModel.fBiddingHistory.get(0));
      
      opponentConcession = opponentUtil - opponentFirstBidUtil;
    }
    log("opponent Concession:" + opponentConcession);
    

    double OurFirstBidOppUtil = this.fOpponentModel.getNormalizedUtility((Bid)this.myPreviousBids.get(0));
    
    double OurTargetBidOppUtil = OurFirstBidOppUtil - opponentConcession;
    if (OurTargetBidOppUtil > 1.0D) {
      OurTargetBidOppUtil = 1.0D;
    }
    if (OurTargetBidOppUtil < OurFirstBidOppUtil) {
      OurTargetBidOppUtil = OurFirstBidOppUtil;
    }
    log("our target opponent utility=" + OurTargetBidOppUtil);
    

    double targetUtil = bs.ourUtilityOnPareto(OurTargetBidOppUtil);
    
    BidPoint bp = bs.getNearestBidPoint(targetUtil, OurTargetBidOppUtil, 0.5D, 1.0D, this.myPreviousBids);
    
    log("found bid " + bp);
    return bp.getBid();
  }
  
  Bid getNewBidWithUtil(double ourUtility, BidSpace bs)
  {
    BidPoint bestbid = null;
    double bestbidutil = 0.0D;
    for (BidPoint p : bs.bidPoints) {
      if ((Math.abs(ourUtility - p.getUtilityA().doubleValue()) < 0.01D) && (p.getUtilityB().doubleValue() > bestbidutil) && (!this.myPreviousBids.contains(p.getBid())))
      {
        bestbid = p;
        bestbidutil = p.getUtilityB().doubleValue();
      }
    }
    if (bestbid == null) {
      return null;
    }
    return bestbid.getBid();
  }
  
  protected Bid getSmartBid(Bid pBid)
    throws Exception
  {
    Bid lBid = null;
    double lExpectedUtility = -1.0D;
    double lUtility = this.utilitySpace.getUtility(pBid);
    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    while (lIter.hasNext())
    {
      Bid tmpBid = lIter.next();
      if (Math.abs(this.utilitySpace.getUtility(tmpBid) - lUtility) < 0.01D)
      {
        double lTmpExpecteUtility = this.fOpponentModel.getNormalizedUtility(tmpBid);
        if (lTmpExpecteUtility > lExpectedUtility)
        {
          lExpectedUtility = lTmpExpecteUtility;
          lBid = tmpBid;
        }
      }
    }
    return lBid;
  }
  
  protected Bid getNextBidSmart(Bid pOppntBid)
    throws Exception
  {
    double lMyUtility = this.utilitySpace.getUtility(this.myLastBid);
    double lOppntUtility = this.utilitySpace.getUtility(pOppntBid);
    double lTargetUtility;
    if (this.fSmartSteps >= 0)
    {
      double lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
      this.fSmartSteps = 0;
    }
    else
    {
      lTargetUtility = lMyUtility;
      this.fSmartSteps += 1;
    }
    if (lTargetUtility < this.utilitySpace.getReservationValue().doubleValue()) {
      return null;
    }
    return getTradeOff(lTargetUtility);
  }
  
  protected Bid getTradeOff(double pUtility)
    throws Exception
  {
    if (pUtility < this.utilitySpace.getReservationValue().doubleValue()) {
      return null;
    }
    Bid lBid = null;
    double lExpectedUtility = -100.0D;
    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    while (lIter.hasNext())
    {
      Bid tmpBid = lIter.next();
      if ((!this.fMarketPreassure) || 
        (this.fNegotiation.getOpponentUtility(this, tmpBid) >= 0.3D)) {
        if (Math.abs(this.utilitySpace.getUtility(tmpBid) - pUtility) < 0.01D)
        {
          double lTmpExpecteUtility = this.fNegotiation.getOpponentUtility(this, tmpBid);
          if (lTmpExpecteUtility > lExpectedUtility)
          {
            lExpectedUtility = lTmpExpecteUtility;
            lBid = tmpBid;
          }
        }
      }
    }
    return lBid;
  }
  
  protected Bid proposeNextBid(Bid pOppntBid)
    throws Exception
  {
    Bid lBid = null;
    switch (this.fStrategy)
    {
    case TIT_FOR_TAT: 
      lBid = getNextBid(pOppntBid);
      break;
    case SMART: 
      lBid = getNextBidSmart(pOppntBid);
      break;
    case AUCTION: 
      lBid = getNextBidAuction(pOppntBid);
      break;
    default: 
      throw new Exception("unknown strategy " + this.fStrategy);
    }
    this.myLastBid = lBid;
    return lBid;
  }
  
  public double getOpponentUtility(Bid bid)
    throws Exception
  {
    return this.fOpponentModel.getExpectedUtility(bid);
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    try
    {
      ACTIONTYPE lActionType = getActionType(this.messageOpponent);
      switch (lActionType)
      {
      case OFFER: 
        lOppntBid = ((Offer)this.messageOpponent).getBid();
        



        System.out.print("Updating beliefs ...");
        if (this.myPreviousBids.size() < 8) {
          this.fOpponentModel.updateBeliefs(lOppntBid);
        }
        System.out.println("Done!");
        if (this.myLastAction == null)
        {
          lAction = proposeInitialBid();
        }
        else
        {
          double offeredutil = this.utilitySpace.getUtility(lOppntBid);
          double time = this.timeline.getTime();
          double P = Paccept(offeredutil, time);
          log("time=" + time + " offeredutil=" + offeredutil + " accept probability P=" + P);
          if (this.utilitySpace.getUtility(lOppntBid) * 1.05D >= this.utilitySpace.getUtility(this.myLastBid))
          {
            lAction = new Accept(getAgentID());
            log("randomly accepted");
          }
          else
          {
            Bid lnextBid = proposeNextBid(lOppntBid);
            if (lnextBid == null)
            {
              lAction = new EndNegotiation(getAgentID());
            }
            else
            {
              lAction = new Offer(getAgentID(), lnextBid);
              if (this.utilitySpace.getUtility(lOppntBid) * 1.05D >= this.utilitySpace.getUtility(lnextBid))
              {
                lAction = new Accept(getAgentID());
                log("opponent's bid higher than util of my last bid! accepted");
              }
            }
          }
          this.fOpponentPreviousBid = lOppntBid;
        }
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else {
          lAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      log("Exception in chooseAction:" + e.getMessage());
      e.printStackTrace();
      lAction = new Offer(getAgentID(), this.myLastBid);
    }
    this.myLastAction = lAction;
    
    this.myPreviousBids.add(((Offer)this.myLastAction).getBid());
    this.myLastBid = ((Offer)this.myLastAction).getBid();
    
    return lAction;
  }
  
  protected ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private double getTargetUtility(double myUtility, double oppntUtility)
  {
    return myUtility - getConcessionFactor();
  }
  
  private double getConcessionFactor()
  {
    return this.CONCESSIONFACTOR;
  }
  
  private void log(String pMessage)
  {
    if (this.fDebug) {
      System.out.println(pMessage);
    }
  }
  
  protected double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  private double sq(double x)
  {
    return x * x;
  }
  
  public final Bid getMaxUtilityBid()
    throws Exception
  {
    Bid maxBid = null;
    double maxutil = 0.0D;
    BidIterator bidit = new BidIterator(this.utilitySpace.getDomain());
    if (bidit.hasNext()) {
      maxBid = bidit.next();
    } else {
      throw new Exception("The domain does not contain any bids!");
    }
    while (bidit.hasNext())
    {
      Bid thisBid = bidit.next();
      if ((!this.fMarketPreassure) || 
        (this.fNegotiation.getOpponentUtility(this, thisBid) >= 0.3D))
      {
        double thisutil = this.utilitySpace.getUtility(thisBid);
        if (thisutil > maxutil)
        {
          maxutil = thisutil;
          maxBid = thisBid;
        }
      }
    }
    return maxBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BayesianAgentForAuction
 * JD-Core Version:    0.7.1
 */