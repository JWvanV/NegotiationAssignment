package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class DecUtilAgent
  extends Agent
{
  private Action actionOfPartner = null;
  ArrayList<Bid> bids = new ArrayList();
  int nextBidIndex = 0;
  
  public void init()
  {
    BidIterator biter = new BidIterator(this.utilitySpace.getDomain());
    while (biter.hasNext()) {
      this.bids.add(biter.next());
    }
    Collections.sort(this.bids, new BidComparator(this.utilitySpace));
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = new Offer(getAgentID(), (Bid)this.bids.get(this.nextBidIndex++));
      }
      if ((this.actionOfPartner instanceof Offer)) {
        action = new Offer(getAgentID(), (Bid)this.bids.get(this.nextBidIndex++));
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.DecUtilAgent
 * JD-Core Version:    0.7.1
 */