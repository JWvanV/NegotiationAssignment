package agents;

import agents.bayesianopponentmodel.BayesianOpponentModelScalable;

public class BayesianAgentNS
  extends BayesianAgent
{
  public String getName()
  {
    return "Bayesian Scalable";
  }
  
  protected void prepareOpponentModel()
  {
    this.fOpponentModel = new BayesianOpponentModelScalable(this.utilitySpace);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BayesianAgentNS
 * JD-Core Version:    0.7.1
 */