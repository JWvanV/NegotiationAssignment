package agents;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.DiscreteTimeline;
import negotiator.SupportedNegotiationSetting;
import negotiator.utility.UtilitySpace;

public class FunctionalAcceptor
  extends TimeDependentAgent
{
  double rv = -0.1D;
  int ownTotalRounds = 0;
  private static ArrayList<Double> cutoffs;
  
  public void init()
  {
    this.rv = this.utilitySpace.getReservationValue().doubleValue();
    this.ownTotalRounds = ((getTotalRounds() - 1) / 2);
    
    cutoffs = new ArrayList(this.ownTotalRounds);
    for (int i = 0; i < this.ownTotalRounds; i++) {
      cutoffs.add(Double.valueOf(bid(i + 1)));
    }
    super.init();
  }
  
  public double getE()
  {
    return 0.0D;
  }
  
  public String getName()
  {
    return "FunctionalAcceptor";
  }
  
  public double bid(int j)
  {
    if (j == 1) {
      return 0.5D + 0.5D * this.rv;
    }
    return 0.5D + 0.5D * Math.pow(bid(j - 1), 2.0D);
  }
  
  public double functionalReservationValue()
  {
    boolean immediate = false;
    if (!immediate) {
      return ((Double)cutoffs.get(getOwnRoundsLeft())).doubleValue();
    }
    return this.utilitySpace.getReservationValue().doubleValue();
  }
  
  public boolean isAcceptable(Bid plannedBid)
  {
    Bid opponentLastBid = getOpponentLastBid();
    if (getUtility(opponentLastBid) >= functionalReservationValue()) {
      return true;
    }
    return false;
  }
  
  public int getRound()
  {
    return ((DiscreteTimeline)this.timeline).getRound();
  }
  
  public int getRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getRoundsLeft();
  }
  
  public int getOwnRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getOwnRoundsLeft();
  }
  
  public int getTotalRounds()
  {
    return ((DiscreteTimeline)this.timeline).getTotalRounds();
  }
  
  public double getTotalTime()
  {
    return ((DiscreteTimeline)this.timeline).getTotalTime();
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.FunctionalAcceptor
 * JD-Core Version:    0.7.1
 */