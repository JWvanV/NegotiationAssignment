package agents;

import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

class MyHistoryCellRenderer
  implements TableCellRenderer
{
  HistoryInfo historyinfo;
  
  public MyHistoryCellRenderer(HistoryInfo n)
  {
    this.historyinfo = n;
  }
  
  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
  {
    return this.historyinfo.getValueAt(row, column);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.MyHistoryCellRenderer
 * JD-Core Version:    0.7.1
 */