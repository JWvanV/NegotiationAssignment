package agents;

import java.awt.Component;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.table.AbstractTableModel;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

class HistoryInfo
  extends AbstractTableModel
{
  public Bid ourOldBid;
  public Bid oppOldBid;
  public int nrOfBids = 0;
  private UIAgentExtended agent;
  private String[] colNames = { "Round", "Bid of your Opponent", "u(opp)", "Your Bid", "u(own)" };
  public UtilitySpace utilitySpace;
  
  public String getColumnName(int col)
  {
    return this.colNames[col];
  }
  
  HistoryInfo(UIAgentExtended agent, Bid our, Bid opponent, UtilitySpace us)
    throws Exception
  {
    this.agent = agent;
    this.utilitySpace = us;
  }
  
  public int getColumnCount()
  {
    return 5;
  }
  
  public int getRowCount()
  {
    return 10;
  }
  
  public Component getValueAt(int row, int col)
  {
    if ((this.nrOfBids != 0) && (row < this.nrOfBids))
    {
      Bid oppBid = ((NegoRoundData)this.agent.historyOfBids.get(row)).getOppentBid();
      Bid ourBid = ((NegoRoundData)this.agent.historyOfBids.get(row)).getOurBid();
      switch (col)
      {
      case 0: 
        return new JLabel(Integer.toString(row + 1));
      case 1: 
        String str1 = "No Bid yet.";
        if (oppBid != null)
        {
          str1 = new String(oppBid.toString());
          str1 = str1.substring(4, str1.length() - 3);
        }
        return new JTextArea(str1);
      case 2: 
        try
        {
          double utilOpp = 0.0D;
          if (oppBid != null) {
            utilOpp = this.utilitySpace.getUtility(oppBid);
          }
          DecimalFormat df = new DecimalFormat("0.00");
          return new JTextArea(df.format(utilOpp));
        }
        catch (Exception e) {}
      case 3: 
        String str2 = new String(ourBid.toString());
        str2 = str2.substring(4, str2.length() - 3);
        return new JTextArea(str2);
      case 4: 
        try
        {
          double utilOur = this.utilitySpace.getUtility(ourBid);
          DecimalFormat df = new DecimalFormat("0.00");
          return new JTextArea(df.format(utilOur));
        }
        catch (Exception e) {}
      }
    }
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.HistoryInfo
 * JD-Core Version:    0.7.1
 */