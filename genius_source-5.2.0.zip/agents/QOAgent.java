package agents;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.StringTokenizer;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class QOAgent
  extends Agent
{
  private agents.qoagent2.QOAgent m_QOAgent;
  private boolean fFirstOffer;
  private Action fNextAction;
  private int fMessageId;
  public UtilitySpace[] opponentModels;
  
  private static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  public Action chooseAction()
  {
    if (this.fFirstOffer)
    {
      this.m_QOAgent.calculateFirstOffer();
      this.fFirstOffer = false;
    }
    return this.fNextAction;
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void init()
  {
    this.fFirstOffer = true;
    this.fMessageId = 1;
    this.opponentModels = new UtilitySpace[3];
    try
    {
      this.opponentModels[0] = new UtilitySpace(this.utilitySpace.getDomain(), getName() + "_long_term.xml");
      
      this.opponentModels[1] = new UtilitySpace(this.utilitySpace.getDomain(), getName() + "_short_term.xml");
      
      this.opponentModels[2] = new UtilitySpace(this.utilitySpace.getDomain(), getName() + "_compromise.xml");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.m_QOAgent = new agents.qoagent2.QOAgent(this, false, "Zimbabwe", "no", "QOAgent", "1");
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    String sMessage = "";
    
    Bid lOppntBid = null;
    ACTIONTYPE lActionType = getActionType(opponentAction);
    switch (lActionType)
    {
    case OFFER: 
      try
      {
        lOppntBid = ((Offer)opponentAction).getBid();
        if (this.fFirstOffer) {
          sMessage = "type offer source 1 target 2 tag " + String.valueOf(this.fMessageId) + " issueSet ";
        } else {
          sMessage = "type counter_offer source 1 target 2 tag " + String.valueOf(this.fMessageId) + " issueSet ";
        }
        for (Issue lIssue : this.utilitySpace.getDomain().getIssues()) {
          sMessage = sMessage + lOppntBid.getValue(lIssue.getNumber()) + "*" + lIssue.getName() + "*";
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    case ACCEPT: 
    case BREAKOFF: 
      break;
    }
    this.m_QOAgent.receivedMessage(sMessage);
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  public void prepareAction(int pMessageType, String pMessage)
  {
    String sFormattedMsg = "";
    Action lAction = null;
    switch (pMessageType)
    {
    case 3: 
    case 9: 
      HashMap<Integer, Value> lValues = new HashMap();
      
      String sOffer = pMessage.substring(pMessage.indexOf("issueSet ") + 9);
      

      StringTokenizer st = new StringTokenizer(sOffer, "*");
      while (st.hasMoreTokens())
      {
        String sCurrentIssueValue = st.nextToken();
        
        String sCurrentIssueName = st.nextToken();
        

        Issue lIssue = null;
        for (Issue lTmp : this.utilitySpace.getDomain().getIssues()) {
          if (lTmp.getName().equals(sCurrentIssueName))
          {
            lIssue = lTmp;
            break;
          }
        }
        IssueDiscrete lIssueDisc = (IssueDiscrete)lIssue;
        
        ValueDiscrete lValue = null;
        for (ValueDiscrete lTmp : lIssueDisc.getValues()) {
          if (lTmp.getValue().equals(sCurrentIssueValue))
          {
            lValue = lTmp;
            break;
          }
        }
        lValues.put(Integer.valueOf(lIssue.getNumber()), lValue);
      }
      try
      {
        Bid lBid = new Bid(this.utilitySpace.getDomain(), lValues);
        lAction = new Offer(this, lBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      break;
    case 6: 
      lAction = new Accept(getAgentID());
      
      break;
    case 7: 
      this.m_QOAgent.incrementCurrentTurn();
      
      return;
    case 4: 
    case 5: 
    case 8: 
    default: 
      System.out.println("[QO]ERROR: Invalid message kind: " + pMessageType + " [QMessages::formatMessage(199)]");
    }
    this.fNextAction = lAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.QOAgent
 * JD-Core Version:    0.7.1
 */