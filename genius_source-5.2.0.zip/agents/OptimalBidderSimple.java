package agents;

import java.util.HashMap;
import negotiator.SupportedNegotiationSetting;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class OptimalBidderSimple
  extends OptimalBidder
{
  public void init()
  {
    partitions = 1000;
    this.rv = this.utilitySpace.getReservationValue().doubleValue();
    super.init();
  }
  
  public String getName()
  {
    return "Optimal Bidder Simple";
  }
  
  public double bid(int j)
  {
    if (j == 1) {
      return 0.5D + 0.5D * this.rv;
    }
    return 0.5D + 0.5D * Math.pow(bid(j - 1), 2.0D);
  }
  
  public void getValues()
    throws Exception
  {
    if (pie.getType().equals(ISSUETYPE.DISCRETE))
    {
      IssueDiscrete discrete_pie = (IssueDiscrete)pie;
      int nvalues = discrete_pie.getNumberOfValues();
      print("   #values = " + nvalues);
      values = new HashMap(nvalues);
      for (int i = 0; i < nvalues; i++)
      {
        ValueDiscrete value = discrete_pie.getValue(i);
        values.put(Integer.valueOf(i), value);
      }
    }
    else
    {
      throw new Exception("Type " + pie.getType() + " not supported by " + getName());
    }
  }
  
  public String getVersion()
  {
    return "v1.0";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.OptimalBidderSimple
 * JD-Core Version:    0.7.1
 */