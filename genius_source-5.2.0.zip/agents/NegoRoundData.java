package agents;

import negotiator.Bid;

class NegoRoundData
{
  private Bid lastOppBid;
  private Bid ourLastBid;
  
  public NegoRoundData(Bid lastOppBid, Bid ourLastBid)
  {
    this.lastOppBid = lastOppBid;
    this.ourLastBid = ourLastBid;
  }
  
  public Bid getOppentBid()
  {
    return this.lastOppBid;
  }
  
  public Bid getOurBid()
  {
    return this.ourLastBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.NegoRoundData
 * JD-Core Version:    0.7.1
 */