package agents;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.PocketNegotiatorAgent;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class SimpleTitForTatPN
  extends Agent
  implements PocketNegotiatorAgent
{
  protected UtilitySpace otherUtilitySpace = null;
  private Bid myLastBid = null;
  private Bid lastOpponentBid = null;
  private Map<Double, Bid> goodBids = new HashMap();
  private Set<Bid> usedBids = new HashSet();
  
  public void init() {}
  
  public String getName()
  {
    return "Simple Tit for Tat PN";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    if ((opponentAction instanceof Offer))
    {
      Bid bid = ((Offer)opponentAction).getBid();
      this.lastOpponentBid = bid;
    }
  }
  
  public Action chooseAction()
  {
    try
    {
      Bid bid = chooseAction1();
      if (bid == null) {
        return new Accept();
      }
      this.myLastBid = bid;
      this.usedBids.add(bid);
      return new Offer(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Accept();
  }
  
  private Bid chooseAction1()
    throws Exception
  {
    if ((this.lastOpponentBid == null) || (this.myLastBid == null)) {
      return this.utilitySpace.getMaxUtilityBid();
    }
    if (this.otherUtilitySpace == null) {
      try
      {
        this.otherUtilitySpace = new OpponentUtilitySpace(this.utilitySpace, this.lastOpponentBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    if (this.goodBids.isEmpty()) {
      findGoodBids();
    }
    double targetUtil = this.otherUtilitySpace.getUtility(this.lastOpponentBid);
    

    targetUtil = Math.max(targetUtil, 0.6D);
    targetUtil = Math.max(targetUtil, this.utilitySpace
      .getUtility(this.myLastBid) - 0.1D);
    
    Bid bid = getUnusedBidNearUtil(targetUtil);
    double util = this.utilitySpace.getUtility(bid);
    

    double minimumutility = util - 0.2D * (1.0D - this.timeline.getTime());
    if (this.utilitySpace.getUtility(this.lastOpponentBid) >= minimumutility) {
      return null;
    }
    return bid;
  }
  
  private Bid getUnusedBidNearUtil(double targetUtil)
  {
    Bid good = (Bid)this.goodBids.get(Double.valueOf(roundUtil(targetUtil)));
    if ((good != null) && (!this.usedBids.contains(good))) {
      return good;
    }
    double nearestUtil = 10.0D;
    Bid nearestBid = null;
    for (Iterator localIterator = this.goodBids.keySet().iterator(); localIterator.hasNext();)
    {
      double util = ((Double)localIterator.next()).doubleValue();
      double distance = Math.abs(targetUtil - util);
      if (distance < nearestUtil)
      {
        Bid bid = (Bid)this.goodBids.get(Double.valueOf(util));
        if (!this.usedBids.contains(bid))
        {
          nearestUtil = distance;
          nearestBid = bid;
        }
      }
    }
    return nearestBid;
  }
  
  private double roundUtil(double util)
  {
    return Math.round(1000.0D * util) / 1000.0D;
  }
  
  private void findGoodBids()
    throws Exception
  {
    if (this.utilitySpace.getDomain().getNumberOfPossibleBids() > 20000L) {
      findApproximateGoodBids();
    } else {
      findAllGoodBids();
    }
    if (this.goodBids.isEmpty()) {
      throw new IllegalStateException("failed to generate bids in this space");
    }
  }
  
  private void findAllGoodBids()
    throws Exception
  {
    BidIterator iterator = new BidIterator(this.utilitySpace.getDomain());
    while (iterator.hasNext()) {
      checkBid(iterator.next());
    }
  }
  
  private void findApproximateGoodBids()
    throws Exception
  {
    Domain domain = this.utilitySpace.getDomain();
    for (int n = 0; n < 20000; n++) {
      checkBid(domain.getRandomBid());
    }
  }
  
  private void checkBid(Bid bid)
    throws Exception
  {
    double util = roundUtil(this.utilitySpace.getUtility(bid));
    Bid good = (Bid)this.goodBids.get(Double.valueOf(util));
    if (good == null)
    {
      this.goodBids.put(Double.valueOf(util), bid);
      return;
    }
    if (this.otherUtilitySpace.getUtility(bid) > this.otherUtilitySpace.getUtility(good)) {
      this.goodBids.put(Double.valueOf(util), bid);
    }
  }
  
  public void initPN(UtilitySpace mySide, UtilitySpace otherSide, Timeline tl)
  {
    updateProfiles(mySide, otherSide);
    this.timeline = tl;
  }
  
  public void handleAction(Action act)
  {
    ReceiveMessage(act);
  }
  
  public Action getAction()
  {
    return chooseAction();
  }
  
  public void updateProfiles(UtilitySpace myUtilities, UtilitySpace opponentUtilities)
  {
    this.utilitySpace = myUtilities;
    this.otherUtilitySpace = opponentUtilities;
    this.goodBids.clear();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.SimpleTitForTatPN
 * JD-Core Version:    0.7.1
 */