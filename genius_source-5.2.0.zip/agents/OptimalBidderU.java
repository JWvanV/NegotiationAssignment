package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.DiscreteTimeline;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public abstract class OptimalBidderU
  extends Agent
{
  private static double rv = -1.0D;
  protected static int partitions;
  private static int ownTotalSessions;
  protected static HashMap<Integer, Value> values;
  private static ArrayList<Double> bids;
  private static ArrayList<Double> utilities;
  protected static Issue pie;
  private Action actionOfPartner = null;
  
  public abstract double bid(int paramInt);
  
  public abstract double utility(int paramInt);
  
  public abstract double getReservationValue(double paramDouble)
    throws Exception;
  
  public void init()
  {
    try
    {
      ownTotalSessions = (getTotalRounds() - 1) / 2;
      pie = (Issue)this.utilitySpace.getDomain().getIssues().get(0);
      
      print("=====================================================================");
      print("   OwntotalSessions = " + ownTotalSessions);
      print("   issue name = " + pie);
      print("   issue type = " + pie.getType());
      
      rv = getReservationValue(rv);
      
      bids = new ArrayList(ownTotalSessions);
      utilities = new ArrayList(ownTotalSessions);
      for (int i = 0; i < ownTotalSessions; i++)
      {
        bids.add(Double.valueOf(bid(i + 1)));
        utilities.add(Double.valueOf(utility(i + 1)));
      }
      print(" OwntotalSessions = " + ownTotalSessions);
      for (int i = 0; i < ownTotalSessions; i++) {
        print(" \t B[" + i + "] = " + bids.get(i) + " \t U[" + i + "] = " + utilities.get(i));
      }
      print("\n=====================================================================");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getVersion()
  {
    return "2.0 (Genius 4.2)";
  }
  
  public String getName()
  {
    return "OptimalBidderU";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseOptimalBidAction();
      }
      if ((this.actionOfPartner instanceof Offer)) {
        action = chooseOptimalBidAction();
      }
    }
    catch (Exception e)
    {
      print("Exception in ChooseAction:" + e.getMessage());
    }
    return action;
  }
  
  private Action chooseOptimalBidAction()
  {
    Bid nextBid = null;
    try
    {
      nextBid = getOptimalBid();
    }
    catch (Exception e)
    {
      print("Problem with received bid:" + e.getMessage() + ". cancelling bidding");
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  public int getRound()
  {
    return ((DiscreteTimeline)this.timeline).getRound();
  }
  
  public int getRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getRoundsLeft();
  }
  
  public int getOwnRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getOwnRoundsLeft();
  }
  
  public int getTotalRounds()
  {
    return ((DiscreteTimeline)this.timeline).getTotalRounds();
  }
  
  public double getTotalTime()
  {
    return ((DiscreteTimeline)this.timeline).getTotalTime();
  }
  
  void print(String s)
  {
    System.out.println("############  " + s);
  }
  
  private Bid getOptimalBid()
    throws Exception
  {
    print("############   B's  ####################################");
    print(" Round         = " + getRound());
    print(" RoundsLeft    = " + getRoundsLeft());
    print(" OwnRoundsLeft = " + getOwnRoundsLeft());
    print(" TotalRounds   = " + getTotalRounds());
    print(" TotalTime     = " + getTotalTime());
    
    double min = 1.0D;
    Value optValue = null;
    
    Double targetUtility = (Double)utilities.get(getOwnRoundsLeft());
    

    double targetBid = targetUtility.doubleValue() + rv;
    
    print(" targetBidToBid  = " + targetBid);
    for (Integer key : new TreeMap(values).keySet())
    {
      double piePartition = key.intValue() / partitions;
      if (Math.abs(targetBid - piePartition) < min)
      {
        min = Math.abs(targetBid - piePartition);
        optValue = (Value)values.get(key);
      }
    }
    HashMap<Integer, Value> optVals = new HashMap();
    optVals.put(Integer.valueOf(pie.getNumber()), optValue);
    return new Bid(this.utilitySpace.getDomain(), optVals);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.OptimalBidderU
 * JD-Core Version:    0.7.1
 */