package agents;

import negotiator.Bid;
import negotiator.utility.UtilitySpace;

class OpponentUtilitySpace
  extends UtilitySpace
{
  private final UtilitySpace ownSpace;
  private final double firstOpponentBidUtility;
  
  public OpponentUtilitySpace(UtilitySpace us, Bid firstBid)
    throws Exception
  {
    if (firstBid == null) {
      throw new NullPointerException("bid=null");
    }
    this.ownSpace = us;
    this.firstOpponentBidUtility = this.ownSpace.getUtility(firstBid);
  }
  
  private double distanceToFirstBid(Bid b)
    throws Exception
  {
    return Math.abs(this.ownSpace.getUtility(b) - this.firstOpponentBidUtility);
  }
  
  public double getUtility(Bid bid)
    throws Exception
  {
    return 1.0D - distanceToFirstBid(bid);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.OpponentUtilitySpace
 * JD-Core Version:    0.7.1
 */