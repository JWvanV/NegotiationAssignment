package agents;

import agents.anac.y2010.AgentFSEGA.AgentFSEGA;
import agents.anac.y2010.AgentK.Agent_K;
import agents.anac.y2010.AgentSmith.AgentSmith;
import agents.anac.y2010.Nozomi.Nozomi;
import agents.anac.y2010.Southampton.IAMcrazyHaggler;
import agents.anac.y2010.Southampton.IAMhaggler;
import agents.anac.y2010.Yushu.Yushu;
import agents.anac.y2011.BramAgent.BRAMAgent;
import agents.anac.y2011.Gahboninho.Gahboninho;
import agents.anac.y2011.TheNegotiator.TheNegotiator;
import agents.anac.y2011.ValueModelAgent.ValueModelAgent;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import negotiator.Agent;

public class AgentsFactory
{
  private static Map<String, Class<? extends Agent>> agents = new HashMap();
  
  static
  {
    add(SimpleTitForTatPN.class);
    add(SimpleAgentPN.class);
    add(TimeDependentAgentConcederPN.class);
    add(BayesianAgentPN.class);
    
    add(AgentFSEGA.class);
    add(Agent_K.class);
    add(IAMhaggler.class);
    add(IAMcrazyHaggler.class);
    add(AgentSmith.class);
    add(Nozomi.class);
    add(Yushu.class);
    add(TheNegotiator.class);
    add(ValueModelAgent.class);
    add(Gahboninho.class);
    add(BRAMAgent.class);
  }
  
  private static void add(Class<? extends Agent> agentClass)
  {
    Agent agent;
    try
    {
      agent = getInstanceOf(agentClass);
    }
    catch (Exception e)
    {
      System.out.println("failed to load agent " + agentClass);
      e.printStackTrace();
      return;
    }
    String name = agent.getName();
    if ((name == null) || (name.isEmpty())) {
      throw new IllegalArgumentException("agent " + agentClass + " has empty or null name");
    }
    Class<? extends Agent> existing = (Class)agents.get(name);
    if (existing != null) {
      throw new IllegalArgumentException("agent " + agent.getClass() + " has same name as agent " + existing.getClass());
    }
    agents.put(agent.getName(), agentClass);
  }
  
  private static Agent getInstanceOf(Class<? extends Agent> agentClass)
    throws InstantiationException, IllegalAccessException
  {
    return (Agent)agentClass.newInstance();
  }
  
  public static Set<String> getAgents()
  {
    return agents.keySet();
  }
  
  public static Set<String> getAgents(Class<?> classType)
  {
    Set<String> names = new HashSet();
    for (String name : agents.keySet())
    {
      Class<? extends Agent> agtclass = (Class)agents.get(name);
      if (classType.isAssignableFrom(agtclass)) {
        names.add(name);
      }
    }
    return names;
  }
  
  public static Agent getAgentInstance(String name)
    throws InstantiationException, IllegalAccessException
  {
    return getInstanceOf((Class)agents.get(name));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.AgentsFactory
 * JD-Core Version:    0.7.1
 */