package agents;

import agents.bayesianopponentmodel.OpponentModel;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.AgentParam;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.UtilitySpace;

public class BayesianAgentForAuctionMultiPhase
  extends BayesianAgentForAuction
{
  protected Bid myProviderLastBid;
  protected double centerMaxOffer = 0.0D;
  
  protected Action proposeInitialBid()
    throws Exception
  {
    Bid lBid = null;
    switch (this.fRole)
    {
    case CENTER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        this.CONCESSIONFACTOR = 0.07000000000000001D;
        lBid = getMaxUtilityBid();
        break;
      case SECOND_PHASE: 
        this.CONCESSIONFACTOR = 0.0D;
        if (this.fOpponentPreviousBid == null) {
          lBid = getMaxUtilityBid();
        } else {
          return new Accept(getAgentID());
        }
        break;
      }
      break;
    case PROVIDER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getMaxUtilityBid();
        break;
      case SECOND_PHASE: 
        double lSecondBest = ((AgentParamValue)getParameterValues().get(new AgentParameterVariable(new AgentParam(BayesianAgentForAuction.class.getName(), "starting_utility", Double.valueOf(0.0D), Double.valueOf(1.0D))))).getValue().doubleValue();
        lBid = getTradeOff(lSecondBest);
        this.myProviderLastBid = lBid;
        if (lBid == null) {
          return new EndNegotiation(getAgentID());
        }
        break;
      }
      break;
    }
    this.fSmartSteps = 0;
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    try
    {
      BayesianAgentForAuction.ACTIONTYPE lActionType = getActionType(this.messageOpponent);
      switch (lActionType)
      {
      case OFFER: 
        lOppntBid = ((Offer)this.messageOpponent).getBid();
        


        System.out.print("Updating beliefs ...");
        if (this.myPreviousBids.size() < 8) {
          this.fOpponentModel.updateBeliefs(lOppntBid);
        }
        System.out.println("Done!");
        if ((this.fRole == BayesianAgentForAuction.ROLE.CENTER) && 
          (this.utilitySpace.getUtility(lOppntBid) > this.centerMaxOffer))
        {
          this.centerMaxOffer = this.utilitySpace.getUtility(lOppntBid);
          if (this.fPhase == BayesianAgentForAuction.PHASE.SECOND_PHASE) {
            return new Accept(getAgentID());
          }
        }
        if (this.myLastAction == null)
        {
          lAction = proposeInitialBid();
        }
        else
        {
          if (this.utilitySpace.getUtility(lOppntBid) * 1.05D >= this.utilitySpace.getUtility(this.myLastBid))
          {
            lAction = new Accept(getAgentID());
          }
          else
          {
            Bid lnextBid = proposeNextBid(lOppntBid);
            if (lnextBid == null)
            {
              lAction = new EndNegotiation(getAgentID());
            }
            else
            {
              lAction = new Offer(getAgentID(), lnextBid);
              
              this.myProviderLastBid = lnextBid;
              if (this.utilitySpace.getUtility(lOppntBid) * 1.05D >= this.utilitySpace.getUtility(lnextBid)) {
                lAction = new Accept(getAgentID());
              }
            }
          }
          this.fOpponentPreviousBid = lOppntBid;
        }
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else {
          lAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      lAction = new Offer(getAgentID(), this.myLastBid);
    }
    this.myLastAction = lAction;
    if ((this.myLastAction instanceof Offer))
    {
      this.myPreviousBids.add(((Offer)this.myLastAction).getBid());
      this.myLastBid = ((Offer)this.myLastAction).getBid();
    }
    return lAction;
  }
  
  protected Bid getNextBidAuction(Bid pOppntBid)
    throws Exception
  {
    if (pOppntBid == null) {
      throw new NullPointerException("pOpptBid=null");
    }
    if (this.myLastBid == null) {
      throw new Exception("myLastBid==null");
    }
    Bid lBid = null;
    switch (this.fRole)
    {
    case CENTER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
        break;
      case SECOND_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
      }
      break;
    case PROVIDER: 
      switch (this.fPhase)
      {
      case FIRST_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
        break;
      case SECOND_PHASE: 
        lBid = getNextBidSmart(pOppntBid);
      }
      break;
    }
    return lBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BayesianAgentForAuctionMultiPhase
 * JD-Core Version:    0.7.1
 */