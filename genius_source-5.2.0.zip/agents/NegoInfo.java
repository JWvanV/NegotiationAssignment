package agents;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.table.AbstractTableModel;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.exceptions.Warning;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

class NegoInfo
  extends AbstractTableModel
  implements ActionListener
{
  public Bid ourOldBid;
  public Bid opponentOldBid;
  public UtilitySpace utilitySpace;
  public ArrayList<Issue> issues = new ArrayList();
  public ArrayList<Integer> IDs;
  public ArrayList<JComboBox> comboBoxes;
  
  NegoInfo(Bid our, Bid opponent, UtilitySpace us)
    throws Exception
  {
    this.ourOldBid = our;this.opponentOldBid = opponent;
    this.utilitySpace = us;
    this.issues = this.utilitySpace.getDomain().getIssues();
    this.IDs = new ArrayList();
    for (int i = 0; i < this.issues.size(); i++) {
      this.IDs.add(Integer.valueOf(((Issue)this.issues.get(i)).getNumber()));
    }
    makeComboBoxes();
  }
  
  public int getColumnCount()
  {
    return 3;
  }
  
  public int getRowCount()
  {
    return this.issues.size() + 2;
  }
  
  public boolean isCellEditable(int row, int col)
  {
    return (col == 2) && (row < this.issues.size());
  }
  
  private String[] colNames = { "Issue", "Last Bid of Opponent", "Your bid" };
  
  public String getColumnName(int col)
  {
    return this.colNames[col];
  }
  
  public void setOurBid(Bid bid)
    throws Exception
  {
    this.ourOldBid = bid;
    if (bid == null) {
      try
      {
        this.ourOldBid = this.utilitySpace.getMaxUtilityBid();
      }
      catch (Exception e)
      {
        System.out.println("error getting max utility first bid:" + e.getMessage());
        e.printStackTrace();
      }
    }
    makeComboBoxes();
    setComboBoxes(this.ourOldBid);
  }
  
  void makeComboBoxes()
    throws Exception
  {
    this.comboBoxes = new ArrayList();
    for (Issue issue : this.issues)
    {
      if (!(issue instanceof IssueDiscrete)) {
        System.out.println("Problem: issue " + issue + " is not IssueDiscrete. ");
      }
      List<ValueDiscrete> values = ((IssueDiscrete)issue).getValues();
      JComboBox cbox = new JComboBox();
      EvaluatorDiscrete eval = null;
      if (this.utilitySpace != null) {
        eval = (EvaluatorDiscrete)this.utilitySpace.getEvaluator(issue.getNumber());
      }
      for (ValueDiscrete val : values)
      {
        String utilinfo = "";
        if (eval != null) {
          try
          {
            utilinfo = "(" + eval.getValue(val) + ")";
          }
          catch (Exception e)
          {
            System.out.println("no evaluator for " + val + "???");
          }
        }
        cbox.addItem(val + utilinfo);
      }
      this.comboBoxes.add(cbox);
      JComboBox b;
      for (Iterator i$ = this.comboBoxes.iterator(); i$.hasNext(); b.addActionListener(this)) {
        b = (JComboBox)i$.next();
      }
    }
  }
  
  void setComboBoxes(Bid bid)
    throws Exception
  {
    for (int i = 0; i < this.issues.size(); i++)
    {
      IssueDiscrete iss = (IssueDiscrete)this.issues.get(i);
      ValueDiscrete val = (ValueDiscrete)bid.getValue(iss.getNumber());
      ((JComboBox)this.comboBoxes.get(i)).setSelectedIndex(iss.getValueIndex(val));
    }
  }
  
  Value getCurrentEval(Bid bid, int rownr)
    throws Exception
  {
    if (bid == null) {
      return null;
    }
    Integer ID = (Integer)this.IDs.get(rownr);
    return bid.getValue(ID.intValue());
  }
  
  public Component getValueAt(int row, int col)
  {
    if (row == this.issues.size())
    {
      if (col == 0) {
        return new JLabel("Utility:");
      }
      if (this.utilitySpace == null) {
        return new JLabel("No UtilSpace");
      }
      Bid bid;
      Bid bid;
      if (col == 1) {
        bid = this.opponentOldBid;
      } else {
        try
        {
          bid = getBid();
        }
        catch (Exception e)
        {
          bid = null;System.out.println("Internal err with getBid:" + e.getMessage());
        }
      }
      JProgressBar bar = new JProgressBar(0, 100);bar.setStringPainted(true);
      try
      {
        bar.setValue((int)(0.5D + 100.0D * this.utilitySpace.getUtility(bid)));
        bar.setIndeterminate(false);
      }
      catch (Exception e)
      {
        new Warning("Exception during cost calculation:" + e.getMessage(), false, 1);
        bar.setIndeterminate(true);
      }
      return bar;
    }
    if (row == this.issues.size() + 1) {
      return null;
    }
    switch (col)
    {
    case 0: 
      return new JTextArea(((Issue)this.issues.get(row)).getName());
    case 1: 
      Value value = null;
      try
      {
        value = getCurrentEval(this.opponentOldBid, row);
      }
      catch (Exception e)
      {
        System.out.println("Err EnterBidDialog2.getValueAt: " + e.getMessage());
      }
      if (value == null) {
        return new JTextArea("-");
      }
      return new JTextArea(value.toString());
    case 2: 
      return (Component)this.comboBoxes.get(row);
    }
    return null;
  }
  
  Bid getBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    for (int i = 0; i < this.issues.size(); i++) {
      values.put(this.IDs.get(i), ((IssueDiscrete)this.issues.get(i)).getValue(((JComboBox)this.comboBoxes.get(i)).getSelectedIndex()));
    }
    return new Bid(this.utilitySpace.getDomain(), values);
  }
  
  public void actionPerformed(ActionEvent e)
  {
    fireTableCellUpdated(this.issues.size(), 2);
    fireTableCellUpdated(this.issues.size() + 1, 2);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.NegoInfo
 * JD-Core Version:    0.7.1
 */