package agents;

import java.io.PrintStream;
import java.io.Serializable;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.NegotiationResult;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class SimpleANAC2013Agent
  extends Agent
{
  private double MINIMUM_BID_UTILITY;
  private Bid opponentLastBid;
  private Bid maxBid;
  
  public void init()
  {
    Serializable prev = loadSessionData();
    if (prev != null)
    {
      double previousOutcome = ((Double)prev).doubleValue();
      this.MINIMUM_BID_UTILITY = Math.max(Math.max(this.utilitySpace
        .getReservationValueUndiscounted(), previousOutcome), 0.5D);
    }
    else
    {
      this.MINIMUM_BID_UTILITY = this.utilitySpace.getReservationValueUndiscounted();
    }
    System.out.println("Minimum bid utility: " + this.MINIMUM_BID_UTILITY);
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public String getName()
  {
    return "Simple ANAC2013 Agent";
  }
  
  public void endSession(NegotiationResult result)
  {
    if (result.getMyDiscountedUtility() > this.MINIMUM_BID_UTILITY) {
      saveSessionData(new Double(result.getMyDiscountedUtility()));
    }
    System.out.println(result);
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.opponentLastBid = Action.getBidFromAction(opponentAction);
  }
  
  public Action chooseAction()
  {
    if ((this.opponentLastBid != null) && 
      (getUtility(this.opponentLastBid) >= this.MINIMUM_BID_UTILITY)) {
      return new Accept();
    }
    return getRandomBid(this.MINIMUM_BID_UTILITY);
  }
  
  private Action getRandomBid(double target)
  {
    Bid bid = null;
    try
    {
      int loops = 0;
      do
      {
        bid = this.utilitySpace.getDomain().getRandomBid();
        loops++;
      } while ((loops < 100000) && (this.utilitySpace.getUtility(bid) < target));
      if (bid == null)
      {
        if (this.maxBid == null) {
          this.maxBid = this.utilitySpace.getMaxUtilityBid();
        }
        bid = this.maxBid;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(bid);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.SimpleANAC2013Agent
 * JD-Core Version:    0.7.1
 */