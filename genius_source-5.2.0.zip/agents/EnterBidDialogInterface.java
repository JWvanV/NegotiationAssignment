package agents;

import com.sun.media.jfxmediaimpl.MediaDisposer.Disposable;
import negotiator.Bid;
import negotiator.actions.Action;

public abstract interface EnterBidDialogInterface
  extends MediaDisposer.Disposable
{
  public abstract Action askUserForAction(Action paramAction, Bid paramBid);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.EnterBidDialogInterface
 * JD-Core Version:    0.7.1
 */