package agents;

import java.util.HashMap;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class OptimalBidderSimpleU
  extends OptimalBidderU
{
  private static double rvB;
  
  public void init()
  {
    partitions = 1000;
    super.init();
  }
  
  public String getName()
  {
    return "OptimalBidderSimpleU";
  }
  
  public double bid(int j)
  {
    if (j == 1) {
      return 0.5D + 0.5D * rvB;
    }
    return 0.5D + 0.5D * Math.pow(bid(j - 1), 2.0D);
  }
  
  public double getReservationValue(double arg)
    throws Exception
  {
    boolean flag = true;
    double rv = 0.0D;
    if (arg == -1.0D)
    {
      if (pie.getType().equals(ISSUETYPE.DISCRETE))
      {
        IssueDiscrete discrete_pie = (IssueDiscrete)pie;
        int nvalues = discrete_pie.getNumberOfValues();
        print("   nvalues = " + nvalues);
        values = new HashMap(nvalues);
        for (int i = 0; i < nvalues; i++)
        {
          ValueDiscrete value = discrete_pie.getValue(i);
          Evaluator evaluator = this.utilitySpace.getEvaluator(pie.getNumber());
          Integer evaluation = ((EvaluatorDiscrete)evaluator).getValue(value);
          values.put(Integer.valueOf(i), value);
          if ((evaluation.intValue() != 0) && (flag))
          {
            rv = i / partitions;
            this.utilitySpace.setReservationValue(rv);
            flag = false;
            print("   rvB = " + rv);
          }
        }
        return rv;
      }
      throw new Exception("Type " + pie.getType() + " not supported by " + getName());
    }
    return arg;
  }
  
  public double utility(int j)
  {
    return (Math.pow(bid(j), 2.0D) - rvB) / (1.0D - rvB);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.OptimalBidderSimpleU
 * JD-Core Version:    0.7.1
 */