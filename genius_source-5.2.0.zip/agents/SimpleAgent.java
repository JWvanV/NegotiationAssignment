package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.Timeline.Type;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class SimpleAgent
  extends Agent
{
  private Action actionOfPartner = null;
  private static double MINIMUM_BID_UTILITY = 0.0D;
  
  public void init()
  {
    MINIMUM_BID_UTILITY = this.utilitySpace.getReservationValueUndiscounted();
  }
  
  public String getVersion()
  {
    return "3.1";
  }
  
  public String getName()
  {
    return "Simple Agent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseRandomBidAction();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        double offeredUtilFromOpponent = getUtility(partnerBid);
        
        double time = this.timeline.getTime();
        action = chooseRandomBidAction();
        
        Bid myBid = ((Offer)action).getBid();
        double myOfferedUtil = getUtility(myBid);
        if (isAcceptable(offeredUtilFromOpponent, myOfferedUtil, time)) {
          action = new Accept(getAgentID());
        }
      }
      if (this.timeline.getType().equals(Timeline.Type.Time)) {
        sleep(0.005D);
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private boolean isAcceptable(double offeredUtilFromOpponent, double myOfferedUtil, double time)
    throws Exception
  {
    double P = Paccept(offeredUtilFromOpponent, time);
    if (P > Math.random()) {
      return true;
    }
    return false;
  }
  
  private Action chooseRandomBidAction()
  {
    Bid nextBid = null;
    try
    {
      nextBid = getRandomBid();
    }
    catch (Exception e)
    {
      System.out.println("Problem with received bid:" + e.getMessage() + ". cancelling bidding");
    }
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid getRandomBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random randomnr = new Random();
    




    Bid bid = null;
    do
    {
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          int optionIndex = randomnr.nextInt(lIssueDiscrete
            .getNumberOfValues());
          values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete
            .getValue(optionIndex));
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int optionInd = randomnr.nextInt(lIssueReal
            .getNumberOfDiscretizationSteps() - 1);
          values.put(
            Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal
            .getLowerBound() + 
            
            (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal
            

            .getNumberOfDiscretizationSteps()));
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          
          int optionIndex2 = lIssueInteger.getLowerBound() + randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
            .getLowerBound());
          values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
          
          break;
        default: 
          throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
        }
      }
      bid = new Bid(this.utilitySpace.getDomain(), values);
    } while (getUtility(bid) < MINIMUM_BID_UTILITY);
    return bid;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.SimpleAgent
 * JD-Core Version:    0.7.1
 */