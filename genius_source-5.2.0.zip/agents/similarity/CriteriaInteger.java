package agents.similarity;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.issue.ValueInteger;
import negotiator.utility.EVALFUNCTYPE;
import negotiator.utility.EVALUATORTYPE;
import negotiator.xml.SimpleElement;

public class CriteriaInteger
  implements Criteria
{
  int lowerBound;
  int upperBound;
  int fIssueIndex;
  EVALFUNCTYPE type;
  HashMap<Integer, Integer> fParam;
  
  public CriteriaInteger()
  {
    this.fParam = new HashMap();
  }
  
  public double getValue(Bid bid)
  {
    Integer lTmp = null;
    try
    {
      lTmp = Integer.valueOf(((ValueInteger)bid.getValue(this.fIssueIndex)).getValue());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    switch (this.type)
    {
    case LINEAR: 
      Double d = Double.valueOf(EVALFUNCTYPE.evalLinear(lTmp.intValue(), ((Integer)this.fParam.get(Integer.valueOf(1))).intValue(), ((Integer)this.fParam.get(Integer.valueOf(0))).intValue()));
      if (d.doubleValue() < 0.0D) {
        d = Double.valueOf(0.0D);
      } else if (d.doubleValue() > 1.0D) {
        d = Double.valueOf(1.0D);
      }
      return d.intValue();
    case CONSTANT: 
      return ((Integer)this.fParam.get(Integer.valueOf(0))).intValue();
    }
    return -1.0D;
  }
  
  public EVALUATORTYPE getType()
  {
    return EVALUATORTYPE.INTEGER;
  }
  
  public int getLowerBound()
  {
    return this.lowerBound;
  }
  
  public int getUpperBound()
  {
    return this.lowerBound;
  }
  
  public void loadFromXML(SimpleElement pRoot)
  {
    Object[] xml_item = pRoot.getChildByTagName("range");
    this.lowerBound = Integer.valueOf(((SimpleElement)xml_item[0]).getAttribute("lowerBound")).intValue();
    this.upperBound = Integer.valueOf(((SimpleElement)xml_item[0]).getAttribute("upperBound")).intValue();
    Object[] xml_items = pRoot.getChildByTagName("evaluator");
    String ftype = ((SimpleElement)xml_items[0]).getAttribute("ftype");
    if (ftype != null) {
      this.type = EVALFUNCTYPE.convertToType(ftype);
    }
    switch (this.type)
    {
    case LINEAR: 
      this.fParam.put(Integer.valueOf(1), Integer.valueOf(((SimpleElement)xml_items[0]).getAttribute("parameter1")));
    case CONSTANT: 
      this.fParam.put(Integer.valueOf(0), Integer.valueOf(((SimpleElement)xml_items[0]).getAttribute("parameter0")));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.CriteriaInteger
 * JD-Core Version:    0.7.1
 */