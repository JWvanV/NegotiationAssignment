package agents.similarity;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.IssueReal;
import negotiator.issue.ValueReal;
import negotiator.utility.EVALFUNCTYPE;
import negotiator.utility.EVALUATORTYPE;
import negotiator.xml.SimpleElement;

public class CriteriaReal
  implements Criteria
{
  EVALFUNCTYPE type;
  private int fIssueIndex;
  private Domain fDomain;
  HashMap<Integer, Double> fParam;
  
  public CriteriaReal(Domain pDomain, int pIssueIndex)
  {
    this.fIssueIndex = pIssueIndex;
    this.fDomain = pDomain;
    this.fParam = new HashMap();
  }
  
  public double getValue(Bid pBid)
  {
    double utility = 0.0D;
    try
    {
      double value = ((ValueReal)pBid.getValue(this.fIssueIndex)).getValue();
      switch (this.type)
      {
      case FARATIN: 
        IssueReal lIssue = (IssueReal)this.fDomain.getObjective(this.fIssueIndex);
        return EVALFUNCTYPE.evalFaratin(value, lIssue.getUpperBound(), lIssue.getLowerBound(), ((Double)this.fParam.get(Integer.valueOf(0))).doubleValue(), ((Double)this.fParam.get(Integer.valueOf(1))).doubleValue());
      case LINEAR: 
        utility = EVALFUNCTYPE.evalLinear(value, ((Double)this.fParam.get(Integer.valueOf(1))).doubleValue(), ((Double)this.fParam.get(Integer.valueOf(0))).doubleValue());
        if (utility < 0.0D) {
          utility = 0.0D;
        } else if (utility <= 1.0D) {}
        return 1.0D;
      case CONSTANT: 
        return ((Double)this.fParam.get(Integer.valueOf(0))).doubleValue();
      }
      return -1.0D;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return utility;
  }
  
  public EVALUATORTYPE getType()
  {
    return EVALUATORTYPE.REAL;
  }
  
  public void loadFromXML(SimpleElement pRoot)
  {
    String ftype = pRoot.getAttribute("type");
    if (ftype != null) {
      this.type = EVALFUNCTYPE.convertToType(ftype);
    }
    switch (this.type)
    {
    case FARATIN: 
      this.fParam.put(Integer.valueOf(1), Double.valueOf(pRoot.getAttribute("parameter1")));
      this.fParam.put(Integer.valueOf(0), Double.valueOf(pRoot.getAttribute("parameter0")));
      break;
    case LINEAR: 
      this.fParam.put(Integer.valueOf(1), Double.valueOf(pRoot.getAttribute("parameter1")));
    case CONSTANT: 
      this.fParam.put(Integer.valueOf(0), Double.valueOf(pRoot.getAttribute("parameter0")));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.CriteriaReal
 * JD-Core Version:    0.7.1
 */