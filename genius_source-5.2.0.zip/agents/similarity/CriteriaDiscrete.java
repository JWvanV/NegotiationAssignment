package agents.similarity;

import java.io.PrintStream;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.issue.ValueDiscrete;
import negotiator.xml.SimpleElement;

public class CriteriaDiscrete
  implements Criteria
{
  private int fIssueIndex;
  private HashMap<ValueDiscrete, Double> fCriteriaValues;
  
  public CriteriaDiscrete(int pIssueIndex)
  {
    this.fIssueIndex = pIssueIndex;
    this.fCriteriaValues = new HashMap();
  }
  
  public double getValue(Bid pBid)
  {
    ValueDiscrete lValue = null;
    try
    {
      lValue = (ValueDiscrete)pBid.getValue(this.fIssueIndex);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    Double lTmp = (Double)this.fCriteriaValues.get(lValue);
    if (lTmp != null) {
      return ((Double)this.fCriteriaValues.get(lValue)).doubleValue();
    }
    System.out.println("Can't find criteria value for " + lValue.toString() + "(issue index = " + String.valueOf(this.fIssueIndex) + ")");
    return -1.0D;
  }
  
  public void loadFromXML(SimpleElement pRoot)
  {
    Object[] xml_items = pRoot.getChildByTagName("item");
    int nrOfValues = xml_items.length;
    for (int j = 0; j < nrOfValues; j++)
    {
      ValueDiscrete value = new ValueDiscrete(((SimpleElement)xml_items[j]).getAttribute("value"));
      this.fCriteriaValues.put(value, Double.valueOf(((SimpleElement)xml_items[j]).getAttribute("evaluation")));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.CriteriaDiscrete
 * JD-Core Version:    0.7.1
 */