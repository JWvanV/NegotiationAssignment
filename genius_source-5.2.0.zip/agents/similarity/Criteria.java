package agents.similarity;

import negotiator.Bid;
import negotiator.xml.SimpleElement;

public abstract interface Criteria
{
  public abstract double getValue(Bid paramBid);
  
  public abstract void loadFromXML(SimpleElement paramSimpleElement);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.Criteria
 * JD-Core Version:    0.7.1
 */