package agents.similarity;

public enum SIMILARITYTYPE
{
  CUSTOM_DEFINED,  BINARY;
  
  private SIMILARITYTYPE() {}
  
  public static SIMILARITYTYPE convertToType(String typeString)
  {
    if (typeString == null) {
      return CUSTOM_DEFINED;
    }
    if (typeString.equalsIgnoreCase("binary")) {
      return BINARY;
    }
    return CUSTOM_DEFINED;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.SIMILARITYTYPE
 * JD-Core Version:    0.7.1
 */