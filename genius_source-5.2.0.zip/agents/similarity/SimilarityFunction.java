package agents.similarity;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.xml.SimpleElement;

public class SimilarityFunction
{
  private double[] fWeights;
  private ArrayList<Criteria> fCriteria;
  private Domain fDomain;
  private SIMILARITYTYPE fType;
  private int fIssueIndex;
  
  public SimilarityFunction(Domain pDomain)
  {
    this.fDomain = pDomain;
    this.fCriteria = new ArrayList();
  }
  
  public double getSimilarityValue(Bid pMyBid, Bid pOpponentBid)
  {
    double lResult = 0.0D;
    switch (this.fType)
    {
    case BINARY: 
      try
      {
        if (pMyBid.getValue(this.fIssueIndex).equals(pOpponentBid.getValue(this.fIssueIndex))) {
          lResult = 1.0D;
        } else {
          lResult = 0.0D;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    case CUSTOM_DEFINED: 
      for (int i = 0; i < this.fCriteria.size(); i++)
      {
        Criteria lCriteria = (Criteria)this.fCriteria.get(i);
        lResult += this.fWeights[i] * (1.0D - Math.abs(lCriteria.getValue(pMyBid) - lCriteria.getValue(pOpponentBid)));
      }
    }
    return lResult;
  }
  
  public void loadFromXML(SimpleElement pRoot, int pIssueIndex)
  {
    this.fIssueIndex = pIssueIndex;
    switch (SIMILARITYTYPE.convertToType(pRoot.getAttribute("type")))
    {
    case BINARY: 
      this.fType = SIMILARITYTYPE.BINARY;
      break;
    case CUSTOM_DEFINED: 
      this.fType = SIMILARITYTYPE.CUSTOM_DEFINED;
      Object[] lXMLCriteriaFn = pRoot.getChildByTagName("criteria_function");
      this.fWeights = new double[lXMLCriteriaFn.length];
      for (int i = 0; i < lXMLCriteriaFn.length; i++)
      {
        this.fWeights[i] = Double.valueOf(((SimpleElement)(SimpleElement)lXMLCriteriaFn[i]).getAttribute("weight")).doubleValue();
        Criteria lCriteria = null;
        switch (this.fDomain.getObjective(pIssueIndex).getType())
        {
        case REAL: 
          lCriteria = new CriteriaReal(this.fDomain, pIssueIndex);
          lCriteria.loadFromXML((SimpleElement)lXMLCriteriaFn[i]);
          this.fCriteria.add(lCriteria);
          break;
        case DISCRETE: 
          lCriteria = new CriteriaDiscrete(pIssueIndex);
          lCriteria.loadFromXML((SimpleElement)lXMLCriteriaFn[i]);
          this.fCriteria.add(lCriteria);
        }
      }
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.SimilarityFunction
 * JD-Core Version:    0.7.1
 */