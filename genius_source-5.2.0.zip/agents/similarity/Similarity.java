package agents.similarity;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.xml.SimpleElement;

public class Similarity
{
  private Domain fDomain;
  private double[] fWeights;
  private ArrayList<SimilarityFunction> fSimilarityFunctions;
  
  public Similarity(Domain pDomain)
  {
    this.fDomain = pDomain;
    this.fSimilarityFunctions = new ArrayList();
  }
  
  public final double getSimilarity(Bid pMyBid, Bid pOpponentBid)
  {
    double lSimilarity = 0.0D;
    for (int i = 0; i < this.fSimilarityFunctions.size(); i++) {
      lSimilarity += this.fWeights[i] * ((SimilarityFunction)this.fSimilarityFunctions.get(i)).getSimilarityValue(pMyBid, pOpponentBid);
    }
    return lSimilarity;
  }
  
  public void loadFromXML(SimpleElement pRoot)
  {
    SimpleElement lXMLUtilitySpace = (SimpleElement)pRoot.getChildByTagName("utility_space")[0];
    SimpleElement lXMLObjective = (SimpleElement)lXMLUtilitySpace.getChildByTagName("objective")[0];
    Object[] lXMLIssue = lXMLObjective.getChildByTagName("issue");
    this.fWeights = new double[lXMLIssue.length];
    for (int j = 0; j < lXMLIssue.length; j++)
    {
      Object[] lXMLSimFn = ((SimpleElement)lXMLIssue[j]).getChildByTagName("similarity_function");
      if (lXMLSimFn != null)
      {
        SimilarityFunction lSimFn = new SimilarityFunction(this.fDomain);
        
        this.fWeights[j] = Double.valueOf(((SimpleElement)(SimpleElement)lXMLSimFn[0]).getAttribute("weight")).doubleValue();
        lSimFn.loadFromXML((SimpleElement)lXMLSimFn[0], Integer.valueOf(((SimpleElement)lXMLIssue[j]).getAttribute("index")).intValue());
        this.fSimilarityFunctions.add(lSimFn);
      }
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.similarity.Similarity
 * JD-Core Version:    0.7.1
 */