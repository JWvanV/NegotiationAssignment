package agents;

import java.io.PrintStream;
import javax.swing.JOptionPane;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;

public class UIAgent
  extends Agent
{
  private Action opponentAction = null;
  private EnterBidDialog ui = null;
  private Bid myPreviousBid = null;
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void init()
  {
    System.out.println("init UIAgent");
    
    System.out.println("closing old dialog of ");
    if (this.ui != null)
    {
      this.ui.dispose();
      this.ui = null;
    }
    System.out.println("old  dialog closed. Trying to open new dialog. ");
    try
    {
      this.ui = new EnterBidDialog(this, null, true, this.utilitySpace);
    }
    catch (Exception e)
    {
      System.out.println("Problem in UIAgent2.init:" + e.getMessage());
      e.printStackTrace();
    }
    System.out.println("finished init of UIAgent2");
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.opponentAction = opponentAction;
    if ((opponentAction instanceof Accept)) {
      JOptionPane.showMessageDialog(null, "Opponent accepted your last offer.");
    }
    if ((opponentAction instanceof EndNegotiation)) {
      JOptionPane.showMessageDialog(null, "Opponent canceled the negotiation session");
    }
  }
  
  public Action chooseAction()
  {
    Action action = this.ui.askUserForAction(this.opponentAction, this.myPreviousBid);
    if ((action != null) && ((action instanceof Offer))) {
      this.myPreviousBid = ((Offer)action).getBid();
    }
    return action;
  }
  
  public boolean isUIAgent()
  {
    return true;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.UIAgent
 * JD-Core Version:    0.7.1
 */