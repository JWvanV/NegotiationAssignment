package agents;

import negotiator.Bid;
import negotiator.BidHistory;

public abstract interface BidHistoryKeeper
{
  public abstract BidHistory getOpponentHistory();
  
  public abstract Bid getMyLastBid();
  
  public abstract Bid getOpponentLastBid();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BidHistoryKeeper
 * JD-Core Version:    0.7.1
 */