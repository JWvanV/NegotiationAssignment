package agents;

import agents.similarity.Similarity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class SimilarityAgent
  extends Agent
{
  private Action messageOpponent;
  private Bid myLastBid = null;
  private Action myLastAction = null;
  private Similarity fSimilarity;
  
  private static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  private static enum STRATEGY
  {
    SMART,  SERIAL,  RESPONSIVE,  RANDOM;
    
    private STRATEGY() {}
  }
  
  private STRATEGY fStrategy = STRATEGY.SMART;
  private int fSmartSteps;
  private static final double CONCESSIONFACTOR = 0.035D;
  private static final double ALLOWED_UTILITY_DEVIATION = 0.01D;
  private static final int NUMBER_OF_SMART_STEPS = 0;
  private HashMap<Bid, Double> utilityCash;
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastBid = null;
    this.myLastAction = null;
    this.fSmartSteps = 0;
    
    this.fSimilarity = new Similarity(this.utilitySpace.getDomain());
    this.fSimilarity.loadFromXML(this.utilitySpace.getDomain().getXMLRoot());
    
    this.utilityCash = new HashMap();
    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    try
    {
      while (lIter.hasNext())
      {
        Bid tmpBid = lIter.next();
        this.utilityCash.put(tmpBid, new Double(this.utilitySpace.getUtility(tmpBid)));
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.messageOpponent = opponentAction;
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  private Action proposeInitialBid()
  {
    Bid lBid = null;
    try
    {
      lBid = this.utilitySpace.getMaxUtilityBid();
      Bid lBid2 = getBidRandomWalk(this.utilitySpace.getUtility(lBid) * 0.98D, this.utilitySpace.getUtility(lBid));
      if (lBid != null) {
        lBid = lBid2;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.fSmartSteps = 1;
    this.myLastBid = lBid;
    
    return new Offer(getAgentID(), lBid);
  }
  
  private Bid getNextBidSmart(Bid pOppntBid)
  {
    double lMyUtility = 0.0D;double lOppntUtility = 0.0D;
    try
    {
      lMyUtility = this.utilitySpace.getUtility(this.myLastBid);
      lOppntUtility = this.utilitySpace.getUtility(pOppntBid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double lTargetUtility;
    if (this.fSmartSteps >= 0)
    {
      double lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
      this.fSmartSteps = 0;
    }
    else
    {
      lTargetUtility = lMyUtility;
      this.fSmartSteps += 1;
    }
    Bid lMyLastBid = this.myLastBid;
    Bid lBid = getTradeOffExhaustive(lTargetUtility, pOppntBid);
    if (Math.abs(this.fSimilarity.getSimilarity(lMyLastBid, lBid)) > 0.993D)
    {
      lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
      this.fSmartSteps = 0;
      lBid = getTradeOffExhaustive(lTargetUtility, pOppntBid);
    }
    return lBid;
  }
  
  private Bid getTradeOffExhaustive(double pUtility, Bid pOppntBid)
  {
    Bid lBid = null;
    double lSim = -1.0D;
    for (Map.Entry<Bid, Double> entry : this.utilityCash.entrySet())
    {
      Bid tmpBid = (Bid)entry.getKey();
      double lUtil = ((Double)entry.getValue()).doubleValue();
      if (Math.abs(lUtil - pUtility) < 0.01D)
      {
        double lTmpSim = this.fSimilarity.getSimilarity(tmpBid, pOppntBid);
        if (lTmpSim > lSim)
        {
          lSim = lTmpSim;
          lBid = tmpBid;
        }
      }
    }
    return lBid;
  }
  
  private Action proposeNextBid(Bid pOppntBid)
  {
    Bid lBid = null;
    switch (this.fStrategy)
    {
    case SMART: 
      lBid = getNextBidSmart(pOppntBid);
    }
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    
    ACTIONTYPE lActionType = getActionType(this.messageOpponent);
    try
    {
      switch (lActionType)
      {
      case OFFER: 
        lOppntBid = ((Offer)this.messageOpponent).getBid();
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else if (this.utilitySpace.getUtility(lOppntBid) >= this.utilitySpace.getUtility(this.myLastBid)) {
          lAction = new Accept(getAgentID());
        } else {
          lAction = proposeNextBid(lOppntBid);
        }
        if (this.utilitySpace.getUtility(lOppntBid) >= this.utilitySpace.getUtility(this.myLastBid)) {
          lAction = new Accept(getAgentID());
        }
        break;
      case ACCEPT: 
        break;
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else {
          lAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.myLastAction = lAction;
    return lAction;
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private Bid getBidRandomWalk(double lowerBound, double upperBoud)
    throws Exception
  {
    ArrayList<Bid> lBidsRange = new ArrayList();
    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    while (lIter.hasNext())
    {
      Bid tmpBid = lIter.next();
      double lUtil = 0.0D;
      try
      {
        lUtil = this.utilitySpace.getUtility(tmpBid);
        if ((lUtil >= lowerBound) && (lUtil <= upperBoud)) {
          lBidsRange.add(tmpBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    if (lBidsRange.size() < 1) {
      return null;
    }
    if (lBidsRange.size() < 2) {
      return (Bid)lBidsRange.get(0);
    }
    int lIndex = new Random().nextInt(lBidsRange.size() - 1);
    return (Bid)lBidsRange.get(lIndex);
  }
  
  private double getTargetUtility(double myUtility, double oppntUtility)
  {
    return myUtility - getConcessionFactor();
  }
  
  private double getConcessionFactor()
  {
    return 0.035D;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.SimilarityAgent
 * JD-Core Version:    0.7.1
 */