package agents;

import java.awt.Component;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import negotiator.Bid;
import negotiator.exceptions.Warning;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

class NegoShowOffer
  extends NegoInfo
{
  private Bid topic;
  
  public NegoShowOffer(Bid our, Bid opponent, UtilitySpace us, Bid topic)
    throws Exception
  {
    super(our, opponent, us);
    this.topic = topic;
  }
  
  private String[] colNames = { "Issue", "Current offer" };
  
  public int getColumnCount()
  {
    return 2;
  }
  
  public String getColumnName(int col)
  {
    return this.colNames[col];
  }
  
  public Component getValueAt(int row, int col)
  {
    if (row == this.issues.size())
    {
      if (col == 0) {
        return new JLabel("Utility:");
      }
      if (this.utilitySpace == null) {
        return new JLabel("No UtilSpace");
      }
      Bid bid;
      Bid bid;
      if (col == 1) {
        bid = this.opponentOldBid;
      } else {
        try
        {
          bid = getBid();
        }
        catch (Exception e)
        {
          bid = null;System.out.println("Internal err with getBid:" + e.getMessage());
        }
      }
      JProgressBar bar = new JProgressBar(0, 100);bar.setStringPainted(true);
      try
      {
        bar.setValue((int)(0.5D + 100.0D * this.utilitySpace.getUtility(bid)));
        bar.setIndeterminate(false);
      }
      catch (Exception e)
      {
        new Warning("Exception during cost calculation:" + e.getMessage(), false, 1);
        bar.setIndeterminate(true);
      }
      return bar;
    }
    if (row == this.issues.size() + 1) {
      return null;
    }
    switch (col)
    {
    case 0: 
      return new JTextArea(((Issue)this.issues.get(row)).getName());
    case 1: 
      Value value = null;
      try
      {
        value = getCurrentEval(this.topic, row);
      }
      catch (Exception e)
      {
        System.out.println("Err EnterBidDialog2.getValueAt: " + e.getMessage());
      }
      if (value == null) {
        return new JTextArea("-");
      }
      return new JTextArea(value.toString());
    }
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.NegoShowOffer
 * JD-Core Version:    0.7.1
 */