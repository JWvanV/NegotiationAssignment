package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class ABMPAgent
  extends Agent
{
  private Action messageOpponent;
  private Bid myLastBid = null;
  private Action myLastAction = null;
  private static final double NEGOTIATIONSPEED = 0.1D;
  private static final double CONCESSIONFACTOR = 1.0D;
  private static final double CONFTOLERANCE = 0.0D;
  private static final double UTIlITYGAPSIZE = 0.02D;
  
  private static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastBid = null;
    this.myLastAction = null;
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.messageOpponent = opponentAction;
  }
  
  private Action proposeInitialBid()
  {
    Bid lBid = null;
    try
    {
      lBid = this.utilitySpace.getMaxUtilityBid();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  private Action proposeNextBid(Bid lOppntBid)
    throws Exception
  {
    Bid lBid = null;
    


    double lMyUtility = this.utilitySpace.getUtility(this.myLastBid);
    double lOppntUtility = this.utilitySpace.getUtility(lOppntBid);
    double lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
    lBid = getBidABMPsimple(lTargetUtility);
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    
    ACTIONTYPE lActionType = getActionType(this.messageOpponent);
    switch (lActionType)
    {
    case OFFER: 
      lOppntBid = ((Offer)this.messageOpponent).getBid();
      if (this.myLastAction == null) {
        lAction = proposeInitialBid();
      } else {
        try
        {
          if (this.utilitySpace.getUtility(lOppntBid) >= this.utilitySpace.getUtility(this.myLastBid) - 0.02D) {
            lAction = new Accept(getAgentID());
          } else {
            try
            {
              lAction = proposeNextBid(lOppntBid);
            }
            catch (Exception e)
            {
              e.printStackTrace();
            }
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
      break;
    case ACCEPT: 
    case BREAKOFF: 
      break;
    default: 
      if (this.myLastAction == null) {
        lAction = proposeInitialBid();
      } else {
        lAction = this.myLastAction;
      }
      break;
    }
    this.myLastAction = lAction;
    return lAction;
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private Bid getBidABMPsimple(double targetUtility)
    throws Exception
  {
    HashMap<Integer, Value> lIssueIndex = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    double[] lIssueAlpha = new double[issues.size()];
    double[] lBE = new double[issues.size()];
    double[] lBTE = new double[issues.size()];
    double[] lTE = new double[issues.size()];
    double lUtility = 0.0D;double lNF = 0.0D;double lTotalConcession = 0.0D;
    


    double lUtilityGap = targetUtility - this.utilitySpace.getUtility(this.myLastBid);
    for (int i = 0; i < issues.size(); i++) {
      lBE[i] = this.utilitySpace.getEvaluator(((Issue)issues.get(i))
        .getNumber()).getEvaluation(this.utilitySpace, this.myLastBid, 
        ((Issue)issues.get(i)).getNumber()).doubleValue();
    }
    int i = 0;
    for (Issue lIssue : issues)
    {
      double lAlpha = (1.0D - this.utilitySpace.getWeight(lIssue.getNumber())) * lBE[i];
      







      lNF += this.utilitySpace.getWeight(lIssue.getNumber()) * lAlpha;
      lIssueAlpha[i] = lAlpha;
      i++;
    }
    for (i = 0; i < issues.size(); i++) {
      lBE[i] += lIssueAlpha[i] / lNF * lUtilityGap;
    }
    for (i = 0; i < issues.size(); i++)
    {
      lUtility = this.utilitySpace.getEvaluator(((Issue)issues.get(i))
        .getNumber()).getEvaluation(this.utilitySpace, ((Offer)this.messageOpponent)
        .getBid(), ((Issue)issues.get(i))
        .getNumber()).doubleValue();
      lTE[i] = (1.0D * lBTE[i] + 0.0D * lUtility);
    }
    int lNrOfRealIssues = 0;
    for (i = 0; i < issues.size(); i++)
    {
      lUtility = 1.0D;
      Objective lIssue = (Objective)issues.get(i);
      if (lIssue.getType() == ISSUETYPE.DISCRETE)
      {
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        for (int j = 0; j < lIssueDiscrete.getNumberOfValues(); j++)
        {
          double lEvalValue = 
            ((EvaluatorDiscrete)this.utilitySpace.getEvaluator(lIssue.getNumber()))
            .getEvaluation(lIssueDiscrete.getValue(j)).doubleValue();
          if (Math.abs(lTE[i] - lEvalValue) < lUtility)
          {
            lIssueIndex.put(new Integer(lIssue.getNumber()), lIssueDiscrete
              .getValue(j));
            lUtility = Math.abs(lTE[i] - lEvalValue);
          }
        }
        lTotalConcession = lTotalConcession + this.utilitySpace.getWeight(lIssue.getNumber()) * (lBE[i] - 
          ((EvaluatorDiscrete)this.utilitySpace.getEvaluator(lIssue.getNumber()))
          .getEvaluation(
          (ValueDiscrete)lIssueIndex.get(Integer.valueOf(lIssue.getNumber()))).doubleValue());
      }
      else if (lIssue.getType() == ISSUETYPE.REAL)
      {
        lNrOfRealIssues++;
      }
    }
    double lRestUtitility = lUtilityGap + lTotalConcession;
    for (i = 0; i < issues.size(); i++)
    {
      Objective lIssue = (Objective)issues.get(i);
      if (lIssue.getType() == ISSUETYPE.REAL)
      {
        lTE[i] += lRestUtitility / lNrOfRealIssues;
        
        EvaluatorReal lRealEvaluator = (EvaluatorReal)this.utilitySpace.getEvaluator(lIssue.getNumber());
        double r = lRealEvaluator.getValueByEvaluation(lTE[i]);
        
        lIssueIndex.put(new Integer(lIssue.getNumber()), new ValueReal(r));
      }
    }
    return new Bid(this.utilitySpace.getDomain(), lIssueIndex);
  }
  
  private double getTargetUtility(double myUtility, double oppntUtility)
  {
    return myUtility + getConcessionStep(myUtility, oppntUtility);
  }
  
  private double getNegotiationSpeed()
  {
    return 0.1D;
  }
  
  private double getConcessionFactor()
  {
    return 1.0D;
  }
  
  private double getConcessionStep(double myUtility, double oppntUtility)
  {
    double lConcessionStep = 0.0D;double lMinUtility = 0.0D;double lUtilityGap = 0.0D;
    

    lMinUtility = 1.0D - getConcessionFactor();
    lUtilityGap = oppntUtility - myUtility;
    lConcessionStep = getNegotiationSpeed() * (1.0D - lMinUtility / myUtility) * lUtilityGap;
    
    System.out.println(lConcessionStep);
    return lConcessionStep;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.ABMPAgent
 * JD-Core Version:    0.7.1
 */