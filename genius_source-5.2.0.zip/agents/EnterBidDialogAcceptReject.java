package agents;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.OfferForVoting;
import negotiator.actions.Reject;
import negotiator.exceptions.Warning;
import negotiator.parties.NegotiationParty;
import negotiator.utility.UtilitySpace;

public class EnterBidDialogAcceptReject
  extends JDialog
  implements EnterBidDialogInterface
{
  private static final long serialVersionUID = -8582527630534972701L;
  private NegoInfo negoOffer;
  private Action selectedAction;
  private NegotiationParty party;
  private Bid topic;
  private JTextArea negotiationMessages = new JTextArea("NO MESSAGES YET");
  private JButton buttonAccept = new JButton(" Accept ");
  private JButton buttonReject = new JButton(" Reject ");
  private JButton buttonExit = new JButton(" Exit Application ");
  private JPanel buttonPanel = new JPanel();
  private JTable BidTable;
  
  public EnterBidDialogAcceptReject(NegotiationParty party, Frame parent, boolean modal, UtilitySpace us, Bid topic)
    throws Exception
  {
    super(parent, modal);
    this.party = party;
    this.topic = topic;
    this.negoOffer = new NegoShowOffer(null, null, us, topic);
    initThePanel();
  }
  
  public void setUtilitySpace(UtilitySpace us)
  {
    this.negoOffer.utilitySpace = us;
  }
  
  private void initThePanel()
  {
    if (this.negoOffer == null) {
      throw new NullPointerException("negoOffer is null");
    }
    Container pane = getContentPane();
    pane.setLayout(new BorderLayout());
    setDefaultCloseOperation(2);
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    



    pane.add(this.negotiationMessages, "North");
    


    this.BidTable = new JTable(this.negoOffer);
    

    this.BidTable.setGridColor(Color.lightGray);
    JPanel tablepane = new JPanel(new BorderLayout());
    tablepane.add(this.BidTable.getTableHeader(), "North");
    tablepane.add(this.BidTable, "Center");
    pane.add(tablepane, "Center");
    this.BidTable.setRowHeight(35);
    
    this.buttonPanel.setLayout(new FlowLayout());
    this.buttonPanel.add(this.buttonAccept);
    this.buttonPanel.add(this.buttonReject);
    this.buttonPanel.add(this.buttonExit);
    pane.add(this.buttonPanel, "South");
    this.buttonAccept.setSelected(true);
    
    this.buttonAccept.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptReject.this.buttonAcceptActionPerformed(evt);
      }
    });
    this.buttonReject.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptReject.this.buttonRejectActionPerformed(evt);
      }
    });
    this.buttonExit.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptReject.this.buttonExitActionPerformed(evt);
      }
    });
    pack();
  }
  
  private Bid getBid()
  {
    Bid bid = null;
    try
    {
      bid = this.negoOffer.getBid();
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(null, "There is a problem with your bid: " + e.getMessage());
    }
    return bid;
  }
  
  private void buttonAcceptActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      System.out.println("Accept performed");
      this.selectedAction = new Accept(this.party.getPartyId());
      setVisible(false);
    }
  }
  
  private void buttonRejectActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      System.out.println("Reject performed");
      this.selectedAction = new Reject(this.party.getPartyId());
      setVisible(false);
    }
  }
  
  private void buttonExitActionPerformed(ActionEvent evt)
  {
    System.out.println("End negotiation action performed");
    this.selectedAction = new EndNegotiation(this.party.getPartyId());
    dispose();
  }
  
  public Action askUserForAction(Action opponentAction, Bid votingTopic)
  {
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    this.negoOffer.opponentOldBid = null;
    if (opponentAction == null) {
      this.negotiationMessages.setText("Opponent did not send any action.");
    }
    if ((opponentAction instanceof OfferForVoting))
    {
      Bid bid = ((OfferForVoting)opponentAction).getBid();
      this.negotiationMessages.setText("Offer:" + bid);
      this.negoOffer.opponentOldBid = bid;
    }
    try
    {
      this.negotiationMessages.setText("Offer:" + this.topic);
      this.negoOffer.opponentOldBid = this.topic;
      this.negoOffer.setOurBid(this.topic);
    }
    catch (Exception e)
    {
      new Warning("error in askUserForAction:", e, true, 2);
    }
    this.BidTable.setDefaultRenderer(this.BidTable.getColumnClass(0), new MyCellRenderer1(this.negoOffer));
    
    this.BidTable.setDefaultEditor(this.BidTable.getColumnClass(0), new MyCellEditor(this.negoOffer));
    
    pack();
    setVisible(true);
    
    return this.selectedAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.EnterBidDialogAcceptReject
 * JD-Core Version:    0.7.1
 */