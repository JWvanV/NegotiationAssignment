package agents;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.Vote;
import negotiator.actions.Action;
import negotiator.actions.IllegalAction;
import negotiator.actions.OfferForVoting;
import negotiator.actions.VoteForOfferAcceptance;
import negotiator.exceptions.Warning;
import negotiator.parties.NegotiationParty;
import negotiator.utility.UtilitySpace;

public class EnterBidDialogAcceptance
  extends JDialog
  implements EnterBidDialogInterface
{
  private static final long serialVersionUID = -8582527630534972704L;
  private NegoInfo negoInfo;
  private Action selectedAction;
  private NegotiationParty party;
  private JTextArea negotiationMessages = new JTextArea("NO MESSAGES YET");
  private JButton buttonAccept = new JButton(" Accept ");
  private JButton buttonReject = new JButton(" Reject ");
  private JButton buttonExit = new JButton(" Exit Application ");
  private JPanel buttonPanel = new JPanel();
  private JTable BidTable;
  
  public EnterBidDialogAcceptance(NegotiationParty party, Frame parent, boolean modal, UtilitySpace us)
    throws Exception
  {
    super(parent, modal);
    this.party = party;
    this.negoInfo = new NegoOffer(null, null, us);
    initThePanel();
  }
  
  public void setUtilitySpace(UtilitySpace us)
  {
    this.negoInfo.utilitySpace = us;
  }
  
  private void initThePanel()
  {
    if (this.negoInfo == null) {
      throw new NullPointerException("negoInfo is null");
    }
    Container pane = getContentPane();
    pane.setLayout(new BorderLayout());
    setDefaultCloseOperation(2);
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    setSize(new Dimension(600, 400));
    setBounds(0, 0, 640, 480);
    

    pane.add(this.negotiationMessages, "North");
    


    this.BidTable = new JTable(this.negoInfo);
    

    this.BidTable.setGridColor(Color.lightGray);
    JPanel tablepane = new JPanel(new BorderLayout());
    tablepane.add(this.BidTable.getTableHeader(), "North");
    tablepane.add(this.BidTable, "Center");
    pane.add(tablepane, "Center");
    this.BidTable.setRowHeight(35);
    

    this.buttonPanel.setLayout(new FlowLayout());
    this.buttonPanel.add(this.buttonAccept);
    this.buttonPanel.add(this.buttonReject);
    this.buttonPanel.add(this.buttonExit);
    pane.add(this.buttonPanel, "South");
    this.buttonAccept.setSelected(true);
    
    this.buttonAccept.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptance.this.buttonAcceptActionPerformed(evt);
      }
    });
    this.buttonReject.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptance.this.buttonRejectActionPerformed(evt);
      }
    });
    this.buttonExit.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogAcceptance.this.buttonExitActionPerformed(evt);
      }
    });
    pack();
  }
  
  private Bid getBid()
  {
    Bid bid = null;
    try
    {
      bid = this.negoInfo.getBid();
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(null, "There is a problem with your bid: " + e.getMessage());
    }
    return bid;
  }
  
  private void buttonAcceptActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      System.out.println("Accept performed");
      this.selectedAction = new VoteForOfferAcceptance(this.party.getPartyId(), Vote.ACCEPT);
      setVisible(false);
    }
  }
  
  private void buttonRejectActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      System.out.println("Reject performed");
      this.selectedAction = new VoteForOfferAcceptance(this.party.getPartyId(), Vote.REJECT);
      setVisible(false);
    }
  }
  
  private void buttonExitActionPerformed(ActionEvent evt)
  {
    System.out.println("Exit action performed");
    this.selectedAction = new IllegalAction(this.party.getPartyId(), "Exiting application");
    dispose();
  }
  
  public Action askUserForAction(Action opponentAction, Bid myPreviousBid)
  {
    return askUserForAction(opponentAction, myPreviousBid, null);
  }
  
  public Action askUserForAction(Action opponentAction, Bid currentOffer, Bid lastAcceptedOffer)
  {
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    this.negoInfo.opponentOldBid = null;
    if (opponentAction == null) {
      this.negotiationMessages.setText("Opponent did not send any action.");
    }
    if ((opponentAction instanceof OfferForVoting))
    {
      Bid bid = ((OfferForVoting)opponentAction).getBid();
      this.negotiationMessages.setText("Offer:" + bid);
      this.negoInfo.opponentOldBid = lastAcceptedOffer;
    }
    try
    {
      this.negoInfo.setOurBid(currentOffer);
    }
    catch (Exception e)
    {
      new Warning("error in askUserForAction:", e, true, 2);
    }
    this.BidTable.setDefaultRenderer(this.BidTable.getColumnClass(0), new MyCellRenderer1(this.negoInfo));
    
    this.BidTable.setDefaultEditor(this.BidTable.getColumnClass(0), new MyCellEditor(this.negoInfo));
    
    pack();
    setVisible(true);
    
    return this.selectedAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.EnterBidDialogAcceptance
 * JD-Core Version:    0.7.1
 */