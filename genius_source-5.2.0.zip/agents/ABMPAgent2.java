package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class ABMPAgent2
  extends Agent
{
  private Action messageOpponent;
  private Bid myLastBid = null;
  private Action myLastAction = null;
  private double fOldTargetUtility;
  private static final double NEGOTIATIONSPEED = 0.1D;
  private static final double CONCESSIONFACTOR = 1.0D;
  private static final double CONFTOLERANCE = 0.0D;
  private static final double UTIlITYGAPSIZE = 0.02D;
  
  private static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  public void init()
  {
    super.init();
    this.messageOpponent = null;
    this.myLastBid = null;
    this.myLastAction = null;
    this.fOldTargetUtility = 1.0D;
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.messageOpponent = opponentAction;
  }
  
  private Action proposeInitialBid()
    throws Exception
  {
    Bid lBid = this.utilitySpace.getMaxUtilityBid();
    lBid = getBidRandomWalk(this.utilitySpace.getUtility(lBid) * 0.95D, this.utilitySpace.getUtility(lBid));
    
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  private Action proposeNextBid(Bid lOppntBid)
  {
    Bid lBid = null;
    double lOppntUtility = 1.0D;
    

    double lMyUtility = this.fOldTargetUtility;
    try
    {
      lOppntUtility = this.utilitySpace.getUtility(lOppntBid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
    try
    {
      lBid = getBidABMPsimple(lTargetUtility);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.myLastBid = lBid;
    this.fOldTargetUtility = lTargetUtility;
    return new Offer(getAgentID(), lBid);
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    
    ACTIONTYPE lActionType = getActionType(this.messageOpponent);
    switch (lActionType)
    {
    case OFFER: 
      try
      {
        lOppntBid = ((Offer)this.messageOpponent).getBid();
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else if (this.utilitySpace.getUtility(lOppntBid) >= this.fOldTargetUtility - 0.02D) {
          lAction = new Accept(getAgentID());
        } else {
          lAction = proposeNextBid(lOppntBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    case ACCEPT: 
    case BREAKOFF: 
      break;
    default: 
      if (this.myLastAction == null) {
        try
        {
          lAction = proposeInitialBid();
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      } else {
        lAction = this.myLastAction;
      }
      break;
    }
    this.myLastAction = lAction;
    return lAction;
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private Bid getBidABMPsimple(double targetUtility)
    throws Exception
  {
    int nrOfIssues = this.utilitySpace.getDomain().getIssues().size();
    double[] lIssueWeight = new double[nrOfIssues];
    int i = 0;
    for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
    {
      lIssueWeight[i] = this.utilitySpace.getWeight(lIssue.getNumber());
      i++;
    }
    ArrayList<Issue> lIssues = this.utilitySpace.getDomain().getIssues();
    Value[] lIssueIndex = new Value[nrOfIssues];
    double[] lIssueAlpha = new double[nrOfIssues];
    double[] lBE = new double[nrOfIssues];
    double[] lBTE = new double[nrOfIssues];
    double[] lTE = new double[nrOfIssues];
    double lUtility = 0.0D;double lNF = 0.0D;double lTotalConcession = 0.0D;
    


    double lUtilityGap = targetUtility - this.utilitySpace.getUtility(this.myLastBid);
    for (i = 0; i < nrOfIssues; i++) {
      lBE[i] = this.utilitySpace.getEvaluator(((Issue)lIssues.get(i)).getNumber()).getEvaluation(this.utilitySpace, this.myLastBid, ((Issue)lIssues.get(i)).getNumber()).doubleValue();
    }
    for (i = 0; i < nrOfIssues; i++)
    {
      double lAlpha = (1.0D - lIssueWeight[i]) * lBE[i];
      

      lNF += lIssueWeight[i] * lAlpha;
      lIssueAlpha[i] = lAlpha;
    }
    for (i = 0; i < nrOfIssues; i++) {
      lBE[i] += lIssueAlpha[i] / lNF * lUtilityGap;
    }
    for (i = 0; i < nrOfIssues; i++)
    {
      lUtility = this.utilitySpace.getEvaluator(((Issue)lIssues.get(i)).getNumber()).getEvaluation(this.utilitySpace, ((Offer)this.messageOpponent).getBid(), ((Issue)lIssues.get(i)).getNumber()).doubleValue();
      


      lTE[i] = (1.0D * lBTE[i] + 0.0D * lUtility);
    }
    int lNrOfRealIssues = 0;
    for (i = 0; i < nrOfIssues; i++)
    {
      lUtility = 1.0D;
      Issue lIssue = (Issue)lIssues.get(i);
      if (lIssue.getType() == ISSUETYPE.DISCRETE)
      {
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        for (int j = 0; j < lIssueDiscrete.getNumberOfValues(); j++)
        {
          double lEvalValue = ((EvaluatorDiscrete)this.utilitySpace.getEvaluator(((Issue)lIssues.get(i)).getNumber())).getEvaluation(lIssueDiscrete.getValue(j)).doubleValue();
          if (Math.abs(lTE[i] - lEvalValue) < lUtility)
          {
            lIssueIndex[i] = lIssueDiscrete.getValue(j);
            lUtility = Math.abs(lTE[i] - lEvalValue);
          }
        }
        lTotalConcession += lIssueWeight[i] * (lBE[i] - ((EvaluatorDiscrete)this.utilitySpace.getEvaluator(((Issue)lIssues.get(i)).getNumber())).getEvaluation((ValueDiscrete)lIssueIndex[i]).doubleValue());
      }
      else if (lIssue.getType() == ISSUETYPE.REAL)
      {
        lNrOfRealIssues++;
      }
    }
    double lRestUtitility = lUtilityGap + lTotalConcession;
    for (i = 0; i < nrOfIssues; i++)
    {
      Issue lIssue = (Issue)lIssues.get(i);
      if (lIssue.getType() == ISSUETYPE.REAL)
      {
        lTE[i] += lRestUtitility / lNrOfRealIssues;
        EvaluatorReal lRealEvaluator = (EvaluatorReal)this.utilitySpace.getEvaluator(((Issue)lIssues.get(i)).getNumber());
        
        double r = lRealEvaluator.getValueByEvaluation(lTE[i]);
        lIssueIndex[i] = new ValueReal(r);
      }
    }
    HashMap<Integer, Value> lValues = new HashMap();
    for (i = 0; i < nrOfIssues; i++) {
      lValues.put(Integer.valueOf(((Issue)lIssues.get(i)).getNumber()), lIssueIndex[i]);
    }
    return new Bid(this.utilitySpace.getDomain(), lValues);
  }
  
  private double getTargetUtility(double myUtility, double oppntUtility)
  {
    return myUtility + getConcessionStep(myUtility, oppntUtility);
  }
  
  private double getNegotiationSpeed()
  {
    return 0.1D;
  }
  
  private double getConcessionFactor()
  {
    return 1.0D;
  }
  
  private double getConcessionStep(double myUtility, double oppntUtility)
  {
    double lConcessionStep = 0.0D;double lMinUtility = 0.0D;double lUtilityGap = 0.0D;
    

    lMinUtility = 1.0D - getConcessionFactor();
    lUtilityGap = oppntUtility - myUtility;
    lConcessionStep = getNegotiationSpeed() * (1.0D - lMinUtility / myUtility) * lUtilityGap;
    
    System.out.println(lConcessionStep);
    return lConcessionStep;
  }
  
  private Bid getBidRandomWalk(double lowerBound, double upperBoud)
    throws Exception
  {
    Bid lBid = null;Bid lBestBid = null;
    


    lBestBid = this.utilitySpace.getDomain().getRandomBid();
    do
    {
      lBid = this.utilitySpace.getDomain().getRandomBid();
    } while ((this.utilitySpace.getUtility(lBid) <= lowerBound) || (this.utilitySpace.getUtility(lBestBid) >= upperBoud));
    lBestBid = lBid;
    



    return lBestBid;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
  
  public String getVersion()
  {
    return "1.0";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.ABMPAgent2
 * JD-Core Version:    0.7.1
 */