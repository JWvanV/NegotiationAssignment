package agents;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.PrintStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.exceptions.Warning;
import negotiator.parties.NegotiationParty;
import negotiator.utility.UtilitySpace;

public class EnterBidDialogOffer
  extends JDialog
  implements EnterBidDialogInterface
{
  private static final long serialVersionUID = -8582527630534972702L;
  private NegoInfo negoinfo;
  private Action selectedAction;
  private NegotiationParty party;
  private JTextArea negotiationMessages = new JTextArea("NO MESSAGES YET");
  private JButton buttonEnd = new JButton("End Negotiation");
  private JButton buttonBid = new JButton("       Propose       ");
  private JPanel buttonPanel = new JPanel();
  private JTable BidTable;
  
  public EnterBidDialogOffer(NegotiationParty party, Frame parent, boolean modal, UtilitySpace us)
    throws Exception
  {
    super(parent, modal);
    this.party = party;
    this.negoinfo = new NegoInfo(null, null, us);
    initThePanel();
  }
  
  public void setUtilitySpace(UtilitySpace us)
  {
    this.negoinfo.utilitySpace = us;
  }
  
  private void initThePanel()
  {
    if (this.negoinfo == null) {
      throw new NullPointerException("negoinfo is null");
    }
    Container pane = getContentPane();
    pane.setLayout(new BorderLayout());
    setDefaultCloseOperation(2);
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    



    pane.add(this.negotiationMessages, "North");
    


    this.BidTable = new JTable(this.negoinfo);
    

    this.BidTable.setGridColor(Color.lightGray);
    JPanel tablepane = new JPanel(new BorderLayout());
    tablepane.add(this.BidTable.getTableHeader(), "North");
    tablepane.add(this.BidTable, "Center");
    pane.add(tablepane, "Center");
    this.BidTable.setRowHeight(35);
    
    this.buttonPanel.setLayout(new FlowLayout());
    this.buttonPanel.add(this.buttonEnd);
    
    this.buttonPanel.add(this.buttonBid);
    pane.add(this.buttonPanel, "South");
    this.buttonBid.setSelected(true);
    

    this.buttonBid.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogOffer.this.buttonBidActionPerformed(evt);
      }
    });
    this.buttonEnd.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent evt)
      {
        EnterBidDialogOffer.this.buttonEndActionPerformed(evt);
      }
    });
    pack();
  }
  
  private Bid getBid()
  {
    Bid bid = null;
    try
    {
      bid = this.negoinfo.getBid();
    }
    catch (Exception e)
    {
      JOptionPane.showMessageDialog(null, "There is a problem with your bid: " + e.getMessage());
    }
    return bid;
  }
  
  private void buttonBidActionPerformed(ActionEvent evt)
  {
    Bid bid = getBid();
    if (bid != null)
    {
      this.selectedAction = new Offer(this.party.getPartyId(), bid);
      setVisible(false);
    }
  }
  
  private void buttonEndActionPerformed(ActionEvent evt)
  {
    System.out.println("End Negotiation performed");
    this.selectedAction = new EndNegotiation(this.party.getPartyId());
    dispose();
  }
  
  public Action askUserForAction(Action opponentAction, Bid myPreviousBid)
  {
    setTitle("Choose action for party " + this.party.getPartyId().toString());
    this.negoinfo.opponentOldBid = null;
    if (opponentAction == null) {
      this.negotiationMessages.setText("Opponent did not send any action.");
    }
    if ((opponentAction instanceof Accept))
    {
      this.negotiationMessages.setText("Opponent accepted your last bid!");
      this.negoinfo.opponentOldBid = myPreviousBid;
    }
    if ((opponentAction instanceof EndNegotiation)) {
      this.negotiationMessages.setText("Opponent cancels the negotiation.");
    }
    if ((opponentAction instanceof Offer))
    {
      this.negotiationMessages.setText("Opponent proposes the following bid:");
      this.negoinfo.opponentOldBid = ((Offer)opponentAction).getBid();
    }
    try
    {
      this.negoinfo.setOurBid(myPreviousBid);
    }
    catch (Exception e)
    {
      new Warning("error in askUserForAction:", e, true, 2);
    }
    this.BidTable.setDefaultRenderer(this.BidTable.getColumnClass(0), new MyCellRenderer1(this.negoinfo));
    
    this.BidTable.setDefaultEditor(this.BidTable.getColumnClass(0), new MyCellEditor(this.negoinfo));
    
    pack();
    setVisible(true);
    
    return this.selectedAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.EnterBidDialogOffer
 * JD-Core Version:    0.7.1
 */