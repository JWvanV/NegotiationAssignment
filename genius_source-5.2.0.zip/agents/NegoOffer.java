package agents;

import java.awt.Component;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import negotiator.Bid;
import negotiator.exceptions.Warning;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

class NegoOffer
  extends NegoInfo
{
  NegoOffer(Bid our, Bid opponent, UtilitySpace us)
    throws Exception
  {
    super(our, opponent, us);
  }
  
  private String[] colNames = { "Issue", "Most recently accepted", "Current offer" };
  
  public Component getValueAt(int row, int col)
  {
    if (row == this.issues.size())
    {
      if (col == 0) {
        return new JLabel("Utility:");
      }
      if (this.utilitySpace == null) {
        return new JLabel("No UtilSpace");
      }
      Bid bid;
      Bid bid;
      if (col == 1) {
        bid = this.opponentOldBid;
      } else {
        try
        {
          bid = getBid();
        }
        catch (Exception e)
        {
          Bid bid;
          bid = null;System.out.println("Internal err with getBid:" + e.getMessage());
        }
      }
      JProgressBar bar = new JProgressBar(0, 100);bar.setStringPainted(true);
      try
      {
        bar.setValue((int)(0.5D + 100.0D * this.utilitySpace.getUtility(bid)));
        bar.setIndeterminate(false);
      }
      catch (Exception e)
      {
        new Warning("Exception during cost calculation:" + e.getMessage(), false, 1);
        bar.setIndeterminate(true);
      }
      return bar;
    }
    if (row == this.issues.size() + 1) {
      return null;
    }
    Value value;
    switch (col)
    {
    case 0: 
      return new JTextArea(((Issue)this.issues.get(row)).getName());
    case 1: 
      value = null;
      try
      {
        value = getCurrentEval(this.opponentOldBid, row);
      }
      catch (Exception e)
      {
        System.out.println("Err EnterBidDialog2.getValueAt: " + e.getMessage());
      }
      if (value == null) {
        return new JTextArea("-");
      }
      return new JTextArea(value.toString());
    case 2: 
      value = null;
      try
      {
        value = getCurrentEval(this.ourOldBid, row);
      }
      catch (Exception e)
      {
        System.out.println("Err EnterBidDialog2.getValueAt: " + e.getMessage());
      }
      if (value == null) {
        return new JTextArea("-");
      }
      return new JTextArea(value.toString());
    }
    return null;
  }
  
  public String getColumnName(int col)
  {
    return this.colNames[col];
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.NegoOffer
 * JD-Core Version:    0.7.1
 */