package agents;

import negotiator.PocketNegotiatorAgent;
import negotiator.Timeline;
import negotiator.actions.Action;
import negotiator.utility.UtilitySpace;

public class BayesianAgentPN
  extends BayesianAgent
  implements PocketNegotiatorAgent
{
  public void initPN(UtilitySpace mySide, UtilitySpace otherSide, Timeline tl)
  {
    this.utilitySpace = mySide;
    
    this.timeline = tl;
    init();
  }
  
  public void updateProfiles(UtilitySpace my, UtilitySpace other)
  {
    if (my != null) {
      this.utilitySpace = my;
    }
  }
  
  public void handleAction(Action act)
  {
    ReceiveMessage(act);
  }
  
  public Action getAction()
  {
    return chooseAction();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BayesianAgentPN
 * JD-Core Version:    0.7.1
 */