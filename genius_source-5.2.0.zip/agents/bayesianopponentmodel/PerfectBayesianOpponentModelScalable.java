package agents.bayesianopponentmodel;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueReal;
import negotiator.utility.EVALFUNCTYPE;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class PerfectBayesianOpponentModelScalable
  extends OpponentModel
{
  private UtilitySpace fUS;
  private ArrayList<ArrayList<WeightHypothesis2>> fWeightHyps;
  private ArrayList<ArrayList<EvaluatorHypothesis>> fEvaluatorHyps;
  ArrayList<Issue> issues;
  private double[] fExpectedWeights;
  private UtilitySpace opponentSpace;
  
  public PerfectBayesianOpponentModelScalable(UtilitySpace pUtilitySpace)
  {
    this.fDomain = pUtilitySpace.getDomain();
    this.issues = this.fDomain.getIssues();
    this.fUS = pUtilitySpace;
    this.fBiddingHistory = new ArrayList();
    this.fExpectedWeights = new double[pUtilitySpace.getDomain().getIssues().size()];
    this.fWeightHyps = new ArrayList();
    

    initWeightHyps();
    
    this.fEvaluatorHyps = new ArrayList();
    int lTotalTriangularFns = 4;
    for (int i = 0; i < this.fUS.getNrOfEvaluators(); i++) {
      switch (this.fUS.getEvaluator(((Issue)this.issues.get(i)).getNumber()).getType())
      {
      case REAL: 
        ArrayList<EvaluatorHypothesis> lEvalHyps = new ArrayList();
        this.fEvaluatorHyps.add(lEvalHyps);
        
        IssueReal lIssue = (IssueReal)this.fDomain.getIssue(i);
        

        EvaluatorReal lHypEval = new EvaluatorReal();
        lHypEval.setUpperBound(lIssue.getUpperBound());
        lHypEval.setLowerBound(lIssue.getLowerBound());
        lHypEval.setType(EVALFUNCTYPE.LINEAR);
        lHypEval.addParam(1, 1.0D / (lHypEval.getUpperBound() - lHypEval.getLowerBound()));
        lHypEval.addParam(0, -lHypEval.getLowerBound() / (lHypEval.getUpperBound() - lHypEval.getLowerBound()));
        EvaluatorHypothesis lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEval);
        lEvaluatorHypothesis.setDesc("uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        
        lHypEval = new EvaluatorReal();
        lHypEval.setUpperBound(lIssue.getUpperBound());
        lHypEval.setLowerBound(lIssue.getLowerBound());
        lHypEval.setType(EVALFUNCTYPE.LINEAR);
        lHypEval.addParam(1, -1.0D / (lHypEval.getUpperBound() - lHypEval.getLowerBound()));
        lHypEval.addParam(0, 1.0D + lHypEval.getLowerBound() / (lHypEval.getUpperBound() - lHypEval.getLowerBound()));
        lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEval);
        lEvalHyps.add(lEvaluatorHypothesis);
        lEvaluatorHypothesis.setDesc("downhill");
        for (int k = 1; k <= lTotalTriangularFns; k++)
        {
          lHypEval = new EvaluatorReal();
          lHypEval.setUpperBound(lIssue.getUpperBound());
          lHypEval.setLowerBound(lIssue.getLowerBound());
          lHypEval.setType(EVALFUNCTYPE.TRIANGULAR);
          lHypEval.addParam(0, lHypEval.getLowerBound());
          lHypEval.addParam(1, lHypEval.getUpperBound());
          double lMaxPoint = lHypEval.getLowerBound() + k * (lHypEval.getUpperBound() - lHypEval.getLowerBound()) / (lTotalTriangularFns + 1);
          lHypEval.addParam(2, lMaxPoint);
          lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEval);
          lEvalHyps.add(lEvaluatorHypothesis);
          lEvaluatorHypothesis.setDesc("triangular " + String.format("%1.2f", new Object[] { Double.valueOf(lMaxPoint) }));
        }
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
        break;
      case DISCRETE: 
        ArrayList<EvaluatorHypothesis> lEvalHyps = new ArrayList();
        this.fEvaluatorHyps.add(lEvalHyps);
        
        IssueDiscrete lDiscIssue = (IssueDiscrete)this.fDomain.getIssue(i);
        
        EvaluatorDiscrete lDiscreteEval = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j + 1));
        }
        EvaluatorHypothesis lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
        lEvaluatorHypothesis.setProbability(0.3333333333333333D);
        lEvaluatorHypothesis.setDesc("uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        
        lDiscreteEval = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1) + 1));
        }
        lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
        lEvaluatorHypothesis.setProbability(0.3333333333333333D);
        lEvalHyps.add(lEvaluatorHypothesis);
        lEvaluatorHypothesis.setDesc("downhill");
        if (lDiscIssue.getNumberOfValues() > 2)
        {
          lTotalTriangularFns = lDiscIssue.getNumberOfValues() - 1;
          for (int k = 1; k < lTotalTriangularFns; k++)
          {
            lDiscreteEval = new EvaluatorDiscrete();
            for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
              if (j < k) {
                lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j / k));
              } else {
                lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), 
                  Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1) / (lDiscIssue.getNumberOfValues() - k - 1) + 1));
              }
            }
            lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
            lEvalHyps.add(lEvaluatorHypothesis);
            lEvaluatorHypothesis.setDesc("triangular " + String.valueOf(k));
          }
        }
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
      }
    }
    for (int i = 0; i < this.fExpectedWeights.length; i++) {
      this.fExpectedWeights[i] = getExpectedWeight(i);
    }
  }
  
  void initWeightHyps()
  {
    int lWeightHypsNumber = 11;
    for (int i = 0; i < this.fUS.getDomain().getIssues().size(); i++)
    {
      ArrayList<WeightHypothesis2> lWeightHyps = new ArrayList();
      for (int j = 0; j < lWeightHypsNumber; j++)
      {
        WeightHypothesis2 lHyp = new WeightHypothesis2(this.fDomain);
        lHyp.setProbability((1.0D - (j + 1.0D) / lWeightHypsNumber) * (1.0D - (j + 1.0D) / lWeightHypsNumber) * (1.0D - (j + 1.0D) / lWeightHypsNumber));
        lHyp.setWeight(j / (lWeightHypsNumber - 1));
        lWeightHyps.add(lHyp);
      }
      double lN = 0.0D;
      for (int j = 0; j < lWeightHypsNumber; j++) {
        lN += ((WeightHypothesis2)lWeightHyps.get(j)).getProbability();
      }
      for (int j = 0; j < lWeightHypsNumber; j++) {
        ((WeightHypothesis2)lWeightHyps.get(j)).setProbability(((WeightHypothesis2)lWeightHyps.get(j)).getProbability() / lN);
      }
      this.fWeightHyps.add(lWeightHyps);
    }
  }
  
  private double conditionalDistribution(double pUtility, double pPreviousBidUtility)
  {
    double lSigma = 0.25D;
    double x = (pPreviousBidUtility - pUtility) / pPreviousBidUtility;
    double lResult = 1.0D / (lSigma * Math.sqrt(6.283185307179586D)) * Math.exp(-(x * x) / (2.0D * lSigma * lSigma));
    return lResult;
  }
  
  public double getExpectedEvaluationValue(Bid pBid, int pIssueNumber)
    throws Exception
  {
    double lExpectedEval = 0.0D;
    for (int j = 0; j < ((ArrayList)this.fEvaluatorHyps.get(pIssueNumber)).size(); j++) {
      lExpectedEval = lExpectedEval + ((EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(pIssueNumber)).get(j)).getProbability() * ((EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(pIssueNumber)).get(j)).getEvaluator().getEvaluation(this.fUS, pBid, ((Issue)this.issues.get(pIssueNumber)).getNumber()).doubleValue();
    }
    return lExpectedEval;
  }
  
  public double getExpectedWeight(int pIssueNumber)
  {
    double lExpectedWeight = 0.0D;
    for (int i = 0; i < ((ArrayList)this.fWeightHyps.get(pIssueNumber)).size(); i++) {
      lExpectedWeight += ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(pIssueNumber)).get(i)).getProbability() * ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(pIssueNumber)).get(i)).getWeight();
    }
    return lExpectedWeight;
  }
  
  private double getPartialUtility(Bid pBid, int pIssueIndex)
    throws Exception
  {
    double u = 0.0D;
    for (int j = 0; j < this.fDomain.getIssues().size(); j++) {
      if (pIssueIndex != j)
      {
        double w = 0.0D;
        for (int k = 0; k < ((ArrayList)this.fWeightHyps.get(j)).size(); k++) {
          w += ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(k)).getProbability() * ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(k)).getWeight();
        }
        u += w * getExpectedEvaluationValue(pBid, j);
      }
    }
    return u;
  }
  
  public void updateWeights(double opponentUtility)
    throws Exception
  {
    Bid lBid = (Bid)this.fBiddingHistory.get(this.fBiddingHistory.size() - 1);
    ArrayList<ArrayList<WeightHypothesis2>> lWeightHyps = new ArrayList();
    for (int i = 0; i < this.fWeightHyps.size(); i++)
    {
      ArrayList<WeightHypothesis2> lTmp = new ArrayList();
      for (int j = 0; j < ((ArrayList)this.fWeightHyps.get(i)).size(); j++)
      {
        WeightHypothesis2 lHyp = new WeightHypothesis2(this.fUS.getDomain());
        lHyp.setWeight(((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(i)).get(j)).getWeight());
        lHyp.setProbability(((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(i)).get(j)).getProbability());
        lTmp.add(lHyp);
      }
      lWeightHyps.add(lTmp);
    }
    for (int j = 0; j < this.fDomain.getIssues().size(); j++)
    {
      double lN = 0.0D;
      double lUtility = 0.0D;
      for (int i = 0; i < ((ArrayList)this.fWeightHyps.get(j)).size(); i++)
      {
        lUtility = ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(i)).getWeight() * getExpectedEvaluationValue(lBid, j) + getPartialUtility(lBid, j);
        lN += ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(i)).getProbability() * conditionalDistribution(lUtility, opponentUtility);
      }
      for (int i = 0; i < ((ArrayList)this.fWeightHyps.get(j)).size(); i++)
      {
        lUtility = ((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(i)).getWeight() * getExpectedEvaluationValue(lBid, j) + getPartialUtility(lBid, j);
        ((WeightHypothesis2)((ArrayList)lWeightHyps.get(j)).get(i)).setProbability(((WeightHypothesis2)((ArrayList)this.fWeightHyps.get(j)).get(i)).getProbability() * conditionalDistribution(lUtility, opponentUtility) / lN);
      }
    }
    this.fWeightHyps = lWeightHyps;
  }
  
  public void updateEvaluationFns(double opponentUtility)
    throws Exception
  {
    Bid lBid = (Bid)this.fBiddingHistory.get(this.fBiddingHistory.size() - 1);
    

    ArrayList<ArrayList<EvaluatorHypothesis>> lEvaluatorHyps = new ArrayList();
    for (int i = 0; i < this.fEvaluatorHyps.size(); i++)
    {
      ArrayList<EvaluatorHypothesis> lTmp = new ArrayList();
      for (int j = 0; j < ((ArrayList)this.fEvaluatorHyps.get(i)).size(); j++)
      {
        EvaluatorHypothesis lHyp = new EvaluatorHypothesis(((EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(i)).get(j)).getEvaluator());
        lHyp.setDesc(((EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(i)).get(j)).getDesc());
        lHyp.setProbability(((EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(i)).get(j)).getProbability());
        lTmp.add(lHyp);
      }
      lEvaluatorHyps.add(lTmp);
    }
    for (int i = 0; i < this.fDomain.getIssues().size(); i++)
    {
      double lN = 0.0D;
      for (int j = 0; j < ((ArrayList)this.fEvaluatorHyps.get(i)).size(); j++)
      {
        EvaluatorHypothesis lHyp = (EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(i)).get(j);
        lN += lHyp.getProbability() * conditionalDistribution(getPartialUtility(lBid, i) + getExpectedWeight(i) * lHyp.getEvaluator().getEvaluation(this.fUS, lBid, ((Issue)this.issues.get(i)).getNumber()).doubleValue(), opponentUtility);
      }
      for (int j = 0; j < ((ArrayList)this.fEvaluatorHyps.get(i)).size(); j++)
      {
        EvaluatorHypothesis lHyp = (EvaluatorHypothesis)((ArrayList)this.fEvaluatorHyps.get(i)).get(j);
        ((EvaluatorHypothesis)((ArrayList)lEvaluatorHyps.get(i)).get(j)).setProbability(lHyp.getProbability() * conditionalDistribution(getPartialUtility(lBid, i) + getExpectedWeight(i) * lHyp.getEvaluator().getEvaluation(this.fUS, lBid, ((Issue)this.issues.get(i)).getNumber()).doubleValue(), opponentUtility) / lN);
      }
    }
    this.fEvaluatorHyps = lEvaluatorHyps;
  }
  
  public boolean haveSeenBefore(Bid pBid)
  {
    for (Bid tmpBid : this.fBiddingHistory) {
      if (pBid.equals(tmpBid)) {
        return true;
      }
    }
    return false;
  }
  
  public void updateBeliefs(Bid pBid)
    throws Exception
  {
    if (haveSeenBefore(pBid)) {
      return;
    }
    this.fBiddingHistory.add(pBid);
    double opponentUtility = this.opponentSpace.getUtility(pBid);
    if (this.fBiddingHistory.size() > 1)
    {
      updateWeights(opponentUtility);
      
      updateEvaluationFns(opponentUtility);
    }
    else
    {
      updateEvaluationFns(opponentUtility);
    }
    for (int i = 0; i < this.fExpectedWeights.length; i++) {
      this.fExpectedWeights[i] = getExpectedWeight(i);
    }
    findMinMaxUtility();
  }
  
  public double getExpectedUtility(Bid pBid)
    throws Exception
  {
    double u = 0.0D;
    for (int j = 0; j < this.fDomain.getIssues().size(); j++)
    {
      double w = this.fExpectedWeights[j];
      

      u += w * getExpectedEvaluationValue(pBid, j);
    }
    return u;
  }
  
  public double getNormalizedWeight(Issue i, int startingNumber)
  {
    double sum = 0.0D;
    for (Issue issue : this.fDomain.getIssues()) {
      sum += getExpectedWeight(issue.getNumber() - startingNumber);
    }
    return getExpectedWeight(i.getNumber() - startingNumber) / sum;
  }
  
  public void setOpponentUtilitySpace(UtilitySpace opponentUtilitySpace)
  {
    this.opponentSpace = opponentUtilitySpace;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.PerfectBayesianOpponentModelScalable
 * JD-Core Version:    0.7.1
 */