package agents.bayesianopponentmodel;

import negotiator.Domain;

public class WeightHypothesis2
  extends Hypothesis
{
  double fWeight;
  
  public WeightHypothesis2(Domain pDomain) {}
  
  public void setWeight(double value)
  {
    this.fWeight = value;
  }
  
  public double getWeight()
  {
    return this.fWeight;
  }
  
  public String toString()
  {
    String lResult = "";
    lResult = String.format("%1.2f", new Object[] { Double.valueOf(this.fWeight) }) + ";";
    return lResult;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.WeightHypothesis2
 * JD-Core Version:    0.7.1
 */