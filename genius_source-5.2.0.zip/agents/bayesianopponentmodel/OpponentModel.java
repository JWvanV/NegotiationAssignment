package agents.bayesianopponentmodel;

import java.io.PrintStream;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;

public class OpponentModel
{
  private boolean isCrashed = false;
  protected Domain fDomain;
  public ArrayList<Bid> fBiddingHistory;
  
  public Domain getDomain()
  {
    return this.fDomain;
  }
  
  Double minUtility = null;
  Double maxUtility = null;
  
  public double getExpectedUtility(Bid pBid)
    throws Exception
  {
    return -1.0D;
  }
  
  public double getNormalizedUtility(Bid pBid)
    throws Exception
  {
    double u = getExpectedUtility(pBid);
    if ((this.minUtility == null) || (this.maxUtility == null)) {
      findMinMaxUtility();
    }
    double value = (u - this.minUtility.doubleValue()) / (this.maxUtility.doubleValue() - this.minUtility.doubleValue());
    if (Double.isNaN(value))
    {
      if (!this.isCrashed)
      {
        this.isCrashed = true;
        System.err.println("Bayesian scalable encountered NaN and therefore crashed");
      }
      return 0.0D;
    }
    return (u - this.minUtility.doubleValue()) / (this.maxUtility.doubleValue() - this.minUtility.doubleValue());
  }
  
  public void updateBeliefs(Bid pBid)
    throws Exception
  {}
  
  public double getExpectedWeight(int pIssueNumber)
  {
    return 0.0D;
  }
  
  public boolean haveSeenBefore(Bid pBid)
  {
    for (Bid tmpBid : this.fBiddingHistory) {
      if (pBid.equals(tmpBid)) {
        return true;
      }
    }
    return false;
  }
  
  protected void findMinMaxUtility()
    throws Exception
  {
    BidIterator biditer = new BidIterator(this.fDomain);
    this.minUtility = Double.valueOf(1.0D);this.maxUtility = Double.valueOf(0.0D);
    while (biditer.hasNext())
    {
      Bid b = biditer.next();
      double u = getExpectedUtility(b);
      if (this.minUtility.doubleValue() > u) {
        this.minUtility = Double.valueOf(u);
      }
      if (this.maxUtility.doubleValue() < u) {
        this.maxUtility = Double.valueOf(u);
      }
    }
  }
  
  public boolean isCrashed()
  {
    return this.isCrashed;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.OpponentModel
 * JD-Core Version:    0.7.1
 */