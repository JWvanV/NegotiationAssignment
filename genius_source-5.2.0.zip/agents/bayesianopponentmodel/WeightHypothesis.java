package agents.bayesianopponentmodel;

import java.util.ArrayList;
import negotiator.Domain;

public class WeightHypothesis
  extends Hypothesis
{
  double[] fWeight;
  double fAprioriProbability;
  
  public WeightHypothesis(Domain pDomain)
  {
    this.fWeight = new double[pDomain.getIssues().size()];
  }
  
  public void setWeight(int index, double value)
  {
    this.fWeight[index] = value;
  }
  
  public double getWeight(int index)
  {
    return this.fWeight[index];
  }
  
  public String toString()
  {
    String lResult = "";
    for (double lWeight : this.fWeight) {
      lResult = lResult + String.format("%1.2f", new Object[] { Double.valueOf(lWeight) }) + ";";
    }
    return lResult;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.WeightHypothesis
 * JD-Core Version:    0.7.1
 */