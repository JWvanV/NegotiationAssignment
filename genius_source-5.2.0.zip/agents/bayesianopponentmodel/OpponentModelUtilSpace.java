package agents.bayesianopponentmodel;

import java.io.PrintStream;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class OpponentModelUtilSpace
  extends UtilitySpace
{
  OpponentModel opponentmodel;
  
  public OpponentModelUtilSpace(OpponentModel opmod)
  {
    this.domain = opmod.getDomain();
    this.opponentmodel = opmod;
  }
  
  public double getUtility(Bid b)
  {
    double u = 0.0D;
    try
    {
      u = this.opponentmodel.getNormalizedUtility(b);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("getNormalizedUtility failed. returning 0");u = 0.0D;
    }
    return u;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.OpponentModelUtilSpace
 * JD-Core Version:    0.7.1
 */