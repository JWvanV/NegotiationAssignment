package agents.bayesianopponentmodel;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.utility.Evaluator;
import negotiator.utility.UtilitySpace;

public class UtilitySpaceHypothesis
  extends Hypothesis
{
  private WeightHypothesis fWeightHyp;
  private EvaluatorHypothesis[] fEvalHyp;
  private Domain fDomain;
  private UtilitySpace fUS;
  ArrayList<Issue> issues;
  
  public UtilitySpaceHypothesis(Domain pDomain, UtilitySpace pUS, WeightHypothesis pWeightHyp, EvaluatorHypothesis[] pEvalHyp)
  {
    this.fUS = pUS;
    this.fDomain = pDomain;
    this.issues = this.fDomain.getIssues();
    this.fWeightHyp = pWeightHyp;
    this.fEvalHyp = pEvalHyp;
  }
  
  public Domain getDomain()
  {
    return this.fDomain;
  }
  
  public UtilitySpace getUtilitySpace()
  {
    return this.fUS;
  }
  
  public EvaluatorHypothesis[] getEvalHyp()
  {
    return this.fEvalHyp;
  }
  
  public WeightHypothesis getHeightHyp()
  {
    return this.fWeightHyp;
  }
  
  public double getUtility(Bid pBid)
  {
    double u = 0.0D;
    for (int k = 0; k < this.fEvalHyp.length; k++) {
      try
      {
        u += this.fWeightHyp.getWeight(k) * this.fEvalHyp[k].getEvaluator().getEvaluation(this.fUS, pBid, ((Issue)this.issues.get(k)).getNumber()).doubleValue();
      }
      catch (Exception e)
      {
        u = 0.0D;
      }
    }
    return u;
  }
  
  public String toString()
  {
    String lResult = "";
    lResult = lResult + this.fWeightHyp.toString();
    for (EvaluatorHypothesis lHyp : this.fEvalHyp) {
      lResult = lResult + lHyp.toString() + ";";
    }
    lResult = lResult + String.format("%1.5f", new Object[] { Double.valueOf(getProbability()) });
    return lResult;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.bayesianopponentmodel.UtilitySpaceHypothesis
 * JD-Core Version:    0.7.1
 */