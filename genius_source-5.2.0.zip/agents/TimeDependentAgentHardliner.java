package agents;

import negotiator.SupportedNegotiationSetting;

public class TimeDependentAgentHardliner
  extends TimeDependentAgent
{
  public double getE()
  {
    return 0.0D;
  }
  
  public String getName()
  {
    return "Hardliner";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TimeDependentAgentHardliner
 * JD-Core Version:    0.7.1
 */