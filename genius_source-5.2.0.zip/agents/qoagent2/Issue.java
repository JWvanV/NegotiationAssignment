package agents.qoagent2;

import java.util.StringTokenizer;

class Issue
{
  private String m_sAttribute;
  private String m_sWeight;
  private String m_sValue;
  private String m_sUtility;
  private String m_sTimeEffect;
  private boolean m_bAgreed;
  private int m_nTurn;
  private String m_sValues;
  private String m_sUtilities;
  
  public Issue()
  {
    this.m_bAgreed = false;
    this.m_nTurn = 0;
    this.m_sAttribute = "";
    this.m_sValue = "";
    this.m_sUtility = "";
    this.m_sTimeEffect = "";
    this.m_sValues = "";
    this.m_sUtilities = "";
  }
  
  public boolean getAgreed()
  {
    return this.m_bAgreed;
  }
  
  public void setAgreed(boolean bAgreed)
  {
    this.m_bAgreed = bAgreed;
  }
  
  public int getTurn()
  {
    return this.m_nTurn;
  }
  
  public void setTurn(int nTurn)
  {
    this.m_nTurn = nTurn;
  }
  
  public String getAttribute()
  {
    return this.m_sAttribute;
  }
  
  public void setAttribute(String sAttribute)
  {
    this.m_sAttribute = sAttribute;
  }
  
  public void setWeight(String sWeight)
  {
    this.m_sWeight = sWeight;
  }
  
  public String getWeight()
  {
    return this.m_sWeight;
  }
  
  public String getValue()
  {
    return this.m_sValue;
  }
  
  public String getValues()
  {
    return this.m_sValues;
  }
  
  public String getUtility()
  {
    return this.m_sUtility;
  }
  
  public String getUtilities()
  {
    return this.m_sUtilities;
  }
  
  public String getTimeEffect()
  {
    return this.m_sTimeEffect;
  }
  
  public void setValue(String sValue)
  {
    this.m_sValue = sValue;
  }
  
  public void setValues(String sValues)
  {
    this.m_sValues = sValues;
  }
  
  public void setUtility(String sUtility)
  {
    this.m_sUtility = sUtility;
  }
  
  public void setUtilities(String sUtilities)
  {
    this.m_sUtilities = sUtilities;
  }
  
  public void setTimeEffect(String sTimeEffect)
  {
    this.m_sTimeEffect = sTimeEffect;
  }
  
  public void setNoAgreementValue()
  {
    int position = 1;
    String values = getValues();
    StringTokenizer stValues = new StringTokenizer(values, "~");
    while (stValues.hasMoreTokens())
    {
      String value = stValues.nextToken();
      if (value.equals("No agreement")) {
        break;
      }
      position++;
    }
    setValue("No agreement");
    

    String utilities = getUtilities();
    StringTokenizer stUtilities = new StringTokenizer(utilities);
    String utility = "";
    for (int i = 1; (i <= position) && (stUtilities.hasMoreTokens()); i++) {
      utility = stUtilities.nextToken();
    }
    setUtility(utility);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.Issue
 * JD-Core Version:    0.7.1
 */