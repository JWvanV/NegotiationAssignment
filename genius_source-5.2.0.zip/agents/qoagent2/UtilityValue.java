package agents.qoagent2;

public class UtilityValue
{
  public String sValue;
  public double dUtility;
  public double dTimeEffect;
  
  public UtilityValue()
  {
    this.sValue = "";
    this.dUtility = 0.0D;
    this.dTimeEffect = 0.0D;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.UtilityValue
 * JD-Core Version:    0.7.1
 */