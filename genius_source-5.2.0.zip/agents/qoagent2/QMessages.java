package agents.qoagent2;

import java.io.PrintStream;
import java.util.StringTokenizer;

public class QMessages
{
  public static final int MESSAGE_RECEIVED = 0;
  public static final int MESSAGE_REJECTED = 1;
  public static final int REGISTER = 0;
  public static final int THREAT = 1;
  public static final int COMMENT = 2;
  public static final int OFFER = 3;
  public static final int PROMISE = 4;
  public static final int QUERY = 5;
  public static final int ACCEPT = 6;
  public static final int REJECT = 7;
  public static final int OPT_OUT = 8;
  public static final int COUNTER_OFFER = 9;
  private QOAgent m_agent;
  
  public QMessages(QOAgent agent)
  {
    this.m_agent = agent;
  }
  
  public String formatMessage(int nMessageKind, String sMsgBody)
  {
    String sFormattedMsg = "";
    switch (nMessageKind)
    {
    case 0: 
      sFormattedMsg = "type register tag " + this.m_agent.getMsgId() + " id " + sMsgBody + " side " + this.m_agent.getAgentSide() + " name " + this.m_agent.getAgentName() + " supportMediator " + this.m_agent.getSupportMediator() + " preferenceDetails automatedAgent";
      




      break;
    case 1: 
      sFormattedMsg = "type threat source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " body " + sMsgBody;
      




      break;
    case 2: 
      sFormattedMsg = "type comment source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " body " + sMsgBody;
      




      break;
    case 3: 
      sFormattedMsg = "type offer source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " issueSet ";
      




      sFormattedMsg = sFormattedMsg + sMsgBody;
      
      break;
    case 9: 
      sFormattedMsg = "type counter_offer source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " issueSet ";
      




      sFormattedMsg = sFormattedMsg + sMsgBody;
      
      break;
    case 4: 
      sFormattedMsg = "type promise source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId();
      




      String sAgentPromise = " myIssueSet ";
      



      sAgentPromise = sAgentPromise + sMsgBody;
      














      sFormattedMsg = sFormattedMsg + sAgentPromise + " ";
      

      String sOpponentPromise = "yourIssueSet ";
      












      sFormattedMsg = sFormattedMsg + sOpponentPromise;
      
      break;
    case 5: 
      sFormattedMsg = "type query source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " issueSet ";
      




      sFormattedMsg = sFormattedMsg + sMsgBody;
      
      break;
    case 6: 
      sFormattedMsg = "type response source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " answer AGREE" + " message " + sMsgBody + " reason ";
      







      String sResponse = sFormattedMsg.substring(sFormattedMsg.indexOf("answer ") + 7, sFormattedMsg.indexOf("reason") - 1);
      String sMessage = sResponse.substring(sResponse.indexOf("message ") + 8);
      




      String sSavedMsg = "";
      if (sMessage.startsWith("type query"))
      {
        sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
      }
      else if (sMessage.startsWith("type counter_offer"))
      {
        sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
      }
      else if (sMessage.startsWith("type offer"))
      {
        sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
      }
      else if (sMessage.startsWith("type promise"))
      {
        String sPromise = sMessage.substring(sMessage.indexOf("myIssueSet ") + 11);
        String sMyIssueSet = sPromise.substring(0, sPromise.indexOf("yourIssueSet "));
        String sYourIssueSet = sPromise.substring(sPromise.indexOf("yourIssueSet ") + 13);
        

        sSavedMsg = sMyIssueSet + sYourIssueSet;
      }
      if ((sMessage.startsWith("type counter_offer")) || (sMessage.startsWith("type offer"))) {
        this.m_agent.saveAcceptedMsg(sSavedMsg);
      }
      break;
    case 7: 
      sFormattedMsg = "type response source " + this.m_agent.getAgentId() + " target " + this.m_agent.getOpponentAgentId() + " tag " + this.m_agent.getMsgId() + " answer DISAGREE" + " message " + sMsgBody + " reason ";
      






      break;
    case 8: 
      sFormattedMsg = "type opt-out tag " + this.m_agent.getMsgId();
      
      break;
    default: 
      System.out.println("[QO]ERROR: Invalid message kind: " + nMessageKind + " [QMessages::formatMessage(199)]");
      System.err.println("[QO]ERROR: Invalid message kind: " + nMessageKind + " [QMessages::formatMessage(199)]");
    }
    return sFormattedMsg;
  }
  
  public String parseMessage(String sServerLine)
  {
    String sParsedString = "";
    String sComment;
    if (sServerLine.startsWith("type comment"))
    {
      sComment = sServerLine.substring(sServerLine.indexOf(" body ") + 6);
    }
    else
    {
      String sThreat;
      if (sServerLine.startsWith("type threat"))
      {
        sThreat = sServerLine.substring(sServerLine.indexOf(" body ") + 6);
      }
      else if (sServerLine.startsWith("type endTurn"))
      {
        this.m_agent.incrementCurrentTurn();
      }
      else if (sServerLine.startsWith("type endNegotiation"))
      {
        this.m_agent.m_gtStopTurn.setRun(false);
        this.m_agent.m_gtStopNeg.setRun(false);
        
        String sEndNegDetails = sServerLine.substring(sServerLine.indexOf("whyEnded"));
        
        System.out.println("[QO]Negotiation Ended");
        System.err.println("[QO]Negotiation Ended");
        
        this.m_agent.endNegotiation();
      }
      else if (sServerLine.startsWith("type response"))
      {
        String sResponse = sServerLine.substring(sServerLine.indexOf("answer ") + 7, sServerLine.indexOf("reason") - 1);
        String sAnswerType = sResponse.substring(0, sResponse.indexOf(" "));
        String sMessage = sResponse.substring(sResponse.indexOf("message ") + 8);
        
        String sReason = sServerLine.substring(sServerLine.indexOf("reason ") + 7);
        if (sAnswerType.equals("AGREE"))
        {
          String sSavedMsg = "";
          if (sMessage.startsWith("type query"))
          {
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
          }
          else if (sMessage.startsWith("type counter_offer"))
          {
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
          }
          else if (sMessage.startsWith("type offer"))
          {
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
          }
          else if (sMessage.startsWith("type promise"))
          {
            String sPromise = sMessage.substring(sMessage.indexOf("myIssueSet ") + 11);
            String sMyIssueSet = sPromise.substring(0, sPromise.indexOf("yourIssueSet "));
            String sYourIssueSet = sPromise.substring(sPromise.indexOf("yourIssueSet ") + 13);
            

            sSavedMsg = sMyIssueSet + sYourIssueSet;
          }
          if ((sMessage.startsWith("type counter_offer")) || (sMessage.startsWith("type offer"))) {
            this.m_agent.saveAcceptedMsg(sSavedMsg);
          }
        }
        else if (sAnswerType.equals("DISAGREE"))
        {
          String sSavedMsg = "";
          int nMessageType = -1;
          if (sMessage.startsWith("type query"))
          {
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
            nMessageType = 5;
          }
          else if (sMessage.startsWith("type counter_offer"))
          {
            nMessageType = 3;
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
          }
          else if (sMessage.startsWith("type offer"))
          {
            nMessageType = 3;
            sSavedMsg = sMessage.substring(sMessage.indexOf("issueSet ") + 9);
          }
          else if (sMessage.startsWith("type promise"))
          {
            nMessageType = 4;
            String sPromise = sMessage.substring(sMessage.indexOf("myIssueSet ") + 11);
            String sMyIssueSet = sPromise.substring(0, sPromise.indexOf("yourIssueSet "));
            String sYourIssueSet = sPromise.substring(sPromise.indexOf("yourIssueSet ") + 13);
            

            sSavedMsg = sMyIssueSet + sYourIssueSet;
          }
          int[] CurrentAgreementIdx = new int[20];
          CurrentAgreementIdx = this.m_agent.getAgreementIndices(sSavedMsg);
          

          this.m_agent.updateOpponentProbability(CurrentAgreementIdx, nMessageType, 1);
        }
      }
      else if (sServerLine.startsWith("type registered"))
      {
        String sSecsForTurn = sServerLine.substring(sServerLine.indexOf("secForTurn ") + 11);
        StringTokenizer st = new StringTokenizer(sSecsForTurn);
        
        long lSecondsForTurn = Long.parseLong(st.nextToken());
        this.m_agent.setSecondsForTurn(lSecondsForTurn);
        
        String sMaxTurns = sServerLine.substring(sServerLine.indexOf("maxTurn ") + 8);
        st = new StringTokenizer(sMaxTurns);
        this.m_agent.setMaxTurns(Integer.parseInt(st.nextToken()));
        
        long lTotalSec = lSecondsForTurn;
        int nHours = (int)lTotalSec / 3600;
        
        lTotalSec -= nHours * 3600;
        int nMinutes = (int)lTotalSec / 60;
        
        lTotalSec -= nMinutes * 60;
        
        this.m_agent.m_gtStopTurn = new QGameTime(false, nHours, nMinutes, (int)lTotalSec, this.m_agent, true);
        this.m_agent.m_gtStopTurn.newGame();
        
        new Thread(this.m_agent.m_gtStopTurn).start();
        
        lTotalSec = lSecondsForTurn * this.m_agent.getMaxTurns();
        nHours = (int)lTotalSec / 3600;
        
        lTotalSec -= nHours * 3600;
        nMinutes = (int)lTotalSec / 60;
        
        lTotalSec -= nMinutes * 60;
        
        this.m_agent.m_gtStopNeg = new QGameTime(false, nHours, nMinutes, (int)lTotalSec, this.m_agent, false);
        this.m_agent.m_gtStopNeg.newGame();
        
        new Thread(this.m_agent.m_gtStopNeg).start();
        
        String sAgentID = sServerLine.substring(sServerLine.indexOf("agentID ") + 8);
        
        this.m_agent.setHasOpponent(true, sAgentID);
        
        this.m_agent.calculateFirstOffer();
      }
      else if (sServerLine.startsWith("type agentOptOut"))
      {
        this.m_agent.setHasOpponent(false, null);
        
        this.m_agent.m_gtStopTurn.setRun(false);
        this.m_agent.m_gtStopNeg.setRun(false);
      }
      else if (!sServerLine.equals("type log request error"))
      {
        if (!sServerLine.startsWith("type log response")) {
          if (sServerLine.startsWith("type query"))
          {
            StringTokenizer st = new StringTokenizer(sServerLine);
            
            boolean bFound = false;
            String sMsgId;
            while ((st.hasMoreTokens()) && (!bFound)) {
              if (st.nextToken().equals("tag"))
              {
                bFound = true;
                sMsgId = st.nextToken();
              }
            }
            String sQuery = sServerLine.substring(sServerLine.indexOf("issueSet ") + 9);
            
            int[] CurrentAgreementIdx = new int[20];
            CurrentAgreementIdx = this.m_agent.getAgreementIndices(sQuery);
            
            this.m_agent.calculateResponse(5, CurrentAgreementIdx, sServerLine);
          }
          else if (sServerLine.startsWith("type counter_offer"))
          {
            StringTokenizer st = new StringTokenizer(sServerLine);
            
            boolean bFound = false;
            String sMsgId;
            while ((st.hasMoreTokens()) && (!bFound)) {
              if (st.nextToken().equals("tag"))
              {
                bFound = true;
                sMsgId = st.nextToken();
              }
            }
            String sOffer = sServerLine.substring(sServerLine.indexOf("issueSet ") + 9);
            
            int[] CurrentAgreementIdx = new int[20];
            CurrentAgreementIdx = this.m_agent.getAgreementIndices(sOffer);
            this.m_agent.calculateResponse(9, CurrentAgreementIdx, sServerLine);
          }
          else if (sServerLine.startsWith("type offer"))
          {
            StringTokenizer st = new StringTokenizer(sServerLine);
            
            boolean bFound = false;
            String sMsgId;
            while ((st.hasMoreTokens()) && (!bFound)) {
              if (st.nextToken().equals("tag"))
              {
                bFound = true;
                sMsgId = st.nextToken();
              }
            }
            String sOffer = sServerLine.substring(sServerLine.indexOf("issueSet ") + 9);
            
            int[] CurrentAgreementIdx = new int[20];
            CurrentAgreementIdx = this.m_agent.getAgreementIndices(sOffer);
            
            this.m_agent.calculateResponse(3, CurrentAgreementIdx, sServerLine);
          }
          else if (sServerLine.startsWith("type promise"))
          {
            StringTokenizer st = new StringTokenizer(sServerLine);
            
            boolean bFound = false;
            String sMsgId;
            while ((st.hasMoreTokens()) && (!bFound)) {
              if (st.nextToken().equals("tag"))
              {
                bFound = true;
                sMsgId = st.nextToken();
              }
            }
            String sPromise = sServerLine.substring(sServerLine.indexOf("myIssueSet ") + 11);
            String sMyIssueSet = sPromise.substring(0, sPromise.indexOf("yourIssueSet "));
            String sYourIssueSet = sPromise.substring(sPromise.indexOf("yourIssueSet ") + 13);
            

            int[] CurrentAgreementIdxMine = new int[20];
            int[] CurrentAgreementIdxYours = new int[20];
            CurrentAgreementIdxMine = this.m_agent.getAgreementIndices(sMyIssueSet);
            CurrentAgreementIdxYours = this.m_agent.getAgreementIndices(sYourIssueSet);
            for (int i = 0; i < 20; i++) {
              if (CurrentAgreementIdxYours[i] != -1) {
                CurrentAgreementIdxMine[i] = CurrentAgreementIdxYours[i];
              }
            }
            this.m_agent.calculateResponse(4, CurrentAgreementIdxMine, sServerLine);
          }
          else if ((sServerLine.equals("nak")) || (sServerLine.equals("ack")))
          {
            sParsedString = sServerLine;
          }
          else
          {
            System.out.println("[QO]Unknown Message Error: " + sServerLine + " [QMessages::parseMessage(470)]");
            System.err.println("[QO]Unknown Message Error: " + sServerLine + " [QMessages::parseMessage(470)]");
            
            sParsedString = sServerLine;
          }
        }
      }
    }
    return sParsedString;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.QMessages
 * JD-Core Version:    0.7.1
 */