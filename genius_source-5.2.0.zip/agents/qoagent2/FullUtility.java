package agents.qoagent2;

import java.util.ArrayList;

public class FullUtility
{
  public double dTimeEffect;
  public double dStatusQuoValue;
  public double dOptOutValue;
  public ArrayList<UtilityDetails> lstUtilityDetails;
  
  public FullUtility()
  {
    this.dTimeEffect = 0.0D;
    this.dStatusQuoValue = 0.0D;
    this.dOptOutValue = 0.0D;
    this.lstUtilityDetails = new ArrayList();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.FullUtility
 * JD-Core Version:    0.7.1
 */