package agents.qoagent2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class QAgentType
{
  public static final double PRECISION_VALUE = 0.3D;
  public static final int VERY_SMALL_NUMBER = -9999;
  public static final int VERY_HIGH_NUMBER = 9999;
  public static final int LOWER_THAN_SQ_RET_VAL = -99990;
  public static final int MAX_ISSUES = 20;
  public static final int NO_VALUE = -1;
  public FullUtility m_fullUtility;
  private double m_dTypeProbability;
  private double m_dTotalAgreementsPoints;
  private double m_dTotalAgreementsPointsAboveSQ;
  private double m_dSQValue;
  private double m_dMaxValue;
  private double m_dBestAgreementValue;
  private double m_dWorstAgreementValue;
  private int[] m_MaxIssueValues;
  private int[] m_BestAgreementIdx;
  private int[] m_WorstAgreementIdx;
  private int m_nTotalAgreements;
  private int m_nType;
  public static final int NO_TYPE = -1;
  public static final int ENGLAND_TYPE = 0;
  public static final int ZIMBABWE_TYPE = 1;
  private Hashtable<String, Integer> m_mapAgreementToRanking;
  private boolean m_bEquilibriumAgent = false;
  private static final int BEST_OFFER_REMOVAL = 5;
  
  private class IdxToValue
  {
    public int[] AgreementIdx;
    public double dAgreementValue;
    
    IdxToValue()
    {
      this.dAgreementValue = 0.0D;
      this.AgreementIdx = new int[20];
    }
  }
  
  public QAgentType(boolean bEquilibriumAgent)
  {
    this.m_bEquilibriumAgent = bEquilibriumAgent;
    this.m_mapAgreementToRanking = new Hashtable();
    this.m_nType = -1;
    
    this.m_dBestAgreementValue = -9999.0D;
    this.m_dWorstAgreementValue = 9999.0D;
    
    this.m_fullUtility = new FullUtility();
    
    this.m_BestAgreementIdx = new int[20];
    this.m_WorstAgreementIdx = new int[20];
    this.m_MaxIssueValues = new int[20];
    this.m_nTotalAgreements = 0;
    for (int i = 0; i < 20; i++)
    {
      this.m_BestAgreementIdx[i] = -1;
      this.m_WorstAgreementIdx[i] = -1;
      this.m_MaxIssueValues[i] = -1;
    }
    this.m_dTotalAgreementsPoints = 0.0D;
    this.m_dTotalAgreementsPointsAboveSQ = 0.0D;
    this.m_dSQValue = -9999.0D;
    this.m_dMaxValue = 9999.0D;
    
    this.m_dTypeProbability = 0.3333333333333333D;
  }
  
  public int getIssuesNum()
  {
    int nIssuesNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      nIssuesNum += utilityDetails.lstUtilityIssues.size();
    }
    return nIssuesNum;
  }
  
  public int getMaxIssueValue(int nIssueNum)
  {
    return this.m_MaxIssueValues[nIssueNum];
  }
  
  public int getTotalAgreements()
  {
    return this.m_nTotalAgreements;
  }
  
  public void setAgentType(int nType)
  {
    this.m_nType = nType;
  }
  
  public double getSQValue()
  {
    return this.m_dSQValue;
  }
  
  public double getMaxValue()
  {
    return this.m_dMaxValue;
  }
  
  public void calculateValues(int nCurrentTurn)
  {
    this.m_dTotalAgreementsPoints = 0.0D;
    this.m_dTotalAgreementsPointsAboveSQ = 0.0D;
    
    double dAgreementValue = 0.0D;
    int nValuesNum = 0;
    

    this.m_dBestAgreementValue = -9999.0D;
    this.m_dWorstAgreementValue = 9999.0D;
    


    int nIssuesNum = getIssuesNum();
    
    int[] CurrentAgreementIdx = new int[nIssuesNum];
    for (int i = 0; i < nIssuesNum; i++)
    {
      this.m_BestAgreementIdx[i] = 0;
      this.m_WorstAgreementIdx[i] = 0;
      CurrentAgreementIdx[i] = 0;
    }
    if (this.m_nTotalAgreements == 0)
    {
      this.m_nTotalAgreements = 1;
      
      int nIssueNum = 0;
      for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
      {
        UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
        for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          
          nValuesNum = utilityIssue.lstUtilityValues.size();
          
          this.m_MaxIssueValues[nIssueNum] = nValuesNum;
          this.m_nTotalAgreements *= nValuesNum;
          
          nIssueNum++;
        }
      }
    }
    IdxToValue[] AgreementRankings = new IdxToValue[this.m_nTotalAgreements];
    for (int i = 0; i < this.m_nTotalAgreements; i++)
    {
      AgreementRankings[i] = new IdxToValue();
      
      dAgreementValue = getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
      if (dAgreementValue > this.m_dBestAgreementValue)
      {
        this.m_dBestAgreementValue = dAgreementValue;
        for (int k = 0; k < nIssuesNum; k++) {
          this.m_BestAgreementIdx[k] = CurrentAgreementIdx[k];
        }
      }
      if (dAgreementValue < this.m_dWorstAgreementValue)
      {
        this.m_dWorstAgreementValue = dAgreementValue;
        for (int k = 0; k < nIssuesNum; k++) {
          this.m_WorstAgreementIdx[k] = CurrentAgreementIdx[k];
        }
      }
      this.m_dTotalAgreementsPoints += dAgreementValue;
      




      double dTimeEffectForSQ = this.m_fullUtility.dTimeEffect;
      this.m_dSQValue = this.m_fullUtility.dStatusQuoValue;
      this.m_dSQValue = ((this.m_dSQValue + dTimeEffectForSQ * (nCurrentTurn - 1)) / 100.0D);
      double originalAgreementValue = Math.log(dAgreementValue) / 0.3D;
      if (originalAgreementValue > this.m_dSQValue) {
        this.m_dTotalAgreementsPointsAboveSQ += dAgreementValue;
      }
      boolean bFound = false;
      for (int nRankIdx = 0; (nRankIdx < i) && (!bFound); nRankIdx++) {
        if (AgreementRankings[nRankIdx].dAgreementValue > dAgreementValue)
        {
          for (int nInsertIdx = i; nInsertIdx > nRankIdx; nInsertIdx--)
          {
            for (int ind = 0; ind < CurrentAgreementIdx.length; ind++) {
              AgreementRankings[nInsertIdx].AgreementIdx[ind] = AgreementRankings[(nInsertIdx - 1)].AgreementIdx[ind];
            }
            AgreementRankings[nInsertIdx].dAgreementValue = AgreementRankings[(nInsertIdx - 1)].dAgreementValue;
          }
          for (int ind = 0; ind < CurrentAgreementIdx.length; ind++) {
            AgreementRankings[nRankIdx].AgreementIdx[ind] = CurrentAgreementIdx[ind];
          }
          AgreementRankings[nRankIdx].dAgreementValue = dAgreementValue;
          
          bFound = true;
        }
      }
      if (!bFound)
      {
        for (int ind = 0; ind < CurrentAgreementIdx.length; ind++) {
          AgreementRankings[i].AgreementIdx[ind] = CurrentAgreementIdx[ind];
        }
        AgreementRankings[i].dAgreementValue = dAgreementValue;
      }
      boolean bFinishUpdate = false;
      for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
        if (CurrentAgreementIdx[k] + 1 >= this.m_MaxIssueValues[k])
        {
          CurrentAgreementIdx[k] = 0;
        }
        else
        {
          CurrentAgreementIdx[k] += 1;
          bFinishUpdate = true;
        }
      }
    }
    for (int i = 0; i < this.m_nTotalAgreements; i++)
    {
      String sAgreement = getAgreementStr(AgreementRankings[i].AgreementIdx);
      this.m_mapAgreementToRanking.put(sAgreement, new Integer(i + 1));
    }
    int ind = AgreementRankings.length - 5 * nCurrentTurn;
    this.m_dMaxValue = AgreementRankings[ind].dAgreementValue;
  }
  
  public double calcRejectionProbabilities(String sRejectedMsg, int nCurrentTurn)
  {
    int nIssuesNum = getIssuesNum();
    int[] CurrentAgreementIdx = new int[nIssuesNum];
    for (int i = 0; i < nIssuesNum; i++) {
      CurrentAgreementIdx[i] = 0;
    }
    int nRanking = 0;
    
    int nMessageRanking = getAgreementRanking(sRejectedMsg);
    double dPrevTypeProbability = getTypeProbability();
    double dOfferValue = 0.0D;
    double dOffersSum = 0.0D;
    double dOfferProbability = 0.0D;
    for (int i = 0; i < this.m_nTotalAgreements; i++)
    {
      String sAgreement = getAgreementStr(CurrentAgreementIdx);
      
      nRanking = getAgreementRanking(sAgreement);
      if (nRanking > nMessageRanking)
      {
        dOfferValue = getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dOfferProbability = getAgreementLuceValue(dOfferValue, true);
        
        dOffersSum += dOfferProbability * dPrevTypeProbability;
      }
      boolean bFinishUpdate = false;
      for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
        if (CurrentAgreementIdx[k] + 1 >= this.m_MaxIssueValues[k])
        {
          CurrentAgreementIdx[k] = 0;
        }
        else
        {
          CurrentAgreementIdx[k] += 1;
          bFinishUpdate = true;
        }
      }
    }
    return dOffersSum;
  }
  
  public void printRankings()
  {
    int nIssuesNum = getIssuesNum();
    int[] CurrentAgreementIdx = new int[nIssuesNum];
    for (int i = 0; i < nIssuesNum; i++) {
      CurrentAgreementIdx[i] = 0;
    }
    int nRanking = 0;
    double dRankingProb = 0.0D;
    PrintWriter out = null;
    try
    {
      out = new PrintWriter(new FileWriter("test.txt"), true);
    }
    catch (IOException e)
    {
      System.out.println("Error opening test file [QAgentsType::printRankings(308)]");
      System.err.println("Error opening test file [QAgentsType::printRankings(308)]");
      e.printStackTrace();
    }
    out.println("Rank\tProb.\tAgr.");
    for (int i = 0; i < this.m_nTotalAgreements; i++)
    {
      String sAgreement = getAgreementStr(CurrentAgreementIdx);
      
      nRanking = getAgreementRanking(sAgreement);
      
      dRankingProb = getAgreementRankingProbability(CurrentAgreementIdx);
      
      out.println(nRanking + "\t" + dRankingProb + "\t" + sAgreement);
      

      boolean bFinishUpdate = false;
      for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
        if (CurrentAgreementIdx[k] + 1 >= this.m_MaxIssueValues[k])
        {
          CurrentAgreementIdx[k] = 0;
        }
        else
        {
          CurrentAgreementIdx[k] += 1;
          bFinishUpdate = true;
        }
      }
    }
    out.close();
  }
  
  public boolean isTypeOf(int nAgentType)
  {
    if (nAgentType == this.m_nType) {
      return true;
    }
    return false;
  }
  
  public double getBestAgreementValue(int nCurrentTurn)
  {
    return getAgreementValue(this.m_BestAgreementIdx, nCurrentTurn);
  }
  
  public String getBestAgreementStr()
  {
    return getAgreementStr(this.m_BestAgreementIdx);
  }
  
  public double getWorstAgreementValue(int nCurrentTurn)
  {
    return getAgreementValue(this.m_WorstAgreementIdx, nCurrentTurn);
  }
  
  public String getWorstAgreementStr()
  {
    return getAgreementStr(this.m_WorstAgreementIdx);
  }
  
  private int getAgreementRanking(String sAgreement)
  {
    int nRank = 0;
    
    Integer n = (Integer)this.m_mapAgreementToRanking.get(sAgreement);
    if (n != null) {
      nRank = n.intValue();
    } else {
      System.err.println("ERR");
    }
    return nRank;
  }
  
  public double getAgreementRankingProbability(int[] CurrentAgreementIdx)
  {
    String sAgreement = getAgreementStr(CurrentAgreementIdx);
    
    int nRank = getAgreementRanking(sAgreement);
    
    return nRank / this.m_nTotalAgreements;
  }
  
  public double getAgreementLuceValue(double dAgreementValue)
  {
    return dAgreementValue / this.m_dTotalAgreementsPointsAboveSQ;
  }
  
  public double getAgreementLuceValue(double dAgreementValue, boolean calculateProbability)
  {
    if (calculateProbability) {
      return dAgreementValue / this.m_dTotalAgreementsPoints;
    }
    return -99990.0D;
  }
  
  public double getAgreementValue(int[] CurrentAgreementIdx, int nCurrentTurn)
  {
    double dAttributeWeight = 0.0D;
    double dUtility = 0.0D;
    double dCurrentIssueValue = 0.0D;
    double dAgreementValue = 0.0D;
    
    boolean bAgreementHasValues = false;
    

    int nIssueNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
      {
        UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
        if (CurrentAgreementIdx[nIssueNum] != -1)
        {
          bAgreementHasValues = true;
          
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(CurrentAgreementIdx[nIssueNum]);
          
          dUtility = utilityValue.dUtility;
          





          dUtility += (nCurrentTurn - 1) * utilityValue.dTimeEffect;
        }
        else
        {
          dUtility = 0.0D;
        }
        dAttributeWeight = utilityIssue.dAttributeWeight;
        dCurrentIssueValue = dUtility * dAttributeWeight / 100.0D;
        dAgreementValue += dCurrentIssueValue;
        
        nIssueNum++;
      }
    }
    double dTimeEffect = this.m_fullUtility.dTimeEffect;
    




    dAgreementValue += dTimeEffect * (nCurrentTurn - 1) / 100.0D;
    if (!bAgreementHasValues) {
      dAgreementValue = -9999.0D;
    }
    if (!this.m_bEquilibriumAgent) {
      dAgreementValue = Math.exp(dAgreementValue * 0.3D);
    }
    return dAgreementValue;
  }
  
  public String getAgreementStr(int[] CurrentAgreementIdx)
  {
    String sAgreementStr = "";
    String sCurrentIssueName = "";
    String sCurrentIssueValue = "";
    

    int nIssueNum = 0;
    for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++)
      {
        UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
        if (CurrentAgreementIdx[nIssueNum] != -1)
        {
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(CurrentAgreementIdx[nIssueNum]);
          
          sCurrentIssueValue = utilityValue.sValue;
          sCurrentIssueName = utilityIssue.sAttributeName;
          
          sAgreementStr = sAgreementStr + sCurrentIssueValue + "*" + sCurrentIssueName + "*";
        }
        nIssueNum++;
      }
    }
    return sAgreementStr;
  }
  
  public boolean isIssueValueNoAgreement(int nIssueNum, int nIssueNumIdx)
  {
    String sIssueValue = getIssueValueStr(nIssueNum, nIssueNumIdx);
    if (sIssueValue.equals("No agreement")) {
      return true;
    }
    return false;
  }
  
  private String getIssueValueStr(int nIssueNum, int nIssueNumIdx)
  {
    String sIssueValueStr = "";
    

    int nCurrentIssueNum = 0;
    boolean bFound = false;
    for (int i = 0; (i < this.m_fullUtility.lstUtilityDetails.size()) && (!bFound); i++)
    {
      UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
      for (int j = 0; j < utilityDetails.lstUtilityIssues.size(); j++) {
        if ((nCurrentIssueNum == nIssueNum) && (!bFound))
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          
          UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(nIssueNumIdx);
          
          sIssueValueStr = utilityValue.sValue;
          bFound = true;
        }
        else
        {
          nCurrentIssueNum++;
        }
      }
    }
    return sIssueValueStr;
  }
  
  public void setTypeProbability(double dProbability)
  {
    this.m_dTypeProbability = dProbability;
  }
  
  public double getTypeProbability()
  {
    return this.m_dTypeProbability;
  }
  
  public int[] getAgreementIndices(String sAgreementStr)
  {
    sAgreementStr = sAgreementStr.trim();
    
    int[] CurrentAgreementIdx = new int[20];
    for (int i = 0; i < 20; i++) {
      CurrentAgreementIdx[i] = -1;
    }
    int nIssueNum = 0;
    boolean bFoundIssue = false;boolean bFoundValue = false;
    String sCurrentIssueName = "";
    String sCurrentIssueValue = "";
    

    StringTokenizer st = new StringTokenizer(sAgreementStr, "*");
    while (st.hasMoreTokens())
    {
      sCurrentIssueValue = st.nextToken();
      if (!st.hasMoreTokens())
      {
        System.out.println("[QO]ERROR: Invalid agreement structure: " + sAgreementStr + " [QAgentType::getAgreementIndices(660)]");
        System.err.println("[QO]ERROR: Invalid agreement structure: " + sAgreementStr + " [QAgentType::getAgreementIndices(660)]");
        return null;
      }
      sCurrentIssueName = st.nextToken();
      

      nIssueNum = 0;
      bFoundIssue = false;
      bFoundValue = false;
      for (int i = 0; i < this.m_fullUtility.lstUtilityDetails.size(); i++)
      {
        UtilityDetails utilityDetails = (UtilityDetails)this.m_fullUtility.lstUtilityDetails.get(i);
        for (int j = 0; (j < utilityDetails.lstUtilityIssues.size()) && (!bFoundIssue); j++)
        {
          UtilityIssue utilityIssue = (UtilityIssue)utilityDetails.lstUtilityIssues.get(j);
          if (utilityIssue.sAttributeName.equals(sCurrentIssueName))
          {
            bFoundIssue = true;
            for (int k = 0; (k < utilityIssue.lstUtilityValues.size()) && (!bFoundValue); k++)
            {
              UtilityValue utilityValue = (UtilityValue)utilityIssue.lstUtilityValues.get(k);
              if (utilityValue.sValue.equals(sCurrentIssueValue))
              {
                bFoundValue = true;
                
                CurrentAgreementIdx[nIssueNum] = k;
              }
            }
          }
          nIssueNum++;
        }
      }
    }
    return CurrentAgreementIdx;
  }
  
  public void printValuesToFile(String sSourceFileName)
  {
    PrintWriter pw = null;
    try
    {
      pw = new PrintWriter(new FileWriter("values.txt", true));
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    pw.println("------------" + sSourceFileName + "----------");
    
    double dAgreementValue = 0.0D;
    
    int nIssuesNum = getIssuesNum();
    
    int[] CurrentAgreementIdx = new int[nIssuesNum];
    for (int i = 0; i < nIssuesNum; i++) {
      CurrentAgreementIdx[i] = 0;
    }
    for (int i = 0; i < this.m_nTotalAgreements; i++)
    {
      dAgreementValue = getAgreementValue(CurrentAgreementIdx, 1);
      
      pw.println(dAgreementValue);
      

      boolean bFinishUpdate = false;
      for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
        if (CurrentAgreementIdx[k] + 1 >= this.m_MaxIssueValues[k])
        {
          CurrentAgreementIdx[k] = 0;
        }
        else
        {
          CurrentAgreementIdx[k] += 1;
          bFinishUpdate = true;
        }
      }
    }
    pw.close();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.QAgentType
 * JD-Core Version:    0.7.1
 */