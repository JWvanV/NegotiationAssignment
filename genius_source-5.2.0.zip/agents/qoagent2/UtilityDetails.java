package agents.qoagent2;

import java.util.ArrayList;

public class UtilityDetails
{
  public String sTitle;
  public ArrayList lstUtilityIssues;
  
  public UtilityDetails()
  {
    this.sTitle = "";
    this.lstUtilityIssues = new ArrayList();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.UtilityDetails
 * JD-Core Version:    0.7.1
 */