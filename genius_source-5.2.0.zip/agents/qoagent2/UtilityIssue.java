package agents.qoagent2;

import java.util.ArrayList;

public class UtilityIssue
{
  public String sAttributeName;
  public String sSide;
  public double dAttributeWeight;
  public String sExplanation;
  public ArrayList<UtilityValue> lstUtilityValues;
  
  public UtilityIssue()
  {
    this.sSide = "";
    this.sAttributeName = "";
    this.dAttributeWeight = 0.0D;
    this.sExplanation = "";
    this.lstUtilityValues = new ArrayList();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.UtilityIssue
 * JD-Core Version:    0.7.1
 */