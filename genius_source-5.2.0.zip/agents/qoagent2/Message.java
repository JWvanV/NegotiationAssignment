package agents.qoagent2;

class Message
{
  private String m_sID;
  private String m_sBody;
  
  public Message(String id, String body)
  {
    this.m_sID = id;
    this.m_sBody = body;
  }
  
  public void setId(String id)
  {
    this.m_sID = id;
  }
  
  public void setBody(String body)
  {
    this.m_sBody = body;
  }
  
  public String getId()
  {
    return this.m_sID;
  }
  
  public String getBody()
  {
    return this.m_sBody;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.Message
 * JD-Core Version:    0.7.1
 */