package agents.qoagent2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class QOAgent
{
  static final double OFFERS_VALUE_THRESHOLD = 0.05D;
  public static final String NOT_APPLICABLE_STR1 = "No agreement";
  static final String AGENT_NAME = "Automated_Agent";
  static final String AGENT_ID = "000000";
  private agents.QOAgent m_Agent;
  private String m_sAgentSide;
  private String m_sAgentName;
  private String m_sAgentId;
  private String m_sSupportMediator;
  private String m_sLogFileName;
  private String m_sProbFileName;
  private String m_sOppAgentId;
  private int m_nMaxTurns;
  private int m_nCurrentTurn;
  private int m_nMsgId;
  private boolean m_bHasOpponent;
  private long m_lSecondsForTurn;
  private QMessages m_messages;
  public QGameTime m_gtStopTurn;
  public QGameTime m_gtStopNeg;
  private QAgentsCore m_AgentCore;
  private QAgentType m_AgentType;
  private QAgentType m_AgentTypeNextTurn;
  private int[] m_PreviosAcceptedOffer;
  private boolean m_bSendOffer;
  private boolean m_bEquilibriumAgent = false;
  private boolean m_bCalculateForAllAgents;
  
  public QOAgent(agents.QOAgent pAgent, String sSide, String sSupportMediator, String sName, String sId)
  {
    this.m_Agent = pAgent;
    this.m_sLogFileName = "";
    this.m_bSendOffer = true;
    this.m_bEquilibriumAgent = false;
    this.m_bCalculateForAllAgents = false;
    this.m_PreviosAcceptedOffer = new int[20];
    for (int i = 0; i < 20; i++) {
      this.m_PreviosAcceptedOffer[i] = -1;
    }
    if (sName.equals("")) {
      sName = "Automated_Agent";
    }
    if (sId.equals("")) {
      sId = "000000";
    }
    this.m_messages = new QMessages(this);
    
    this.m_sAgentSide = sSide;
    
    this.m_sSupportMediator = sSupportMediator;
    this.m_sAgentName = sName;
    this.m_sAgentId = sId;
    
    setHasOpponent(false, null);
    setMaxTurns(0);
    setCurrentTurn(1);
    
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy.H.mm.ss");
    Date now = new Date();
    String sNow = formatter.format(now);
    
    this.m_sLogFileName = ("logs\\QOData" + sNow + ".log");
    this.m_sProbFileName = ("logs\\prob" + sNow + ".");
    this.m_AgentCore = new QAgentsCore(this.m_sLogFileName, sNow, this.m_Agent);
    if (this.m_sAgentSide.equals("Zimbabwe")) {
      this.m_AgentType = this.m_AgentCore.getZimbabweShortTermType();
    } else if (this.m_sAgentSide.equals("England")) {
      this.m_AgentType = this.m_AgentCore.getEnglandShortTermType();
    }
    this.m_AgentType.calculateValues(this.m_nCurrentTurn);
    this.m_AgentTypeNextTurn = this.m_AgentType;
    this.m_AgentTypeNextTurn.calculateValues(this.m_nCurrentTurn + 1);
    
    this.m_AgentCore.initGenerateAgreement(this.m_AgentType);
  }
  
  public QOAgent(agents.QOAgent pAgent, boolean bIsEquilibriumAgent, String sSide, String sSupportMediator, String sName, String sId)
  {
    this.m_Agent = pAgent;
    this.m_sLogFileName = "";
    this.m_bSendOffer = true;
    this.m_bEquilibriumAgent = bIsEquilibriumAgent;
    this.m_bCalculateForAllAgents = false;
    this.m_PreviosAcceptedOffer = new int[20];
    for (int i = 0; i < 20; i++) {
      this.m_PreviosAcceptedOffer[i] = -1;
    }
    if (sName.equals("")) {
      sName = "Automated_Agent";
    }
    if (sId.equals("")) {
      sId = "000000";
    }
    this.m_messages = new QMessages(this);
    
    this.m_sAgentSide = sSide;
    
    this.m_sSupportMediator = sSupportMediator;
    this.m_sAgentName = sName;
    this.m_sAgentId = sId;
    
    setHasOpponent(false, null);
    setMaxTurns(0);
    setCurrentTurn(1);
    
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy.H.mm.ss");
    Date now = new Date();
    String sNow = formatter.format(now);
    
    this.m_sLogFileName = ("logs\\QOData" + sNow + ".log");
    this.m_sProbFileName = ("logs\\prob" + sNow + ".");
    this.m_AgentCore = new QAgentsCore(this.m_sLogFileName, sNow, this.m_bEquilibriumAgent, this.m_Agent);
    if (this.m_sAgentSide.equals("Zimbabwe")) {
      this.m_AgentType = this.m_AgentCore.getZimbabweShortTermType();
    } else if (this.m_sAgentSide.equals("England")) {
      this.m_AgentType = this.m_AgentCore.getEnglandShortTermType();
    }
    this.m_AgentType.calculateValues(this.m_nCurrentTurn);
    this.m_AgentTypeNextTurn = this.m_AgentType;
    this.m_AgentTypeNextTurn.calculateValues(this.m_nCurrentTurn + 1);
    
    this.m_AgentCore.initGenerateAgreement(this.m_AgentType);
  }
  
  public void setEquilibriumAgent(boolean bIsEquilibriumAgent)
  {
    this.m_bEquilibriumAgent = bIsEquilibriumAgent;
  }
  
  public void setCalculateEquilibriumForAllAgents(boolean bCalculateForAllAgents)
  {
    this.m_bCalculateForAllAgents = bCalculateForAllAgents;
  }
  
  public String getAgentName()
  {
    return this.m_sAgentName;
  }
  
  public String getAgentSide()
  {
    return this.m_sAgentSide;
  }
  
  public String getAgentId()
  {
    return this.m_sAgentId;
  }
  
  public void receivedMessage(String sMessage)
  {
    String sParsedMsg = this.m_messages.parseMessage(sMessage);
    String sRegister;
    if (sParsedMsg.equals("nak"))
    {
      setMsgId(1);
      generateId();
      sRegister = this.m_messages.formatMessage(0, this.m_sAgentId);
    }
  }
  
  public void printMessageToServer(String sMessage) {}
  
  public void endNegotiation()
  {
    this.m_bSendOffer = false;
    


    PrintWriter bw = null;
    try
    {
      bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
      bw.println("Final Probabilities:");
      bw.println(getOpponentsProbabilitStr());
      bw.close();
      if (this.m_AgentType.isTypeOf(0))
      {
        bw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Zim.txt", true));
        bw.println("Final Probabilities:");
        bw.println(getOpponentsProbabilitStr());
        bw.close();
      }
      else if (this.m_AgentType.isTypeOf(1))
      {
        bw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Eng.txt", true));
        bw.println("Final Probabilities: " + getOpponentsProbabilitStr());
        bw.close();
      }
    }
    catch (IOException e)
    {
      System.out.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::endNegotiation(245)]");
      System.err.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::endNegotiation(245)]");
    }
  }
  
  public void setHasOpponent(boolean bHasOpponent, String sOppId)
  {
    this.m_bHasOpponent = bHasOpponent;
    if (this.m_bHasOpponent)
    {
      setOpponentAgentId(sOppId);
      try
      {
        PrintWriter bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
        bw.println("QO Side: " + this.m_sAgentSide);
        bw.println("Opponent ID: " + sOppId);
        bw.close();
      }
      catch (IOException e)
      {
        System.out.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::setHasOpponent(266)]");
        System.err.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::setHasOpponent(266)]");
      }
    }
    else
    {
      setOpponentAgentId("");
    }
  }
  
  public void setOpponentAgentId(String sOppId)
  {
    this.m_sOppAgentId = sOppId;
  }
  
  public String getOpponentAgentId()
  {
    return this.m_sOppAgentId;
  }
  
  public void setSecondsForTurn(long lSeconds)
  {
    this.m_lSecondsForTurn = lSeconds;
  }
  
  public long getSecondsForTurn()
  {
    return this.m_lSecondsForTurn;
  }
  
  public String getSupportMediator()
  {
    return "no";
  }
  
  public int getMaxTurns()
  {
    return this.m_nMaxTurns;
  }
  
  public void setMaxTurns(int nMaxTurns)
  {
    this.m_nMaxTurns = nMaxTurns;
  }
  
  public int getCurrentTurn()
  {
    return this.m_nCurrentTurn;
  }
  
  public void setCurrentTurn(int nCurrentTurn)
  {
    this.m_nCurrentTurn = nCurrentTurn;
  }
  
  public void incrementCurrentTurn()
  {
    this.m_nCurrentTurn += 1;
    this.m_bSendOffer = true;
    updateAgreementsValues();
    
    double dNextAgreementValue = 0.0D;
    double dAcceptedAgreementValue = 0.0D;
    String sQOAgreement = "";
    String sEquilibriumAgreement = "";
    String sOffer = "";
    if (this.m_bEquilibriumAgent)
    {
      if (this.m_nCurrentTurn == this.m_nMaxTurns)
      {
        this.m_bSendOffer = false;
        return;
      }
      this.m_AgentCore.calculateEquilibriumAgreement(this.m_AgentType, this.m_nMaxTurns, this.m_bCalculateForAllAgents, this.m_nCurrentTurn);
      
      sEquilibriumAgreement = this.m_AgentCore.getEquilibriumAgreement();
      sOffer = this.m_messages.formatMessage(3, sEquilibriumAgreement);
      


      int[] nextAgreementIndices = new int[20];
      nextAgreementIndices = getAgreementIndices(sEquilibriumAgreement);
      
      dNextAgreementValue = this.m_AgentType.getAgreementValue(nextAgreementIndices, this.m_nCurrentTurn);
      dAcceptedAgreementValue = this.m_AgentType.getAgreementValue(this.m_PreviosAcceptedOffer, this.m_nCurrentTurn);
      
      System.err.println("~~~~~~~~~~~~~~~~~~~~~");
      System.err.println("Accepted Agreement Value for Agent: " + dAcceptedAgreementValue);
      System.err.println("~~~~~~~~~~~~~~~~~~~~~");
    }
    else
    {
      this.m_AgentCore.calculateAgreement(this.m_AgentType, this.m_nCurrentTurn);
      

      sQOAgreement = this.m_AgentCore.getQOAgreement();
      sOffer = this.m_messages.formatMessage(3, sQOAgreement);
      


      int[] nextAgreementIndices = new int[20];
      nextAgreementIndices = getAgreementIndices(sQOAgreement);
      
      dNextAgreementValue = this.m_AgentType.getAgreementValue(nextAgreementIndices, this.m_nCurrentTurn);
      dAcceptedAgreementValue = this.m_AgentType.getAgreementValue(this.m_PreviosAcceptedOffer, this.m_nCurrentTurn);
      
      System.err.println("~~~~~~~~~~~~~~~~~~~~~");
      System.err.println("Accepted Agreement Value for Agent: " + dAcceptedAgreementValue);
      System.err.println("~~~~~~~~~~~~~~~~~~~~~");
    }
    if (dAcceptedAgreementValue >= dNextAgreementValue) {
      this.m_bSendOffer = false;
    }
    if (this.m_bSendOffer) {
      this.m_Agent.prepareAction(3, sOffer);
    }
  }
  
  public void calculateFirstOffer()
  {
    this.m_bSendOffer = true;
    
    String sQOAgreement = "";
    String sEquilibriumAgreement = "";
    String sOffer = "";
    if (this.m_bEquilibriumAgent)
    {
      this.m_AgentCore.calculateEquilibriumAgreement(this.m_AgentType, this.m_nMaxTurns, this.m_bCalculateForAllAgents, this.m_nCurrentTurn);
      
      sEquilibriumAgreement = this.m_AgentCore.getEquilibriumAgreement();
      sOffer = this.m_messages.formatMessage(3, sEquilibriumAgreement);
    }
    else
    {
      this.m_AgentCore.calculateAgreement(this.m_AgentType, this.m_nCurrentTurn);
      

      sQOAgreement = this.m_AgentCore.getQOAgreement();
      sOffer = this.m_messages.formatMessage(3, sQOAgreement);
    }
    if (this.m_bSendOffer) {
      this.m_Agent.prepareAction(3, sOffer);
    }
  }
  
  public boolean getIsOfferToSend()
  {
    return this.m_bSendOffer;
  }
  
  public void updateAgreementsValues()
  {
    this.m_AgentType.calculateValues(this.m_nCurrentTurn);
    this.m_AgentTypeNextTurn.calculateValues(this.m_nCurrentTurn + 1);
    
    this.m_AgentCore.updateAgreementsValues(this.m_nCurrentTurn);
  }
  
  public int getMsgId()
  {
    return this.m_nMsgId;
  }
  
  public void setMsgId(int nMsgId)
  {
    this.m_nMsgId = nMsgId;
  }
  
  public void incrementMsgId()
  {
    this.m_nMsgId += 1;
  }
  
  public void generateId()
  {
    Random rn = new Random();
    
    int nRandomAgentId = rn.nextInt();
    nRandomAgentId = Math.abs(nRandomAgentId);
    

    String sAgentId = new Integer(nRandomAgentId).toString();
    this.m_sAgentId = sAgentId;
  }
  
  public void register()
  {
    setMsgId(1);
    String sRegister = this.m_messages.formatMessage(0, this.m_sAgentId);
  }
  
  public void sendBestAgreement()
  {
    String sBestAgreement = this.m_AgentType.getBestAgreementStr();
    




    this.m_Agent.prepareAction(3, sBestAgreement);
  }
  
  public int[] getAgreementIndices(String sAgreementStr)
  {
    return this.m_AgentType.getAgreementIndices(sAgreementStr);
  }
  
  public void calculateResponse(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage)
  {
    System.err.println("Is Equ. Agent? " + this.m_bEquilibriumAgent);
    if (this.m_bEquilibriumAgent)
    {
      calculateEquilibriumResponse(nMessageType, CurrentAgreementIdx, sOriginalMessage);
      
      return;
    }
    for (int i = 0; i < 20; i++) {
      if (CurrentAgreementIdx[i] == -1) {
        CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
      } else if (this.m_AgentType.isIssueValueNoAgreement(i, CurrentAgreementIdx[i])) {
        if (this.m_PreviosAcceptedOffer[i] != -1) {
          CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
        }
      }
    }
    this.m_AgentCore.updateOpponentProbability(CurrentAgreementIdx, this.m_nCurrentTurn, nMessageType, 0);
    

    double dOppOfferValueForAgent = -9999.0D;
    double dQONextOfferValueForAgent = -9999.0D;
    
    double dOppOfferValueForOpponent = -9999.0D;
    double dQONextOfferValueForOpponent = -9999.0D;
    


    dOppOfferValueForAgent = this.m_AgentType.getAgreementValue(CurrentAgreementIdx, this.m_nCurrentTurn);
    

    double dAcceptedAgreementValue = this.m_AgentType.getAgreementValue(this.m_PreviosAcceptedOffer, this.m_nCurrentTurn);
    
    System.err.println("~~~~~~~~~~~~~~~~~~~~");
    System.err.println("Opponent Offer Value for Agent: " + dOppOfferValueForAgent);
    System.err.println("Accepted Agreement Value for Agent: " + dAcceptedAgreementValue);
    if (dAcceptedAgreementValue >= dOppOfferValueForAgent)
    {
      this.m_Agent.prepareAction(7, sOriginalMessage);
      return;
    }
    this.m_AgentCore.calculateNextTurnAgreement(this.m_AgentTypeNextTurn, this.m_nCurrentTurn + 1);
    dQONextOfferValueForAgent = this.m_AgentCore.getNextTurnAgentQOUtilityValue();
    
    System.err.println("Next Turn Offer Value for Agent: " + dQONextOfferValueForAgent);
    System.err.println("Next Turn Offer: " + this.m_AgentCore.getNextTurnAgentQOAgreement());
    System.err.println("~~~~~~~~~~~~~~~~~~~~");
    if (dOppOfferValueForAgent >= dQONextOfferValueForAgent)
    {
      try
      {
        PrintWriter bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
        bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        bw.println("Accepted offer: val (" + dOppOfferValueForAgent + ") >= QO_Next (" + dQONextOfferValueForAgent + ")");
        bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        bw.close();
      }
      catch (IOException e)
      {
        System.out.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateResponse(605)]");
        System.err.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateResponse(605)]");
      }
      this.m_Agent.prepareAction(6, sOriginalMessage);
      
      this.m_bSendOffer = false;
    }
    else
    {
      QAgentType opponentNextTurnAgentType = this.m_AgentCore.getNextTurnOpponentType();
      
      dOppOfferValueForOpponent = opponentNextTurnAgentType.getAgreementValue(CurrentAgreementIdx, this.m_nCurrentTurn + 1);
      dQONextOfferValueForOpponent = this.m_AgentCore.getNextTurnOpponentQOUtilityValue();
      
      double dValueDifference = Math.abs(dOppOfferValueForOpponent - dQONextOfferValueForOpponent);
      if (dValueDifference <= 0.05D)
      {
        this.m_Agent.prepareAction(7, sOriginalMessage);
      }
      else
      {
        Random generator = new Random();
        double dRandNum = generator.nextDouble();
        
        System.err.println("Rand num = " + dRandNum);
        


        double dOfferProbabilityValue = this.m_AgentType.getAgreementRankingProbability(CurrentAgreementIdx);
        System.err.println("Agreement ranking prob. = " + dOfferProbabilityValue);
        


        boolean accept = true;
        double dSQValue = this.m_AgentType.getSQValue();
        double dAgreementValue = this.m_AgentType.getAgreementValue(CurrentAgreementIdx, this.m_nCurrentTurn);
        
        double originalAgreementValue = Math.log(dAgreementValue) / 0.3D;
        if (originalAgreementValue < dSQValue) {
          accept = false;
        }
        if (!accept)
        {
          System.out.println("====Agreement will not be accepted, lower than SQ");
          System.err.println("====Agreement will not be accepted, lower than SQ");
        }
        try
        {
          PrintWriter bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
          bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
          bw.println("Using probability to decide whether to accept:");
          bw.println("Agreement ranking prob. = " + dOfferProbabilityValue);
          bw.println("Rand num = " + dRandNum);
          bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
          bw.close();
        }
        catch (IOException e)
        {
          System.out.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateResponse(605)]");
          System.err.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateResponse(605)]");
        }
        if ((dRandNum <= dOfferProbabilityValue) && (accept))
        {
          this.m_Agent.prepareAction(6, sOriginalMessage);
          


          this.m_bSendOffer = false;
        }
        else
        {
          this.m_Agent.prepareAction(7, sOriginalMessage);
        }
      }
    }
  }
  
  public void calculateEquilibriumResponse(int nMessageType, int[] CurrentAgreementIdx, String sOriginalMessage)
  {
    for (int i = 0; i < 20; i++) {
      if (CurrentAgreementIdx[i] == -1) {
        CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
      } else if (this.m_AgentType.isIssueValueNoAgreement(i, CurrentAgreementIdx[i])) {
        if (this.m_PreviosAcceptedOffer[i] != -1) {
          CurrentAgreementIdx[i] = this.m_PreviosAcceptedOffer[i];
        }
      }
    }
    this.m_AgentCore.updateOpponentProbability(CurrentAgreementIdx, this.m_nCurrentTurn, nMessageType, 0);
    

    double dOppOfferValueForAgent = -9999.0D;
    double dEquilibriumNextOfferValueForAgent = -9999.0D;
    
    double dOppOfferValueForOpponent = -9999.0D;
    double dEquilibriumNextOfferValueForOpponent = -9999.0D;
    


    dOppOfferValueForAgent = this.m_AgentType.getAgreementValue(CurrentAgreementIdx, this.m_nCurrentTurn);
    

    double dAcceptedAgreementValue = this.m_AgentType.getAgreementValue(this.m_PreviosAcceptedOffer, this.m_nCurrentTurn);
    
    System.err.println("~~~~~~~~~~~~~~~~~~~~");
    System.err.println("Opponent Offer Value for Agent: " + dOppOfferValueForAgent);
    System.err.println("Accepted Agreement Value for Agent: " + dAcceptedAgreementValue);
    if (dAcceptedAgreementValue >= dOppOfferValueForAgent)
    {
      this.m_Agent.prepareAction(7, sOriginalMessage);
      

      return;
    }
    this.m_AgentCore.calculateNextTurnEquilibriumAgreement(this.m_AgentTypeNextTurn, this.m_nMaxTurns, this.m_bCalculateForAllAgents, this.m_nCurrentTurn + 1);
    dEquilibriumNextOfferValueForAgent = this.m_AgentCore.getNextTurnAgentEquilibriumUtilityValue();
    
    System.err.println("Next Turn Offer Value for Agent: " + dEquilibriumNextOfferValueForAgent);
    System.err.println("Next Turn Offer: " + this.m_AgentCore.getNextTurnAgentEquilibriumAgreement());
    System.err.println("~~~~~~~~~~~~~~~~~~~~");
    if (dOppOfferValueForAgent >= dEquilibriumNextOfferValueForAgent)
    {
      try
      {
        PrintWriter bw = new PrintWriter(new FileWriter(this.m_sLogFileName, true));
        bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        bw.println("Accepted offer: val (" + dOppOfferValueForAgent + ") >= QO_Next (" + dEquilibriumNextOfferValueForAgent + ")");
        bw.println("^^^^^^^^^^^^^^^^^^^^^^^^^^^");
        bw.close();
      }
      catch (IOException e)
      {
        System.out.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateEquilibriumResponse(605)]");
        System.err.println("[QO]ERROR----Error opening logfile: " + e.getMessage() + " [QOAgent::calculateEquilibriumResponse(605)]");
      }
      this.m_Agent.prepareAction(6, sOriginalMessage);
      


      this.m_bSendOffer = false;
    }
    else
    {
      this.m_Agent.prepareAction(7, sOriginalMessage);
    }
  }
  
  public void saveAcceptedMsg(String sMessage)
  {
    this.m_PreviosAcceptedOffer = getAgreementIndices(sMessage);
    if (this.m_PreviosAcceptedOffer == null) {
      this.m_PreviosAcceptedOffer = new int[20];
    }
  }
  
  public String getOpponentsProbabilitStr()
  {
    if (this.m_AgentType.isTypeOf(0)) {
      return this.m_AgentCore.getZimbabweProbabilitiesStr();
    }
    if (this.m_AgentType.isTypeOf(1)) {
      return this.m_AgentCore.getEnglandProbabilitiesStr();
    }
    return "";
  }
  
  public void updateOpponentProbability(int[] CurrentAgreementIdx, int nMessageType, int nResponseType)
  {
    this.m_AgentCore.updateOpponentProbability(CurrentAgreementIdx, this.m_nCurrentTurn, nMessageType, nResponseType);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.QOAgent
 * JD-Core Version:    0.7.1
 */