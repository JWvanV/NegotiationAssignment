package agents.qoagent2;

import agents.QOAgent;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Random;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class QAgentsCore
{
  public static final String COMMENT_CHAR_STR = "#";
  public static final String ISSUE_HEADER_STR = "!";
  public static final String ISSUE_SEPARATOR_STR = "*";
  public static final String VALUES_UTILITY_SEPARATOR_STR = " ";
  public static final String VALUES_NAMES_SEPARATOR_STR = "~";
  public static final String GENERAL_DATA_SEPARATOR_STR = "@";
  public static final String TIME_EFFECT_STR = "Time-Effect";
  public static final String OPT_OUT_STR = "Opt-Out";
  public static final String STATUS_QUO_STR = "Status-Quo";
  public static final int TIME_EFFECT_IND = 0;
  public static final int OPT_OUT_IND = 1;
  public static final int STATUS_QUO_IND = 2;
  public static final int GENERAL_VALUES_NUM = 3;
  public static final int LONG_TERM_TYPE_IDX = 0;
  public static final int SHORT_TERM_TYPE_IDX = 1;
  public static final int COMPROMISE_TYPE_IDX = 2;
  public static final int AGENT_TYPES_NUM = 3;
  private ArrayList<QAgentType> m_EnglandAgentTypesList;
  private ArrayList<QAgentType> m_ZimbabweAgentTypesList;
  private ArrayList<QAgentType> m_EnglandAgentTypesNextTurnList;
  private ArrayList<QAgentType> m_ZimbabweAgentTypesNextTurnList;
  private QAgentType m_CurrentAgentType;
  private QAgentType m_CurrentAgentNextTurnType;
  private int m_nNextTurnOppType;
  private String m_sLogFileName;
  private String m_sProbFileName;
  private QGenerateAgreement m_GenerateAgreement;
  private boolean m_bEquilibriumAgent = false;
  private QOAgent m_Agent;
  
  public class QGenerateAgreement
  {
    private double m_dQOValue;
    private double m_dNextTurnQOValue;
    private double m_dAgentSelectedValue;
    private double m_dAgentSelectedNextTurnValue;
    private double m_dOppSelectedValue;
    private double m_dOppSelectedNextTurnValue;
    private double[] m_dFirstEquilibriumValue;
    private double[] m_dFirstEquilibriumValueNextTurn;
    private double[] m_dSecondEquilibriumValue;
    private double[] m_dSecondEquilibriumValueNextTurn;
    private double m_dEquilibriumValue;
    private double m_dNextTurnEquilibriumValue;
    private double m_dNextTurnCurrentAgentValueForEqOffer;
    private String m_sAgreement;
    private String m_sNextTurnAgreement;
    private String[] m_sFirstEquilibriumAgreement;
    private String[] m_sFirstEquilibriumAgreementNextTurn;
    private String[] m_sSecondEquilibriumAgreement;
    private String[] m_sSecondEquilibriumAgreementNextTurn;
    private String m_sEquilibriumAgreement;
    private String m_sNextTurnEquilibriumAgreement;
    private boolean m_bCalcNashAgreement;
    private double m_dBelievedThreshold;
    public static final double BELIEVED_THRESHOLD_VAR = 0.1D;
    public static final boolean CALC_NASH_AGREEMENT_VAR = false;
    public static final int FIRST_EQUILIBRIUM = 1;
    public static final int SECOND_EQUILIBRIUM = 2;
    private static final int OFFER_SET_SIZE = 4;
    
    public QGenerateAgreement()
    {
      this.m_dQOValue = -9999.0D;
      this.m_dNextTurnQOValue = -9999.0D;
      
      QAgentsCore.this.m_nNextTurnOppType = -1;
      
      this.m_sAgreement = "";
      this.m_sNextTurnAgreement = "";
      
      this.m_dBelievedThreshold = 0.1D;
      this.m_bCalcNashAgreement = false;
      
      this.m_sEquilibriumAgreement = "";
      this.m_sNextTurnEquilibriumAgreement = "";
      this.m_dEquilibriumValue = -9999.0D;
      this.m_dNextTurnEquilibriumValue = -9999.0D;
      this.m_dNextTurnCurrentAgentValueForEqOffer = -9999.0D;
      
      this.m_sFirstEquilibriumAgreement = new String[4];
      this.m_sFirstEquilibriumAgreementNextTurn = new String[4];
      this.m_sSecondEquilibriumAgreement = new String[4];
      this.m_sSecondEquilibriumAgreementNextTurn = new String[4];
      
      this.m_dFirstEquilibriumValue = new double[3];
      this.m_dFirstEquilibriumValueNextTurn = new double[3];
      this.m_dSecondEquilibriumValue = new double[3];
      this.m_dSecondEquilibriumValueNextTurn = new double[3];
      for (int i = 0; i < 3; i++)
      {
        this.m_sFirstEquilibriumAgreement[i] = "";
        this.m_sFirstEquilibriumAgreementNextTurn[i] = "";
        this.m_sSecondEquilibriumAgreement[i] = "";
        this.m_sSecondEquilibriumAgreementNextTurn[i] = "";
        this.m_dFirstEquilibriumValue[i] = -9999.0D;
        this.m_dFirstEquilibriumValueNextTurn[i] = -9999.0D;
        this.m_dSecondEquilibriumValue[i] = -9999.0D;
        this.m_dSecondEquilibriumValueNextTurn[i] = -9999.0D;
      }
    }
    
    public void calculateAgreement(QAgentType agentType, int nCurrentTurn, boolean bCalcForNextTurn)
    {
      if (bCalcForNextTurn) {
        QAgentsCore.this.m_CurrentAgentNextTurnType = agentType;
      } else {
        QAgentsCore.this.m_CurrentAgentType = agentType;
      }
      if (QAgentsCore.this.m_CurrentAgentType.isTypeOf(1))
      {
        calculateOfferAgainstOpponent("England", nCurrentTurn, bCalcForNextTurn);
      }
      else if (QAgentsCore.this.m_CurrentAgentType.isTypeOf(0))
      {
        calculateOfferAgainstOpponent("Zimbabwe", nCurrentTurn, bCalcForNextTurn);
      }
      else
      {
        System.out.println("[QO]Agent type is unknown [QAgentsCore::calculateAgreement(204)]");
        System.err.println("[QO]Agent type is unknown [QAgentsCore::calculateAgreement(204)]");
      }
    }
    
    public void calculateOfferAgainstOpponent(String sOpponentType, int nCurrentTurn, boolean bCalcForNextTurn)
    {
      try
      {
        PrintWriter bw = new PrintWriter(new FileWriter(QAgentsCore.this.m_sLogFileName, true));
        

        QAgentType agentOpponentCompromise = null;
        QAgentType agentOpponentLongTerm = null;
        QAgentType agentOpponentShortTerm = null;
        
        this.m_dQOValue = -9999.0D;
        this.m_dNextTurnQOValue = -9999.0D;
        
        QAgentsCore.this.m_nNextTurnOppType = -1;
        
        int nIssuesNum = QAgentsCore.this.m_CurrentAgentType.getIssuesNum();
        

        int[][] OpponentShortTermIdx = new int[4][nIssuesNum];
        int[][] OpponentLongTermIdx = new int[4][nIssuesNum];
        int[][] OpponentCompromiseIdx = new int[4][nIssuesNum];
        

        double dOpponentShortTermAgreementValue = -9999.0D;double dOpponentShortTermLuceAgreementValue = 0.0D;
        double dOpponentLongTermAgreementValue = -9999.0D;double dOpponentLongTermLuceAgreementValue = 0.0D;
        double dOpponentCompromiseAgreementValue = -9999.0D;double dOpponentCompromiseLuceAgreementValue = 0.0D;
        double dQOValue = -9999.0D;
        

        double[] dOpponentShortTermQOValue = new double[4];
        double[] dOpponentLongTermQOValue = new double[4];
        double[] dOpponentCompromiseQOValue = new double[4];
        for (int i = 0; i < dOpponentShortTermQOValue.length; i++)
        {
          dOpponentShortTermQOValue[i] = -9999.0D;
          dOpponentLongTermQOValue[i] = -9999.0D;
          dOpponentCompromiseQOValue[i] = -9999.0D;
        }
        double dCurrentNashValue = -9999.0D;
        double dOpponentCompromiseNashValue = -9999.0D;
        double dOpponentLongTermNashValue = -9999.0D;
        double dOpponentShortTermNashValue = -9999.0D;
        
        double dBelievedTypeOpponentShortTerm = 0.0D;
        double dBelievedTypeOpponentLongTerm = 0.0D;
        double dBelievedTypeOpponentCompromise = 0.0D;
        
        boolean bCalcOpponentShortTerm = false;
        boolean bCalcOpponentLongTerm = false;
        boolean bCalcOpponentCompromise = false;
        
        double dCurrentAgentAgreementValue = -9999.0D;double dCurrentAgentLuceAgreementValue = -9999.0D;
        
        int index = -1;
        if (sOpponentType.equals("England"))
        {
          if (bCalcForNextTurn)
          {
            agentOpponentCompromise = QAgentsCore.this.getEnglandCompromiseNextTurnType();
            agentOpponentLongTerm = QAgentsCore.this.getEnglandLongTermNextTurnType();
            agentOpponentShortTerm = QAgentsCore.this.getEnglandShortTermNextTurnType();
          }
          else
          {
            agentOpponentCompromise = QAgentsCore.this.getEnglandCompromiseType();
            agentOpponentLongTerm = QAgentsCore.this.getEnglandLongTermType();
            agentOpponentShortTerm = QAgentsCore.this.getEnglandShortTermType();
          }
        }
        else if (sOpponentType.equals("Zimbabwe"))
        {
          if (bCalcForNextTurn)
          {
            agentOpponentCompromise = QAgentsCore.this.getZimbabweCompromiseNextTurnType();
            agentOpponentLongTerm = QAgentsCore.this.getZimbabweLongTermNextTurnType();
            agentOpponentShortTerm = QAgentsCore.this.getZimbabweShortTermNextTurnType();
          }
          else
          {
            agentOpponentCompromise = QAgentsCore.this.getZimbabweCompromiseType();
            agentOpponentLongTerm = QAgentsCore.this.getZimbabweLongTermType();
            agentOpponentShortTerm = QAgentsCore.this.getZimbabweShortTermType();
          }
        }
        else
        {
          System.out.println("[QO]Agent type is unknown [QAgentsCore::calculateOfferAgainstOpponent(291)]");
          System.err.println("[QO]Agent type is unknown [QAgentsCore::calculateOfferAgainstOpponent(291)]");
          return;
        }
        dBelievedTypeOpponentCompromise = agentOpponentCompromise.getTypeProbability();
        dBelievedTypeOpponentLongTerm = agentOpponentLongTerm.getTypeProbability();
        dBelievedTypeOpponentShortTerm = agentOpponentShortTerm.getTypeProbability();
        if (dBelievedTypeOpponentCompromise > dBelievedTypeOpponentLongTerm)
        {
          if (dBelievedTypeOpponentCompromise > dBelievedTypeOpponentShortTerm)
          {
            bCalcOpponentCompromise = true;
            if (dBelievedTypeOpponentCompromise - dBelievedTypeOpponentShortTerm < this.m_dBelievedThreshold) {
              bCalcOpponentShortTerm = true;
            }
            if (dBelievedTypeOpponentCompromise - dBelievedTypeOpponentLongTerm < this.m_dBelievedThreshold) {
              bCalcOpponentLongTerm = true;
            }
          }
          else
          {
            bCalcOpponentShortTerm = true;
            if (dBelievedTypeOpponentShortTerm - dBelievedTypeOpponentCompromise < this.m_dBelievedThreshold) {
              bCalcOpponentCompromise = true;
            }
            if (dBelievedTypeOpponentShortTerm - dBelievedTypeOpponentLongTerm < this.m_dBelievedThreshold) {
              bCalcOpponentLongTerm = true;
            }
          }
        }
        else if (dBelievedTypeOpponentLongTerm > dBelievedTypeOpponentShortTerm)
        {
          bCalcOpponentLongTerm = true;
          if (dBelievedTypeOpponentLongTerm - dBelievedTypeOpponentShortTerm < this.m_dBelievedThreshold) {
            bCalcOpponentShortTerm = true;
          }
          if (dBelievedTypeOpponentLongTerm - dBelievedTypeOpponentCompromise < this.m_dBelievedThreshold) {
            bCalcOpponentCompromise = true;
          }
        }
        else
        {
          bCalcOpponentShortTerm = true;
          if (dBelievedTypeOpponentShortTerm - dBelievedTypeOpponentCompromise < this.m_dBelievedThreshold) {
            bCalcOpponentCompromise = true;
          }
          if (dBelievedTypeOpponentShortTerm - dBelievedTypeOpponentLongTerm < this.m_dBelievedThreshold) {
            bCalcOpponentLongTerm = true;
          }
        }
        int[] CurrentAgreementIdx = new int[nIssuesNum];
        int[] MaxIssueValues = new int[nIssuesNum];
        for (int i = 0; i < nIssuesNum; i++)
        {
          CurrentAgreementIdx[i] = 0;
          MaxIssueValues[i] = QAgentsCore.this.m_CurrentAgentType.getMaxIssueValue(i);
        }
        int nTotalAgreements = QAgentsCore.this.m_CurrentAgentType.getTotalAgreements();
        for (int i = 0; i < nTotalAgreements; i++)
        {
          if (bCalcForNextTurn)
          {
            dCurrentAgentAgreementValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementRankingProbability(CurrentAgreementIdx);
            double agreementUtilityValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
            dCurrentAgentLuceAgreementValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementLuceValue(agreementUtilityValue);
            if (agreementUtilityValue <= QAgentsCore.this.m_CurrentAgentNextTurnType.getSQValue())
            {
              boolean bFinishUpdate = false;
              for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
                if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
                {
                  CurrentAgreementIdx[k] = 0;
                }
                else
                {
                  CurrentAgreementIdx[k] += 1;
                  bFinishUpdate = true;
                }
              }
              continue;
            }
          }
          else
          {
            dCurrentAgentAgreementValue = QAgentsCore.this.m_CurrentAgentType.getAgreementRankingProbability(CurrentAgreementIdx);
            double agreementUtilityValue = QAgentsCore.this.m_CurrentAgentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
            dCurrentAgentLuceAgreementValue = QAgentsCore.this.m_CurrentAgentType.getAgreementLuceValue(agreementUtilityValue);
            if (agreementUtilityValue <= QAgentsCore.this.m_CurrentAgentType.getSQValue())
            {
              boolean bFinishUpdate = false;
              for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
                if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
                {
                  CurrentAgreementIdx[k] = 0;
                }
                else
                {
                  CurrentAgreementIdx[k] += 1;
                  bFinishUpdate = true;
                }
              }
              continue;
            }
          }
          bw.println("----------------------------------------");
          bw.println("Agreement: " + QAgentsCore.this.m_CurrentAgentType.getAgreementStr(CurrentAgreementIdx) + "(turn: " + nCurrentTurn + ")");
          bw.println("Agreement Value: " + dCurrentAgentAgreementValue);
          bw.println("Agreement Luce: " + dCurrentAgentLuceAgreementValue);
          if (bCalcOpponentCompromise)
          {
            dOpponentCompromiseAgreementValue = agentOpponentCompromise.getAgreementRankingProbability(CurrentAgreementIdx);
            double agreementUtilityValue = agentOpponentCompromise.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
            dOpponentCompromiseLuceAgreementValue = agentOpponentCompromise.getAgreementLuceValue(agreementUtilityValue);
            if (agreementUtilityValue <= agentOpponentCompromise.getSQValue())
            {
              boolean bFinishUpdate = false;
              for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
                if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
                {
                  CurrentAgreementIdx[k] = 0;
                }
                else
                {
                  CurrentAgreementIdx[k] += 1;
                  bFinishUpdate = true;
                }
              }
              continue;
            }
            bw.println("CompOpponent Value: " + dOpponentCompromiseAgreementValue);
            bw.println("CompOpponent Luce: " + dOpponentCompromiseLuceAgreementValue);
            
            dQOValue = Math.min(dCurrentAgentAgreementValue * dCurrentAgentLuceAgreementValue, dOpponentCompromiseAgreementValue * (dOpponentCompromiseLuceAgreementValue + dCurrentAgentLuceAgreementValue));
            



            bw.println("CompQO Value: " + dQOValue);
            
            index = 0;
            if (dQOValue > dOpponentCompromiseQOValue[0])
            {
              if (dQOValue > dOpponentCompromiseQOValue[1])
              {
                index = 1;
                if (dQOValue > dOpponentCompromiseQOValue[2])
                {
                  index = 2;
                  if (dQOValue > dOpponentCompromiseQOValue[3]) {
                    index = 3;
                  }
                }
              }
              if (index == 3)
              {
                dOpponentCompromiseQOValue[0] = dOpponentCompromiseQOValue[1];
                dOpponentCompromiseQOValue[1] = dOpponentCompromiseQOValue[2];
                dOpponentCompromiseQOValue[2] = dOpponentCompromiseQOValue[3];
                dOpponentCompromiseQOValue[3] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentCompromiseIdx[0][j] = OpponentCompromiseIdx[1][j];
                  OpponentCompromiseIdx[1][j] = OpponentCompromiseIdx[2][j];
                  OpponentCompromiseIdx[2][j] = OpponentCompromiseIdx[3][j];
                  OpponentCompromiseIdx[3][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 2)
              {
                dOpponentCompromiseQOValue[0] = dOpponentCompromiseQOValue[1];
                dOpponentCompromiseQOValue[1] = dOpponentCompromiseQOValue[2];
                dOpponentCompromiseQOValue[2] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentCompromiseIdx[0][j] = OpponentCompromiseIdx[1][j];
                  OpponentCompromiseIdx[1][j] = OpponentCompromiseIdx[2][j];
                  OpponentCompromiseIdx[2][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 1)
              {
                dOpponentCompromiseQOValue[0] = dOpponentCompromiseQOValue[1];
                dOpponentCompromiseQOValue[1] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentCompromiseIdx[0][j] = OpponentCompromiseIdx[1][j];
                  OpponentCompromiseIdx[1][j] = CurrentAgreementIdx[j];
                }
              }
              else
              {
                dOpponentCompromiseQOValue[0] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++) {
                  OpponentCompromiseIdx[0][j] = CurrentAgreementIdx[j];
                }
              }
              bw.println("------------SAVED VALUE--------------");
            }
            if (this.m_bCalcNashAgreement)
            {
              dCurrentNashValue = dOpponentCompromiseAgreementValue * dCurrentAgentAgreementValue;
              if (dCurrentNashValue > dOpponentCompromiseNashValue) {
                dOpponentCompromiseNashValue = dCurrentNashValue;
              }
            }
          }
          if (bCalcOpponentLongTerm)
          {
            dOpponentLongTermAgreementValue = agentOpponentLongTerm.getAgreementRankingProbability(CurrentAgreementIdx);
            double agreementUtilityValue = agentOpponentLongTerm.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
            dOpponentLongTermLuceAgreementValue = agentOpponentLongTerm.getAgreementLuceValue(agreementUtilityValue);
            if (agreementUtilityValue <= agentOpponentLongTerm.getSQValue())
            {
              boolean bFinishUpdate = false;
              for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
                if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
                {
                  CurrentAgreementIdx[k] = 0;
                }
                else
                {
                  CurrentAgreementIdx[k] += 1;
                  bFinishUpdate = true;
                }
              }
              continue;
            }
            bw.println("LongOpponent Value: " + dOpponentLongTermAgreementValue);
            bw.println("LongOpponent Luce: " + dOpponentLongTermLuceAgreementValue);
            
            dQOValue = Math.min(dCurrentAgentAgreementValue * dCurrentAgentLuceAgreementValue, dOpponentLongTermAgreementValue * (dOpponentLongTermLuceAgreementValue + dCurrentAgentLuceAgreementValue));
            



            bw.println("LongQO Value: " + dQOValue);
            
            index = 0;
            if (dQOValue > dOpponentLongTermQOValue[0])
            {
              if (dQOValue > dOpponentLongTermQOValue[1])
              {
                index = 1;
                if (dQOValue > dOpponentLongTermQOValue[2])
                {
                  index = 2;
                  if (dQOValue > dOpponentLongTermQOValue[3]) {
                    index = 3;
                  }
                }
              }
              if (index == 3)
              {
                dOpponentLongTermQOValue[0] = dOpponentLongTermQOValue[1];
                dOpponentLongTermQOValue[1] = dOpponentLongTermQOValue[2];
                dOpponentLongTermQOValue[2] = dOpponentLongTermQOValue[3];
                dOpponentLongTermQOValue[3] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentLongTermIdx[0][j] = OpponentLongTermIdx[1][j];
                  OpponentLongTermIdx[1][j] = OpponentLongTermIdx[2][j];
                  OpponentLongTermIdx[2][j] = OpponentLongTermIdx[3][j];
                  OpponentLongTermIdx[3][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 2)
              {
                dOpponentLongTermQOValue[0] = dOpponentLongTermQOValue[1];
                dOpponentLongTermQOValue[1] = dOpponentLongTermQOValue[2];
                dOpponentLongTermQOValue[2] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentLongTermIdx[0][j] = OpponentLongTermIdx[1][j];
                  OpponentLongTermIdx[1][j] = OpponentLongTermIdx[2][j];
                  OpponentLongTermIdx[2][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 1)
              {
                dOpponentLongTermQOValue[0] = dOpponentLongTermQOValue[1];
                dOpponentLongTermQOValue[1] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentLongTermIdx[0][j] = OpponentLongTermIdx[1][j];
                  OpponentLongTermIdx[1][j] = CurrentAgreementIdx[j];
                }
              }
              else
              {
                dOpponentLongTermQOValue[0] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++) {
                  OpponentLongTermIdx[0][j] = CurrentAgreementIdx[j];
                }
              }
              bw.println("------------SAVED VALUE--------------");
            }
            if (this.m_bCalcNashAgreement)
            {
              dCurrentNashValue = dOpponentLongTermAgreementValue * dCurrentAgentAgreementValue;
              if (dCurrentNashValue > dOpponentLongTermNashValue) {
                dOpponentLongTermNashValue = dCurrentNashValue;
              }
            }
          }
          if (bCalcOpponentShortTerm)
          {
            dOpponentShortTermAgreementValue = agentOpponentShortTerm.getAgreementRankingProbability(CurrentAgreementIdx);
            double agreementUtilityValue = agentOpponentShortTerm.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
            dOpponentShortTermLuceAgreementValue = agentOpponentShortTerm.getAgreementLuceValue(agreementUtilityValue);
            if (agreementUtilityValue <= agentOpponentShortTerm.getSQValue())
            {
              boolean bFinishUpdate = false;
              for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
                if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
                {
                  CurrentAgreementIdx[k] = 0;
                }
                else
                {
                  CurrentAgreementIdx[k] += 1;
                  bFinishUpdate = true;
                }
              }
              continue;
            }
            bw.println("ShortOpponent Value: " + dOpponentShortTermAgreementValue);
            bw.println("ShortOpponent Luce: " + dOpponentShortTermLuceAgreementValue);
            
            dQOValue = Math.min(dCurrentAgentAgreementValue * dCurrentAgentLuceAgreementValue, dOpponentShortTermAgreementValue * (dOpponentShortTermLuceAgreementValue + dCurrentAgentLuceAgreementValue));
            



            bw.println("ShortQO Value: " + dQOValue);
            
            index = 0;
            if (dQOValue > dOpponentShortTermQOValue[0])
            {
              if (dQOValue > dOpponentShortTermQOValue[1])
              {
                index = 1;
                if (dQOValue > dOpponentShortTermQOValue[2])
                {
                  index = 2;
                  if (dQOValue > dOpponentShortTermQOValue[3]) {
                    index = 3;
                  }
                }
              }
              if (index == 3)
              {
                dOpponentShortTermQOValue[0] = dOpponentShortTermQOValue[1];
                dOpponentShortTermQOValue[1] = dOpponentShortTermQOValue[2];
                dOpponentShortTermQOValue[2] = dOpponentShortTermQOValue[3];
                dOpponentShortTermQOValue[3] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentShortTermIdx[0][j] = OpponentShortTermIdx[1][j];
                  OpponentShortTermIdx[1][j] = OpponentShortTermIdx[2][j];
                  OpponentShortTermIdx[2][j] = OpponentShortTermIdx[3][j];
                  OpponentShortTermIdx[3][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 2)
              {
                dOpponentShortTermQOValue[0] = dOpponentShortTermQOValue[1];
                dOpponentShortTermQOValue[1] = dOpponentShortTermQOValue[2];
                dOpponentShortTermQOValue[2] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentShortTermIdx[0][j] = OpponentShortTermIdx[1][j];
                  OpponentShortTermIdx[1][j] = OpponentShortTermIdx[2][j];
                  OpponentShortTermIdx[2][j] = CurrentAgreementIdx[j];
                }
              }
              else if (index == 1)
              {
                dOpponentShortTermQOValue[0] = dOpponentShortTermQOValue[1];
                dOpponentShortTermQOValue[1] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++)
                {
                  OpponentShortTermIdx[0][j] = OpponentShortTermIdx[1][j];
                  OpponentShortTermIdx[1][j] = CurrentAgreementIdx[j];
                }
              }
              else
              {
                dOpponentShortTermQOValue[0] = dQOValue;
                for (int j = 0; j < nIssuesNum; j++) {
                  OpponentShortTermIdx[0][j] = CurrentAgreementIdx[j];
                }
              }
              bw.println("------------SAVED VALUE--------------");
            }
            if (this.m_bCalcNashAgreement)
            {
              dCurrentNashValue = dOpponentShortTermAgreementValue * dCurrentAgentAgreementValue;
              if (dCurrentNashValue > dOpponentShortTermNashValue) {
                dOpponentShortTermNashValue = dCurrentNashValue;
              }
            }
          }
          boolean bFinishUpdate = false;
          for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
            if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
            {
              CurrentAgreementIdx[k] = 0;
            }
            else
            {
              CurrentAgreementIdx[k] += 1;
              bFinishUpdate = true;
            }
          }
        }
        Random rand = new Random();
        


        int randNum = rand.nextInt(4);
        if (bCalcForNextTurn)
        {
          if (bCalcOpponentCompromise) {
            if (dOpponentCompromiseQOValue[randNum] * dBelievedTypeOpponentCompromise > this.m_dNextTurnQOValue)
            {
              this.m_dNextTurnQOValue = (dOpponentCompromiseQOValue[randNum] * dBelievedTypeOpponentCompromise);
              this.m_dAgentSelectedNextTurnValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementValue(OpponentCompromiseIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedNextTurnValue = agentOpponentCompromise.getAgreementValue(OpponentCompromiseIdx[randNum], nCurrentTurn);
              this.m_sNextTurnAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentCompromiseIdx[randNum]);
              QAgentsCore.this.m_nNextTurnOppType = 2;
            }
          }
          if (bCalcOpponentLongTerm) {
            if (dOpponentLongTermQOValue[randNum] * dBelievedTypeOpponentLongTerm > this.m_dNextTurnQOValue)
            {
              this.m_dNextTurnQOValue = (dOpponentLongTermQOValue[randNum] * dBelievedTypeOpponentLongTerm);
              this.m_dAgentSelectedNextTurnValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementValue(OpponentLongTermIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedNextTurnValue = agentOpponentLongTerm.getAgreementValue(OpponentLongTermIdx[randNum], nCurrentTurn);
              this.m_sNextTurnAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentLongTermIdx[randNum]);
              QAgentsCore.this.m_nNextTurnOppType = 0;
            }
          }
          if (bCalcOpponentShortTerm) {
            if (dOpponentShortTermQOValue[randNum] * dBelievedTypeOpponentShortTerm > this.m_dNextTurnQOValue)
            {
              this.m_dNextTurnQOValue = (dOpponentShortTermQOValue[randNum] * dBelievedTypeOpponentShortTerm);
              this.m_dAgentSelectedNextTurnValue = QAgentsCore.this.m_CurrentAgentNextTurnType.getAgreementValue(OpponentShortTermIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedNextTurnValue = agentOpponentShortTerm.getAgreementValue(OpponentShortTermIdx[randNum], nCurrentTurn);
              this.m_sNextTurnAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentShortTermIdx[randNum]);
              QAgentsCore.this.m_nNextTurnOppType = 1;
            }
          }
        }
        else
        {
          String sSelectedOffer = "";
          String sSelectedOpponent = "";
          if (bCalcOpponentCompromise) {
            if (dOpponentCompromiseQOValue[randNum] * dBelievedTypeOpponentCompromise > this.m_dQOValue)
            {
              bw.println("~~~~~~~~~~SELECTED COMP~~~~~~~~~~");
              this.m_dQOValue = (dOpponentCompromiseQOValue[randNum] * dBelievedTypeOpponentCompromise);
              this.m_dAgentSelectedValue = QAgentsCore.this.m_CurrentAgentType.getAgreementValue(OpponentCompromiseIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedValue = agentOpponentCompromise.getAgreementValue(OpponentCompromiseIdx[randNum], nCurrentTurn);
              this.m_sAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentCompromiseIdx[randNum]);
              bw.println("Agreement: " + this.m_sAgreement);
              bw.println("QO Value: " + this.m_dQOValue);
              bw.println("Agent Value: " + this.m_dAgentSelectedValue);
              bw.println("Opponent Value: " + this.m_dOppSelectedValue);
              
              sSelectedOpponent = "Compromise";
            }
          }
          if (bCalcOpponentLongTerm) {
            if (dOpponentLongTermQOValue[randNum] * dBelievedTypeOpponentLongTerm > this.m_dQOValue)
            {
              bw.println("~~~~~~~~~~SELECTED LONG~~~~~~~~~~");
              this.m_dQOValue = (dOpponentLongTermQOValue[randNum] * dBelievedTypeOpponentLongTerm);
              this.m_dAgentSelectedValue = QAgentsCore.this.m_CurrentAgentType.getAgreementValue(OpponentLongTermIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedValue = agentOpponentLongTerm.getAgreementValue(OpponentLongTermIdx[randNum], nCurrentTurn);
              this.m_sAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentLongTermIdx[randNum]);
              bw.println("Agreement: " + this.m_sAgreement);
              bw.println("QO Value: " + this.m_dQOValue);
              bw.println("Agent Value: " + this.m_dAgentSelectedValue);
              bw.println("Opponent Value: " + this.m_dOppSelectedValue);
              
              sSelectedOpponent = "Long";
            }
          }
          if (bCalcOpponentShortTerm) {
            if (dOpponentShortTermQOValue[randNum] * dBelievedTypeOpponentShortTerm > this.m_dQOValue)
            {
              bw.println("~~~~~~~~~~SELECTED SHORT~~~~~~~~~~");
              this.m_dQOValue = (dOpponentShortTermQOValue[randNum] * dBelievedTypeOpponentShortTerm);
              this.m_dAgentSelectedValue = QAgentsCore.this.m_CurrentAgentType.getAgreementValue(OpponentShortTermIdx[randNum], nCurrentTurn);
              this.m_dOppSelectedValue = agentOpponentShortTerm.getAgreementValue(OpponentShortTermIdx[randNum], nCurrentTurn);
              this.m_sAgreement = QAgentsCore.this.m_CurrentAgentType.getAgreementStr(OpponentShortTermIdx[randNum]);
              bw.println("Agreement: " + this.m_sAgreement);
              bw.println("QO Value: " + this.m_dQOValue);
              bw.println("Agent Value: " + this.m_dAgentSelectedValue);
              bw.println("Opponent Value: " + this.m_dOppSelectedValue);
              
              sSelectedOpponent = "Short";
            }
          }
          sSelectedOffer = "Agreement: " + this.m_sAgreement + "\n" + "QO Value: " + this.m_dQOValue + "\n" + "Agent Value: " + this.m_dAgentSelectedValue + "\n" + "Opponent Value: " + this.m_dOppSelectedValue;
          



          System.err.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");
          System.err.println("Will Send Message for Opponent: " + sSelectedOpponent);
          System.err.println(sSelectedOffer);
          System.err.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");
        }
        bw.println("-----------------Final Probabilities-------------");
        bw.println("Short: " + dBelievedTypeOpponentShortTerm);
        bw.println("Long: " + dBelievedTypeOpponentLongTerm);
        bw.println("Comp: " + dBelievedTypeOpponentCompromise);
        
        bw.close();
      }
      catch (Exception e)
      {
        System.out.println("Error opening QO log file [QAgentsCore::OfferAgainstOpponent(592)]");
        System.err.println("Error opening QO log file [QAgentsCore::OfferAgainstOpponent(592)]");
        e.printStackTrace();
      }
    }
    
    public double getSelectedQOAgreementValue()
    {
      return this.m_dQOValue;
    }
    
    public double getSelectedEquilibriumAgreementValue()
    {
      return this.m_dEquilibriumValue;
    }
    
    public String getSelectedQOAgreementStr()
    {
      return this.m_sAgreement;
    }
    
    public String getSelectedEquilibriumAgreementStr()
    {
      return this.m_sEquilibriumAgreement;
    }
    
    public double getNextTurnAgentQOUtilityValue()
    {
      return this.m_dAgentSelectedNextTurnValue;
    }
    
    public double getNextTurnAgentEquilibriumUtilityValue()
    {
      return this.m_dNextTurnCurrentAgentValueForEqOffer;
    }
    
    public String getNextTurnQOAgreement()
    {
      return this.m_sNextTurnAgreement;
    }
    
    public String getNextTurnEquilibriumAgreement()
    {
      return this.m_sNextTurnEquilibriumAgreement;
    }
    
    public double getNextTurnOpponentQOUtilityValue()
    {
      return this.m_dOppSelectedNextTurnValue;
    }
    
    public int getNextTurnOpponentType()
    {
      return QAgentsCore.this.m_nNextTurnOppType;
    }
    
    public void calculateEquilibrium(QAgentType agentType, int nMaxTurns, boolean bCalculateForAllAgents, boolean bCalcForNextTurn, int nCurrentTurn)
    {
      this.m_dEquilibriumValue = -9999.0D;
      this.m_dNextTurnEquilibriumValue = -9999.0D;
      if (bCalcForNextTurn) {
        QAgentsCore.this.m_CurrentAgentNextTurnType = agentType;
      } else {
        QAgentsCore.this.m_CurrentAgentType = agentType;
      }
      if (QAgentsCore.this.m_CurrentAgentType.isTypeOf(1))
      {
        QAgentType engCompromise = null;
        if (bCalcForNextTurn) {
          engCompromise = QAgentsCore.this.getEnglandCompromiseNextTurnType();
        } else {
          engCompromise = QAgentsCore.this.getEnglandCompromiseType();
        }
        calculateEquilibrium(engCompromise, true, nMaxTurns, 2, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
        





        QAgentType engLongTerm = null;
        if (bCalcForNextTurn) {
          engLongTerm = QAgentsCore.this.getEnglandLongTermNextTurnType();
        } else {
          engLongTerm = QAgentsCore.this.getEnglandLongTermType();
        }
        calculateEquilibrium(engLongTerm, true, nMaxTurns, 0, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
        





        QAgentType engShortTerm = null;
        if (bCalcForNextTurn) {
          engShortTerm = QAgentsCore.this.getEnglandShortTermNextTurnType();
        } else {
          engShortTerm = QAgentsCore.this.getEnglandShortTermType();
        }
        calculateEquilibrium(engShortTerm, true, nMaxTurns, 1, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
      }
      else if (QAgentsCore.this.m_CurrentAgentType.isTypeOf(0))
      {
        QAgentType zimCompromise = null;
        if (bCalcForNextTurn) {
          zimCompromise = QAgentsCore.this.getZimbabweCompromiseNextTurnType();
        } else {
          zimCompromise = QAgentsCore.this.getZimbabweCompromiseType();
        }
        calculateEquilibrium(zimCompromise, true, nMaxTurns, 2, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
        




        QAgentType zimLongTerm = null;
        if (bCalcForNextTurn) {
          zimLongTerm = QAgentsCore.this.getZimbabweLongTermNextTurnType();
        } else {
          zimLongTerm = QAgentsCore.this.getZimbabweLongTermType();
        }
        calculateEquilibrium(zimLongTerm, true, nMaxTurns, 0, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
        





        QAgentType zimShortTerm = null;
        if (bCalcForNextTurn) {
          zimShortTerm = QAgentsCore.this.getZimbabweShortTermNextTurnType();
        } else {
          zimShortTerm = QAgentsCore.this.getZimbabweShortTermType();
        }
        calculateEquilibrium(zimShortTerm, true, nMaxTurns, 1, 1, bCalculateForAllAgents, bCalcForNextTurn, nCurrentTurn);
      }
      else
      {
        System.out.println("[QO]Agent type is unknown [QAgentsCore::calculateEquilibrium(658");
        System.err.println("[QO]Agent type is unknown [QAgentsCore::calculateEquilibrium(658)]");
        return;
      }
      if (bCalculateForAllAgents)
      {
        ArrayList<Double> dSortedValuesList = new ArrayList();
        ArrayList<String> sSortedValuesList = new ArrayList();
        
        double dCurrentValue = -9999.0D;
        boolean bFoundInd = false;
        int nInsertionPoint = 0;
        for (int i = 0; i < 3; i++)
        {
          bFoundInd = false;
          for (int ind = 0; (ind < dSortedValuesList.size()) && (!bFoundInd); ind++)
          {
            dCurrentValue = ((Double)dSortedValuesList.get(ind)).doubleValue();
            if (bCalcForNextTurn)
            {
              if (this.m_dFirstEquilibriumValueNextTurn[i] < dCurrentValue)
              {
                bFoundInd = true;
                nInsertionPoint = ind;
              }
            }
            else if (this.m_dFirstEquilibriumValue[i] < dCurrentValue)
            {
              bFoundInd = true;
              nInsertionPoint = ind;
            }
          }
          if (bFoundInd)
          {
            if (bCalcForNextTurn)
            {
              dSortedValuesList.add(nInsertionPoint, new Double(this.m_dFirstEquilibriumValueNextTurn[i]));
              sSortedValuesList.add(nInsertionPoint, this.m_sFirstEquilibriumAgreementNextTurn[i]);
            }
            else
            {
              dSortedValuesList.add(nInsertionPoint, new Double(this.m_dFirstEquilibriumValue[i]));
              sSortedValuesList.add(nInsertionPoint, this.m_sFirstEquilibriumAgreement[i]);
            }
          }
          else if (bCalcForNextTurn)
          {
            dSortedValuesList.add(new Double(this.m_dFirstEquilibriumValueNextTurn[i]));
            sSortedValuesList.add(this.m_sFirstEquilibriumAgreementNextTurn[i]);
          }
          else
          {
            dSortedValuesList.add(new Double(this.m_dFirstEquilibriumValue[i]));
            sSortedValuesList.add(this.m_sFirstEquilibriumAgreement[i]);
          }
          bFoundInd = false;
          for (int ind = 0; (ind < dSortedValuesList.size()) && (!bFoundInd); ind++)
          {
            dCurrentValue = ((Double)dSortedValuesList.get(ind)).doubleValue();
            if (bCalcForNextTurn)
            {
              if (this.m_dSecondEquilibriumValueNextTurn[i] < dCurrentValue)
              {
                bFoundInd = true;
                nInsertionPoint = ind;
              }
            }
            else if (this.m_dSecondEquilibriumValue[i] < dCurrentValue)
            {
              bFoundInd = true;
              nInsertionPoint = ind;
            }
          }
          if (bFoundInd)
          {
            if (bCalcForNextTurn)
            {
              dSortedValuesList.add(nInsertionPoint, new Double(this.m_dSecondEquilibriumValueNextTurn[i]));
              sSortedValuesList.add(nInsertionPoint, this.m_sSecondEquilibriumAgreementNextTurn[i]);
            }
            else
            {
              dSortedValuesList.add(nInsertionPoint, new Double(this.m_dSecondEquilibriumValue[i]));
              sSortedValuesList.add(nInsertionPoint, this.m_sSecondEquilibriumAgreement[i]);
            }
          }
          else if (bCalcForNextTurn)
          {
            dSortedValuesList.add(new Double(this.m_dSecondEquilibriumValueNextTurn[i]));
            sSortedValuesList.add(this.m_sSecondEquilibriumAgreementNextTurn[i]);
          }
          else
          {
            dSortedValuesList.add(new Double(this.m_dSecondEquilibriumValue[i]));
            sSortedValuesList.add(this.m_sSecondEquilibriumAgreement[i]);
          }
        }
        if (bCalcForNextTurn)
        {
          this.m_dNextTurnEquilibriumValue = ((Double)dSortedValuesList.get(dSortedValuesList.size() - 1)).doubleValue();
          this.m_sNextTurnEquilibriumAgreement = ((String)sSortedValuesList.get(sSortedValuesList.size() - 1));
          this.m_dNextTurnCurrentAgentValueForEqOffer = agentType.getAgreementValue(agentType.getAgreementIndices(this.m_sNextTurnEquilibriumAgreement), nCurrentTurn + 1);
        }
        else
        {
          this.m_dEquilibriumValue = ((Double)dSortedValuesList.get(dSortedValuesList.size() - 1)).doubleValue();
          this.m_sEquilibriumAgreement = ((String)sSortedValuesList.get(sSortedValuesList.size() - 1));
        }
      }
      else if (bCalcForNextTurn)
      {
        if (this.m_dFirstEquilibriumValueNextTurn[1] > this.m_dSecondEquilibriumValueNextTurn[1])
        {
          this.m_dNextTurnEquilibriumValue = this.m_dFirstEquilibriumValueNextTurn[1];
          this.m_sNextTurnEquilibriumAgreement = this.m_sFirstEquilibriumAgreementNextTurn[1];
          this.m_dNextTurnCurrentAgentValueForEqOffer = agentType.getAgreementValue(agentType.getAgreementIndices(this.m_sNextTurnEquilibriumAgreement), nCurrentTurn + 1);
        }
        else if (this.m_dFirstEquilibriumValueNextTurn[1] < this.m_dSecondEquilibriumValueNextTurn[1])
        {
          this.m_dNextTurnEquilibriumValue = this.m_dSecondEquilibriumValueNextTurn[1];
          this.m_sNextTurnEquilibriumAgreement = this.m_sSecondEquilibriumAgreementNextTurn[1];
          this.m_dNextTurnCurrentAgentValueForEqOffer = agentType.getAgreementValue(agentType.getAgreementIndices(this.m_sNextTurnEquilibriumAgreement), nCurrentTurn + 1);
        }
        else
        {
          Random generator = new Random();
          double dRandNum = generator.nextDouble();
          if (dRandNum <= 0.5D)
          {
            this.m_dNextTurnEquilibriumValue = this.m_dFirstEquilibriumValueNextTurn[1];
            this.m_sNextTurnEquilibriumAgreement = this.m_sFirstEquilibriumAgreementNextTurn[1];
            this.m_dNextTurnCurrentAgentValueForEqOffer = agentType.getAgreementValue(agentType.getAgreementIndices(this.m_sNextTurnEquilibriumAgreement), nCurrentTurn + 1);
          }
          else
          {
            this.m_dNextTurnEquilibriumValue = this.m_dSecondEquilibriumValueNextTurn[1];
            this.m_sNextTurnEquilibriumAgreement = this.m_sSecondEquilibriumAgreementNextTurn[1];
            this.m_dNextTurnCurrentAgentValueForEqOffer = agentType.getAgreementValue(agentType.getAgreementIndices(this.m_sNextTurnEquilibriumAgreement), nCurrentTurn + 1);
          }
        }
      }
      else if (this.m_dFirstEquilibriumValue[1] > this.m_dSecondEquilibriumValue[1])
      {
        this.m_dEquilibriumValue = this.m_dFirstEquilibriumValue[1];
        this.m_sEquilibriumAgreement = this.m_sFirstEquilibriumAgreement[1];
      }
      else if (this.m_dFirstEquilibriumValue[1] < this.m_dSecondEquilibriumValue[1])
      {
        this.m_dEquilibriumValue = this.m_dSecondEquilibriumValue[1];
        this.m_sEquilibriumAgreement = this.m_sSecondEquilibriumAgreement[1];
      }
      else
      {
        Random generator = new Random();
        double dRandNum = generator.nextDouble();
        if (dRandNum <= 0.5D)
        {
          this.m_dEquilibriumValue = this.m_dFirstEquilibriumValue[1];
          this.m_sEquilibriumAgreement = this.m_sFirstEquilibriumAgreement[1];
        }
        else
        {
          this.m_dEquilibriumValue = this.m_dSecondEquilibriumValue[1];
          this.m_sEquilibriumAgreement = this.m_sSecondEquilibriumAgreement[1];
        }
      }
    }
    
    public void calculateEquilibrium(QAgentType oppAgentType, boolean bOppEnds, int nMaxTurns, int nAgentType, int nEquilibriumNum, boolean bCalculateForAllAgents, boolean bCalcForNextTurn, int nCurrentTurn)
    {
      QCombinedAgreement ca = new QCombinedAgreement();
      


      QAgentType currentAgentType = null;
      if (bCalcForNextTurn) {
        currentAgentType = QAgentsCore.this.m_CurrentAgentNextTurnType;
      } else {
        currentAgentType = QAgentsCore.this.m_CurrentAgentType;
      }
      if (nCurrentTurn >= nMaxTurns) {
        nCurrentTurn = nMaxTurns - 1;
      }
      double[] dAgreements = new double[2];
      dAgreements[0] = -9999.0D;
      dAgreements[1] = -9999.0D;
      getBothBestAgreementsAtTime(currentAgentType, oppAgentType, nMaxTurns - 1, dAgreements, ca);
      for (int t = nMaxTurns - 2; t >= nCurrentTurn; t--) {
        getBothBestAgreementsAtTime(currentAgentType, oppAgentType, t, dAgreements, ca);
      }
      if (nEquilibriumNum == 1)
      {
        if (bCalcForNextTurn)
        {
          this.m_sFirstEquilibriumAgreementNextTurn[nAgentType] = ca.m_sAgreement;
          
          int[] tempCurrentAgreementIdx = new int[20];
          tempCurrentAgreementIdx = currentAgentType.getAgreementIndices(ca.m_sAgreement);
          double dCurrentAgentValue = currentAgentType.getAgreementValue(tempCurrentAgreementIdx, nCurrentTurn);
          





          this.m_dFirstEquilibriumValueNextTurn[nAgentType] = dCurrentAgentValue;
          if (bCalculateForAllAgents) {
            this.m_dFirstEquilibriumValueNextTurn[nAgentType] *= oppAgentType.getTypeProbability();
          }
        }
        else
        {
          this.m_sFirstEquilibriumAgreement[nAgentType] = ca.m_sAgreement;
          
          int[] tempCurrentAgreementIdx = new int[20];
          tempCurrentAgreementIdx = currentAgentType.getAgreementIndices(ca.m_sAgreement);
          double dCurrentAgentValue = currentAgentType.getAgreementValue(tempCurrentAgreementIdx, nCurrentTurn);
          




          this.m_dFirstEquilibriumValue[nAgentType] = dCurrentAgentValue;
          if (bCalculateForAllAgents) {
            this.m_dFirstEquilibriumValue[nAgentType] *= oppAgentType.getTypeProbability();
          }
        }
      }
      else if (nEquilibriumNum == 2) {
        if (bCalcForNextTurn)
        {
          this.m_sSecondEquilibriumAgreementNextTurn[nAgentType] = ca.m_sAgreement;
          
          int[] tempCurrentAgreementIdx = new int[20];
          tempCurrentAgreementIdx = currentAgentType.getAgreementIndices(ca.m_sAgreement);
          double dCurrentAgentValue = currentAgentType.getAgreementValue(tempCurrentAgreementIdx, nCurrentTurn);
          




          this.m_dSecondEquilibriumValueNextTurn[nAgentType] = dCurrentAgentValue;
          if (bCalculateForAllAgents) {
            this.m_dSecondEquilibriumValueNextTurn[nAgentType] *= oppAgentType.getTypeProbability();
          }
        }
        else
        {
          this.m_sSecondEquilibriumAgreement[nAgentType] = ca.m_sAgreement;
          
          int[] tempCurrentAgreementIdx = new int[20];
          tempCurrentAgreementIdx = currentAgentType.getAgreementIndices(ca.m_sAgreement);
          double dCurrentAgentValue = currentAgentType.getAgreementValue(tempCurrentAgreementIdx, nCurrentTurn);
          




          this.m_dSecondEquilibriumValue[nAgentType] = dCurrentAgentValue;
          if (bCalculateForAllAgents) {
            this.m_dSecondEquilibriumValue[nAgentType] *= oppAgentType.getTypeProbability();
          }
        }
      }
    }
    
    private void getBothBestAgreementsAtTime(QAgentType first, QAgentType second, int nCurrentTurn, double[] agreements, QCombinedAgreement ca)
    {
      double dFirstValue = -9999.0D;
      double dSecondValue = -9999.0D;
      
      double dFirstUtilityFromSecondBest = -9999.0D;
      double dSecondUtilityFromFirstBest = -9999.0D;
      







      double initialAgreement0 = agreements[0];
      double initialAgreement1 = agreements[1];
      
      int nIssuesNum = QAgentsCore.this.m_CurrentAgentType.getIssuesNum();
      int nTotalAgreements = QAgentsCore.this.m_CurrentAgentType.getTotalAgreements();
      
      int[] CurrentAgreementIdx = new int[nIssuesNum];
      int[] MaxIssueValues = new int[nIssuesNum];
      for (int i = 0; i < nIssuesNum; i++)
      {
        CurrentAgreementIdx[i] = 0;
        MaxIssueValues[i] = QAgentsCore.this.m_CurrentAgentType.getMaxIssueValue(i);
      }
      for (int i = 0; i < nTotalAgreements; i++)
      {
        dFirstValue = first.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dSecondValue = second.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        if (dSecondValue > initialAgreement1) {
          if (dFirstValue > agreements[0])
          {
            agreements[0] = dFirstValue;
            dSecondUtilityFromFirstBest = dSecondValue;
            ca.m_sAgreement = first.getAgreementStr(CurrentAgreementIdx);
          }
        }
        boolean bFinishUpdate = false;
        for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
          if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
          {
            CurrentAgreementIdx[k] = 0;
          }
          else
          {
            CurrentAgreementIdx[k] += 1;
            bFinishUpdate = true;
          }
        }
      }
      for (int i = 0; i < nIssuesNum; i++)
      {
        CurrentAgreementIdx[i] = 0;
        MaxIssueValues[i] = QAgentsCore.this.m_CurrentAgentType.getMaxIssueValue(i);
      }
      for (int i = 0; i < nTotalAgreements; i++)
      {
        dFirstValue = first.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dSecondValue = second.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        if (dFirstValue > initialAgreement0) {
          if (dSecondValue > agreements[1])
          {
            agreements[1] = dSecondValue;
            dFirstUtilityFromSecondBest = dFirstValue;
          }
        }
        boolean bFinishUpdate = false;
        for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
          if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
          {
            CurrentAgreementIdx[k] = 0;
          }
          else
          {
            CurrentAgreementIdx[k] += 1;
            bFinishUpdate = true;
          }
        }
      }
      if (dFirstUtilityFromSecondBest > -9999.0D) {
        agreements[0] = (0.5D * (agreements[0] + dFirstUtilityFromSecondBest));
      }
      if (dSecondUtilityFromFirstBest > dFirstUtilityFromSecondBest) {
        agreements[1] = (0.5D * (agreements[1] + dSecondUtilityFromFirstBest));
      }
    }
    
    public void getBestAgreementAtTime(QAgentType offerAgent, QAgentType recvAgent, QCombinedAgreement ca, int nCurrentTurn)
    {
      double dGivenRecvValue = ca.m_dOpponentAgreementValue;
      double dGivenOfferValue = ca.m_dAgentAgreementValue;
      
      double dAgreementValue = dGivenOfferValue;double dOfferAgentValue = 0.0D;double dRecvAgentValue = 0.0D;
      
      int nIssuesNum = QAgentsCore.this.m_CurrentAgentType.getIssuesNum();
      int nTotalAgreements = QAgentsCore.this.m_CurrentAgentType.getTotalAgreements();
      
      int[] CurrentAgreementIdx = new int[nIssuesNum];
      int[] MaxIssueValues = new int[nIssuesNum];
      for (int i = 0; i < nIssuesNum; i++)
      {
        CurrentAgreementIdx[i] = 0;
        MaxIssueValues[i] = QAgentsCore.this.m_CurrentAgentType.getMaxIssueValue(i);
      }
      for (int i = 0; i < nTotalAgreements; i++)
      {
        dRecvAgentValue = recvAgent.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dOfferAgentValue = offerAgent.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        if (dRecvAgentValue > dGivenRecvValue) {
          if (dOfferAgentValue > dAgreementValue)
          {
            dAgreementValue = dOfferAgentValue;
            
            ca.m_dOpponentAgreementValue = dRecvAgentValue;
            ca.m_dAgentAgreementValue = dOfferAgentValue;
            
            ca.m_sAgreement = offerAgent.getAgreementStr(CurrentAgreementIdx);
          }
        }
        boolean bFinishUpdate = false;
        for (int k = nIssuesNum - 1; (k >= 0) && (!bFinishUpdate); k--) {
          if (CurrentAgreementIdx[k] + 1 >= MaxIssueValues[k])
          {
            CurrentAgreementIdx[k] = 0;
          }
          else
          {
            CurrentAgreementIdx[k] += 1;
            bFinishUpdate = true;
          }
        }
      }
    }
    
    class QCombinedAgreement
    {
      public double m_dAgentAgreementValue;
      public double m_dOpponentAgreementValue;
      public String m_sAgreement;
      
      QCombinedAgreement() {}
    }
  }
  
  public QAgentsCore(String sFileName, String sNow, QOAgent agent)
  {
    this.m_Agent = agent;
    this.m_bEquilibriumAgent = false;
    this.m_sLogFileName = sFileName;
    
    this.m_CurrentAgentType = null;
    this.m_CurrentAgentNextTurnType = null;
    
    this.m_EnglandAgentTypesList = new ArrayList();
    this.m_ZimbabweAgentTypesList = new ArrayList();
    
    this.m_EnglandAgentTypesNextTurnList = new ArrayList();
    this.m_ZimbabweAgentTypesNextTurnList = new ArrayList();
    
    this.m_sProbFileName = ("logs\\prob" + sNow + ".");
    for (int i = 0; i < 3; i++)
    {
      this.m_EnglandAgentTypesList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      this.m_ZimbabweAgentTypesList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      
      this.m_EnglandAgentTypesNextTurnList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      this.m_ZimbabweAgentTypesNextTurnList.add(i, new QAgentType(this.m_bEquilibriumAgent));
    }
    createEnglandLongTermType();
    createEnglandShortTermType();
    createEnglandCompromiseType();
    
    createZimbabweLongTermType();
    createZimbabweShortTermType();
    createZimbabweCompromiseType();
  }
  
  public QAgentsCore(String sFileName, String sNow, boolean bIsEquilibriumAgent, QOAgent agent)
  {
    this.m_Agent = agent;
    this.m_bEquilibriumAgent = bIsEquilibriumAgent;
    this.m_sLogFileName = sFileName;
    
    this.m_CurrentAgentType = null;
    this.m_CurrentAgentNextTurnType = null;
    
    this.m_EnglandAgentTypesList = new ArrayList();
    this.m_ZimbabweAgentTypesList = new ArrayList();
    
    this.m_EnglandAgentTypesNextTurnList = new ArrayList();
    this.m_ZimbabweAgentTypesNextTurnList = new ArrayList();
    
    this.m_sProbFileName = ("logs\\prob" + sNow + ".");
    for (int i = 0; i < 3; i++)
    {
      this.m_EnglandAgentTypesList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      this.m_ZimbabweAgentTypesList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      
      this.m_EnglandAgentTypesNextTurnList.add(i, new QAgentType(this.m_bEquilibriumAgent));
      this.m_ZimbabweAgentTypesNextTurnList.add(i, new QAgentType(this.m_bEquilibriumAgent));
    }
    createEnglandLongTermType();
    createEnglandShortTermType();
    createEnglandCompromiseType();
    
    createZimbabweLongTermType();
    createZimbabweShortTermType();
    createZimbabweCompromiseType();
  }
  
  public QAgentType getEnglandLongTermType()
  {
    return (QAgentType)this.m_EnglandAgentTypesList.get(0);
  }
  
  public QAgentType getEnglandShortTermType()
  {
    return (QAgentType)this.m_EnglandAgentTypesList.get(1);
  }
  
  public QAgentType getEnglandCompromiseType()
  {
    return (QAgentType)this.m_EnglandAgentTypesList.get(2);
  }
  
  public QAgentType getZimbabweLongTermType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesList.get(0);
  }
  
  public QAgentType getZimbabweShortTermType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesList.get(1);
  }
  
  public QAgentType getZimbabweCompromiseType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesList.get(2);
  }
  
  public QAgentType getEnglandLongTermNextTurnType()
  {
    return (QAgentType)this.m_EnglandAgentTypesNextTurnList.get(0);
  }
  
  public QAgentType getEnglandShortTermNextTurnType()
  {
    return (QAgentType)this.m_EnglandAgentTypesNextTurnList.get(1);
  }
  
  public QAgentType getEnglandCompromiseNextTurnType()
  {
    return (QAgentType)this.m_EnglandAgentTypesNextTurnList.get(2);
  }
  
  public QAgentType getZimbabweLongTermNextTurnType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesNextTurnList.get(0);
  }
  
  public QAgentType getZimbabweShortTermNextTurnType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesNextTurnList.get(1);
  }
  
  public QAgentType getZimbabweCompromiseNextTurnType()
  {
    return (QAgentType)this.m_ZimbabweAgentTypesNextTurnList.get(2);
  }
  
  private void createZimbabweCompromiseType()
  {
    QAgentType compromiseType = new QAgentType(this.m_bEquilibriumAgent);
    compromiseType.setAgentType(1);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[2], compromiseType);
    
    this.m_ZimbabweAgentTypesList.set(2, compromiseType);
    
    QAgentType agentTypeNextTurn = compromiseType;
    agentTypeNextTurn.calculateValues(2);
    this.m_ZimbabweAgentTypesNextTurnList.set(2, agentTypeNextTurn);
  }
  
  private void createZimbabweShortTermType()
  {
    QAgentType shortTermType = new QAgentType(this.m_bEquilibriumAgent);
    shortTermType.setAgentType(1);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[1], shortTermType);
    
    this.m_ZimbabweAgentTypesList.set(1, shortTermType);
    
    QAgentType agentTypeNextTurn = shortTermType;
    agentTypeNextTurn.calculateValues(2);
    this.m_ZimbabweAgentTypesNextTurnList.set(1, agentTypeNextTurn);
  }
  
  private void createZimbabweLongTermType()
  {
    QAgentType longTermType = new QAgentType(this.m_bEquilibriumAgent);
    longTermType.setAgentType(1);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[0], longTermType);
    
    this.m_ZimbabweAgentTypesList.set(0, longTermType);
    
    QAgentType agentTypeNextTurn = longTermType;
    agentTypeNextTurn.calculateValues(2);
    this.m_ZimbabweAgentTypesNextTurnList.set(0, agentTypeNextTurn);
  }
  
  private void createEnglandCompromiseType()
  {
    QAgentType compromiseType = new QAgentType(this.m_bEquilibriumAgent);
    compromiseType.setAgentType(0);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[2], compromiseType);
    

    this.m_EnglandAgentTypesList.set(2, compromiseType);
    
    QAgentType agentTypeNextTurn = compromiseType;
    agentTypeNextTurn.calculateValues(2);
    this.m_EnglandAgentTypesNextTurnList.set(2, agentTypeNextTurn);
  }
  
  private void createEnglandShortTermType()
  {
    QAgentType shortTermType = new QAgentType(this.m_bEquilibriumAgent);
    shortTermType.setAgentType(0);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[1], shortTermType);
    
    this.m_EnglandAgentTypesList.set(1, shortTermType);
    
    QAgentType agentTypeNextTurn = shortTermType;
    agentTypeNextTurn.calculateValues(2);
    this.m_EnglandAgentTypesNextTurnList.set(1, agentTypeNextTurn);
  }
  
  private void createEnglandLongTermType()
  {
    QAgentType longTermType = new QAgentType(this.m_bEquilibriumAgent);
    longTermType.setAgentType(0);
    
    createAgentTypeFromFile(this.m_Agent.opponentModels[0], longTermType);
    
    this.m_EnglandAgentTypesList.set(0, longTermType);
    
    QAgentType agentTypeNextTurn = longTermType;
    agentTypeNextTurn.calculateValues(2);
    this.m_EnglandAgentTypesNextTurnList.set(0, agentTypeNextTurn);
  }
  
  private void createAgentTypeFromFile(UtilitySpace utilitySpace, QAgentType agentType)
  {
    double[] dGeneralValues = new double[3];
    

    dGeneralValues[0] = 0.0D;
    dGeneralValues[2] = -9999.0D;
    dGeneralValues[1] = -9999.0D;
    
    String line = readUtilityDetails(utilitySpace, agentType.m_fullUtility.lstUtilityDetails, dGeneralValues);
    agentType.m_fullUtility.dTimeEffect = dGeneralValues[0];
    agentType.m_fullUtility.dStatusQuoValue = dGeneralValues[2];
    agentType.m_fullUtility.dOptOutValue = dGeneralValues[1];
    

    agentType.calculateValues(1);
  }
  
  public String readUtilityDetails(UtilitySpace utilitySpace, ArrayList<UtilityDetails> lstUtilityDetails, double[] dGeneralValues)
  {
    UtilityDetails utilityDetails = null;
    

    dGeneralValues[0] = -6.0D;
    
    dGeneralValues[2] = 306.0D;
    
    dGeneralValues[1] = 215.0D;
    
    utilityDetails = new UtilityDetails();
    for (Issue lTmp : utilitySpace.getDomain().getIssues())
    {
      IssueDiscrete lIssue = (IssueDiscrete)lTmp;
      utilityDetails.sTitle = lIssue.getName();
      
      UtilityIssue utilityIssue = new UtilityIssue();
      utilityIssue.sAttributeName = lIssue.getName();
      utilityIssue.sSide = "Both";
      utilityIssue.dAttributeWeight = (utilitySpace.getWeight(lIssue.getNumber()) * 100.0D);
      for (ValueDiscrete lValue : lIssue.getValues())
      {
        UtilityValue utilityValue = new UtilityValue();
        
        utilityValue.sValue = lValue.getValue();
        try
        {
          utilityValue.dUtility = ((EvaluatorDiscrete)utilitySpace.getEvaluator(lIssue.getNumber())).getEvaluationNotNormalized(lValue).intValue();
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
        utilityValue.dTimeEffect = new Double(0.0D).doubleValue();
        
        utilityIssue.lstUtilityValues.add(utilityValue);
        utilityIssue.sExplanation = lIssue.getDescription();
      }
      utilityDetails.lstUtilityIssues.add(utilityIssue);
    }
    lstUtilityDetails.add(utilityDetails);
    return "";
  }
  
  public void updateAgreementsValues(int nTimePeriod)
  {
    QAgentType agentType = null;
    QAgentType agentTypeNextTurn = null;
    for (int i = 0; i < 3; i++)
    {
      agentType = (QAgentType)this.m_EnglandAgentTypesList.get(i);
      agentType.calculateValues(nTimePeriod);
      this.m_EnglandAgentTypesList.set(i, agentType);
      
      agentTypeNextTurn = agentType;
      agentTypeNextTurn.calculateValues(nTimePeriod + 1);
      this.m_EnglandAgentTypesNextTurnList.set(i, agentTypeNextTurn);
      
      agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(i);
      agentType.calculateValues(nTimePeriod);
      this.m_ZimbabweAgentTypesList.set(i, agentType);
      
      agentTypeNextTurn = agentType;
      agentTypeNextTurn.calculateValues(nTimePeriod + 1);
      this.m_ZimbabweAgentTypesNextTurnList.set(i, agentTypeNextTurn);
    }
  }
  
  public void initGenerateAgreement(QAgentType agentType)
  {
    this.m_CurrentAgentType = agentType;
    
    this.m_GenerateAgreement = new QGenerateAgreement();
  }
  
  public void calculateAgreement(QAgentType agentType, int nCurrentTurn)
  {
    this.m_GenerateAgreement.calculateAgreement(agentType, nCurrentTurn, false);
  }
  
  public void calculateEquilibriumAgreement(QAgentType agentType, int nMaxTurns, boolean bCalculateForAllAgents, int nCurrentTurn)
  {
    this.m_GenerateAgreement.calculateEquilibrium(agentType, nMaxTurns, bCalculateForAllAgents, false, nCurrentTurn);
  }
  
  public String getQOAgreement()
  {
    return this.m_GenerateAgreement.getSelectedQOAgreementStr();
  }
  
  public String getEquilibriumAgreement()
  {
    return this.m_GenerateAgreement.getSelectedEquilibriumAgreementStr();
  }
  
  public void calculateNextTurnAgreement(QAgentType agentType, int nNextTurn)
  {
    this.m_GenerateAgreement.calculateAgreement(agentType, nNextTurn, true);
  }
  
  public void calculateNextTurnEquilibriumAgreement(QAgentType agentType, int nMaxTurns, boolean bCalculateForAllAgents, int nNextTurn)
  {
    this.m_GenerateAgreement.calculateEquilibrium(agentType, nMaxTurns, bCalculateForAllAgents, true, nNextTurn);
  }
  
  public double getNextTurnAgentQOUtilityValue()
  {
    return this.m_GenerateAgreement.getNextTurnAgentQOUtilityValue();
  }
  
  public double getNextTurnAgentEquilibriumUtilityValue()
  {
    return this.m_GenerateAgreement.getNextTurnAgentEquilibriumUtilityValue();
  }
  
  public String getNextTurnAgentQOAgreement()
  {
    return this.m_GenerateAgreement.getNextTurnQOAgreement();
  }
  
  public String getNextTurnAgentEquilibriumAgreement()
  {
    return this.m_GenerateAgreement.getNextTurnEquilibriumAgreement();
  }
  
  public double getNextTurnOpponentQOUtilityValue()
  {
    return this.m_GenerateAgreement.getNextTurnOpponentQOUtilityValue();
  }
  
  public QAgentType getNextTurnOpponentType()
  {
    QAgentType opponentNextTurnType = null;
    int nOppType = this.m_GenerateAgreement.getNextTurnOpponentType();
    if (this.m_CurrentAgentType.isTypeOf(1)) {
      switch (nOppType)
      {
      case 2: 
        opponentNextTurnType = getEnglandCompromiseNextTurnType();
        break;
      case 0: 
        opponentNextTurnType = getEnglandLongTermNextTurnType();
        break;
      case 1: 
        opponentNextTurnType = getEnglandShortTermNextTurnType();
        break;
      default: 
        System.out.println("[QO]Agent type is unknown [QAgentsCore::getNextTurnOpponentType(1310)]");
        System.err.println("[QO]Agent type is unknown [QAgentsCore::getNextTurnOpponentType(1310)]");
        break;
      }
    } else if (this.m_CurrentAgentType.isTypeOf(0)) {
      switch (nOppType)
      {
      case 2: 
        opponentNextTurnType = getZimbabweCompromiseNextTurnType();
        break;
      case 0: 
        opponentNextTurnType = getZimbabweLongTermNextTurnType();
        break;
      case 1: 
        opponentNextTurnType = getZimbabweShortTermNextTurnType();
        break;
      default: 
        System.out.println("[QO]Agent type is unknown [QAgentsCore::getNextTurnOpponentType(1329)]");
        System.err.println("[QO]Agent type is unknown [QAgentsCore::getNextTurnOpponentType(1329)]");
      }
    }
    return opponentNextTurnType;
  }
  
  public void updateOpponentProbability(int[] CurrentAgreementIdx, int nCurrentTurn, int nMessageType, int nResponseType)
  {
    if (nResponseType == 0) {
      updateOpponentProbabilityUponMessageReceived(CurrentAgreementIdx, nCurrentTurn, nMessageType);
    } else if (nResponseType == 1) {
      updateOpponentProbabilityUponMessageRejected(CurrentAgreementIdx, nCurrentTurn, nMessageType);
    }
  }
  
  private void updateOpponentProbabilityUponMessageReceived(int[] CurrentAgreementIdx, int nCurrentTurn, int nMessageType)
  {
    QAgentType agentType = null;
    double dPrevTypeProbability = 0.0D;
    double dPrevOfferValue = 0.0D;
    double dPrevOfferProbability = 0.0D;
    double dOfferSum = 0.0D;
    double dUpdatedTypeProbability = 0.0D;
    if (this.m_CurrentAgentType.isTypeOf(1))
    {
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_EnglandAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        dPrevOfferValue = agentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dPrevOfferProbability = agentType.getAgreementLuceValue(dPrevOfferValue, true);
        
        dOfferSum += dPrevOfferProbability * dPrevTypeProbability;
      }
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_EnglandAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        dPrevOfferValue = agentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dPrevOfferProbability = agentType.getAgreementLuceValue(dPrevOfferValue, true);
        
        dUpdatedTypeProbability = dPrevOfferProbability * dPrevTypeProbability / dOfferSum;
        
        System.err.println("%%%%%%%%%%%%%%%%%%%%%%%");
        System.err.println("PREV = " + dPrevTypeProbability + ", UP = " + dUpdatedTypeProbability);
        
        agentType.setTypeProbability(dUpdatedTypeProbability);
        
        this.m_EnglandAgentTypesList.set(i, agentType);
      }
      try
      {
        PrintWriter pw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Eng.txt", true));
        pw.println(getEnglandProbabilitiesStr());
        pw.close();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }
    else if (this.m_CurrentAgentType.isTypeOf(0))
    {
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        dPrevOfferValue = agentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dPrevOfferProbability = agentType.getAgreementLuceValue(dPrevOfferValue, true);
        
        dOfferSum += dPrevOfferProbability * dPrevTypeProbability;
      }
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        dPrevOfferValue = agentType.getAgreementValue(CurrentAgreementIdx, nCurrentTurn);
        dPrevOfferProbability = agentType.getAgreementLuceValue(dPrevOfferValue, true);
        
        dUpdatedTypeProbability = dPrevOfferProbability * dPrevTypeProbability / dOfferSum;
        
        System.err.println("%%%%%%%%%%%%%%%%%%%%%%%");
        System.err.println("PREV = " + dPrevTypeProbability + ", UP = " + dUpdatedTypeProbability);
        
        agentType.setTypeProbability(dUpdatedTypeProbability);
        
        this.m_ZimbabweAgentTypesList.set(i, agentType);
      }
      try
      {
        PrintWriter pw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Zim.txt", true));
        pw.println(getZimbabweProbabilitiesStr());
        pw.close();
      }
      catch (IOException e)
      {
        System.out.println("Error opening QO prob file [QAgentsCore::UpdateOpponentProbabilityUponMessageReceived(1423)]");
        System.err.println("Error opening QO prob file [QAgentsCore::UpdateOpponentProbabilityUponMessageReceived(1423)]");
        e.printStackTrace();
      }
    }
  }
  
  private void updateOpponentProbabilityUponMessageRejected(int[] CurrentAgreementIdx, int nCurrentTurn, int nMessageType)
  {
    QAgentType agentType = null;
    double dPrevTypeProbability = 0.0D;
    double dPrevOfferProbability = 0.0D;
    double dOfferSum = 0.0D;
    double dUpdatedTypeProbability = 0.0D;
    double dAgentOfferSum = 0.0D;
    
    String sRejectedMsg = this.m_CurrentAgentType.getAgreementStr(CurrentAgreementIdx);
    if (this.m_CurrentAgentType.isTypeOf(1))
    {
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_EnglandAgentTypesList.get(i);
        
        dOfferSum += agentType.calcRejectionProbabilities(sRejectedMsg, nCurrentTurn);
      }
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_EnglandAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        
        dAgentOfferSum = agentType.calcRejectionProbabilities(sRejectedMsg, nCurrentTurn);
        
        dUpdatedTypeProbability = dAgentOfferSum * dPrevTypeProbability / dOfferSum;
        
        System.err.println("%%%%%%%%%%%%%%%%%%%%%%%");
        System.err.println("PREV = " + dPrevTypeProbability + ", UP = " + dUpdatedTypeProbability);
        
        agentType.setTypeProbability(dUpdatedTypeProbability);
        
        this.m_EnglandAgentTypesList.set(i, agentType);
      }
      try
      {
        PrintWriter pw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Eng.txt", true));
        pw.println(getEnglandProbabilitiesStr());
        pw.close();
      }
      catch (IOException e)
      {
        e.printStackTrace();
      }
    }
    else if (this.m_CurrentAgentType.isTypeOf(0))
    {
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(i);
        
        dOfferSum += agentType.calcRejectionProbabilities(sRejectedMsg, nCurrentTurn);
        
        dOfferSum += dPrevOfferProbability * dPrevTypeProbability;
      }
      for (int i = 0; i < 3; i++)
      {
        agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(i);
        
        dPrevTypeProbability = agentType.getTypeProbability();
        
        dAgentOfferSum = agentType.calcRejectionProbabilities(sRejectedMsg, nCurrentTurn);
        
        dUpdatedTypeProbability = dAgentOfferSum * dPrevTypeProbability / dOfferSum;
        
        System.err.println("%%%%%%%%%%%%%%%%%%%%%%%");
        System.err.println("PREV = " + dPrevTypeProbability + ", UP = " + dUpdatedTypeProbability);
        
        agentType.setTypeProbability(dUpdatedTypeProbability);
        
        this.m_ZimbabweAgentTypesList.set(i, agentType);
      }
      try
      {
        PrintWriter pw = new PrintWriter(new FileWriter(this.m_sProbFileName + "Zim.txt", true));
        pw.println(getZimbabweProbabilitiesStr());
        pw.close();
      }
      catch (IOException e)
      {
        System.out.println("Error opening QO prob file [QAgentsCore::UpdateOpponentProbabilityUponMessageRejected(1525)]");
        System.err.println("Error opening QO prob file [QAgentsCore::UpdateOpponentProbabilityUponMessageRejected(1525)]");
        e.printStackTrace();
      }
    }
  }
  
  public String getEnglandProbabilitiesStr()
  {
    String sProbabilitiesStr = "";
    
    QAgentType agentType = null;
    double dAgentProbability = 0.0D;
    
    agentType = (QAgentType)this.m_EnglandAgentTypesList.get(0);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = "EngLong: " + dAgentProbability;
    
    agentType = (QAgentType)this.m_EnglandAgentTypesList.get(1);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = sProbabilitiesStr + "; EngShort: " + dAgentProbability;
    
    agentType = (QAgentType)this.m_EnglandAgentTypesList.get(2);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = sProbabilitiesStr + "; EngComp: " + dAgentProbability;
    
    return sProbabilitiesStr;
  }
  
  public String getZimbabweProbabilitiesStr()
  {
    String sProbabilitiesStr = "";
    
    QAgentType agentType = null;
    double dAgentProbability = 0.0D;
    
    agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(0);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = "ZimLong: " + dAgentProbability;
    
    agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(1);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = sProbabilitiesStr + "; ZimShort: " + dAgentProbability;
    
    agentType = (QAgentType)this.m_ZimbabweAgentTypesList.get(2);
    dAgentProbability = agentType.getTypeProbability();
    
    sProbabilitiesStr = sProbabilitiesStr + "; ZimComp: " + dAgentProbability;
    
    return sProbabilitiesStr;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.QAgentsCore
 * JD-Core Version:    0.7.1
 */