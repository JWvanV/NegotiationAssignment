package agents.qoagent2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.StringTokenizer;
import java.util.Vector;

class Agent
{
  private Vector<Issue> m_vecIssues;
  private boolean m_bHasOpponent;
  private boolean m_bHasMediator;
  private boolean m_bSupportMediator;
  private int m_nCurrentTurn;
  private Socket m_socket = null;
  private String m_sSide;
  private PrintWriter m_out = null;
  GameTimeServer m_gtEndTurn = null;
  GameTimeServer m_gtEndNeg = null;
  private InetAddress m_ip = null;
  private int m_nPort;
  private double m_dScore;
  private double m_dTimeEffect;
  private double m_dOptOutValue;
  private double m_dStatusQuoValue;
  private String m_sId;
  private String m_sName;
  private String m_sOppId;
  private String m_sOppName;
  private String m_sMedId;
  private String m_sMedName;
  private String m_sIdReligious;
  private String m_sIdSecular;
  private String m_sNameReligious;
  private String m_sNameSecular;
  public static final String TIME_EFFECT_STR = "Time-Effect";
  public static final String OPT_OUT_STR = "Opt-Out";
  public static final String STATUS_QUO_STR = "Status-Quo";
  private String m_sPrefDetails;
  private String m_sEndNegReason;
  private int m_nOptOutNum;
  private int m_nResponsesNum;
  private int m_nAcceptsNum;
  private int m_nRejectionsNum;
  private int m_nCommentsNum;
  private int m_nThreatsNum;
  private int m_nOffersNum;
  private int m_nPromisesNum;
  private int m_nQueriesNum;
  
  public Agent(boolean SupportMed, String sSide)
  {
    this.m_nOptOutNum = 0;
    this.m_nResponsesNum = 0;
    this.m_nAcceptsNum = 0;
    this.m_nRejectionsNum = 0;
    this.m_nThreatsNum = 0;
    this.m_nCommentsNum = 0;
    this.m_nOffersNum = 0;
    this.m_nPromisesNum = 0;
    this.m_nQueriesNum = 0;
    
    this.m_sEndNegReason = "";
    
    this.m_dTimeEffect = 0.0D;
    this.m_dStatusQuoValue = 0.0D;
    this.m_dOptOutValue = 0.0D;
    
    this.m_sIdReligious = null;
    this.m_sIdSecular = null;
    this.m_sMedId = null;
    
    this.m_sSide = sSide;
    this.m_bHasMediator = false;
    this.m_bSupportMediator = SupportMed;
    

    this.m_bHasOpponent = false;
    this.m_nCurrentTurn = 1;
    this.m_nPort = 0;
    this.m_dScore = 0.0D;
    
    this.m_vecIssues = new Vector();
    try
    {
      BufferedReader br = new BufferedReader(new FileReader("utility" + this.m_sSide + ".txt"));
      
      int nOrder = 1;
      Issue issue = new Issue();
      String line;
      while ((line = br.readLine()) != null) {
        if (!line.startsWith("#")) {
          if (line.startsWith("@"))
          {
            StringTokenizer stGeneral = new StringTokenizer(line);
            
            stGeneral.nextToken();
            
            String sType = stGeneral.nextToken();
            
            String sValue = stGeneral.nextToken();
            Double dTemp = new Double(sValue);
            if (sType.equals("Time-Effect")) {
              this.m_dTimeEffect = dTemp.doubleValue();
            } else if (sType.equals("Status-Quo")) {
              this.m_dStatusQuoValue = dTemp.doubleValue();
            } else if (sType.equals("Opt-Out")) {
              this.m_dOptOutValue = dTemp.doubleValue();
            }
          }
          else if (!line.startsWith("!"))
          {
            switch (nOrder)
            {
            case 1: 
              issue.setAttribute(line.substring(0, line.indexOf("*")));
              String sTemp = line.substring(line.indexOf("*") + 1);
              sTemp = sTemp.substring(sTemp.indexOf("*") + 1);
              issue.setWeight(sTemp);
              break;
            case 2: 
              issue.setValues(line);
              break;
            case 3: 
              issue.setUtilities(line);
              break;
            case 4: 
              issue.setTimeEffect(line);
              break;
            case 5: 
              this.m_vecIssues.addElement(issue);
              nOrder = 0;
              issue = new Issue();
            }
            nOrder++;
          }
        }
      }
      br.close();
    }
    catch (IOException e)
    {
      System.out.println("ERROR----[Agent " + this.m_sId + "] " + "I/O Error while reading from file: " + e.getMessage() + "[Agent::Agent(153)]");
      System.err.println("ERROR----[Agent " + this.m_sId + "] " + "I/O Error while reading from file: " + e.getMessage() + "[Agent::Agent(153)]");
    }
  }
  
  public void setScore(double score)
  {
    this.m_dScore = score;
  }
  
  public double getScore()
  {
    return this.m_dScore;
  }
  
  public void setIssuesVector(Vector<Issue> vec)
  {
    this.m_vecIssues = vec;
  }
  
  public Vector<Issue> getIssuesVector()
  {
    return this.m_vecIssues;
  }
  
  public void initIssuesVector()
  {
    if (this.m_vecIssues != null) {
      for (int i = 0; i < getIssuesNum(); i++) {
        getIssueAt(i).setAgreed(false);
      }
    }
  }
  
  public void setName(String sName)
  {
    this.m_sName = sName;
  }
  
  public String getName()
  {
    return this.m_sName;
  }
  
  public String getOpponentName()
  {
    return this.m_sOppName;
  }
  
  public String getMedName()
  {
    return this.m_sMedName;
  }
  
  public String getNameReligious()
  {
    return this.m_sNameReligious;
  }
  
  public String getNameSecular()
  {
    return this.m_sNameSecular;
  }
  
  public void setOpponentName(String sOppName)
  {
    this.m_sOppName = sOppName;
  }
  
  public void setMedName(String sMedName)
  {
    this.m_sMedName = sMedName;
  }
  
  public void setNameReligious(String sName)
  {
    this.m_sNameReligious = sName;
  }
  
  public void setNameSecular(String sName)
  {
    this.m_sNameSecular = sName;
  }
  
  public void setEndTurnNewGame()
  {
    this.m_gtEndTurn.newGame();
  }
  
  public void setEndNegNewGame()
  {
    this.m_gtEndNeg.newGame();
  }
  
  public String getSide()
  {
    return this.m_sSide;
  }
  
  public void setSide(String sSide)
  {
    this.m_sSide = sSide;
  }
  
  public void setIp(InetAddress ip)
  {
    this.m_ip = ip;
  }
  
  public void setIssueAt(int index, Issue issue)
  {
    this.m_vecIssues.set(index, issue);
  }
  
  public void setEndNeg(boolean bCountUp, int nHours, int nMinutes, int nSeconds, boolean bTurnOrNeg, int nMaxTurn)
  {
    this.m_gtEndNeg = new GameTimeServer(bCountUp, nHours, nMinutes, nSeconds, this, bTurnOrNeg, nMaxTurn);
  }
  
  public void setEndNegRun(boolean bRun)
  {
    this.m_gtEndNeg.setRun(bRun);
  }
  
  public void setEndTurn(boolean bCountUp, int nHours, int nMinutes, int nSeconds, boolean bTurnOrNeg, int nMaxTurn)
  {
    this.m_gtEndTurn = new GameTimeServer(bCountUp, nHours, nMinutes, nSeconds, this, bTurnOrNeg, nMaxTurn);
  }
  
  public void setEndTurnRun(boolean bRun)
  {
    this.m_gtEndTurn.setRun(bRun);
  }
  
  public int getIssuesNum()
  {
    return this.m_vecIssues.size();
  }
  
  public Issue getIssueAt(int index)
  {
    return (Issue)this.m_vecIssues.elementAt(index);
  }
  
  public void setPort(int nPort)
  {
    this.m_nPort = nPort;
  }
  
  public int getPort()
  {
    return this.m_nPort;
  }
  
  public void setId(String sId)
  {
    this.m_sId = sId;
  }
  
  public String getId()
  {
    return this.m_sId;
  }
  
  public String getOpponentId()
  {
    return this.m_sOppId;
  }
  
  public String getMedId()
  {
    return this.m_sMedId;
  }
  
  public String getIdReligious()
  {
    return this.m_sIdReligious;
  }
  
  public String getIdSecular()
  {
    return this.m_sIdSecular;
  }
  
  public void setOpponentId(String sOppId)
  {
    this.m_sOppId = sOppId;
  }
  
  public void setMedId(String sMedId)
  {
    this.m_sMedId = sMedId;
  }
  
  public void setIdReligious(String sId)
  {
    this.m_sIdReligious = sId;
  }
  
  public void setIdSecular(String sId)
  {
    this.m_sIdSecular = sId;
  }
  
  public void setSocket(Socket socket)
  {
    this.m_socket = socket;
    try
    {
      this.m_out = new PrintWriter(this.m_socket.getOutputStream(), true);
    }
    catch (IOException e)
    {
      System.out.println("ERROR----[Agent " + this.m_sId + "] " + "Error opening socket: " + e.getMessage() + " [Agent::setSocket(614)]");
      System.err.println("ERROR----[Agent " + this.m_sId + "] " + "Error opening socket: " + e.getMessage() + " [Agent::setSocket(614)]");
    }
  }
  
  public void closeSocketStream()
  {
    this.m_out.close();
  }
  
  public Socket getSocket()
  {
    return this.m_socket;
  }
  
  public void writeToSocket(String sMsg)
  {
    this.m_out.println(sMsg);
  }
  
  public void incrementCurrentTurn()
  {
    this.m_nCurrentTurn += 1;
  }
  
  public void setCurrentTurn(int nCurrentTurn)
  {
    this.m_nCurrentTurn = nCurrentTurn;
  }
  
  public int getCurrentTurn()
  {
    return this.m_nCurrentTurn;
  }
  
  public boolean hasOpponent()
  {
    return this.m_bHasOpponent;
  }
  
  public void setHasOpponent(boolean bHasOpponent)
  {
    this.m_bHasOpponent = bHasOpponent;
  }
  
  public boolean hasMediator()
  {
    return this.m_bHasMediator;
  }
  
  public void setHasMediator(boolean bHasMediator)
  {
    this.m_bHasMediator = bHasMediator;
  }
  
  public boolean supportMediator()
  {
    return this.m_bSupportMediator;
  }
  
  public void startEndNegThread()
  {
    new Thread(this.m_gtEndNeg).start();
  }
  
  public void startEndTurnThread()
  {
    new Thread(this.m_gtEndTurn).start();
  }
  
  public void setPrefDetails(String sPrefDetails)
  {
    this.m_sPrefDetails = sPrefDetails;
  }
  
  public String getPrefDetails()
  {
    return this.m_sPrefDetails;
  }
  
  public double getAgreementTimeEffect()
  {
    return this.m_dTimeEffect;
  }
  
  public double getAgreementOptOutValue()
  {
    return this.m_dOptOutValue;
  }
  
  public void setEndNegReason(String sEndNegReason)
  {
    this.m_sEndNegReason = sEndNegReason;
  }
  
  public String getEndNegReason()
  {
    return this.m_sEndNegReason;
  }
  
  public void setOptOutNum(int nOptOutNum)
  {
    this.m_nOptOutNum = nOptOutNum;
  }
  
  public int getOptOutNum()
  {
    return this.m_nOptOutNum;
  }
  
  public void incrementResponsesNum()
  {
    this.m_nResponsesNum += 1;
  }
  
  public int getResponsesNum()
  {
    return this.m_nResponsesNum++;
  }
  
  public void incrementAcceptsNum()
  {
    this.m_nAcceptsNum += 1;
  }
  
  public int getAcceptsNum()
  {
    return this.m_nAcceptsNum;
  }
  
  public void incrementRejectionsNum()
  {
    this.m_nRejectionsNum += 1;
  }
  
  public int getRejectionsNum()
  {
    return this.m_nRejectionsNum;
  }
  
  public void incrementThreatsNum()
  {
    this.m_nThreatsNum += 1;
  }
  
  public int getThreatsNum()
  {
    return this.m_nThreatsNum;
  }
  
  public void incrementCommentsNum()
  {
    this.m_nCommentsNum += 1;
  }
  
  public int getCommentsNum()
  {
    return this.m_nCommentsNum;
  }
  
  public void incrementQueriesNum()
  {
    this.m_nQueriesNum += 1;
  }
  
  public int getQueriesNum()
  {
    return this.m_nQueriesNum;
  }
  
  public void incrementOffersNum()
  {
    this.m_nOffersNum += 1;
  }
  
  public int getOffersNum()
  {
    return this.m_nOffersNum;
  }
  
  public void incrementPromisesNum()
  {
    this.m_nPromisesNum += 1;
  }
  
  public int getPromisesNum()
  {
    return this.m_nPromisesNum;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.qoagent2.Agent
 * JD-Core Version:    0.7.1
 */