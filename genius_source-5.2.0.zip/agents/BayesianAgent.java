package agents;

import agents.bayesianopponentmodel.BayesianOpponentModelScalable;
import agents.bayesianopponentmodel.OpponentModel;
import agents.bayesianopponentmodel.OpponentModelUtilSpace;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.issue.Issue;
import negotiator.protocol.BilateralAtomicNegotiationSession;
import negotiator.utility.UtilitySpace;
import negotiator.xml.SimpleElement;

public class BayesianAgent
  extends Agent
{
  private Action messageOpponent;
  private Bid myLastBid = null;
  private Action myLastAction = null;
  private Bid fOpponentPreviousBid = null;
  
  private static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  private static enum STRATEGY
  {
    SMART,  SERIAL,  RESPONSIVE,  RANDOM,  TIT_FOR_TAT;
    
    private STRATEGY() {}
  }
  
  private STRATEGY fStrategy = STRATEGY.TIT_FOR_TAT;
  private int fSmartSteps;
  protected OpponentModel fOpponentModel;
  private static final double CONCESSIONFACTOR = 0.04D;
  private static final double ALLOWED_UTILITY_DEVIATION = 0.01D;
  private static final int NUMBER_OF_SMART_STEPS = 0;
  private ArrayList<Bid> myPreviousBids;
  private boolean fSkipDistanceCalc = false;
  private boolean logging = true;
  
  public String getVersion()
  {
    return "2.1";
  }
  
  public String getName()
  {
    return "Bayesian Agent";
  }
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastAction = null;
    this.fSmartSteps = 0;
    this.myPreviousBids = new ArrayList();
    prepareOpponentModel();
  }
  
  protected void prepareOpponentModel()
  {
    this.fOpponentModel = new BayesianOpponentModelScalable(this.utilitySpace);
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.messageOpponent = opponentAction;
  }
  
  private Action proposeInitialBid()
    throws Exception
  {
    Bid lBid = null;
    
    lBid = this.utilitySpace.getMaxUtilityBid();
    this.fSmartSteps = 0;
    this.myLastBid = lBid;
    return new Offer(getAgentID(), lBid);
  }
  
  private Bid getNextBid(Bid pOppntBid)
    throws Exception
  {
    if (pOppntBid == null) {
      throw new NullPointerException("pOpptBid=null");
    }
    if (this.myLastBid == null) {
      throw new Exception("myLastBid==null");
    }
    log("Get next bid ...");
    
    BidSpace bs = new BidSpace(this.utilitySpace, new OpponentModelUtilSpace(this.fOpponentModel), false, true);
    



    double opponentConcession = 0.0D;
    if (this.fOpponentPreviousBid == null)
    {
      opponentConcession = 0.0D;
    }
    else
    {
      double opponentUtil = this.fOpponentModel.getNormalizedUtility(pOppntBid);
      
      double opponentFirstBidUtil = this.fOpponentModel.getNormalizedUtility((Bid)this.fOpponentModel.fBiddingHistory.get(0));
      
      opponentConcession = opponentUtil - opponentFirstBidUtil;
    }
    log("opponent Concession:" + opponentConcession);
    

    double OurFirstBidOppUtil = this.fOpponentModel.getNormalizedUtility((Bid)this.myPreviousBids.get(0));
    
    double OurTargetBidOppUtil = OurFirstBidOppUtil - opponentConcession;
    if (OurTargetBidOppUtil > 1.0D) {
      OurTargetBidOppUtil = 1.0D;
    }
    if (OurTargetBidOppUtil < OurFirstBidOppUtil) {
      OurTargetBidOppUtil = OurFirstBidOppUtil;
    }
    log("our target opponent utility=" + OurTargetBidOppUtil);
    

    double targetUtil = bs.ourUtilityOnPareto(OurTargetBidOppUtil);
    


    BidPoint bp = bs.getNearestBidPoint(targetUtil, OurTargetBidOppUtil, 0.5D, 0.1D, this.myPreviousBids);
    
    log("found bid " + bp);
    return bp.getBid();
  }
  
  Bid getNewBidWithUtil(double ourUtility, BidSpace bs)
  {
    BidPoint bestbid = null;
    double bestbidutil = 0.0D;
    for (BidPoint p : bs.bidPoints) {
      if ((Math.abs(ourUtility - p.getUtilityA().doubleValue()) < 0.01D) && (p.getUtilityB().doubleValue() > bestbidutil) && (!this.myPreviousBids.contains(p.getBid())))
      {
        bestbid = p;
        bestbidutil = p.getUtilityB().doubleValue();
      }
    }
    if (bestbid == null) {
      return null;
    }
    return bestbid.getBid();
  }
  
  private Bid getNextBidSmart(Bid pOppntBid)
    throws Exception
  {
    double lMyUtility = this.utilitySpace.getUtility(this.myLastBid);
    double lOppntUtility = this.utilitySpace.getUtility(pOppntBid);
    double lTargetUtility;
    if (this.fSmartSteps >= 0)
    {
      double lTargetUtility = getTargetUtility(lMyUtility, lOppntUtility);
      this.fSmartSteps = 0;
    }
    else
    {
      lTargetUtility = lMyUtility;
      this.fSmartSteps += 1;
    }
    return getTradeOff(lTargetUtility, pOppntBid);
  }
  
  private Bid getTradeOff(double pUtility, Bid pOppntBid)
    throws Exception
  {
    Bid lBid = null;
    double lExpectedUtility = -100.0D;
    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    while (lIter.hasNext())
    {
      Bid tmpBid = lIter.next();
      if (Math.abs(this.utilitySpace.getUtility(tmpBid) - pUtility) < 0.01D)
      {
        double lTmpExpecteUtility = this.fOpponentModel.getNormalizedUtility(tmpBid);
        if (lTmpExpecteUtility > lExpectedUtility)
        {
          lExpectedUtility = lTmpExpecteUtility;
          lBid = tmpBid;
        }
      }
    }
    return lBid;
  }
  
  private Bid proposeNextBid(Bid pOppntBid)
    throws Exception
  {
    Bid lBid = null;
    switch (this.fStrategy)
    {
    case TIT_FOR_TAT: 
      lBid = getNextBid(pOppntBid);
      break;
    case SMART: 
      lBid = getNextBidSmart(pOppntBid);
      break;
    default: 
      throw new Exception("unknown strategy " + this.fStrategy);
    }
    this.myLastBid = lBid;
    return lBid;
  }
  
  public Action chooseAction()
  {
    Action lAction = null;
    
    Bid lOppntBid = null;
    try
    {
      ACTIONTYPE lActionType = getActionType(this.messageOpponent);
      switch (lActionType)
      {
      case OFFER: 
        lOppntBid = ((Offer)this.messageOpponent).getBid();
        



        System.out.print("Updating beliefs ...");
        if (this.myPreviousBids.size() < 8) {
          this.fOpponentModel.updateBeliefs(lOppntBid);
        }
        System.out.println("Done!");
        if (this.myLastAction == null)
        {
          lAction = proposeInitialBid();
        }
        else
        {
          double offeredutil = this.utilitySpace.getUtility(lOppntBid);
          if (isAcceptableBefore(offeredutil))
          {
            lAction = new Accept(getAgentID());
            log("opponent's bid higher than util of my last bid! accepted");
          }
          else
          {
            Bid lnextBid = proposeNextBid(lOppntBid);
            lAction = new Offer(getAgentID(), lnextBid);
            if (lnextBid == null) {
              lnextBid = (Bid)this.myPreviousBids.get(this.myPreviousBids.size() - 1);
            }
            if (isAcceptableAfter(offeredutil, lnextBid))
            {
              lAction = new Accept(getAgentID());
              log("opponent's bid higher than util of my next bid! accepted");
            }
          }
          this.fOpponentPreviousBid = lOppntBid;
        }
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          lAction = proposeInitialBid();
        } else {
          lAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      log("Exception in chooseAction:" + e.getMessage());
      e.printStackTrace();
      lAction = new Offer(getAgentID(), this.myLastBid);
    }
    this.myLastAction = lAction;
    if ((this.myLastAction instanceof Offer))
    {
      this.myPreviousBids.add(((Offer)this.myLastAction).getBid());
      this.myLastBid = ((Offer)this.myLastAction).getBid();
    }
    return lAction;
  }
  
  protected boolean isAcceptableAfter(double offeredutil, Bid lnextBid)
    throws Exception
  {
    return offeredutil >= this.utilitySpace.getUtility(lnextBid);
  }
  
  protected boolean isAcceptableBefore(double offeredutil)
    throws Exception
  {
    return offeredutil * 1.03D >= this.utilitySpace.getUtility(this.myLastBid);
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private double getTargetUtility(double myUtility, double oppntUtility)
  {
    return myUtility - getConcessionFactor();
  }
  
  private double getConcessionFactor()
  {
    return 0.04D;
  }
  
  private void log(String pMessage)
  {
    if (this.logging) {
      System.out.println(pMessage);
    }
  }
  
  private double sq(double x)
  {
    return x * x;
  }
  
  private double calculateEuclideanDistanceUtilitySpace(double[] pLearnedUtil, double[] pOpponentUtil)
  {
    double lDistance = 0.0D;
    try
    {
      for (int i = 0; i < pLearnedUtil.length; i++) {
        lDistance += sq(pOpponentUtil[i] - pLearnedUtil[i]);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    lDistance /= this.utilitySpace.getDomain().getNumberOfPossibleBids();
    
    return lDistance;
  }
  
  private double calculateEuclideanDistanceWeghts(double[] pExpectedWeight)
  {
    double lDistance = 0.0D;
    int i = 0;
    try
    {
      for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
      {
        lDistance += sq(this.fNegotiation.getOpponentWeight(this, lIssue.getNumber()) - pExpectedWeight[i]);
        


        i++;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return lDistance / i;
  }
  
  private double calculatePearsonDistanceUtilitySpace(double[] pLearnedUtility, double[] pOpponentUtil)
  {
    double lDistance = 0.0D;
    double lAverageLearnedUtil = 0.0D;
    double lAverageOriginalUtil = 0.0D;
    for (int i = 0; i < pLearnedUtility.length; i++)
    {
      lAverageLearnedUtil += pLearnedUtility[i];
      lAverageOriginalUtil += pOpponentUtil[i];
    }
    lAverageLearnedUtil /= this.utilitySpace.getDomain().getNumberOfPossibleBids();
    
    lAverageOriginalUtil /= this.utilitySpace.getDomain().getNumberOfPossibleBids();
    

    double lSumX = 0.0D;
    double lSumY = 0.0D;
    for (int i = 0; i < pLearnedUtility.length; i++)
    {
      lDistance += (pLearnedUtility[i] - lAverageLearnedUtil) * (pOpponentUtil[i] - lAverageOriginalUtil);
      
      lSumX += sq(pLearnedUtility[i] - lAverageLearnedUtil);
      lSumY += sq(pOpponentUtil[i] - lAverageOriginalUtil);
    }
    return lDistance / Math.sqrt(lSumX * lSumY);
  }
  
  private double calculatePearsonDistanceWeghts(double[] pExpectedWeight)
  {
    double lDistance = 0.0D;
    double lAverageLearnedWeight = 0.0D;
    double lAverageOriginalWeight = 0.0D;
    int i = 0;
    try
    {
      for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
      {
        lAverageLearnedWeight += pExpectedWeight[i];
        
        lAverageOriginalWeight += this.fNegotiation.getOpponentWeight(this, lIssue.getNumber());
        

        i++;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    lAverageLearnedWeight /= i;
    lAverageOriginalWeight /= i;
    

    i = 0;
    double lSumX = 0.0D;
    double lSumY = 0.0D;
    try
    {
      for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
      {
        lDistance += (this.fNegotiation.getOpponentWeight(this, lIssue.getNumber()) - lAverageOriginalWeight) * (pExpectedWeight[i] - lAverageLearnedWeight);
        


        lSumX += sq(this.fNegotiation.getOpponentWeight(this, lIssue.getNumber()) - lAverageOriginalWeight);
        


        lSumY += sq(pExpectedWeight[i] - lAverageLearnedWeight);
        i++;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return lDistance / Math.sqrt(lSumX * lSumY);
  }
  
  private double calculateRankingDistanceUtilitySpaceMonteCarlo(double[] pLearnedUtil, double[] pOpponentUtil)
  {
    double lDistance = 0.0D;
    int lNumberOfPossibleBids = (int)this.utilitySpace.getDomain().getNumberOfPossibleBids();
    
    int lNumberOfComparisons = 10000;
    for (int k = 0; k < lNumberOfComparisons; k++)
    {
      int i = new Random().nextInt(lNumberOfPossibleBids - 1);
      int j = new Random().nextInt(lNumberOfPossibleBids - 1);
      if (((pLearnedUtil[i] <= pLearnedUtil[j]) || (pOpponentUtil[i] <= pOpponentUtil[j])) && ((pLearnedUtil[i] >= pLearnedUtil[j]) || (pOpponentUtil[i] >= pOpponentUtil[j])) && ((pLearnedUtil[i] != pLearnedUtil[j]) || (pOpponentUtil[i] != pOpponentUtil[j]))) {
        lDistance += 1.0D;
      }
    }
    return lDistance / lNumberOfComparisons;
  }
  
  private double calculateRankingDistanceUtilitySpace(double[] pLearnedUtil, double[] pOpponentUtil)
  {
    double lDistance = 0.0D;
    int lNumberOfPossibleBids = (int)this.utilitySpace.getDomain().getNumberOfPossibleBids();
    try
    {
      for (int i = 0; i < lNumberOfPossibleBids - 1; i++) {
        for (int j = i + 1; j < lNumberOfPossibleBids; j++) {
          if (Math.signum(pLearnedUtil[i] - pLearnedUtil[j]) != Math.signum(pOpponentUtil[i] - pOpponentUtil[j])) {
            lDistance += 1.0D;
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    lDistance = 2.0D * lDistance / (this.utilitySpace.getDomain().getNumberOfPossibleBids() * this.utilitySpace.getDomain().getNumberOfPossibleBids());
    


    return lDistance;
  }
  
  private double calculateRankingDistanceWeghts(double[] pExpectedWeights)
  {
    double lDistance = 0.0D;
    double[] lOriginalWeights = new double[this.utilitySpace.getDomain().getIssues().size()];
    
    int k = 0;
    try
    {
      for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
      {
        lOriginalWeights[k] = this.fNegotiation.getOpponentWeight(this, lIssue.getNumber());
        
        k++;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    k = 0;
    int nrOfIssues = this.utilitySpace.getDomain().getIssues().size();
    for (int i = 0; i < nrOfIssues - 1; i++) {
      for (int j = i + 1; j < nrOfIssues; j++)
      {
        k++;
        double tmpWeightLearned = pExpectedWeights[i];
        double tmpWeightOriginal = lOriginalWeights[i];
        double tmpWeight2Learned = pExpectedWeights[j];
        double tmpWeight2Original = lOriginalWeights[j];
        if (((tmpWeightLearned <= tmpWeight2Learned) || (tmpWeightOriginal <= tmpWeight2Original)) && ((tmpWeightLearned >= tmpWeight2Learned) || (tmpWeightOriginal >= tmpWeight2Original)) && ((tmpWeightLearned != tmpWeight2Learned) || (tmpWeightOriginal != tmpWeight2Original))) {
          lDistance += 1.0D;
        }
      }
    }
    return lDistance / k;
  }
  
  protected void dumpDistancesToLog(int pRound)
  {
    if (this.fSkipDistanceCalc) {
      return;
    }
    System.out.print(getName() + ": calculating distance between the learned space and the original one ...");
    


    double[] lExpectedWeights = new double[this.utilitySpace.getDomain().getIssues().size()];
    
    int i = 0;
    for (Issue lIssue : this.utilitySpace.getDomain().getIssues())
    {
      lExpectedWeights[i] = this.fOpponentModel.getExpectedWeight(i);
      i++;
    }
    double[] pLearnedUtil = new double[(int)this.utilitySpace.getDomain().getNumberOfPossibleBids()];
    

    BidIterator lIter = new BidIterator(this.utilitySpace.getDomain());
    i = 0;
    while (lIter.hasNext())
    {
      Bid lBid = lIter.next();
      try
      {
        pLearnedUtil[i] = this.fOpponentModel.getNormalizedUtility(lBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      i++;
    }
    double[] pOpponentUtil = new double[(int)this.utilitySpace.getDomain().getNumberOfPossibleBids()];
    

    lIter = new BidIterator(this.utilitySpace.getDomain());
    i = 0;
    while (lIter.hasNext())
    {
      Bid lBid = lIter.next();
      try
      {
        pOpponentUtil[i] = this.fNegotiation.getOpponentUtility(this, lBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      i++;
    }
    double lEuclideanDistUtil = calculateEuclideanDistanceUtilitySpace(pLearnedUtil, pOpponentUtil);
    
    double lEuclideanDistWeights = calculateEuclideanDistanceWeghts(lExpectedWeights);
    double lRankingDistUtil = 0.0D;
    if ((int)this.utilitySpace.getDomain().getNumberOfPossibleBids() > 100000) {
      lRankingDistUtil = calculateRankingDistanceUtilitySpaceMonteCarlo(pLearnedUtil, pOpponentUtil);
    } else {
      lRankingDistUtil = calculateRankingDistanceUtilitySpace(pLearnedUtil, pOpponentUtil);
    }
    double lRankingDistWeights = calculateRankingDistanceWeghts(lExpectedWeights);
    double lPearsonDistUtil = calculatePearsonDistanceUtilitySpace(pLearnedUtil, pOpponentUtil);
    
    double lPearsonDistWeights = calculatePearsonDistanceWeghts(lExpectedWeights);
    SimpleElement lLearningPerformance = new SimpleElement("learning_performance");
    
    lLearningPerformance.setAttribute("round", String.valueOf(pRound));
    lLearningPerformance.setAttribute("agent", getName());
    lLearningPerformance.setAttribute("euclidean_distance_utility_space", String.valueOf(lEuclideanDistUtil));
    
    lLearningPerformance.setAttribute("euclidean_distance_weights", String.valueOf(lEuclideanDistWeights));
    
    lLearningPerformance.setAttribute("ranking_distance_utility_space", String.valueOf(lRankingDistUtil));
    
    lLearningPerformance.setAttribute("ranking_distance_weights", String.valueOf(lRankingDistWeights));
    
    lLearningPerformance.setAttribute("pearson_distance_utility_space", String.valueOf(lPearsonDistUtil));
    
    lLearningPerformance.setAttribute("pearson_distance_weights", String.valueOf(lPearsonDistWeights));
    
    System.out.println("Done!");
    System.out.println(lLearningPerformance.toString());
    this.fNegotiation.addAdditionalLog(lLearningPerformance);
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BayesianAgent
 * JD-Core Version:    0.7.1
 */