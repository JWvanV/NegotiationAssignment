package agents;

import java.awt.Component;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

class MyCellRenderer1
  implements TableCellRenderer
{
  NegoInfo negoinfo;
  
  public MyCellRenderer1(NegoInfo n)
  {
    this.negoinfo = n;
  }
  
  public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
  {
    return this.negoinfo.getValueAt(row, column);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.MyCellRenderer1
 * JD-Core Version:    0.7.1
 */