package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class TestingAgent
  extends Agent
{
  private Action actionOfPartner = null;
  private static double MINIMUM_BID_UTILITY = 0.0D;
  
  public void init()
  {
    Double reservationValue = this.utilitySpace.getReservationValue();
    System.out.println(getName());
    System.out.println();
    System.out.println("Discount: " + this.utilitySpace.getDiscountFactor());
    System.out.println("RV: " + reservationValue);
    Domain domain = this.utilitySpace.getDomain();
    System.out.println("NumberOfPossibleBids: " + domain.getNumberOfPossibleBids());
    
    Bid randomBid = domain.getRandomBid();
    try
    {
      System.out.println("Utitility of bid " + randomBid + " = " + this.utilitySpace.getUtility(randomBid));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public static void main(String[] args)
  {
    double util = 0.2485888464438361D;
    double time = 0.2106471210944445D;
    double discount = 0.5D;
    double discountedUtil = util * Math.pow(discount, time);
    System.out.println(discountedUtil);
  }
  
  public String getName()
  {
    return "Testing Agent";
  }
  
  public String getVersion()
  {
    return "1.3";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseRandomBidAction();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        double time = this.timeline.getTime();
        System.out.println("t = " + Math.round(100.0D * time) / 100.0D + ", discountedRV = " + this.utilitySpace.getReservationValueWithDiscount(time));
        if (time > 0.1D)
        {
          System.out.println("End, because t = " + time);
          action = new EndNegotiation(getAgentID());
        }
        else
        {
          action = chooseRandomBidAction();
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private Action chooseRandomBidAction()
  {
    Bid nextBid = null;
    try
    {
      nextBid = getRandomBid();
    }
    catch (Exception e)
    {
      System.out.println("Problem with received bid:" + e.getMessage() + ". cancelling bidding");
    }
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid getRandomBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random randomnr = new Random();
    




    Bid bid = null;
    double utility;
    do
    {
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          int optionIndex = randomnr.nextInt(lIssueDiscrete.getNumberOfValues());
          
          values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
          
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int optionInd = randomnr.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
          
          values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
          






          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          int optionIndex2 = lIssueInteger.getLowerBound() + randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
          

          values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
          
          break;
        default: 
          throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
        }
      }
      bid = new Bid(this.utilitySpace.getDomain(), values);
      utility = getUtility(bid);
    } while (utility < MINIMUM_BID_UTILITY);
    return bid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TestingAgent
 * JD-Core Version:    0.7.1
 */