package agents;

import java.util.Comparator;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

class BidComparator
  implements Comparator<Bid>
{
  UtilitySpace utilspace;
  
  BidComparator(UtilitySpace us)
  {
    if (us == null) {
      throw new NullPointerException("null utility space");
    }
    this.utilspace = us;
  }
  
  public int compare(Bid b1, Bid b2)
    throws ClassCastException
  {
    double d1 = 0.0D;double d2 = 0.0D;
    try
    {
      d1 = this.utilspace.getUtility(b1);
      d2 = this.utilspace.getUtility(b2);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if (d1 < d2) {
      return 1;
    }
    if (d1 > d2) {
      return -1;
    }
    return 0;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.BidComparator
 * JD-Core Version:    0.7.1
 */