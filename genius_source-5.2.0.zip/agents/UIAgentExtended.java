package agents;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.PrintStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;

public class UIAgentExtended
  extends Agent
{
  private Action opponentAction = null;
  private EnterBidDialogExtended ui = null;
  private Bid myPreviousBid = null;
  private Bid oppPreviousBid = null;
  protected int bidCounter = 0;
  protected NegoRoundData roundData;
  protected ArrayList<NegoRoundData> historyOfBids = null;
  
  public String getVersion()
  {
    return "2.0";
  }
  
  public void init()
  {
    System.out.println("try to init UIAgent");
    System.out.println("Utility Space initialized: " + this.utilitySpace);
    this.historyOfBids = new ArrayList();
    
    System.out.println("closing old dialog of ");
    if (this.ui != null)
    {
      this.ui.dispose();
      this.ui = null;
    }
    System.out.println("old  dialog closed. Trying to open new dialog. ");
    try
    {
      this.ui = new EnterBidDialogExtended(this, null, true, this.utilitySpace);
      
      Toolkit t = Toolkit.getDefaultToolkit();
      int x = (int)((t.getScreenSize().getWidth() - this.ui.getWidth()) / 2.0D);
      int y = (int)((t.getScreenSize().getHeight() - this.ui.getHeight()) / 2.0D);
      this.ui.setLocation(x, y);
      System.out.println("finished init of UIAgent2");
    }
    catch (Exception e)
    {
      System.out.println("Problem in UIAgent2.init:" + e.getMessage());
      e.printStackTrace();
      System.out.println("UIAgent could not be initialized");
    }
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.opponentAction = opponentAction;
    if ((opponentAction instanceof Accept)) {
      JOptionPane.showMessageDialog(null, "Opponent accepted your last offer.");
    }
    if ((opponentAction instanceof EndNegotiation)) {
      JOptionPane.showMessageDialog(null, "Opponent canceled the negotiation session");
    }
  }
  
  public Action chooseAction()
  {
    Action action = this.ui.askUserForAction(this.opponentAction, this.myPreviousBid);
    if ((action != null) && ((action instanceof Offer)))
    {
      this.myPreviousBid = ((Offer)action).getBid();
      if (this.opponentAction != null)
      {
        this.oppPreviousBid = ((Offer)this.opponentAction).getBid();
        this.roundData = new NegoRoundData(this.oppPreviousBid, this.myPreviousBid);
        this.historyOfBids.add(this.roundData);
      }
      else
      {
        this.roundData = new NegoRoundData(null, this.myPreviousBid);
        this.historyOfBids.add(this.roundData);
      }
      this.bidCounter += 1;
    }
    return action;
  }
  
  public boolean isUIAgent()
  {
    return true;
  }
  
  public Bid getMyPreviousBid()
  {
    return this.myPreviousBid;
  }
  
  public Bid getOppPreviousBid()
  {
    return this.oppPreviousBid;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.UIAgentExtended
 * JD-Core Version:    0.7.1
 */