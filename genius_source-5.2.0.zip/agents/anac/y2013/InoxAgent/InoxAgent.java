package agents.anac.y2013.InoxAgent;

import negotiator.SupportedNegotiationSetting;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.acceptanceconditions.anac2013.AC_InoxAgent;
import negotiator.boaframework.agent.BOAagent;
import negotiator.boaframework.offeringstrategy.anac2013.InoxAgent_Offering;
import negotiator.boaframework.omstrategy.BestBid;
import negotiator.boaframework.opponentmodel.InoxAgent_OM;

public class InoxAgent
  extends BOAagent
{
  public void agentSetup()
  {
    this.opponentModel = new InoxAgent_OM(this.negotiationSession);
    this.opponentModel.init(this.negotiationSession);
    this.omStrategy = new BestBid(this.negotiationSession, this.opponentModel);
    this.offeringStrategy = new InoxAgent_Offering(this.negotiationSession, this.opponentModel, this.omStrategy);
    
    this.acceptConditions = new AC_InoxAgent(this.negotiationSession, this.offeringStrategy, this.opponentModel);
  }
  
  public String getName()
  {
    return "InoxAgent";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.InoxAgent.InoxAgent
 * JD-Core Version:    0.7.1
 */