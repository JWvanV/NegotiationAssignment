package agents.anac.y2013.TMFAgent;

import negotiator.Bid;

public class ComparableBid
  implements Comparable<ComparableBid>
{
  public double utility;
  public Bid bid;
  
  public ComparableBid(Bid b, double u)
  {
    this.bid = new Bid(b);
    this.utility = u;
  }
  
  public int compareTo(ComparableBid other)
  {
    if (other.utility < this.utility) {
      return -1;
    }
    if (other.utility > this.utility) {
      return 1;
    }
    return 0;
  }
  
  public String toString()
  {
    return this.utility + ": " + this.bid.toString();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.TMFAgent.ComparableBid
 * JD-Core Version:    0.7.1
 */