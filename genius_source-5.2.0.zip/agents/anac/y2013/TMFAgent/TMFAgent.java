package agents.anac.y2013.TMFAgent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.NegotiationResult;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class TMFAgent
  extends Agent
{
  private ArrayList<ComparableBid> relevantBids;
  private ArrayList<HashMap<Object, Double>> opponentUtilityEstimator;
  private HashMap<Bid, Integer> previousOpponentBids;
  private Bid lastBid;
  private ArrayList<Double> maxValue;
  private int lastPropose = 0;
  private Bid BestOpponentBid;
  private double firstOpponentBidUtility = 0.0D;
  private double EstimatedRTT = 0.0D;
  private double devRTT = 0.0D;
  private double prevTime = 0.0D;
  private boolean isFirstBid;
  
  public void init()
  {
    this.isFirstBid = true;
    

    Serializable s = loadSessionData();
    this.maxValue = new ArrayList();
    int i;
    double curr;
    if (s != null)
    {
      this.opponentUtilityEstimator = ((ArrayList)s);
      i = 0;
      for (HashMap<Object, Double> issue : this.opponentUtilityEstimator)
      {
        this.maxValue.add(Double.valueOf(0.0D));
        for (Iterator localIterator2 = issue.values().iterator(); localIterator2.hasNext();)
        {
          curr = ((Double)localIterator2.next()).doubleValue();
          if (((Double)this.maxValue.get(i)).doubleValue() < curr) {
            this.maxValue.set(i, Double.valueOf(curr));
          }
        }
        i++;
      }
    }
    else
    {
      this.opponentUtilityEstimator = new ArrayList();
      
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Issue issue : issues)
      {
        int max_i = this.opponentUtilityEstimator.size();
        this.opponentUtilityEstimator.add(new HashMap());
        if (issue.getType() == ISSUETYPE.DISCRETE)
        {
          for (ValueDiscrete vd : ((IssueDiscrete)issue).getValues()) {
            ((HashMap)this.opponentUtilityEstimator.get(max_i)).put(vd, Double.valueOf(0.0D));
          }
        }
        else if (issue.getType() == ISSUETYPE.INTEGER)
        {
          int k = Math.min(10, ((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue)
            .getLowerBound());
          for (int i = 0; i <= k; i++) {
            ((HashMap)this.opponentUtilityEstimator.get(max_i)).put(Integer.valueOf(i), Double.valueOf(0.0D));
          }
        }
        else if (issue.getType() == ISSUETYPE.REAL)
        {
          int k = 10;
          for (int i = 0; i < k; i++) {
            ((HashMap)this.opponentUtilityEstimator.get(max_i)).put(Double.valueOf(i + 0.0D), Double.valueOf(0.0D));
          }
        }
        this.maxValue.add(Double.valueOf(0.0D));
      }
    }
    ArrayList<Bid> allBids = GetDiscreteBids();
    this.relevantBids = new ArrayList();
    for (Bid b : allBids) {
      try
      {
        this.relevantBids.add(new ComparableBid(b, this.utilitySpace
          .getUtility(b)));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    Collections.sort(this.relevantBids);
    

    this.previousOpponentBids = new HashMap();
    
    this.BestOpponentBid = null;
    this.lastBid = null;
    this.lastPropose = 0;
  }
  
  public void BeginSession(int sessionNumber)
  {
    this.isFirstBid = true;
  }
  
  public void endSession(NegotiationResult res)
  {
    if ((res.getLastAction() instanceof Accept)) {
      AddOpponentBidToModel(res.getLastBid(), true);
    }
    saveSessionData(this.opponentUtilityEstimator);
  }
  
  public String getVersion()
  {
    return "1.2";
  }
  
  public String getName()
  {
    return "TMF-Agent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    double currRTT = this.timeline.getTime() - this.prevTime;
    this.prevTime = this.timeline.getTime();
    this.EstimatedRTT = (0.6D * this.EstimatedRTT + 0.4D * currRTT);
    this.devRTT = (0.75D * this.devRTT + 0.25D * Math.abs(currRTT - this.EstimatedRTT));
    
    Bid b = Action.getBidFromAction(opponentAction);
    if (b == null) {
      return;
    }
    this.isFirstBid = false;
    Integer i = (Integer)this.previousOpponentBids.get(b);
    if (i == null)
    {
      i = Integer.valueOf(0);
      AddOpponentBidToModel(b, false);
    }
    this.previousOpponentBids.put(b, Integer.valueOf(i.intValue() + 1));
    if (this.lastBid == null) {
      try
      {
        double minimumRelevant = Math.max(this.utilitySpace.getUtility(b), this.utilitySpace
          .getReservationValueUndiscounted());
        while ((this.relevantBids.size() > 0) && 
          (this.utilitySpace.getUtility(
          ((ComparableBid)this.relevantBids.get(this.relevantBids.size() - 1)).bid) < minimumRelevant)) {
          this.relevantBids.remove(this.relevantBids.size() - 1);
        }
        this.BestOpponentBid = b;
        
        this.firstOpponentBidUtility = this.utilitySpace.getUtility(b);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    this.lastBid = b;
    try
    {
      if (this.utilitySpace.getUtility(this.BestOpponentBid) < this.utilitySpace.getUtility(b)) {
        this.BestOpponentBid = b;
      }
    }
    catch (Exception e) {}
  }
  
  private void AddOpponentBidToModel(Bid b, boolean isAgreed)
  {
    for (int i = 0; i < this.utilitySpace.getDomain().getIssues().size(); i++)
    {
      Object v = null;
      Issue issue = (Issue)this.utilitySpace.getDomain().getIssue(i);
      Value v1 = null;
      try
      {
        v1 = b.getValue(issue.getNumber());
      }
      catch (Exception e)
      {
        e.printStackTrace();
        return;
      }
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        v = (ValueDiscrete)v1;
      }
      else if (issue.getType() == ISSUETYPE.INTEGER)
      {
        int currValue = ((ValueInteger)v1).getValue();
        int k = Math.min(10, ((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue)
          .getLowerBound());
        
        int bucket = (int)Math.round(
          (currValue - ((IssueInteger)issue).getLowerBound()) / (((IssueInteger)issue)
          .getUpperBound() - ((IssueInteger)issue)
          .getLowerBound()) * k);
        v = Integer.valueOf(bucket);
      }
      else if (issue.getType() == ISSUETYPE.REAL)
      {
        double currValue = ((ValueReal)v1).getValue();
        int k = 10;
        
        int bucket = (int)Math.round(
          (currValue - ((IssueInteger)issue).getLowerBound()) / (((IssueInteger)issue)
          .getUpperBound() - ((IssueInteger)issue)
          .getLowerBound()) * k);
        v = Double.valueOf(bucket + 0.0D);
      }
      else
      {
        return;
      }
      HashMap<Object, Double> hm = (HashMap)this.opponentUtilityEstimator.get(i);
      Double d = null;
      if (hm.containsKey(v)) {
        d = (Double)hm.get(v);
      } else {
        d = Double.valueOf(0.0D);
      }
      double currData;
      double currData;
      if (isAgreed) {
        currData = d.doubleValue() + (((Double)this.maxValue.get(i)).doubleValue() - d.doubleValue()) / 2.0D;
      } else {
        currData = d.doubleValue() + 1.0D - this.timeline.getTime();
      }
      ((HashMap)this.opponentUtilityEstimator.get(i)).put(v, Double.valueOf(currData));
      if (currData > ((Double)this.maxValue.get(i)).doubleValue()) {
        this.maxValue.set(i, Double.valueOf(currData));
      }
    }
  }
  
  public Action chooseAction()
  {
    if (!HaveMoreTimeToBid(true))
    {
      try
      {
        if (this.utilitySpace.getUtility(this.BestOpponentBid) <= this.utilitySpace.getUtility(this.lastBid))
        {
          if (this.utilitySpace.getUtility(this.lastBid) > this.utilitySpace.getReservationValueUndiscounted()) {
            return new Accept();
          }
        }
        else if (this.utilitySpace.getUtility(this.BestOpponentBid) > this.utilitySpace.getReservationValueUndiscounted()) {
          return new Offer(this.BestOpponentBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      return new EndNegotiation();
    }
    if (!HaveMoreTimeToBid(false))
    {
      try
      {
        if (this.utilitySpace.getUtility(this.lastBid) > this.utilitySpace.getReservationValueUndiscounted()) {
          return new Accept();
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      return new EndNegotiation();
    }
    Action a = null;
    if (this.isFirstBid)
    {
      this.isFirstBid = false;
      try
      {
        return new Offer(this.utilitySpace.getMaxUtilityBid());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    double alpha = getHardness();
    ComparableBid cb = (ComparableBid)this.relevantBids.get(0);
    double best;
    try
    {
      best = alpha * cb.utility + (1.0D - alpha) * GetEstimatedOpponentUtility(cb.bid);
    }
    catch (Exception e1)
    {
      e1.printStackTrace();
      best = 0.0D;
    }
    int j = Math.max(1, this.lastPropose - 3000);
    for (int i = j; (i < this.relevantBids.size()) && (i < this.lastPropose + 7000); i++)
    {
      ComparableBid currBid = (ComparableBid)this.relevantBids.get(i);
      double curr;
      try
      {
        curr = alpha * currBid.utility + (1.0D - alpha) * GetEstimatedOpponentUtility(currBid.bid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
        curr = 0.0D;
      }
      if (curr > best)
      {
        cb = currBid;
        best = curr;
      }
    }
    try
    {
      if ((this.lastBid != null) && 
        (this.utilitySpace.getUtility(this.lastBid) > cb.utility)) {
        a = new Accept();
      } else if (cb.utility < this.utilitySpace.getReservationValueUndiscounted()) {
        a = new EndNegotiation();
      } else {
        a = new Offer(cb.bid);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return a;
  }
  
  private ArrayList<Bid> GetDiscreteBids()
  {
    ArrayList<Bid> bids = new ArrayList();
    HashMap<Integer, Value> issusesFirstValue = new HashMap();
    for (Issue issue : this.utilitySpace.getDomain().getIssues())
    {
      Value v = null;
      if (issue.getType() == ISSUETYPE.INTEGER) {
        v = new ValueInteger(((IssueInteger)issue).getLowerBound());
      } else if (issue.getType() == ISSUETYPE.REAL) {
        v = new ValueReal(((IssueReal)issue).getLowerBound());
      } else if (issue.getType() == ISSUETYPE.DISCRETE) {
        v = ((IssueDiscrete)issue).getValue(0);
      }
      issusesFirstValue.put(Integer.valueOf(issue.getNumber()), v);
    }
    try
    {
      bids.add(new Bid(this.utilitySpace.getDomain(), issusesFirstValue));
    }
    catch (Exception e)
    {
      return null;
    }
    for (e = this.utilitySpace.getDomain().getIssues().iterator(); ((Iterator)e).hasNext();)
    {
      Issue issue = (Issue)((Iterator)e).next();
      
      ArrayList<Bid> tempBids = new ArrayList();
      
      ArrayList<Value> issueValues = new ArrayList();
      ValueReal vr;
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        ArrayList<ValueDiscrete> valuesD = (ArrayList)((IssueDiscrete)issue).getValues();
        for (Value v : valuesD) {
          issueValues.add(v);
        }
      }
      else if (issue.getType() == ISSUETYPE.INTEGER)
      {
        int k = Math.min(10, ((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue)
          .getLowerBound());
        for (int i = 0; i <= k; i++)
        {
          ValueInteger vi = (ValueInteger)GetRepresentorOfBucket(i, issue, k, true);
          
          issueValues.add(vi);
        }
      }
      else if (issue.getType() == ISSUETYPE.REAL)
      {
        k = 10;
        for (int i = 0; i <= k; i++)
        {
          vr = (ValueReal)GetRepresentorOfBucket(i, issue, k, false);
          
          issueValues.add(vr);
        }
      }
      for (int k = bids.iterator(); k.hasNext();)
      {
        bid = (Bid)k.next();
        for (Value value : issueValues)
        {
          HashMap<Integer, Value> bidValues = new HashMap();
          for (Issue issue1 : this.utilitySpace.getDomain().getIssues()) {
            try
            {
              bidValues.put(Integer.valueOf(issue1.getNumber()), bid
                .getValue(issue1.getNumber()));
            }
            catch (Exception e)
            {
              e.printStackTrace();
            }
          }
          bidValues.put(Integer.valueOf(issue.getNumber()), value);
          try
          {
            Bid newBid = new Bid(this.utilitySpace.getDomain(), bidValues);
            
            tempBids.add(newBid);
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
      Bid bid;
      bids = tempBids;
    }
    return bids;
  }
  
  private double GetEstimatedOpponentUtility(Bid b)
  {
    double d = 0.0D;
    int count = 0;
    for (HashMap<Object, Double> h : this.opponentUtilityEstimator)
    {
      try
      {
        Issue issue = (Issue)this.utilitySpace.getDomain().getIssues().get(count);
        int i = issue.getNumber();
        if (issue.getType() == ISSUETYPE.DISCRETE)
        {
          d = d + ((Double)h.get((ValueDiscrete)b.getValue(i))).doubleValue() / ((Double)this.maxValue.get(count)).doubleValue();
        }
        else if (issue.getType() == ISSUETYPE.INTEGER)
        {
          Value v = b.getValue(i);
          ValueInteger vi = (ValueInteger)v;
          d += ((Double)h.get(Integer.valueOf(vi.getValue()))).doubleValue() / ((Double)this.maxValue.get(count)).doubleValue();
        }
        else if (issue.getType() == ISSUETYPE.REAL)
        {
          Value v = b.getValue(i);
          ValueReal vr = (ValueReal)v;
          d += ((Double)h.get(Double.valueOf(vr.getValue()))).doubleValue() / ((Double)this.maxValue.get(count)).doubleValue();
        }
      }
      catch (Exception e)
      {
        return count == 0 ? d : d / count;
      }
      count++;
    }
    return d / count;
  }
  
  private double getHardness()
  {
    double alpha = 0.0D;double x = this.timeline.getTime();
    
    double y = this.utilitySpace.getDiscountFactor() <= 0.0D ? 0.0D : 1.0D - this.utilitySpace.getDiscountFactor();
    double weight = (1.0D - this.firstOpponentBidUtility) * 2.0D / 3.0D;
    alpha = 1.0D - weight * Math.pow(x, 65.0D) - (1.0D - weight) * Math.pow(y, 3.0D);
    alpha /= (x * y + 1.0D);
    
    return alpha;
  }
  
  private boolean HaveMoreTimeToBid(boolean wantToMakeTwoProposals)
  {
    if ((wantToMakeTwoProposals) && 
      (1.0D - this.timeline.getTime() > 2.0D * this.EstimatedRTT + this.devRTT)) {
      return true;
    }
    if ((!wantToMakeTwoProposals) && 
      (1.0D - this.timeline.getTime() > this.EstimatedRTT + this.devRTT)) {
      return true;
    }
    return false;
  }
  
  private Value GetRepresentorOfBucket(int bucket, Issue issue, int k, boolean isInteger)
  {
    double ans = 0.0D;
    if (isInteger)
    {
      EvaluatorInteger ei = new EvaluatorInteger();
      
      boolean upperIsTheBest = ei.getEvaluation(((IssueInteger)issue).getUpperBound()).doubleValue() > ei.getEvaluation(((IssueInteger)issue)
        .getLowerBound()).doubleValue();
      if (upperIsTheBest)
      {
        if (bucket < k)
        {
          ans = (bucket + 1) / k;
          


          ans = ans * (((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue).getLowerBound()) + ((IssueInteger)issue).getLowerBound() - 1.0D;
        }
        else
        {
          ans = ((IssueInteger)issue).getUpperBound();
        }
      }
      else
      {
        ans = bucket / k;
        


        ans = ans * (((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue).getLowerBound()) + ((IssueInteger)issue).getLowerBound();
      }
      return new ValueInteger((int)Math.round(ans));
    }
    EvaluatorReal ei = new EvaluatorReal();
    
    boolean upperIsTheBest = ei.getEvaluation(((IssueReal)issue).getUpperBound()).doubleValue() > ei.getEvaluation(((IssueReal)issue)
      .getLowerBound()).doubleValue();
    if (upperIsTheBest)
    {
      if (bucket < k)
      {
        ans = (bucket + 1) / k;
        


        ans = ans * (((IssueReal)issue).getUpperBound() - ((IssueReal)issue).getLowerBound()) + ((IssueReal)issue).getLowerBound();
      }
      else
      {
        ans = ((IssueReal)issue).getUpperBound();
      }
    }
    else
    {
      ans = bucket / k;
      


      ans = ans * (((IssueReal)issue).getUpperBound() - ((IssueReal)issue).getLowerBound()) + ((IssueReal)issue).getLowerBound();
    }
    return new ValueReal(ans);
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.TMFAgent.TMFAgent
 * JD-Core Version:    0.7.1
 */