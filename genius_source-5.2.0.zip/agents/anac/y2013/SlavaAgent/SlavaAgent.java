package agents.anac.y2013.SlavaAgent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.NegotiationResult;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class SlavaAgent
  extends Agent
{
  private Action actionOfPartner = null;
  private Bid maxBidRecieved = null;
  private Bid maxBid;
  private Map<Bid, Double> bestBidsMap;
  private List<Bid> bidsAsArray;
  private Bid bestOffer;
  private final int MAX_ITERATIONS = 10000;
  private final double EXPLORATION_RATE = 0.95D;
  private final double UTILITY_THRESHOLD = 0.95D;
  private final double MIN_UTILITY_ACCEPT = 0.7D;
  private final double GOOD_ENOUGHT_UTILITY = 0.9D;
  
  public Bid GetMaxBid()
    throws Exception
  {
    Bid max = this.utilitySpace.getDomain().getRandomBid();
    Bid tempBidding = this.utilitySpace.getDomain().getRandomBid();
    for (int i = 0; i < this.utilitySpace.getDomain().getIssues().size(); i++)
    {
      double maxUtil = 0.0D;
      int indexOfMaximumValue = 0;
      
      Issue currIssue = (Issue)this.utilitySpace.getDomain().getIssues().get(i);
      if (currIssue.getType().equals(ISSUETYPE.INTEGER))
      {
        IssueInteger issueInteger = (IssueInteger)currIssue;
        tempBidding.setValue(currIssue.getNumber(), new ValueInteger(issueInteger.getUpperBound()));
        
        maxUtil = this.utilitySpace.getUtility(tempBidding);
        tempBidding.setValue(currIssue.getNumber(), new ValueInteger(issueInteger.getLowerBound()));
        
        double minUtil = this.utilitySpace.getUtility(tempBidding);
        if (maxUtil > minUtil) {
          max.setValue(currIssue.getNumber(), new ValueInteger(issueInteger.getUpperBound()));
        } else {
          max.setValue(currIssue.getNumber(), new ValueInteger(issueInteger.getLowerBound()));
        }
      }
      else if (currIssue.getType().equals(ISSUETYPE.REAL))
      {
        IssueReal issueReal = (IssueReal)currIssue;
        tempBidding.setValue(currIssue.getNumber(), new ValueReal(issueReal.getUpperBound()));
        
        maxUtil = this.utilitySpace.getUtility(tempBidding);
        tempBidding.setValue(currIssue.getNumber(), new ValueReal(issueReal.getLowerBound()));
        
        double minUtil = this.utilitySpace.getUtility(tempBidding);
        if (maxUtil > minUtil) {
          max.setValue(currIssue.getNumber(), new ValueReal(issueReal.getUpperBound()));
        } else {
          max.setValue(currIssue.getNumber(), new ValueReal(issueReal.getLowerBound()));
        }
      }
      else if (currIssue.getType().equals(ISSUETYPE.DISCRETE))
      {
        IssueDiscrete issueDiscrete = (IssueDiscrete)currIssue;
        for (int j = 0; j < issueDiscrete.getNumberOfValues(); j++)
        {
          tempBidding.setValue(currIssue.getNumber(), issueDiscrete.getValue(j));
          
          double tempUtil = this.utilitySpace.getUtility(tempBidding);
          if (tempUtil > maxUtil)
          {
            indexOfMaximumValue = j;
            maxUtil = tempUtil;
          }
        }
        max.setValue(currIssue.getNumber(), issueDiscrete.getValue(indexOfMaximumValue));
      }
    }
    return max;
  }
  
  public void init()
  {
    try
    {
      this.maxBid = this.utilitySpace.getDomain().getRandomBid();
      

      this.bestBidsMap = getBestBidsForUs();
      this.bidsAsArray = new ArrayList(this.bestBidsMap.keySet());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    Serializable previousOffers = loadSessionData();
    if (previousOffers != null) {
      this.bestOffer = ((Bid)previousOffers);
    }
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public String getName()
  {
    return "Slava Agent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
    if (this.actionOfPartner == null) {
      return;
    }
    if ((this.actionOfPartner instanceof Offer))
    {
      Offer opponentOffer = (Offer)this.actionOfPartner;
      Bid bid = opponentOffer.getBid();
      try
      {
        double utility = this.utilitySpace.getUtility(bid);
        if (this.maxBidRecieved == null)
        {
          this.maxBidRecieved = bid;
          if (this.bestOffer == null) {
            this.bestOffer = this.maxBidRecieved;
          } else if (this.utilitySpace.getUtility(this.maxBidRecieved) < this.utilitySpace.getUtility(this.bestOffer)) {
            this.maxBidRecieved = this.bestOffer;
          }
        }
        else if (utility > this.utilitySpace.getUtility(this.maxBidRecieved))
        {
          this.maxBidRecieved = bid;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null)
      {
        this.maxBid = calculateNextBid();
        action = new Offer(this.maxBid);
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Offer opponentOffer = (Offer)this.actionOfPartner;
        Bid bid = opponentOffer.getBid();
        double utility = this.utilitySpace.getUtility(bid);
        getClass();
        if (utility >= 0.9D) {
          return new Accept(getAgentID());
        }
        getClass();
        if (this.timeline.getTime() <= 0.95D)
        {
          this.maxBid = calculateNextBid();
          
          Random rand = new Random();
          if (rand.nextDouble() <= 0.5D)
          {
            action = new Offer(this.maxBid);
          }
          else
          {
            Bid nextBid = (Bid)this.bidsAsArray.get(rand.nextInt(this.bidsAsArray.size()));
            
            action = new Offer(nextBid);
          }
        }
        else
        {
          opponentOffer = (Offer)this.actionOfPartner;
          bid = opponentOffer.getBid();
          try
          {
            utility = this.utilitySpace.getUtility(bid);
            


            getClass();
            if ((utility >= 0.7D) && (utility >= this.utilitySpace.getUtility(this.maxBidRecieved))) {
              action = new Accept(getAgentID());
            } else {
              action = new Offer(this.maxBid);
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
            action = new Offer(this.maxBid);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      this.maxBid = calculateNextBid();
      action = new Offer(this.maxBid);
    }
    sleep(0.005D);
    
    return action;
  }
  
  public void endSession(NegotiationResult result)
  {
    try
    {
      if (this.utilitySpace.getUtility(this.bestOffer) < this.utilitySpace.getUtility(this.maxBidRecieved)) {
        this.bestOffer = this.maxBidRecieved;
      }
      saveSessionData(this.bestOffer);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private Bid calculateNextBid()
  {
    try
    {
      Bid nextBid = generateBid();
      if (this.utilitySpace.getUtility(nextBid) > this.utilitySpace.getUtility(this.maxBid)) {
        this.maxBid = nextBid;
      }
      return this.maxBid;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return this.maxBid;
  }
  
  private Bid generateBid()
    throws Exception
  {
    double maxUtility = 0.0D;
    Bid maxBid = null;
    for (int i = 0;; i++)
    {
      getClass();
      if (i >= 10000) {
        break;
      }
      Bid bid = this.utilitySpace.getDomain().getRandomBid();
      double utility = this.utilitySpace.getUtility(bid);
      if (utility > maxUtility)
      {
        maxUtility = utility;
        maxBid = bid;
      }
    }
    return maxBid;
  }
  
  private Map<Bid, Double> getBestBidsForUs()
  {
    Map<Bid, Double> bestBids = new HashMap();
    for (int i = 0;; i++)
    {
      getClass();
      if (i >= 10000) {
        break;
      }
      Bid randomBid = this.utilitySpace.getDomain().getRandomBid();
      try
      {
        double utility = this.utilitySpace.getUtility(randomBid);
        


        getClass();
        if ((utility >= 0.95D) && 
          (!bestBids.containsKey(randomBid))) {
          bestBids.put(randomBid, Double.valueOf(utility));
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bestBids;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.SlavaAgent.SlavaAgent
 * JD-Core Version:    0.7.1
 */