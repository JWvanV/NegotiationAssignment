package agents.anac.y2013.TheFawkes;

import negotiator.SupportedNegotiationSetting;
import negotiator.boaframework.AcceptanceStrategy;
import negotiator.boaframework.OfferingStrategy;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.acceptanceconditions.anac2013.AC_TheFawkes;
import negotiator.boaframework.agent.BOAagent;
import negotiator.boaframework.offeringstrategy.anac2013.Fawkes_Offering;
import negotiator.boaframework.omstrategy.TheFawkes_OMS;
import negotiator.boaframework.opponentmodel.TheFawkes_OM;

public class TheFawkes
  extends BOAagent
{
  public void agentSetup()
  {
    this.opponentModel = new TheFawkes_OM();
    this.opponentModel.init(this.negotiationSession);
    this.omStrategy = new TheFawkes_OMS(this.negotiationSession, this.opponentModel);
    this.offeringStrategy = new Fawkes_Offering();
    this.acceptConditions = new AC_TheFawkes();
    try
    {
      this.offeringStrategy.init(this.negotiationSession, this.opponentModel, this.omStrategy, null);
      
      this.acceptConditions.init(this.negotiationSession, this.offeringStrategy, this.opponentModel, null);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getName()
  {
    return "TheFawkes";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.TheFawkes.TheFawkes
 * JD-Core Version:    0.7.1
 */