package agents.anac.y2013.AgentKF;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.bidding.BidDetails;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class AgentKF
  extends Agent
{
  private String state;
  private Action partner;
  private HashMap<Bid, Double> offeredBidMap;
  private double target;
  private double bidTarget;
  private double bidReduction;
  private double sum;
  private double sum2;
  private int rounds;
  private double tremor;
  private int MaxLoopNum;
  private BidHistory currSessOppBidHistory = new BidHistory();
  private BidHistory prevSessOppBidHistory = new BidHistory();
  private double MINIMUM_BID_UTILITY;
  private double MinAutoAcceptUtil;
  private boolean FinalPhase;
  private double PrevMean;
  
  public void init()
  {
    this.offeredBidMap = new HashMap();
    this.target = 1.0D;
    this.bidTarget = 1.0D;
    this.bidReduction = 0.01D;
    this.sum = 0.0D;
    this.sum2 = 0.0D;
    this.rounds = 0;
    this.tremor = 2.0D;
    this.MinAutoAcceptUtil = 0.8D;
    this.MaxLoopNum = 1000;
    this.PrevMean = 0.0D;
    this.FinalPhase = false;
    
    this.MINIMUM_BID_UTILITY = this.utilitySpace.getReservationValueUndiscounted();
    
    myBeginSession();
  }
  
  public void myBeginSession()
  {
    Serializable prev = loadSessionData();
    if (prev != null)
    {
      this.prevSessOppBidHistory = ((BidHistory)prev);
      this.currSessOppBidHistory = this.prevSessOppBidHistory;
      
      this.PrevMean = this.prevSessOppBidHistory.getAverageDiscountedUtility(this.utilitySpace);
    }
  }
  
  public String getVersion()
  {
    return "1.1";
  }
  
  public String getName()
  {
    return "AgentKF";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.partner = opponentAction;
    if ((opponentAction instanceof Offer))
    {
      Bid bid = ((Offer)opponentAction).getBid();
      try
      {
        BidDetails opponentBid = new BidDetails(bid, this.utilitySpace.getUtility(bid), this.timeline.getTime());
        this.currSessOppBidHistory.add(opponentBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.partner == null) {
        action = selectBid();
      }
      if ((this.partner instanceof Offer))
      {
        Bid offeredBid = ((Offer)this.partner).getBid();
        
        double p = acceptProbability(offeredBid);
        if (this.utilitySpace.getUtility(offeredBid) > this.MinAutoAcceptUtil) {
          p = 1.0D;
        }
        if (this.rounds % 500 == 0) {
          this.tremor += adjustTremor(this.timeline.getCurrentTime());
        }
        if (this.timeline.getCurrentTime() > 0.85D)
        {
          BidHistory FinalBidHistory = this.currSessOppBidHistory.filterBetweenTime(this.timeline.getCurrentTime(), 1.0D);
          double FinalAvg = FinalBidHistory.getAverageUtility();
          if (FinalAvg < this.sum / this.rounds) {
            this.FinalPhase = true;
          }
        }
        if (p > Math.random()) {
          action = new Accept(getAgentID());
        } else {
          action = selectBid();
        }
        this.state = "Opponet Send the Bid ";
        tryToSaveAndPrintState();
      }
      if ((this.partner instanceof EndNegotiation))
      {
        this.state = "Got EndNegotiation from opponent. ";
        tryToSaveAndPrintState();
      }
    }
    catch (Exception e)
    {
      this.state = "Got Exception. ";
      tryToSaveAndPrintState();
      
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private void tryToSaveAndPrintState()
  {
    if (this.currSessOppBidHistory.size() < Math.pow(10.0D, 5.0D)) {
      saveSessionData(this.currSessOppBidHistory);
    }
  }
  
  private Action selectBid()
  {
    Bid nextBid = null;
    double time = this.timeline.getTime();
    
    ArrayList<Bid> bidTemp = new ArrayList();
    for (Bid bid : this.offeredBidMap.keySet()) {
      if (((Double)this.offeredBidMap.get(bid)).doubleValue() > this.target) {
        bidTemp.add(bid);
      }
    }
    int size = bidTemp.size();
    if (size > 0)
    {
      int sindex = (int)Math.floor(Math.random() * size);
      nextBid = (Bid)bidTemp.get(sindex);
    }
    else
    {
      double searchUtil = 0.0D;
      try
      {
        int loop = 0;
        boolean NotFind = true;
        ArrayList<Bid> AltNextBid = new ArrayList();
        while (loop < this.MaxLoopNum)
        {
          if ((loop == this.MaxLoopNum - 1 & NotFind))
          {
            this.bidTarget -= this.bidReduction;
            loop = 0;
          }
          Bid altNextBid = searchBid();
          searchUtil = this.utilitySpace.getUtilityWithDiscount(altNextBid, time);
          if (searchUtil >= this.bidTarget)
          {
            NotFind = false;
            AltNextBid.add(altNextBid);
          }
          loop++;
        }
        double minUtil = Double.MAX_VALUE;
        Bid minBid = null;
        for (int i = 0; i < AltNextBid.size(); i++)
        {
          Bid bufBid = (Bid)AltNextBid.get(i);
          Double bufUtil = Double.valueOf(this.utilitySpace.getUtilityWithDiscount(bufBid, time));
          if (minUtil > bufUtil.doubleValue())
          {
            minUtil = bufUtil.doubleValue();
            minBid = bufBid;
          }
          else if (minUtil == bufUtil.doubleValue())
          {
            BidHistory simHistory = this.currSessOppBidHistory.filterBetweenUtility(this.MINIMUM_BID_UTILITY, 1.0D);
            if (similarBid(simHistory, bufBid) < similarBid(simHistory, minBid)) {
              minBid = bufBid;
            }
          }
          nextBid = minBid;
        }
      }
      catch (Exception e) {}
    }
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private int similarBid(BidHistory theHistory, Bid theBid)
    throws Exception
  {
    int Value = Integer.MAX_VALUE;
    
    ArrayList<BidDetails> AltList = (ArrayList)theHistory.getNBestBids(theHistory.size() - 1);
    Bid targetBid;
    for (int i = 0; i < AltList.size(); i++)
    {
      targetBid = ((BidDetails)AltList.get(i)).getBid();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          double weight_d = this.utilitySpace.getWeight(lIssueDiscrete
            .getNumber());
          if (theBid.getValue(lIssueDiscrete.getNumber()) == targetBid.getValue(lIssueDiscrete.getNumber())) {
            Value = (int)(Value + 1.0D * weight_d);
          }
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          double weight_r = this.utilitySpace.getWeight(lIssueReal
            .getNumber());
          if (theBid.getValue(lIssueReal.getNumber()) == targetBid.getValue(lIssueReal.getNumber())) {
            Value = (int)(Value + 1.0D * weight_r);
          }
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          double weight_i = this.utilitySpace.getWeight(lIssueInteger
            .getNumber());
          if (theBid.getValue(lIssueInteger.getNumber()) == targetBid.getValue(lIssueInteger.getNumber())) {
            Value = (int)(Value + 1.0D * weight_i);
          }
          break;
        default: 
          throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
        }
      }
    }
    return Value;
  }
  
  private Bid searchBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random randomnr = new Random();
    
    Bid bid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int optionIndex = randomnr.nextInt(lIssueDiscrete
          .getNumberOfValues());
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete
          .getValue(optionIndex));
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = randomnr.nextInt(lIssueReal
          .getNumberOfDiscretizationSteps() - 1);
        values.put(
          Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal
          .getLowerBound() + 
          
          (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal
          

          .getNumberOfDiscretizationSteps()));
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        
        int optionIndex2 = lIssueInteger.getLowerBound() + randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
          .getLowerBound());
        values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
      }
    }
    bid = new Bid(this.utilitySpace.getDomain(), values);
    return bid;
  }
  
  private double adjustTremor(double time)
  {
    if (this.currSessOppBidHistory.isEmpty()) {
      return 0.0D;
    }
    double avg = this.sum / this.rounds;
    


    double histry_avg = this.currSessOppBidHistory.filterBetweenTime(0.0D, this.timeline.getCurrentTime()).getAverageUtility();
    if (avg > histry_avg) {
      return 0.3D;
    }
    return -0.3D;
  }
  
  double acceptProbability(Bid offeredBid)
    throws Exception
  {
    double time = this.timeline.getTime();
    double offeredUtility = this.utilitySpace.getUtilityWithDiscount(offeredBid, time);
    
    this.offeredBidMap.put(offeredBid, Double.valueOf(offeredUtility));
    
    this.sum += offeredUtility;
    this.sum2 += offeredUtility * offeredUtility;
    this.rounds += 1;
    
    double mean = this.sum / this.rounds;
    mean = 0.7D * mean + 0.3D * this.PrevMean;
    
    double variance = this.sum2 / this.rounds - mean * mean;
    
    double deviation = Math.sqrt(variance * 12.0D);
    if (Double.isNaN(deviation)) {
      deviation = 0.0D;
    }
    double t = time * time * time;
    if ((offeredUtility < 0.0D) || (offeredUtility > 1.05D)) {
      throw new Exception("utility " + offeredUtility + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (offeredUtility > 1.0D) {
      offeredUtility = 1.0D;
    }
    double estimateMax = mean + (1.0D - mean) * deviation;
    
    double alpha = 1.0D + this.tremor + 10.0D * mean - 2.0D * this.tremor * mean;
    double beta = alpha + Math.random() * this.tremor - this.tremor / 2.0D;
    
    double preTarget = 1.0D - Math.pow(time, alpha) * (1.0D - estimateMax);
    double preTarget2 = 1.0D - Math.pow(time, beta) * (1.0D - estimateMax);
    
    double ratio = (deviation + 0.1D) / (1.0D - preTarget);
    if ((Double.isNaN(ratio)) || (ratio > 2.0D)) {
      ratio = 2.0D;
    }
    double ratio2 = (deviation + 0.1D) / (1.0D - preTarget2);
    if ((Double.isNaN(ratio2)) || (ratio2 > 2.0D)) {
      ratio2 = 2.0D;
    }
    this.target = (ratio * preTarget + 1.0D - ratio);
    this.bidTarget = (ratio2 * preTarget2 + 1.0D - ratio2);
    
    double m = t * -300.0D + 400.0D;
    if (this.target > estimateMax)
    {
      double r = this.target - estimateMax;
      double f = 1.0D / (r * r);
      if ((f > m) || (Double.isNaN(f))) {
        f = m;
      }
      double app = r * f / m;
      this.target -= app;
    }
    else
    {
      this.target = estimateMax;
    }
    if (this.bidTarget > estimateMax)
    {
      double r = this.bidTarget - estimateMax;
      double f = 1.0D / (r * r);
      if ((f > m) || (Double.isNaN(f))) {
        f = m;
      }
      double app = r * f / m;
      this.bidTarget -= app;
    }
    else
    {
      this.bidTarget = estimateMax;
    }
    if (this.FinalPhase)
    {
      double discount_utility = this.utilitySpace.getUtilityWithDiscount(offeredBid, time);
      
      double discount_ratio = discount_utility / offeredUtility;
      if (!Double.isNaN(discount_utility))
      {
        this.target *= discount_ratio;
        this.bidTarget *= discount_ratio;
      }
    }
    double utilityEvaluation = offeredUtility - estimateMax;
    double satisfy = offeredUtility - this.target;
    
    double p = Math.pow(time, alpha) / 5.0D + utilityEvaluation + satisfy;
    if (p < 0.1D) {
      p = 0.0D;
    }
    return p;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.AgentKF.AgentKF
 * JD-Core Version:    0.7.1
 */