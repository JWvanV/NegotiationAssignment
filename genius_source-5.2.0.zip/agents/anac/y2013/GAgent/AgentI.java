package agents.anac.y2013.GAgent;

import java.util.List;
import java.util.Random;
import misc.Range;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidHistory;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.utility.UtilitySpace;

public class AgentI
  extends Agent
{
  private Action actionOfPartner = null;
  private Range range = new Range(0.0D, 1.0D);
  private double time = 0.0D;
  private BidHistory myBidHistory = new BidHistory();
  private SortedOutcomeSpace outcomeSpace;
  private BidHistory opponetBidHistory = new BidHistory();
  private static double MINIMUM_BID_UTILITY = 1.0D;
  private Random randomnr = new Random();
  private boolean isDiscount = false;
  private boolean isResavationValue = false;
  private double widthUtil = 0.0D;
  private boolean isFirst = true;
  private Probability prob;
  private double preOppponetUtil;
  private double var;
  private static double A = 0.9D;
  private double sigmoidGain = 9.0D;
  private double lowerLimit = 0.6D;
  private double startTime = 0.7D;
  private double tim = 0.0D;
  
  public void init()
  {
    if (this.utilitySpace.getDiscountFactor() != 0.0D) {
      this.isDiscount = true;
    }
    if (this.utilitySpace.getReservationValue().doubleValue() != 0.0D) {
      this.isResavationValue = true;
    }
    this.sigmoidGain = 2.0D;
    this.lowerLimit = 0.9D;
    
    MINIMUM_BID_UTILITY = 1.0D;
    this.range.setLowerbound(changeThreshold(0.0D));
    this.time = this.timeline.getTime();
    this.outcomeSpace = new SortedOutcomeSpace(this.utilitySpace);
  }
  
  public double changeThreshold(double time)
  {
    return (1.0D - this.lowerLimit + this.tim) / (1.0D + Math.exp(this.sigmoidGain * time)) + this.lowerLimit;
  }
  
  public String getVersion()
  {
    return "3.1";
  }
  
  public String getName()
  {
    return "GAgent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = new Offer(getAgentID(), this.utilitySpace.getMaxUtilityBid());
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        BidDetails opponetBid = new BidDetails(partnerBid, 1.0D);
        this.opponetBidHistory.add(opponetBid);
        

        double offeredUtilFromOpponent = getUtility(partnerBid);
        
        double offerundiscoutFromOpponent = this.utilitySpace.getUtility(partnerBid);
        if (this.isFirst)
        {
          this.widthUtil = (1.0D - offeredUtilFromOpponent);
          this.prob = new Probability(this.widthUtil);
          
          this.lowerLimit = (1.0D - this.widthUtil / 3.0D);
          this.isFirst = false;
        }
        else
        {
          double diff = offerundiscoutFromOpponent - this.preOppponetUtil;
          this.var = this.prob.getVar(diff);
        }
        A = changeThreshold(this.time);
        
        this.preOppponetUtil = offerundiscoutFromOpponent;
        

        this.time = this.timeline.getTime();
        
        double a = 1.0D - this.var * this.widthUtil;
        if (a > A) {
          MINIMUM_BID_UTILITY = A;
        } else if (this.var * this.widthUtil > this.widthUtil / 2.0D) {
          MINIMUM_BID_UTILITY = 1.0D - this.widthUtil / 2.0D;
        } else {
          MINIMUM_BID_UTILITY = a;
        }
        this.range.setLowerbound(MINIMUM_BID_UTILITY);
        
        action = chooseRandomBidAction(this.time);
        
        Bid myBid = ((Offer)action).getBid();
        double myOfferedUtil = getUtility(myBid);
        if (isAcceptable(offerundiscoutFromOpponent, myOfferedUtil, this.time, partnerBid)) {
          action = new Accept(getAgentID());
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private boolean isAcceptable(double offeredUtilFromOpponent, double myOfferedUtil, double time, Bid parBid)
    throws Exception
  {
    BidDetails bd = new BidDetails(parBid, 1.0D);
    if (this.myBidHistory.getHistory().contains(bd)) {
      return true;
    }
    if (offeredUtilFromOpponent > MINIMUM_BID_UTILITY) {
      return true;
    }
    if ((this.isResavationValue) && 
      (getUtility(parBid) < this.lowerLimit)) {
      return false;
    }
    if (time > 0.9988D)
    {
      List<BidDetails> bdd = this.opponetBidHistory.getNBestBids(5);
      Bid nextBid = ((BidDetails)bdd.get(4)).getBid();
      double utility = getUtility(nextBid);
      if (offeredUtilFromOpponent > utility) {
        return true;
      }
    }
    return false;
  }
  
  private Action chooseRandomBidAction(double time)
  {
    Bid nextBid = null;
    try
    {
      if (time > 0.9988D)
      {
        List<BidDetails> bdd = this.opponetBidHistory.getNBestBids(3);
        int opt = this.randomnr.nextInt(3);
        nextBid = ((BidDetails)bdd.get(opt)).getBid();
        if ((this.isResavationValue) && 
          (getUtility(nextBid) < this.lowerLimit)) {
          nextBid = getRandomBid();
        }
      }
      else
      {
        nextBid = getRandomBid();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid getRandomBid()
    throws Exception
  {
    List<BidDetails> rangeBid = this.outcomeSpace.getBidsinRange(this.range);
    int rangeBidSize = rangeBid.size();
    BidDetails offerBidDetail;
    BidDetails offerBidDetail;
    if (rangeBidSize == 1)
    {
      Bid offerbid = ((BidDetails)rangeBid.get(0)).getBid();
      offerBidDetail = new BidDetails(offerbid, 1.0D);
    }
    else
    {
      int bitCount = 0;
      offerBidDetail = (BidDetails)rangeBid.get(bitCount);
      while (this.myBidHistory.getHistory().contains(offerBidDetail))
      {
        int ran = this.randomnr.nextInt(rangeBidSize - 1);
        offerBidDetail = (BidDetails)rangeBid.get(ran);
        bitCount++;
        if (bitCount > 60) {
          break;
        }
      }
    }
    this.myBidHistory.add(offerBidDetail);
    Bid offerbid = offerBidDetail.getBid();
    return offerbid;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.GAgent.AgentI
 * JD-Core Version:    0.7.1
 */