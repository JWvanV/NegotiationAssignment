package agents.anac.y2013.GAgent;

public class Probability
{
  public double mean;
  public double widthUtil;
  public double variance;
  public int itemNum;
  private double sumRatio;
  private double sumRatio2;
  
  public Probability(double w)
  {
    this.sumRatio = 0.0D;
    this.sumRatio2 = 0.0D;
    this.mean = 0.0D;
    this.widthUtil = w;
    this.variance = 0.0D;
    this.itemNum = 0;
  }
  
  private void calMean(double ratio)
  {
    this.sumRatio += ratio;
    this.mean = (this.sumRatio / this.itemNum);
  }
  
  private double calVar(double ratio)
  {
    this.sumRatio2 += ratio * ratio;
    this.variance = (this.sumRatio2 / this.itemNum - this.mean * this.mean);
    return this.variance;
  }
  
  private double getRatio(double util)
  {
    return util / this.widthUtil;
  }
  
  public double getM(double diff)
  {
    this.itemNum += 1;
    double ra = getRatio(diff);
    calMean(ra);
    return this.mean;
  }
  
  public double getVar(double diff)
  {
    this.itemNum += 1;
    double ra = getRatio(diff);
    calMean(diff);
    this.variance = calVar(ra);
    return this.mean * 100000.0D * this.variance * this.widthUtil;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.GAgent.Probability
 * JD-Core Version:    0.7.1
 */