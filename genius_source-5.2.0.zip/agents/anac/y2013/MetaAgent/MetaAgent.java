package agents.anac.y2013.MetaAgent;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.NegotiationResult;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.EVALUATORTYPE;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class MetaAgent
  extends Agent
{
  private Agent myAgent;
  private boolean agentInit;
  private Action actionOfPartner;
  HashMap<String, Double> features;
  double opponentFirstBid;
  double slopeBBUA;
  double absSlopeBBUA;
  double avgUtilBBUA;
  boolean isUpdated;
  AgentManager manager = new AgentManager();
  
  public void init()
  {
    this.agentInit = false;
    this.opponentFirstBid = 0.0D;
    this.slopeBBUA = 0.0D;
    this.absSlopeBBUA = 0.0D;
    this.avgUtilBBUA = 0.0D;
    Serializable s = loadSessionData();
    if (s != null)
    {
      this.manager = ((AgentManager)s);
      this.myAgent = this.manager.SelectBestAgent();
      this.myAgent.internalInit(this.sessionNr, this.sessionsTotal, this.startTime, this.totalTime, this.timeline, this.utilitySpace, this.parametervalues);
      

      this.myAgent.setName(getName());
      this.myAgent.setAgentID(getAgentID());
      this.myAgent.init();
      this.agentInit = true;
    }
    this.isUpdated = false;
  }
  
  public void endSession(NegotiationResult res)
  {
    if (!this.isUpdated)
    {
      this.manager.UpdateUtility("", res.getMyDiscountedUtility());
      this.isUpdated = true;
    }
    saveSessionData(this.manager);
  }
  
  private void getDomainParams()
  {
    Domain d = this.utilitySpace.getDomain();
    ArrayList<Issue> a = d.getIssues();
    


    this.features = new HashMap();
    
    int min = Integer.MAX_VALUE;int max = -1;int size = 1;int sumSize = 0;
    




    double EU = 0.0D;double stdevU = 0.0D;double stdevW = 0.0D;double sW = 0.0D;double ssW = 0.0D;double countW = 0.0D;double relevantEU = 0.0D;
    Iterator<Map.Entry<Objective, Evaluator>> issue = this.utilitySpace.getEvaluators().iterator();
    
    List<Double> ssWList = new ArrayList();
    while (issue.hasNext())
    {
      Map.Entry<Objective, Evaluator> entry = (Map.Entry)issue.next();
      Evaluator e = (Evaluator)entry.getValue();
      double weight = e.getWeight();
      countW += 1.0D;
      sW += weight;
      ssWList.add(Double.valueOf(weight));
      double tempEU = 0.0D;double tempStdevU = 0.0D;
      if (e.getType() == EVALUATORTYPE.DISCRETE)
      {
        Iterator<ValueDiscrete> v = ((EvaluatorDiscrete)e).getValues().iterator();
        
        List<Double> s = new ArrayList();
        double sumU = 0.0D;
        while (v.hasNext())
        {
          ValueDiscrete vd = (ValueDiscrete)v.next();
          try
          {
            double val = ((EvaluatorDiscrete)e).getEvaluation(vd).doubleValue();
            s.add(Double.valueOf(val));
            sumU += val;
            if ((this.opponentFirstBid > 0.0D) && (this.opponentFirstBid <= val)) {
              relevantEU += val;
            }
          }
          catch (Exception e1) {}
        }
        int currSize = s.size();
        min = min > currSize ? currSize : min;
        max = max < currSize ? currSize : max;
        sumSize += currSize;
        size *= currSize;
        tempEU = sumU / currSize;
        Iterator<Double> valIt = s.iterator();
        while (valIt.hasNext()) {
          tempStdevU += Math.pow(((Double)valIt.next()).doubleValue() - tempEU, 2.0D);
        }
        tempStdevU = Math.sqrt(tempStdevU / (currSize - 1.0D));
      }
      else if (e.getType() == EVALUATORTYPE.INTEGER)
      {
        tempEU = (((EvaluatorInteger)e).getUpperBound() + ((EvaluatorInteger)e).getLowerBound()) / 2.0D;
        
        tempStdevU = Math.sqrt((Math.pow(((EvaluatorInteger)e).getUpperBound() - tempEU, 2.0D) + Math.pow(((EvaluatorInteger)e).getLowerBound() - tempEU, 2.0D)) / 2.0D);
      }
      else if (e.getType() == EVALUATORTYPE.REAL)
      {
        tempEU = (((EvaluatorReal)e).getUpperBound() + ((EvaluatorReal)e).getLowerBound()) / 2.0D;
        
        tempStdevU = Math.sqrt((Math.pow(((EvaluatorReal)e).getUpperBound() - tempEU, 2.0D) + Math.pow(((EvaluatorReal)e).getLowerBound() - tempEU, 2.0D)) / 2.0D);
      }
      else
      {
        tempEU = 0.5D;
        tempStdevU = 0.0D;
      }
      EU += tempEU * weight;
      stdevU += tempStdevU * weight;
    }
    Iterator<Double> wIt = ssWList.iterator();
    double avgW = sW / countW;
    double avgSize = sumSize / this.utilitySpace.getEvaluators().size();
    while (wIt.hasNext()) {
      ssW += Math.pow(((Double)wIt.next()).doubleValue() - avgW, 2.0D);
    }
    stdevW = countW <= 1.0D ? 0.0D : Math.sqrt(ssW / (countW - 1.0D));
    
    double relsumUtility = 0.0D;double relcountUtility = 0.0D;double relstdevUtility = 0.0D;double stdevUtil = 0.0D;double countbids = 0.0D;double sumbids = 0.0D;double relevantStdevU = 0.0D;
    ArrayList<Double> bidsUtil = new ArrayList();
    ArrayList<Bid> bids = GetDiscreteBids();
    for (Bid bid : bids) {
      try
      {
        bidsUtil.add(Double.valueOf(this.utilitySpace.getUtility(bid)));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    for (Iterator i$ = bidsUtil.iterator(); i$.hasNext();)
    {
      double bidUtil = ((Double)i$.next()).doubleValue();
      stdevUtil += Math.pow(bidUtil, 2.0D);
      sumbids += bidUtil;
      countbids += 1.0D;
      if (bidUtil >= this.opponentFirstBid)
      {
        relsumUtility += bidUtil;
        relcountUtility += 1.0D;
        relstdevUtility += Math.pow(bidUtil, 2.0D);
      }
    }
    if (relcountUtility > 0.0D)
    {
      relevantEU = relsumUtility / relcountUtility;
      relevantStdevU = Math.sqrt(relstdevUtility / relcountUtility - Math.pow(relevantEU, 2.0D));
    }
    if (countbids > 0.0D)
    {
      EU = sumbids / countbids;
      stdevU = Math.sqrt(stdevUtil / countbids - Math.pow(EU, 2.0D));
    }
    this.features.put("(Intercept)", Double.valueOf(1.0D));
    this.features.put("UtilityOfFirstOpponentBid", Double.valueOf(this.opponentFirstBid));
    this.features.put("ReservationValue", this.utilitySpace.getReservationValue());
    
    this.features.put("DiscountFactor", Double.valueOf(this.utilitySpace.getDiscountFactor() == 0.0D ? 1.0D : this.utilitySpace.getDiscountFactor()));
    

    this.features.put("numOfIssues", Double.valueOf(a.size() + 0.0D));
    this.features.put("DomainSize", Double.valueOf(size + 0.0D));
    this.features.put("AvgUtil", Double.valueOf(EU));
    this.features.put("AvgUtilStdev", Double.valueOf(stdevU));
    this.features.put("AvgSize", Double.valueOf(avgSize));
    this.features.put("WeightStdev", Double.valueOf(stdevW));
    this.features.put("RelevantEU", Double.valueOf(relevantEU));
    this.features.put("RelevantStdevU", Double.valueOf(relevantStdevU));
  }
  
  public Action chooseAction()
  {
    try
    {
      if (!this.agentInit)
      {
        if (this.actionOfPartner == null) {
          return new Offer(this, this.utilitySpace.getMaxUtilityBid());
        }
        this.agentInit = true;
        if ((this.actionOfPartner instanceof Offer)) {
          this.opponentFirstBid = this.utilitySpace.getUtility(((Offer)this.actionOfPartner).getBid());
        }
        getDomainParams();
        UpdateAllAgents();
        this.manager.SetAvgUtil(((Double)this.features.get("RelevantEU")).doubleValue() * Math.pow(this.utilitySpace.getDiscountFactor(), 0.5D), ((Double)this.features.get("RelevantStdevU")).doubleValue());
        




        this.myAgent = this.manager.SelectBestAgent();
        this.myAgent.internalInit(this.sessionNr, this.sessionsTotal, this.startTime, this.totalTime, this.timeline, this.utilitySpace, this.parametervalues);
        

        this.myAgent.setName(getName());
        this.myAgent.setAgentID(getAgentID());
        this.myAgent.init();
        
        this.myAgent.ReceiveMessage(this.actionOfPartner);
      }
      Action a = this.myAgent.chooseAction();
      if (a == null) {
        return new Offer(this, this.utilitySpace.getMaxUtilityBid());
      }
      double time = this.timeline.getTime();
      if (((a instanceof Offer)) && (this.utilitySpace.getReservationValueWithDiscount(time) >= this.utilitySpace.getUtilityWithDiscount(((Offer)a).getBid(), time))) {}
      return new EndNegotiation();
    }
    catch (Exception e) {}
    return null;
  }
  
  private void UpdateAllAgents()
  {
    Set<String> agents = this.manager.GetAgents();
    for (String agentName : agents)
    {
      double predicted = Parser.getMean(this.manager.GetAgentData(agentName), this.features);
      
      this.manager.UpdateUtility(agentName, predicted);
    }
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
    if (this.agentInit) {
      this.myAgent.ReceiveMessage(opponentAction);
    }
  }
  
  public String getName()
  {
    return "Meta-Agent 2013";
  }
  
  public String getVersion()
  {
    return "2.0";
  }
  
  private ArrayList<Bid> GetDiscreteBids()
  {
    ArrayList<Bid> bids = new ArrayList();
    HashMap<Integer, Value> issusesFirstValue = new HashMap();
    for (Issue issue : this.utilitySpace.getDomain().getIssues())
    {
      Value v = null;
      if (issue.getType() == ISSUETYPE.INTEGER) {
        v = new ValueInteger(((IssueInteger)issue).getLowerBound());
      } else if (issue.getType() == ISSUETYPE.REAL) {
        v = new ValueReal(((IssueReal)issue).getLowerBound());
      } else if (issue.getType() == ISSUETYPE.DISCRETE) {
        v = ((IssueDiscrete)issue).getValue(0);
      }
      issusesFirstValue.put(Integer.valueOf(issue.getNumber()), v);
    }
    try
    {
      bids.add(new Bid(this.utilitySpace.getDomain(), issusesFirstValue));
    }
    catch (Exception e)
    {
      return null;
    }
    for (Issue issue : this.utilitySpace.getDomain().getIssues())
    {
      ArrayList<Bid> tempBids = new ArrayList();
      
      ArrayList<Value> issueValues = new ArrayList();
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        ArrayList<ValueDiscrete> valuesD = (ArrayList)((IssueDiscrete)issue).getValues();
        for (Value v : valuesD) {
          issueValues.add(v);
        }
      }
      else if (issue.getType() == ISSUETYPE.INTEGER)
      {
        int k = Math.min(10, ((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue).getLowerBound());
        for (int i = 0; i <= k; i++)
        {
          ValueInteger vi = (ValueInteger)GetRepresentorOfBucket(i, issue, k, true);
          
          issueValues.add(vi);
        }
      }
      else if (issue.getType() == ISSUETYPE.REAL)
      {
        int k = 10;
        for (int i = 0; i <= k; i++)
        {
          ValueReal vr = (ValueReal)GetRepresentorOfBucket(i, issue, k, false);
          
          issueValues.add(vr);
        }
      }
      for (Iterator i$ = bids.iterator(); i$.hasNext();)
      {
        bid = (Bid)i$.next();
        for (Value value : issueValues)
        {
          HashMap<Integer, Value> bidValues = new HashMap();
          for (Issue issue1 : this.utilitySpace.getDomain().getIssues()) {
            try
            {
              bidValues.put(Integer.valueOf(issue1.getNumber()), bid.getValue(issue1.getNumber()));
            }
            catch (Exception e)
            {
              e.printStackTrace();
            }
          }
          bidValues.put(Integer.valueOf(issue.getNumber()), value);
          try
          {
            Bid newBid = new Bid(this.utilitySpace.getDomain(), bidValues);
            
            tempBids.add(newBid);
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
      Bid bid;
      bids = tempBids;
    }
    return bids;
  }
  
  private Value GetRepresentorOfBucket(int bucket, Issue issue, int k, boolean isInteger)
  {
    double ans = 0.0D;
    if (isInteger)
    {
      EvaluatorInteger ei = new EvaluatorInteger();
      boolean upperIsTheBest = ei.getEvaluation(((IssueInteger)issue).getUpperBound()).doubleValue() > ei.getEvaluation(((IssueInteger)issue).getLowerBound()).doubleValue();
      if (upperIsTheBest)
      {
        if (bucket < k)
        {
          ans = (bucket + 1) / k;
          ans = ans * (((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue).getLowerBound()) + ((IssueInteger)issue).getLowerBound() - 1.0D;
        }
        else
        {
          ans = ((IssueInteger)issue).getUpperBound();
        }
      }
      else
      {
        ans = bucket / k;
        ans = ans * (((IssueInteger)issue).getUpperBound() - ((IssueInteger)issue).getLowerBound()) + ((IssueInteger)issue).getLowerBound();
      }
      return new ValueInteger((int)Math.round(ans));
    }
    EvaluatorReal ei = new EvaluatorReal();
    boolean upperIsTheBest = ei.getEvaluation(((IssueReal)issue).getUpperBound()).doubleValue() > ei.getEvaluation(((IssueReal)issue).getLowerBound()).doubleValue();
    if (upperIsTheBest)
    {
      if (bucket < k)
      {
        ans = (bucket + 1) / k;
        ans = ans * (((IssueReal)issue).getUpperBound() - ((IssueReal)issue).getLowerBound()) + ((IssueReal)issue).getLowerBound();
      }
      else
      {
        ans = ((IssueReal)issue).getUpperBound();
      }
    }
    else
    {
      ans = bucket / k;
      ans = ans * (((IssueReal)issue).getUpperBound() - ((IssueReal)issue).getLowerBound()) + ((IssueReal)issue).getLowerBound();
    }
    return new ValueReal(ans);
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.MetaAgent
 * JD-Core Version:    0.7.1
 */