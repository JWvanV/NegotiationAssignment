package agents.anac.y2013.MetaAgent.parser.nn;

public class Arrow
{
  int sourceId;
  int destId;
  double value;
  
  public Arrow(int sourceId, int destId, double value)
  {
    this.sourceId = sourceId;
    this.destId = destId;
    this.value = value;
  }
  
  public String toString()
  {
    return "Arrow [sourceId=" + this.sourceId + ", destId=" + this.destId + ", value=" + this.value + "]";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.parser.nn.Arrow
 * JD-Core Version:    0.7.1
 */