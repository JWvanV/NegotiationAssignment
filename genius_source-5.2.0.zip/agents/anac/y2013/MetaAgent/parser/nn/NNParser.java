package agents.anac.y2013.MetaAgent.parser.nn;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Vector;

public class NNParser
{
  String[] sections;
  HashMap<Integer, String> vars;
  Vector<Arrow> arrows;
  int length;
  int lastNodeID;
  
  public NNParser(String fileName)
  {
    this.sections = readFile(fileName);
    for (int i = 0; i < this.sections.length; i++) {
      this.sections[i] = this.sections[i].trim();
    }
    parseVars(this.sections[1]);
    this.arrows = new Vector();
    parseArrows(this.sections[2].split("\n"), this.sections[3].split("\n"));
  }
  
  private void parseArrows(String[] weightsS, String[] sourcesS)
  {
    this.length += 1;
    HashMap<Integer, Double> weights = new HashMap();
    for (int i = 0; i < weightsS.length; i++)
    {
      String[] s2 = weightsS[i].replace("\"", "").split(",");
      Integer id = Integer.valueOf(Integer.parseInt(s2[0]));
      Double w = Double.valueOf(Double.parseDouble(s2[1]));
      weights.put(id, w);
    }
    for (int i = 0; i < 4; i++) {
      for (int j = 0; j < this.length; j++)
      {
        String[] s2 = sourcesS[(i * this.length + j)].replace("\"", "").split(",");
        int from = Integer.parseInt(s2[1]);
        Integer wID = Integer.valueOf(Integer.parseInt(s2[0]));
        double w = ((Double)weights.get(wID)).doubleValue();
        this.arrows.add(new Arrow(from, i + 12, w));
      }
    }
    int i = this.length * 4;
    for (int j = 0; j < 5; j++)
    {
      String[] s2 = sourcesS[(i + j)].replace("\"", "").split(",");
      int from = Integer.parseInt(s2[1]);
      Integer wID = Integer.valueOf(Integer.parseInt(s2[0]));
      double w = ((Double)weights.get(wID)).doubleValue();
      this.arrows.add(new Arrow(from, this.lastNodeID, w));
    }
  }
  
  private void parseVars(String varsString)
  {
    this.vars = new HashMap();
    String[] varsS = varsString.split("\n");
    this.length = varsS.length;
    for (int i = 0; i < varsS.length; i++) {
      parseVar(varsS[i]);
    }
    int length = varsS.length;
    for (int i = 1; i < 6; i++) {
      this.vars.put(Integer.valueOf(i + length), "V" + (i + length));
    }
    this.lastNodeID = this.vars.size();
  }
  
  private void parseVar(String s)
  {
    s = s.replace("\"", "");
    String[] s2 = s.split(",");
    Integer id = Integer.valueOf(Integer.parseInt(s2[0]));
    String name = s2[1];
    this.vars.put(id, name);
  }
  
  private String[] readFile(String fileName)
  {
    String text = "";
    try
    {
      BufferedReader br = new BufferedReader(new FileReader(fileName));
      StringBuilder sb = new StringBuilder();
      String line = br.readLine();
      while (line != null)
      {
        sb.append(line);
        sb.append("\n");
        line = br.readLine();
      }
      text = sb.toString();
      br.close();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return text.trim().split("\"x\"");
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.parser.nn.NNParser
 * JD-Core Version:    0.7.1
 */