package agents.anac.y2013.MetaAgent.parser.cart;

import agents.anac.y2013.MetaAgent.Parser.Type;
import agents.anac.y2013.MetaAgent.agentsData.AgentData;
import agents.anac.y2013.MetaAgent.parser.cart.tree.MeanNode;
import agents.anac.y2013.MetaAgent.parser.cart.tree.Node;
import java.util.HashMap;

public class TreeParser
{
  String text = "";
  Parser.Type type;
  AgentData data;
  
  public TreeParser(AgentData data)
  {
    this.data = data;
  }
  
  public Node Parse()
  {
    this.text = this.data.getText();
    this.text = this.text.trim();
    String[] nodesText = this.text.split("Node number ");
    return parseNodes(nodesText);
  }
  
  private Node parseNodes(String[] nodesText)
  {
    HashMap<Integer, Node> nodes = new HashMap();
    for (int i = 0; i < nodesText.length; i++) {
      if (!nodesText[i].equals(""))
      {
        Node n = MeanNode.factory(nodesText[i]);
        nodes.put(new Integer(n.get_id()), n);
      }
    }
    for (Node node : nodes.values())
    {
      int id = node.get_leftId();
      if (id != -1)
      {
        Node other = (Node)nodes.get(new Integer(id));
        node.set_left(other);
      }
      id = node.get_rightId();
      if (id != -1)
      {
        Node other = (Node)nodes.get(new Integer(id));
        node.set_right(other);
      }
    }
    return (Node)nodes.get(new Integer(1));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.parser.cart.TreeParser
 * JD-Core Version:    0.7.1
 */