package agents.anac.y2013.MetaAgent.parser.cart.tree;

public class SurrogateSplit
  extends Split
{
  String _name;
  double _value;
  Split.Direction _direction;
  double _agree;
  double _adj;
  int _splitsCount;
  
  private SurrogateSplit(String name, double value, Split.Direction direction, double agree, double adj, int splitsCount)
  {
    super(name, value, direction);
    this._agree = agree;
    this._adj = adj;
    this._splitsCount = splitsCount;
  }
  
  public static SurrogateSplit factory(String text)
  {
    text = text.trim();
    String[] wordstext = text.split(" +");
    String name = wordstext[0];
    double value = Double.parseDouble(wordstext[2]);
    Split.Direction dir;
    Split.Direction dir;
    if (wordstext[5].contains("left")) {
      dir = Split.Direction.LEFT;
    } else {
      dir = Split.Direction.RIGHT;
    }
    double agree = Double.parseDouble(Node.substring(text, "agree=", ","));
    double adj = Double.parseDouble(Node.substring(text, "adj=", ","));
    int count = Integer.parseInt(Node.substring(text, "(", text.indexOf("split")).trim());
    SurrogateSplit s = new SurrogateSplit(name, value, dir, agree, adj, count);
    return s;
  }
  
  public String toString()
  {
    return "SurrogateSplit [_name=" + this._name + ", _value=" + this._value + ", _direction=" + this._direction + ", _agree=" + this._agree + ", _adj=" + this._adj + ", _splitsCount=" + this._splitsCount + "]";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.parser.cart.tree.SurrogateSplit
 * JD-Core Version:    0.7.1
 */