package agents.anac.y2013.MetaAgent.parser.cart.tree;

public class PrimarySplit
  extends Split
{
  double _improve;
  int _missing;
  
  private PrimarySplit(String name, double value, Split.Direction direction, double improve, int missing)
  {
    super(name, value, direction);
    this._improve = improve;
    this._missing = missing;
  }
  
  public static PrimarySplit factory(String text)
  {
    text = text.trim();
    String[] wordstext = text.split(" +");
    String name = wordstext[0];
    double value = Double.parseDouble(wordstext[2]);
    Split.Direction dir;
    Split.Direction dir;
    if (wordstext[5].contains("left")) {
      dir = Split.Direction.LEFT;
    } else {
      dir = Split.Direction.RIGHT;
    }
    double improve = Double.parseDouble(Node.substring(text, "improve=", ","));
    int missing = Integer.parseInt(Node.substring(text, "(", text.indexOf("missing")).trim());
    PrimarySplit s = new PrimarySplit(name, value, dir, improve, missing);
    return s;
  }
  
  public String toString()
  {
    return "Split [_name=" + this._name + ", _value=" + this._value + ", _direction=" + this._direction + ", _improve=" + this._improve + ", _missing=" + this._missing + "]";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.parser.cart.tree.PrimarySplit
 * JD-Core Version:    0.7.1
 */