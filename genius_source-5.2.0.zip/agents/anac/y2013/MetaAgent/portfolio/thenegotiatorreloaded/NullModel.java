package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.Bid;

public class NullModel
  extends OpponentModel
{
  public void updateModel(Bid opponentBid) {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.NullModel
 * JD-Core Version:    0.7.1
 */