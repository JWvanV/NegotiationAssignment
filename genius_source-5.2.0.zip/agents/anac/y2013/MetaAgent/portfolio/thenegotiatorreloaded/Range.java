package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public class Range
{
  private double lowerbound;
  private double upperbound;
  
  public Range(double lowerbound, double upperbound)
  {
    this.lowerbound = lowerbound;
    this.upperbound = upperbound;
  }
  
  public double getUpperbound()
  {
    return this.upperbound;
  }
  
  public double getLowerbound()
  {
    return this.lowerbound;
  }
  
  public void setUpperbound(double ubound)
  {
    this.upperbound = ubound;
  }
  
  public void setLowerbound(double lbound)
  {
    this.lowerbound = lbound;
  }
  
  public void increaseUpperbound(double increment)
  {
    this.upperbound += increment;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.Range
 * JD-Core Version:    0.7.1
 */