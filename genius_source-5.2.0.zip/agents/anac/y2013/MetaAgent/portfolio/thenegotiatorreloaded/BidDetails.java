package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.Bid;

public class BidDetails
  implements Comparable<BidDetails>
{
  private Bid bid;
  private double myUndiscountedUtil;
  private double time;
  
  public BidDetails(Bid bid, double myUndiscountedUtil)
  {
    this.bid = bid;
    this.myUndiscountedUtil = myUndiscountedUtil;
  }
  
  public BidDetails(Bid bid, double myUndiscountedUtil, double time)
  {
    this.bid = bid;
    this.myUndiscountedUtil = myUndiscountedUtil;
    this.time = time;
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public void setBid(Bid bid)
  {
    this.bid = bid;
  }
  
  public double getMyUndiscountedUtil()
  {
    return this.myUndiscountedUtil;
  }
  
  public void setMyUndiscountedUtil(double utility)
  {
    this.myUndiscountedUtil = utility;
  }
  
  public double getTime()
  {
    return this.time;
  }
  
  public void setTime(double t)
  {
    this.time = t;
  }
  
  public String toString()
  {
    return "(u=" + this.myUndiscountedUtil + ", t=" + this.time + ")";
  }
  
  public int compareTo(BidDetails utbid)
  {
    double otherUtil = utbid.getMyUndiscountedUtil();
    
    int value = 0;
    if (this.myUndiscountedUtil < otherUtil) {
      value = 1;
    } else if (this.myUndiscountedUtil > otherUtil) {
      value = -1;
    }
    return value;
  }
  
  public int hashCode()
  {
    int prime = 31;
    int result = 1;
    result = 31 * result + (this.bid == null ? 0 : this.bid.hashCode());
    
    long temp = Double.doubleToLongBits(this.myUndiscountedUtil);
    result = 31 * result + (int)(temp ^ temp >>> 32);
    temp = Double.doubleToLongBits(this.time);
    result = 31 * result + (int)(temp ^ temp >>> 32);
    return result;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    BidDetails other = (BidDetails)obj;
    if (this.bid == null)
    {
      if (other.bid != null) {
        return false;
      }
    }
    else if (!this.bid.equals(other.bid)) {
      return false;
    }
    if (Double.doubleToLongBits(this.myUndiscountedUtil) != Double.doubleToLongBits(other.myUndiscountedUtil)) {
      return false;
    }
    if (Double.doubleToLongBits(this.time) != Double.doubleToLongBits(other.time)) {
      return false;
    }
    return true;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BidDetails
 * JD-Core Version:    0.7.1
 */