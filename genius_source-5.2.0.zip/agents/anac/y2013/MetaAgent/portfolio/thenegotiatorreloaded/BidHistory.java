package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class BidHistory
{
  private List<BidDetails> bidList;
  
  public BidHistory(ArrayList<BidDetails> bids)
  {
    this.bidList = bids;
  }
  
  public BidHistory(UtilitySpace utilSpace)
  {
    BidIterator bidsIter = new BidIterator(utilSpace.getDomain());
    this.bidList = new ArrayList();
    while (bidsIter.hasNext())
    {
      Bid bid = bidsIter.next();
      double util = 0.0D;
      try
      {
        util = utilSpace.getUtility(bid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      this.bidList.add(new BidDetails(bid, util));
    }
  }
  
  public BidHistory()
  {
    this.bidList = new ArrayList();
  }
  
  public BidHistory filterBetweenTime(double t1, double t2)
  {
    return filterBetween(0.0D, 1.1D, t1, t2);
  }
  
  public BidHistory filterBetweenUtility(double u1, double u2)
  {
    return filterBetween(u1, u2, 0.0D, 1.1D);
  }
  
  public BidHistory filterBetween(double minU, double maxU, double minT, double maxT)
  {
    BidHistory bidHistory = new BidHistory();
    for (BidDetails b : this.bidList) {
      if ((minU < b.getMyUndiscountedUtil()) && 
        (b.getMyUndiscountedUtil() <= maxU) && 
        (minT < b.getTime()) && 
        (b.getTime() <= maxT)) {
        bidHistory.add(b);
      }
    }
    return bidHistory;
  }
  
  public void add(BidDetails bid)
  {
    this.bidList.add(bid);
  }
  
  public List<BidDetails> getHistory()
  {
    return this.bidList;
  }
  
  public BidDetails getLastBidDetails()
  {
    BidDetails bid = null;
    if (this.bidList.size() > 0) {
      bid = (BidDetails)this.bidList.get(this.bidList.size() - 1);
    }
    return bid;
  }
  
  public BidDetails getFirstBidDetails()
  {
    return (BidDetails)this.bidList.get(0);
  }
  
  public BidDetails getBestBidDetails()
  {
    double max = Double.NEGATIVE_INFINITY;
    BidDetails bestBid = null;
    for (BidDetails b : this.bidList)
    {
      double utility = b.getMyUndiscountedUtil();
      if (utility >= max)
      {
        max = utility;
        bestBid = b;
      }
    }
    return bestBid;
  }
  
  public BidDetails getWorstBidDetails()
  {
    double min = Double.POSITIVE_INFINITY;
    BidDetails worstBid = null;
    for (BidDetails b : this.bidList)
    {
      double utility = b.getMyUndiscountedUtil();
      if (utility < min)
      {
        min = utility;
        worstBid = b;
      }
    }
    return worstBid;
  }
  
  public List<BidDetails> getNBestBids(int count)
  {
    List<BidDetails> result = new ArrayList();
    List<BidDetails> sortedOpponentBids = new ArrayList(this.bidList);
    Collections.sort(sortedOpponentBids, new BidDetailsSorterUtility());
    for (int i = 0; (i < count) && (i < sortedOpponentBids.size()); i++) {
      result.add(sortedOpponentBids.get(i));
    }
    return result;
  }
  
  public int size()
  {
    return this.bidList.size();
  }
  
  public double getAverageUtility()
  {
    int size = size();
    if (size == 0) {
      return 0.0D;
    }
    double totalUtil = 0.0D;
    for (BidDetails bid : this.bidList) {
      totalUtil = bid.getMyUndiscountedUtil();
    }
    return totalUtil / size;
  }
  
  public BidDetails getBidDetailsOfUtility(double u)
  {
    double minDistance = -1.0D;
    BidDetails closestBid = null;
    for (BidDetails b : this.bidList)
    {
      double utility = b.getMyUndiscountedUtil();
      if ((Math.abs(utility - u) <= minDistance) || (minDistance == -1.0D))
      {
        minDistance = Math.abs(utility - u);
        closestBid = b;
      }
    }
    return closestBid;
  }
  
  public BidHistory sortToUtility()
  {
    BidHistory sortedHistory = this;
    Collections.sort(sortedHistory.getHistory(), new BidDetailsSorterUtility());
    return sortedHistory;
  }
  
  public BidHistory sortToTime()
  {
    BidHistory sortedHistory = this;
    Collections.sort(sortedHistory.getHistory(), new BidDetailsSorterTime());
    return sortedHistory;
  }
  
  public BidDetails getRandom()
  {
    return getRandom(new Random());
  }
  
  public BidDetails getRandom(Random rand)
  {
    int size = size();
    if (size == 0) {
      return null;
    }
    int index = rand.nextInt(size);
    return (BidDetails)this.bidList.get(index);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BidHistory
 * JD-Core Version:    0.7.1
 */