package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class NullStrategy
  extends OMStrategy
{
  private Random rand;
  private double updateThreshold = 1.0D;
  
  public NullStrategy() {}
  
  public NullStrategy(NegotiationSession negotiationSession, double time)
  {
    this.rand = new Random();
    this.negotiationSession = negotiationSession;
    this.updateThreshold = time;
  }
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, HashMap<String, Double> parameters)
    throws Exception
  {
    this.rand = new Random();
    this.negotiationSession = negotiationSession;
    if (parameters.containsKey("t")) {
      this.updateThreshold = ((Double)parameters.get("t")).doubleValue();
    }
  }
  
  public BidDetails getBid(List<BidDetails> allBids)
  {
    return (BidDetails)allBids.get(this.rand.nextInt(allBids.size()));
  }
  
  public boolean canUpdateOM()
  {
    return this.negotiationSession.getTime() < this.updateThreshold;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.NullStrategy
 * JD-Core Version:    0.7.1
 */