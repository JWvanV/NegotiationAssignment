package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.utility.UtilitySpace;

public class DomainAnalyzer
{
  private OpponentModel opponentModel;
  private UtilitySpace ownUtilSpace;
  private static double DEFAULT_KALAI = 0.7D;
  private OMStrategy omStrategy;
  private double previousKalaiPoint;
  
  public DomainAnalyzer(UtilitySpace ownUtilSpace, OpponentModel opponentModel, OMStrategy omStrategy)
  {
    this.opponentModel = opponentModel;
    this.omStrategy = omStrategy;
    this.ownUtilSpace = ownUtilSpace;
  }
  
  public double calculateKalaiPoint()
  {
    double kalaiPoint = DEFAULT_KALAI;
    if ((this.opponentModel != null) && (!(this.opponentModel instanceof NullModel)) && (this.opponentModel.getOpponentUtilitySpace() != null)) {
      if (this.omStrategy.canUpdateOM()) {
        try
        {
          BidSpace space = new BidSpace(this.ownUtilSpace, this.opponentModel.getOpponentUtilitySpace(), true);
          BidPoint kalai = space.getKalaiSmorodinsky();
          kalaiPoint = kalai.getUtilityA().doubleValue();
          this.previousKalaiPoint = kalaiPoint;
        }
        catch (Exception e) {}
      } else {
        kalaiPoint = this.previousKalaiPoint;
      }
    }
    return kalaiPoint;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.DomainAnalyzer
 * JD-Core Version:    0.7.1
 */