package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.io.PrintStream;
import java.util.List;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public abstract class BOAagent
  extends Agent
{
  protected AcceptanceStrategy acceptConditions;
  protected NegotiationSession negotiationSession;
  protected OfferingStrategy offeringStrategy;
  protected OpponentModel opponentModel;
  protected OMStrategy omStrategy;
  protected OutcomeSpace outcomeSpace;
  
  public void init()
  {
    super.init();
    this.negotiationSession = new NegotiationSession(this.utilitySpace, this.timeline);
    agentSetup();
  }
  
  public abstract void agentSetup();
  
  public void setDecoupledComponents(AcceptanceStrategy ac, OfferingStrategy os, OpponentModel om, OMStrategy oms)
  {
    this.acceptConditions = ac;
    this.offeringStrategy = os;
    this.opponentModel = om;
    this.omStrategy = oms;
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public abstract String getName();
  
  public void ReceiveMessage(Action opponentAction)
  {
    if ((opponentAction instanceof Offer))
    {
      Bid bid = ((Offer)opponentAction).getBid();
      try
      {
        BidDetails opponentBid = new BidDetails(bid, this.negotiationSession.getUtilitySpace().getUtility(bid), this.negotiationSession.getTime());
        this.negotiationSession.getOpponentBidHistory().add(opponentBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      if ((this.opponentModel != null) && (!(this.opponentModel instanceof NullModel))) {
        if (this.omStrategy.canUpdateOM()) {
          this.opponentModel.updateModel(bid);
        } else if (!this.opponentModel.isCleared()) {
          this.opponentModel.cleanUp();
        }
      }
    }
  }
  
  public Action chooseAction()
  {
    BidDetails bid;
    BidDetails bid;
    if (this.negotiationSession.getOwnBidHistory().getHistory().isEmpty()) {
      bid = this.offeringStrategy.determineOpeningBid();
    } else {
      bid = this.offeringStrategy.determineNextBid();
    }
    if (bid == null)
    {
      System.out.println("Error in code, null bid was given");
      return new Accept(getAgentID());
    }
    this.offeringStrategy.setNextBid(bid);
    


    Actions decision = Actions.Reject;
    if (!this.negotiationSession.getOpponentBidHistory().getHistory().isEmpty()) {
      decision = this.acceptConditions.determineAcceptability();
    }
    if (decision.equals(Actions.Break)) {
      return new EndNegotiation(getAgentID());
    }
    if (decision.equals(Actions.Reject))
    {
      this.negotiationSession.getOwnBidHistory().add(bid);
      return new Offer(getAgentID(), bid.getBid());
    }
    return new Accept(getAgentID());
  }
  
  public OpponentModel getOpponentModel()
  {
    return this.opponentModel;
  }
  
  public void cleanUp()
  {
    this.offeringStrategy = null;
    this.acceptConditions = null;
    this.omStrategy = null;
    this.opponentModel = null;
    this.outcomeSpace = null;
    this.negotiationSession = null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BOAagent
 * JD-Core Version:    0.7.1
 */