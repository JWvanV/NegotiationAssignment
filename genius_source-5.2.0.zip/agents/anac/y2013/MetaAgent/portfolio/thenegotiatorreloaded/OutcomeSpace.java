package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.ArrayList;
import java.util.List;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.utility.UtilitySpace;

public class OutcomeSpace
{
  protected UtilitySpace utilitySpace;
  protected List<BidDetails> allBids = new ArrayList();
  
  public OutcomeSpace() {}
  
  public OutcomeSpace(UtilitySpace utilSpace)
  {
    this.utilitySpace = utilSpace;
    generateAllBids(utilSpace);
  }
  
  public void generateAllBids(UtilitySpace utilSpace)
  {
    BidIterator iter = new BidIterator(utilSpace.getDomain());
    while (iter.hasNext())
    {
      Bid bid = iter.next();
      try
      {
        BidDetails BidDetails = new BidDetails(bid, utilSpace.getUtility(bid));
        this.allBids.add(BidDetails);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public List<BidDetails> getAllOutcomes()
  {
    return this.allBids;
  }
  
  public List<BidDetails> getBidsinRange(Range r)
  {
    ArrayList<BidDetails> result = new ArrayList();
    double upperbound = r.getUpperbound();
    double lowerbound = r.getLowerbound();
    for (BidDetails bid : this.allBids) {
      if ((bid.getMyUndiscountedUtil() > lowerbound) && (bid.getMyUndiscountedUtil() < upperbound)) {
        result.add(bid);
      }
    }
    return result;
  }
  
  public List<BidDetails> getBidsinDiscountedRange(Range r, double time)
  {
    ArrayList<BidDetails> result = new ArrayList();
    double upperbound = r.getUpperbound();
    double lowerbound = r.getLowerbound();
    for (BidDetails bid : this.allBids) {
      if ((this.utilitySpace.getUtilityWithDiscount(bid.getBid(), time) > lowerbound) && (this.utilitySpace.getUtilityWithDiscount(bid.getBid(), time) < upperbound)) {
        result.add(bid);
      }
    }
    return result;
  }
  
  public BidDetails getBidNearUtility(double utility)
  {
    BidDetails closesBid = null;
    double closesDistance = 1.0D;
    for (BidDetails bid : this.allBids) {
      if (Math.abs(bid.getMyUndiscountedUtil() - utility) < closesDistance)
      {
        closesBid = bid;
        closesDistance = Math.abs(bid.getMyUndiscountedUtil() - utility);
      }
    }
    return closesBid;
  }
  
  public BidDetails getBidNearDiscountedUtility(double utility, double time)
  {
    BidDetails closestBid = null;
    double closestDistance = 1.0D;
    for (BidDetails bid : this.allBids) {
      if (Math.abs(this.utilitySpace.getUtilityWithDiscount(bid.getBid(), time) - utility) < closestDistance)
      {
        closestBid = bid;
        closestDistance = Math.abs(bid.getMyUndiscountedUtil() - utility);
      }
    }
    return closestBid;
  }
  
  public BidDetails getMaxBidPossible()
  {
    BidDetails maxBid = (BidDetails)this.allBids.get(0);
    for (BidDetails bid : this.allBids) {
      if (bid.getMyUndiscountedUtil() > maxBid.getMyUndiscountedUtil()) {
        maxBid = bid;
      }
    }
    return maxBid;
  }
  
  public BidDetails getMinBidPossible()
  {
    BidDetails minBid = (BidDetails)this.allBids.get(0);
    for (BidDetails bid : this.allBids) {
      if (bid.getMyUndiscountedUtil() < minBid.getMyUndiscountedUtil()) {
        minBid = bid;
      }
    }
    return minBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.OutcomeSpace
 * JD-Core Version:    0.7.1
 */