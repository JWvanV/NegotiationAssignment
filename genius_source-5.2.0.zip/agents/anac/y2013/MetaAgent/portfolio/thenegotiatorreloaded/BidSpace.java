package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.analysis.BidPoint;
import negotiator.utility.UtilitySpace;

public class BidSpace
{
  UtilitySpace utilspaceA;
  UtilitySpace utilspaceB;
  Domain domain;
  public ArrayList<BidPoint> bidPoints;
  ArrayList<BidPoint> paretoFrontier = null;
  BidPoint kalaiSmorodinsky = null;
  BidPoint nash = null;
  
  public BidSpace(UtilitySpace spaceA, UtilitySpace spaceB)
    throws Exception
  {
    this.utilspaceA = spaceA;
    this.utilspaceB = spaceB;
    if ((this.utilspaceA == null) || (this.utilspaceB == null)) {
      throw new NullPointerException("util space is null");
    }
    this.domain = this.utilspaceA.getDomain();
    this.utilspaceA.checkReadyForNegotiation(this.domain);
    this.utilspaceB.checkReadyForNegotiation(this.domain);
    BuildSpace();
  }
  
  public BidSpace(UtilitySpace spaceA, UtilitySpace spaceB, boolean anything)
    throws Exception
  {
    this.utilspaceA = spaceA;
    this.utilspaceB = spaceB;
    if ((this.utilspaceA == null) || (this.utilspaceB == null)) {
      throw new NullPointerException("util space is null");
    }
    this.domain = this.utilspaceA.getDomain();
    this.utilspaceA.checkReadyForNegotiation(this.domain);
    BuildSpace();
  }
  
  void BuildSpace()
    throws Exception
  {
    this.bidPoints = new ArrayList();
    BidIterator lBidIter = new BidIterator(this.domain);
    while (lBidIter.hasNext())
    {
      Bid bid = lBidIter.next();
      this.bidPoints.add(new BidPoint(null, new Double[] { Double.valueOf(this.utilspaceA.getUtility(bid)), Double.valueOf(this.utilspaceB.getUtility(bid)) }));
    }
  }
  
  public ArrayList<BidPoint> getParetoFrontier()
    throws Exception
  {
    ArrayList<BidPoint> subPareto = new ArrayList();
    boolean bIsBidSpaceAvailable = true;
    if (this.bidPoints.size() < 1) {
      bIsBidSpaceAvailable = false;
    }
    if (this.paretoFrontier == null)
    {
      BidIterator lBidIter = new BidIterator(this.domain);
      int count = 0;
      ArrayList<BidPoint> tmpBidPoints;
      ArrayList<BidPoint> tmpBidPoints;
      if (bIsBidSpaceAvailable) {
        tmpBidPoints = new ArrayList(this.bidPoints);
      } else {
        tmpBidPoints = new ArrayList();
      }
      while (lBidIter.hasNext())
      {
        Bid bid = lBidIter.next();
        if (!bIsBidSpaceAvailable) {
          tmpBidPoints.add(new BidPoint(bid, new Double[] { Double.valueOf(this.utilspaceA.getUtility(bid)), Double.valueOf(this.utilspaceB.getUtility(bid)) }));
        }
        count++;
        if (count > 500000)
        {
          subPareto.addAll(computeParetoFrontier(tmpBidPoints));
          tmpBidPoints = new ArrayList();
          count = 0;
        }
      }
      if (tmpBidPoints.size() > 0) {
        subPareto.addAll(computeParetoFrontier(tmpBidPoints));
      }
      this.paretoFrontier = computeParetoFrontier(subPareto);
    }
    return this.paretoFrontier;
  }
  
  ArrayList<BidPoint> computeParetoFrontier(ArrayList<BidPoint> points)
    throws Exception
  {
    int n = points.size();
    if (n <= 1) {
      return points;
    }
    ArrayList<BidPoint> points1 = new ArrayList();
    ArrayList<BidPoint> points2 = new ArrayList();
    for (int i = 0; i < n / 2; i++) {
      points1.add(points.get(i));
    }
    for (int i = n / 2; i < n; i++) {
      points2.add(points.get(i));
    }
    ArrayList<BidPoint> pareto1 = computeParetoFrontier(points1);
    ArrayList<BidPoint> pareto2 = computeParetoFrontier(points2);
    return mergeParetoFrontiers(pareto1, pareto2);
  }
  
  public ArrayList<BidPoint> mergeParetoFrontiers(ArrayList<BidPoint> pareto1, ArrayList<BidPoint> pareto2)
  {
    if (pareto1.size() == 0) {
      return pareto2;
    }
    if (pareto2.size() == 0) {
      return pareto1;
    }
    ArrayList<BidPoint> list1 = (ArrayList)pareto1.clone();
    ArrayList<BidPoint> list2 = (ArrayList)pareto2.clone();
    if (((BidPoint)list1.get(0)).getUtilityA().doubleValue() > ((BidPoint)list2.get(0)).getUtilityA().doubleValue())
    {
      ArrayList<BidPoint> list3 = list1;list1 = list2;list2 = list3;
    }
    BidPoint firstpoint = (BidPoint)list1.remove(0);
    ArrayList<BidPoint> newpareto = mergeParetoFrontiers(list1, list2);
    if (firstpoint.getUtilityB().doubleValue() > ((BidPoint)list2.get(0)).getUtilityB().doubleValue()) {
      newpareto.add(0, firstpoint);
    }
    return newpareto;
  }
  
  public ArrayList<Bid> getParetoFrontierBids()
    throws Exception
  {
    ArrayList<Bid> bids = new ArrayList();
    ArrayList<BidPoint> points = getParetoFrontier();
    BidPoint p;
    for (Iterator i$ = points.iterator(); i$.hasNext(); bids.add(p.getBid())) {
      p = (BidPoint)i$.next();
    }
    return bids;
  }
  
  public BidPoint getKalaiSmorodinsky()
    throws Exception
  {
    if (this.kalaiSmorodinsky != null) {
      return this.kalaiSmorodinsky;
    }
    if (getParetoFrontier().size() < 1) {
      throw new Exception("kalaiSmorodinsky product: Pareto frontier is unavailable.");
    }
    double minassymetry = 2.0D;
    for (BidPoint p : this.paretoFrontier)
    {
      double asymofp = Math.abs(p.getUtilityA().doubleValue() - p.getUtilityB().doubleValue());
      if (asymofp < minassymetry)
      {
        this.kalaiSmorodinsky = p;minassymetry = asymofp;
      }
    }
    return this.kalaiSmorodinsky;
  }
  
  public BidPoint getNash()
    throws Exception
  {
    if (this.nash != null) {
      return this.nash;
    }
    if (getParetoFrontier().size() < 1) {
      throw new Exception("Nash product: Pareto frontier is unavailable.");
    }
    double maxp = -1.0D;
    double agentAresValue = 0.0D;double agentBresValue = 0.0D;
    if (this.utilspaceA.getReservationValue() != null) {
      agentAresValue = this.utilspaceA.getReservationValue().doubleValue();
    }
    if (this.utilspaceB.getReservationValue() != null) {
      agentBresValue = this.utilspaceB.getReservationValue().doubleValue();
    }
    for (BidPoint p : this.paretoFrontier)
    {
      double utilofp = (p.getUtilityA().doubleValue() - agentAresValue) * (p.getUtilityB().doubleValue() - agentBresValue);
      if (utilofp > maxp)
      {
        this.nash = p;maxp = utilofp;
      }
    }
    return this.nash;
  }
  
  public double OurUtilityOnPareto(double opponentUtility)
    throws Exception
  {
    if ((opponentUtility < 0.0D) || (opponentUtility > 1.0D)) {
      throw new Exception("opponentUtil " + opponentUtility + " is out of [0,1].");
    }
    ArrayList<BidPoint> pareto = getParetoFrontier();
    if (((BidPoint)pareto.get(0)).getUtilityB().doubleValue() < 1.0D) {
      pareto.add(0, new BidPoint(null, new Double[] { Double.valueOf(0.0D), Double.valueOf(1.0D) }));
    }
    if (((BidPoint)pareto.get(pareto.size() - 1)).getUtilityB().doubleValue() > 0.0D) {
      pareto.add(new BidPoint(null, new Double[] { Double.valueOf(1.0D), Double.valueOf(0.0D) }));
    }
    if (pareto.size() < 2) {
      throw new Exception("Pareto has only 1 point?!" + pareto);
    }
    int i = 0;
    while ((((BidPoint)pareto.get(i)).getUtilityB().doubleValue() < opponentUtility) || (opponentUtility < ((BidPoint)pareto.get(i + 1)).getUtilityB().doubleValue())) {
      i++;
    }
    double oppUtil1 = ((BidPoint)pareto.get(i)).getUtilityB().doubleValue();
    double oppUtil2 = ((BidPoint)pareto.get(i + 1)).getUtilityB().doubleValue();
    double f = (opponentUtility - oppUtil1) / (oppUtil2 - oppUtil1);
    
    double lininterpol = (1.0D - f) * ((BidPoint)pareto.get(i)).getUtilityA().doubleValue() + f * ((BidPoint)pareto.get(i + 1)).getUtilityA().doubleValue();
    return lininterpol;
  }
  
  public String toString()
  {
    return this.bidPoints.toString();
  }
  
  public BidPoint NearestBidPoint(double utilA, double utilB, double weightA, double weightB, ArrayList<Bid> excludeList)
  {
    System.out.println("determining nearest bid to " + utilA + "," + utilB);
    
    double mindist = 9.0D;
    BidPoint bestPoint = null;
    for (BidPoint p : this.bidPoints)
    {
      boolean contains = false;
      if (!contains)
      {
        double r = weightA * sq(p.getUtilityA().doubleValue() - utilA) + weightB * sq(p.getUtilityB().doubleValue() - utilB);
        if (r < mindist)
        {
          mindist = r;bestPoint = p;
        }
      }
    }
    System.out.println("point found: (" + bestPoint.getUtilityA() + ", " + bestPoint.getUtilityB() + ") =" + bestPoint.getBid());
    


    return bestPoint;
  }
  
  public double sq(double x)
  {
    return x * x;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BidSpace
 * JD-Core Version:    0.7.1
 */