package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.Comparator;

public class BidDetailsSorterUtility
  implements Comparator<BidDetails>
{
  public int compare(BidDetails b1, BidDetails b2)
  {
    if ((b1 == null) || (b2 == null)) {
      throw new NullPointerException();
    }
    if (b1.equals(b2)) {
      return 0;
    }
    if (b1.getMyUndiscountedUtil() > b2.getMyUndiscountedUtil()) {
      return -1;
    }
    if (b1.getMyUndiscountedUtil() < b2.getMyUndiscountedUtil()) {
      return 1;
    }
    return Integer.valueOf(b1.hashCode()).compareTo(Integer.valueOf(b2.hashCode()));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BidDetailsSorterUtility
 * JD-Core Version:    0.7.1
 */