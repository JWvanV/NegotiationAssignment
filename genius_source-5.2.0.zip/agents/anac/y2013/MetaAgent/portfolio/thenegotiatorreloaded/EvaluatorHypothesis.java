package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.utility.Evaluator;

public class EvaluatorHypothesis
  extends Hypothesis
{
  private String fDesc;
  private Evaluator fEval;
  
  public EvaluatorHypothesis(Evaluator pEval)
  {
    this.fEval = pEval;
  }
  
  public Evaluator getEvaluator()
  {
    return this.fEval;
  }
  
  public String toString()
  {
    String lResult = "";
    lResult = lResult + this.fDesc;
    return lResult;
  }
  
  public void setDesc(String pValue)
  {
    this.fDesc = pValue;
  }
  
  public String getDesc()
  {
    return this.fDesc;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.EvaluatorHypothesis
 * JD-Core Version:    0.7.1
 */