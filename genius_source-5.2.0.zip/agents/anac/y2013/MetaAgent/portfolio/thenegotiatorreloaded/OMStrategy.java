package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.HashMap;
import java.util.List;

public abstract class OMStrategy
{
  protected NegotiationSession negotiationSession;
  protected OpponentModel model;
  private final double RANGE_INCREMENT = 0.05D;
  private final int EXPECTED_BIDS_IN_WINDOW = 25;
  
  public void init(NegotiationSession negotiationSession, OpponentModel model, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.model = model;
  }
  
  public void init(NegotiationSession negotiationSession, OpponentModel model)
  {
    this.negotiationSession = negotiationSession;
    this.model = model;
  }
  
  public abstract BidDetails getBid(List<BidDetails> paramList);
  
  public BidDetails getBid(OutcomeSpace space, Range range)
  {
    List<BidDetails> bids = space.getBidsinRange(range);
    if (bids.size() == 0)
    {
      if (range.getUpperbound() < 1.1D)
      {
        range.increaseUpperbound(0.05D);
        return getBid(space, range);
      }
      this.negotiationSession.setOutcomeSpace(space);
      return this.negotiationSession.getMaxBidinDomain();
    }
    return getBid(bids);
  }
  
  public BidDetails getBid(OutcomeSpace space, double targetUtility)
  {
    Range range = new Range(targetUtility, targetUtility + 0.02D);
    List<BidDetails> bids = space.getBidsinRange(range);
    if (bids.size() < 25)
    {
      if (range.getUpperbound() < 1.01D)
      {
        range.increaseUpperbound(0.05D);
        return getBid(space, range);
      }
      return getBid(bids);
    }
    return getBid(bids);
  }
  
  public abstract boolean canUpdateOM();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.OMStrategy
 * JD-Core Version:    0.7.1
 */