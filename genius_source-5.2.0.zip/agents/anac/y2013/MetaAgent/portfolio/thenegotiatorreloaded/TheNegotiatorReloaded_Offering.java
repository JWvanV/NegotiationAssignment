package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.HashMap;
import negotiator.utility.UtilitySpace;

public class TheNegotiatorReloaded_Offering
  extends OfferingStrategy
{
  private TimeManager timeManager;
  private double kalaiPoint;
  private TimeDependentFunction TDTFunction;
  private StrategyTypes opponentStrategy;
  private DiscountTypes discountType;
  private double reservationValue;
  public TheNegotiatorReloaded_Offering() {}
  
  public static enum DiscountTypes
  {
    High,  Medium,  Low;
    
    private DiscountTypes() {}
  }
  
  private double maxBidTarget = 1.0D;
  private double minBidTarget = 0.7D;
  private static int WINDOWS = 60;
  private double discount;
  
  public TheNegotiatorReloaded_Offering(NegotiationSession negoSession, OpponentModel model, OMStrategy oms)
    throws Exception
  {
    init(negoSession, model, oms, null);
  }
  
  public void init(NegotiationSession negoSession, OpponentModel model, OMStrategy oms, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negoSession;
    this.opponentModel = model;
    this.omStrategy = oms;
    
    this.timeManager = new TimeManager(negoSession, this.opponentModel, oms, WINDOWS);
    this.TDTFunction = new TimeDependentFunction(negoSession);
    
    this.discount = negoSession.getDiscountFactor();
    this.discountType = getDiscountType(this.discount);
    if (this.discount > 0.001D)
    {
      this.minBidTarget = Math.max(0.4D, this.discount * 0.7D);
      this.opponentStrategy = StrategyTypes.Hardliner;
    }
    else
    {
      this.minBidTarget = 0.7D;
      this.opponentStrategy = StrategyTypes.Conceder;
    }
    Double rv = negoSession.getUtilitySpace().getReservationValue();
    this.reservationValue = 0.0D;
    if (rv != null) {
      this.reservationValue = negoSession.getUtilitySpace().getReservationValue().doubleValue();
    }
    this.kalaiPoint = 0.7D;
  }
  
  private DiscountTypes getDiscountType(double discount)
  {
    DiscountTypes type;
    DiscountTypes type;
    if ((discount < 0.0001D) || (discount >= 0.85D))
    {
      type = DiscountTypes.Low;
    }
    else
    {
      DiscountTypes type;
      if (discount <= 0.4D) {
        type = DiscountTypes.High;
      } else {
        type = DiscountTypes.Medium;
      }
    }
    return type;
  }
  
  public BidDetails determineOpeningBid()
  {
    return this.negotiationSession.getMaxBidinDomain();
  }
  
  public BidDetails determineNextBid()
  {
    if (this.timeManager.checkEndOfWindow())
    {
      this.kalaiPoint = this.timeManager.getKalai();
      this.opponentStrategy = this.timeManager.getOpponentStrategy();
      if (this.discount > 0.0001D) {
        this.kalaiPoint = (this.discount * this.kalaiPoint);
      }
      this.minBidTarget = Math.max(this.reservationValue, this.kalaiPoint);
      this.maxBidTarget = 1.0D;
      if (this.maxBidTarget < this.minBidTarget) {
        this.maxBidTarget = (this.minBidTarget + 0.05D);
      }
    }
    switch (this.opponentStrategy)
    {
    case Conceder: 
      if (this.discountType.equals(DiscountTypes.High)) {
        this.nextBid = this.TDTFunction.getNextBid(1.7D, 0.0D, this.minBidTarget, this.maxBidTarget);
      } else if (this.discountType.equals(DiscountTypes.Medium)) {
        this.nextBid = this.TDTFunction.getNextBid(0.8D, 0.0D, this.minBidTarget, this.maxBidTarget);
      } else {
        this.nextBid = this.TDTFunction.getNextBid(0.05D, 0.0D, this.minBidTarget, this.maxBidTarget);
      }
      break;
    case Hardliner: 
      if (this.discountType.equals(DiscountTypes.High)) {
        this.nextBid = this.TDTFunction.getNextBid(1.9D, 0.0D, this.minBidTarget, this.maxBidTarget);
      } else if (this.discountType.equals(DiscountTypes.Medium)) {
        this.nextBid = this.TDTFunction.getNextBid(1.2D, 0.0D, this.minBidTarget, this.maxBidTarget);
      } else {
        this.nextBid = this.TDTFunction.getNextBid(0.05D, 0.0D, this.minBidTarget, this.maxBidTarget);
      }
      break;
    }
    return this.nextBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TheNegotiatorReloaded_Offering
 * JD-Core Version:    0.7.1
 */