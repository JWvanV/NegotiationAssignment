package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public abstract class ConcessionFunction
{
  public abstract double getConcession(double paramDouble1, double paramDouble2, double paramDouble3);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.ConcessionFunction
 * JD-Core Version:    0.7.1
 */