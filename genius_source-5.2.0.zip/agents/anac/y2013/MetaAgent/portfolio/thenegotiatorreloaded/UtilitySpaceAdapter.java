package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.io.PrintStream;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.utility.UtilitySpace;

public class UtilitySpaceAdapter
  extends UtilitySpace
{
  private OpponentModel opponentModel;
  
  public UtilitySpaceAdapter(OpponentModel opponentModel, Domain domain)
  {
    this.opponentModel = opponentModel;
    this.domain = domain;
  }
  
  public double getUtility(Bid b)
  {
    double u = 0.0D;
    try
    {
      u = this.opponentModel.getBidEvaluation(b);
    }
    catch (Exception e)
    {
      e.printStackTrace();
      System.out.println("getNormalizedUtility failed. returning 0");u = 0.0D;
    }
    return u;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.UtilitySpaceAdapter
 * JD-Core Version:    0.7.1
 */