package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.HashMap;
import negotiator.Bid;
import negotiator.protocol.BilateralAtomicNegotiationSession;
import negotiator.utility.UtilitySpace;

public abstract class OpponentModel
{
  protected NegotiationSession negotiationSession;
  protected UtilitySpace opponentUtilitySpace;
  private boolean cleared;
  
  public void init(NegotiationSession domainKnow, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = domainKnow;
    this.opponentUtilitySpace = new UtilitySpace(domainKnow.getUtilitySpace());
    this.cleared = false;
  }
  
  public void init(NegotiationSession domainKnow)
  {
    this.negotiationSession = domainKnow;
    this.opponentUtilitySpace = new UtilitySpace(domainKnow.getUtilitySpace());
  }
  
  public abstract void updateModel(Bid paramBid);
  
  public double getBidEvaluation(Bid b)
  {
    try
    {
      return this.opponentUtilitySpace.getUtility(b);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return -1.0D;
  }
  
  public double getDiscountedBidEvaluation(Bid b, double time)
  {
    return this.opponentUtilitySpace.getUtilityWithDiscount(b, time);
  }
  
  public UtilitySpace getOpponentUtilitySpace()
  {
    return this.opponentUtilitySpace;
  }
  
  public void setOpponentUtilitySpace(BilateralAtomicNegotiationSession fNegotiation) {}
  
  public void cleanUp()
  {
    this.negotiationSession = null;
    this.cleared = true;
  }
  
  public boolean isCleared()
  {
    return this.cleared;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.OpponentModel
 * JD-Core Version:    0.7.1
 */