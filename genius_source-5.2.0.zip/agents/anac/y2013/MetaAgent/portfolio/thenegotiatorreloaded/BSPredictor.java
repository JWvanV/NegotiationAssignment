package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public class BSPredictor
{
  private NegotiationSession negoSession;
  private double numberOfWindows;
  private double beginWindowTime = 0.0D;
  private BidDetails prevBidUtilInWindow;
  private final double TOTAL_EXPECTED_CONCESSION = 1.0D;
  
  public BSPredictor(NegotiationSession negoSession, int numberOfWindows)
  {
    this.negoSession = negoSession;
    this.numberOfWindows = numberOfWindows;
  }
  
  public StrategyTypes calculateOpponentStrategy()
  {
    StrategyTypes opponentStrategy = null;
    double endWindowTime = this.negoSession.getOpponentBidHistory().getLastBidDetails().getTime();
    BidHistory bidsInWindow = this.negoSession.getOpponentBidHistory().filterBetweenTime(this.beginWindowTime, endWindowTime);
    BidDetails bestBidUtilInWindow = bidsInWindow.getBestBidDetails();
    if (bestBidUtilInWindow == null) {
      return StrategyTypes.Hardliner;
    }
    double concession;
    double concession;
    if (this.prevBidUtilInWindow == null) {
      concession = 1.0D - bestBidUtilInWindow.getMyUndiscountedUtil();
    } else {
      concession = bestBidUtilInWindow.getMyUndiscountedUtil() - this.prevBidUtilInWindow.getMyUndiscountedUtil();
    }
    double concessionThreshold = 1.0D / this.numberOfWindows / 2.0D;
    if (concession <= concessionThreshold) {
      opponentStrategy = StrategyTypes.Hardliner;
    } else {
      opponentStrategy = StrategyTypes.Conceder;
    }
    this.prevBidUtilInWindow = bestBidUtilInWindow;
    this.beginWindowTime = endWindowTime;
    
    return opponentStrategy;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BSPredictor
 * JD-Core Version:    0.7.1
 */