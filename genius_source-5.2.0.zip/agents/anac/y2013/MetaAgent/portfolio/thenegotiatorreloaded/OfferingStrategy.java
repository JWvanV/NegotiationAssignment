package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.HashMap;

public abstract class OfferingStrategy
{
  protected BidDetails nextBid;
  protected NegotiationSession negotiationSession;
  protected OpponentModel opponentModel;
  protected OMStrategy omStrategy;
  protected SharedAgentState helper;
  
  public void init(NegotiationSession negotiationSession, OpponentModel opponentModel, OMStrategy omStrategy, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.opponentModel = opponentModel;
    this.omStrategy = omStrategy;
  }
  
  public abstract BidDetails determineOpeningBid();
  
  public abstract BidDetails determineNextBid();
  
  public BidDetails getNextBid()
  {
    return this.nextBid;
  }
  
  public void setNextBid(BidDetails counterBid)
  {
    this.nextBid = counterBid;
  }
  
  public SharedAgentState getHelper()
  {
    return this.helper;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.OfferingStrategy
 * JD-Core Version:    0.7.1
 */