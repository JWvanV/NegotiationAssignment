package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public class TimeDependentFunction
{
  private NegotiationSession negoSession;
  private double e;
  private double k;
  private double Pmin;
  private double Pmax;
  private double utilityGoal = 1.0D;
  
  public TimeDependentFunction(NegotiationSession negoSession)
    throws Exception
  {
    this.negoSession = negoSession;
    SortedOutcomeSpace space = new SortedOutcomeSpace(negoSession.getUtilitySpace());
    negoSession.setOutcomeSpace(space);
  }
  
  public BidDetails getNextBid(double e, double k, double min, double max)
  {
    this.e = e;
    this.k = k;
    this.Pmin = min;
    this.Pmax = max;
    
    double time = this.negoSession.getTime();
    
    this.utilityGoal = p(time);
    
    return this.negoSession.getOutcomeSpace().getBidNearUtility(this.utilityGoal);
  }
  
  public double f(double t)
  {
    double ft = this.k + (1.0D - this.k) * Math.pow(t, 1.0D / this.e);
    return ft;
  }
  
  public double p(double t)
  {
    return this.Pmin + (this.Pmax - this.Pmin) * (1.0D - f(t));
  }
  
  public double getTargetUtility()
  {
    return this.utilityGoal;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TimeDependentFunction
 * JD-Core Version:    0.7.1
 */