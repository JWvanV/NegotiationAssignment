package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.issue.Issue;
import negotiator.utility.UtilitySpace;

public class NegotiationSession
{
  protected OutcomeSpace outcomeSpace;
  protected BidHistory opponentBidHistory;
  protected BidHistory ownBidHistory;
  protected Domain domain;
  protected UtilitySpace utilitySpace;
  protected Timeline timeline;
  
  public NegotiationSession(UtilitySpace utilitySpace, Timeline timeline)
  {
    this.utilitySpace = utilitySpace;
    this.timeline = timeline;
    this.domain = utilitySpace.getDomain();
    this.opponentBidHistory = new BidHistory();
    this.ownBidHistory = new BidHistory();
  }
  
  public BidHistory getOpponentBidHistory()
  {
    return this.opponentBidHistory;
  }
  
  public BidHistory getOwnBidHistory()
  {
    return this.ownBidHistory;
  }
  
  public double getDiscountFactor()
  {
    return this.utilitySpace.getDiscountFactor();
  }
  
  public ArrayList<Issue> getIssues()
  {
    return this.domain.getIssues();
  }
  
  public Timeline getTimeline()
  {
    return this.timeline;
  }
  
  public double getTime()
  {
    return this.timeline.getTime();
  }
  
  public UtilitySpace getUtilitySpace()
  {
    return this.utilitySpace;
  }
  
  public OutcomeSpace getOutcomeSpace()
  {
    return this.outcomeSpace;
  }
  
  public void setOutcomeSpace(OutcomeSpace space)
  {
    this.outcomeSpace = space;
  }
  
  public BidDetails getMaxBidinDomain()
  {
    BidDetails maxBid = null;
    if (this.outcomeSpace == null) {
      try
      {
        Bid maximumBid = this.utilitySpace.getMaxUtilityBid();
        maxBid = new BidDetails(maximumBid, this.utilitySpace.getUtility(maximumBid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    } else {
      maxBid = this.outcomeSpace.getMaxBidPossible();
    }
    return maxBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.NegotiationSession
 * JD-Core Version:    0.7.1
 */