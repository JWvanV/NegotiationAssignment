package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.Timeline;

public class TimeManager
{
  private NegotiationSession negoSession;
  private DomainAnalyzer domainAnalyzer;
  private BSPredictor bsPredictor;
  private double windowInterval;
  private int currentWindow;
  private double kalai;
  private StrategyTypes opponentStrategy;
  
  public TimeManager(NegotiationSession negoSession, OpponentModel opponentModel, OMStrategy omStrategy, int numberOfWindows)
  {
    this.negoSession = negoSession;
    this.domainAnalyzer = new DomainAnalyzer(negoSession.getUtilitySpace(), opponentModel, omStrategy);
    this.bsPredictor = new BSPredictor(negoSession, numberOfWindows);
    this.windowInterval = (negoSession.getTimeline().getTotalTime() / numberOfWindows);
    this.currentWindow = 0;
  }
  
  public boolean checkEndOfWindow()
  {
    if (Math.floor(this.negoSession.getTime() * 180.0D / this.windowInterval) != this.currentWindow)
    {
      this.kalai = this.domainAnalyzer.calculateKalaiPoint();
      this.opponentStrategy = this.bsPredictor.calculateOpponentStrategy();
      this.currentWindow += 1;
      return true;
    }
    return false;
  }
  
  public double getKalai()
  {
    return this.kalai;
  }
  
  public StrategyTypes getOpponentStrategy()
  {
    return this.opponentStrategy;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TimeManager
 * JD-Core Version:    0.7.1
 */