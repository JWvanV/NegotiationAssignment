package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public class WeightHypothesis
  extends Hypothesis
{
  double weight;
  
  public void setWeight(double weight)
  {
    this.weight = weight;
  }
  
  public double getWeight()
  {
    return this.weight;
  }
  
  public String toString()
  {
    return String.format("%1.2f", new Object[] { Double.valueOf(this.weight) }) + ";";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.WeightHypothesis
 * JD-Core Version:    0.7.1
 */