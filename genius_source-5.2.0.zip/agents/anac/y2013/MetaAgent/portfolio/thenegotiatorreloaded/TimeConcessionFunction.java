package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

public class TimeConcessionFunction
  extends ConcessionFunction
{
  private double beta;
  private double breakoff;
  public static final double BREAKOFF = 0.0D;
  public static final double DEFAULT_BREAKOFF = 0.5D;
  
  public TimeConcessionFunction(double beta, double breakoff)
  {
    this.beta = beta;
    this.breakoff = breakoff;
  }
  
  public double getConcession(double startUtility, double currentTime, double totalTime)
  {
    return startUtility - (startUtility - this.breakoff) * Math.pow(currentTime / totalTime, 1.0D / this.beta);
  }
  
  public class Beta
  {
    public static final double CONCEDER_EXTREME = 5.0D;
    public static final double CONCEDER = 2.0D;
    public static final double LINEAR = 1.0D;
    public static final double BOULWARE = 0.5D;
    public static final double BOULWARE_EXTREME = 0.2D;
    
    public Beta() {}
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TimeConcessionFunction
 * JD-Core Version:    0.7.1
 */