package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;

public class BidIterator
  implements Iterator<Bid>
{
  protected Domain fDomain;
  protected int fNumberOfIssues;
  protected int[] fValuesIndexes;
  protected boolean fInit;
  
  public BidIterator(Domain pDomain)
  {
    this.fDomain = pDomain;
    this.fInit = true;
    this.fNumberOfIssues = this.fDomain.getIssues().size();
    this.fValuesIndexes = new int[this.fNumberOfIssues];
  }
  
  public boolean hasNext()
  {
    int[] lNextIndexes = makeNextIndexes();
    boolean result = false;
    if (this.fInit) {
      return true;
    }
    for (int i = 0; i < this.fNumberOfIssues; i++) {
      if (lNextIndexes[i] != 0)
      {
        result = true;
        break;
      }
    }
    return result;
  }
  
  private int[] makeNextIndexes()
  {
    int[] lNewIndexes = new int[this.fNumberOfIssues];
    for (int i = 0; i < this.fNumberOfIssues; i++) {
      lNewIndexes[i] = this.fValuesIndexes[i];
    }
    ArrayList<Issue> lIssues = this.fDomain.getIssues();
    for (int i = 0; i < this.fNumberOfIssues; i++)
    {
      Issue lIssue = (Issue)lIssues.get(i);
      
      int lNumberOfValues = 0;
      switch (lIssue.getType())
      {
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        lNumberOfValues = lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound() + 1;
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        lNumberOfValues = lIssueReal.getNumberOfDiscretizationSteps();
        break;
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        lNumberOfValues = lIssueDiscrete.getNumberOfValues();
      }
      if (lNewIndexes[i] < lNumberOfValues - 1)
      {
        lNewIndexes[i] += 1;
        break;
      }
      lNewIndexes[i] = 0;
    }
    return lNewIndexes;
  }
  
  public Bid next()
  {
    Bid lBid = null;
    int[] lNextIndexes = makeNextIndexes();
    if (this.fInit) {
      this.fInit = false;
    } else {
      this.fValuesIndexes = lNextIndexes;
    }
    try
    {
      HashMap<Integer, Value> lValues = new HashMap();
      ArrayList<Issue> lIssues = this.fDomain.getIssues();
      for (int i = 0; i < this.fNumberOfIssues; i++)
      {
        Issue lIssue = (Issue)lIssues.get(i);
        switch (lIssue.getType())
        {
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          lValues.put(Integer.valueOf(lIssue.getNumber()), new ValueInteger(lIssueInteger
            .getLowerBound() + this.fValuesIndexes[i]));
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / (lIssueReal.getNumberOfDiscretizationSteps() - 1);
          lValues.put(Integer.valueOf(lIssue.getNumber()), new ValueReal(lIssueReal.getLowerBound() + lOneStep * this.fValuesIndexes[i]));
          break;
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          lValues.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(this.fValuesIndexes[i]));
        }
      }
      lBid = new Bid(this.fDomain, lValues);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return lBid;
  }
  
  public void remove() {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.BidIterator
 * JD-Core Version:    0.7.1
 */