package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import negotiator.Domain;
import negotiator.utility.UtilitySpace;

public class TheNegotiatorReloaded
  extends BOAagent
{
  public void agentSetup()
  {
    try
    {
      if (this.negotiationSession.getUtilitySpace().getDomain().getNumberOfPossibleBids() < 200000L) {
        this.opponentModel = new IAMhagglerModel();
      } else {
        this.opponentModel = new NullModel();
      }
      this.opponentModel.init(this.negotiationSession, null);
      this.omStrategy = new NullStrategy(this.negotiationSession, 0.35D);
      this.offeringStrategy = new TheNegotiatorReloaded_Offering(this.negotiationSession, this.opponentModel, this.omStrategy);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.acceptConditions = new AC_TheNegotiatorReloaded(this.negotiationSession, this.offeringStrategy, 1.0D, 0.0D, 1.05D, 0.0D, 0.98D, 0.99D);
  }
  
  public String getName()
  {
    return "TheNegotiator Reloaded";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TheNegotiatorReloaded
 * JD-Core Version:    0.7.1
 */