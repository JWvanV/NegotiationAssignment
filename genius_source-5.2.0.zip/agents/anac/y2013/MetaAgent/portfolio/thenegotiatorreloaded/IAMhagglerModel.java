package agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Objective;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.EVALFUNCTYPE;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class IAMhagglerModel
  extends OpponentModel
{
  private ArrayList<Bid> biddingHistory;
  private ArrayList<ArrayList<EvaluatorHypothesis>> evaluatorHypotheses;
  private ArrayList<ArrayList<WeightHypothesis>> weightHypotheses;
  private double previousBidUtility;
  private Double maxUtility;
  private Double minUtility;
  private double[] expectedWeights;
  private double SIGMA;
  private final int totalTriangularFunctions = 4;
  private TimeConcessionFunction opponentConcessionFunction;
  private Domain domain;
  private UtilitySpace utilitySpace;
  private boolean useAll;
  
  public IAMhagglerModel()
  {
    this.SIGMA = 0.25D;
    this.totalTriangularFunctions = 4;
    


    this.useAll = true;
  }
  
  public void init(NegotiationSession negotiationSession, HashMap<String, Double> parameters)
    throws Exception
  {
    this.negotiationSession = negotiationSession;
    this.opponentConcessionFunction = new TimeConcessionFunction(0.3D, 0.0D);
    this.previousBidUtility = 1.0D;
    this.weightHypotheses = new ArrayList();
    this.evaluatorHypotheses = new ArrayList();
    this.domain = negotiationSession.getUtilitySpace().getDomain();
    this.utilitySpace = negotiationSession.getUtilitySpace();
    this.expectedWeights = new double[this.domain.getIssues().size()];
    this.biddingHistory = new ArrayList();
    
    initWeightHypotheses();
    initEvaluatorHypotheses();
  }
  
  private void initWeightHypotheses()
  {
    int weightHypothesesNumber = 11;
    for (int i = 0; i < this.domain.getIssues().size(); i++)
    {
      ArrayList<WeightHypothesis> weightHypothesis = new ArrayList();
      for (int j = 0; j < weightHypothesesNumber; j++)
      {
        WeightHypothesis weight = new WeightHypothesis();
        weight.setProbability((1.0D - (j + 1.0D) / weightHypothesesNumber) * (1.0D - (j + 1.0D) / weightHypothesesNumber) * (1.0D - (j + 1.0D) / weightHypothesesNumber));
        
        weight.setWeight(j / (weightHypothesesNumber - 1));
        weightHypothesis.add(weight);
      }
      double n = 0.0D;
      for (int j = 0; j < weightHypothesesNumber; j++) {
        n += ((WeightHypothesis)weightHypothesis.get(j)).getProbability();
      }
      for (int j = 0; j < weightHypothesesNumber; j++) {
        ((WeightHypothesis)weightHypothesis.get(j)).setProbability(((WeightHypothesis)weightHypothesis.get(j)).getProbability() / n);
      }
      this.weightHypotheses.add(weightHypothesis);
    }
  }
  
  private void initEvaluatorHypotheses()
  {
    this.evaluatorHypotheses = new ArrayList();
    for (int i = 0; i < this.utilitySpace.getNrOfEvaluators(); i++) {
      switch (this.utilitySpace.getEvaluator(this.utilitySpace.getIssue(i).getNumber()).getType())
      {
      case REAL: 
        ArrayList<EvaluatorHypothesis> lEvalHyps = new ArrayList();
        this.evaluatorHypotheses.add(lEvalHyps);
        
        IssueReal lIssue = (IssueReal)this.utilitySpace.getIssue(i);
        

        EvaluatorReal lHypEvalReal = new EvaluatorReal();
        lHypEvalReal.setUpperBound(lIssue.getUpperBound());
        lHypEvalReal.setLowerBound(lIssue.getLowerBound());
        lHypEvalReal.setType(EVALFUNCTYPE.LINEAR);
        lHypEvalReal.addParam(1, 1.0D / (lHypEvalReal.getUpperBound() - lHypEvalReal.getLowerBound()));
        lHypEvalReal.addParam(0, -lHypEvalReal.getLowerBound() / (lHypEvalReal.getUpperBound() - lHypEvalReal.getLowerBound()));
        EvaluatorHypothesis lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEvalReal);
        lEvaluatorHypothesis.setDesc("uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        for (int k = 1; k <= 4; k++)
        {
          lHypEvalReal = new EvaluatorReal();
          lHypEvalReal.setUpperBound(lIssue.getUpperBound());
          lHypEvalReal.setLowerBound(lIssue.getLowerBound());
          lHypEvalReal.setType(EVALFUNCTYPE.TRIANGULAR);
          lHypEvalReal.addParam(0, lHypEvalReal.getLowerBound());
          lHypEvalReal.addParam(1, lHypEvalReal.getUpperBound());
          double lMaxPoint = lHypEvalReal.getLowerBound() + k * (lHypEvalReal.getUpperBound() - lHypEvalReal.getLowerBound()) / 5.0D;
          
          lHypEvalReal.addParam(2, lMaxPoint);
          lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEvalReal);
          lEvalHyps.add(lEvaluatorHypothesis);
          lEvaluatorHypothesis.setDesc("triangular " + String.format("%1.2f", new Object[] { Double.valueOf(lMaxPoint) }));
        }
        lHypEvalReal = new EvaluatorReal();
        lHypEvalReal.setUpperBound(lIssue.getUpperBound());
        lHypEvalReal.setLowerBound(lIssue.getLowerBound());
        lHypEvalReal.setType(EVALFUNCTYPE.LINEAR);
        lHypEvalReal.addParam(1, -1.0D / (lHypEvalReal.getUpperBound() - lHypEvalReal.getLowerBound()));
        lHypEvalReal.addParam(0, 1.0D + lHypEvalReal.getLowerBound() / (lHypEvalReal.getUpperBound() - lHypEvalReal.getLowerBound()));
        lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEvalReal);
        lEvaluatorHypothesis.setDesc("downhill");
        lEvalHyps.add(lEvaluatorHypothesis);
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
        break;
      case INTEGER: 
        ArrayList<EvaluatorHypothesis> lEvalHyps = new ArrayList();
        this.evaluatorHypotheses.add(lEvalHyps);
        
        IssueInteger lIssue = (IssueInteger)this.utilitySpace.getIssue(i);
        

        EvaluatorInteger lHypEvalInteger = new EvaluatorInteger();
        lHypEvalInteger.setUpperBound(lIssue.getUpperBound());
        lHypEvalInteger.setLowerBound(lIssue.getLowerBound());
        lHypEvalInteger.setConstantParam(-lHypEvalInteger.getLowerBound() / (lHypEvalInteger.getUpperBound() - lHypEvalInteger.getLowerBound()));
        lHypEvalInteger.setLinearParam(1.0D / (lHypEvalInteger.getUpperBound() - lHypEvalInteger.getLowerBound()));
        EvaluatorHypothesis lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEvalInteger);
        lEvaluatorHypothesis.setDesc("uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        

        lHypEvalInteger = new EvaluatorInteger();
        lHypEvalInteger.setUpperBound(lIssue.getUpperBound());
        lHypEvalInteger.setLowerBound(lIssue.getLowerBound());
        lHypEvalInteger.setConstantParam(1.0D + lHypEvalInteger.getLowerBound() / (lHypEvalInteger.getUpperBound() - lHypEvalInteger.getLowerBound()));
        lHypEvalInteger.setLinearParam(-1.0D / (lHypEvalInteger.getUpperBound() - lHypEvalInteger.getLowerBound()));
        lEvaluatorHypothesis = new EvaluatorHypothesis(lHypEvalInteger);
        lEvaluatorHypothesis.setDesc("downhill");
        lEvalHyps.add(lEvaluatorHypothesis);
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
        break;
      case DISCRETE: 
        ArrayList<EvaluatorHypothesis> lEvalHyps = new ArrayList();
        this.evaluatorHypotheses.add(lEvalHyps);
        
        IssueDiscrete lDiscIssue = (IssueDiscrete)this.utilitySpace.getIssue(i);
        

        EvaluatorDiscrete lDiscreteEval = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j + 1));
        }
        EvaluatorHypothesis lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
        lEvaluatorHypothesis.setDesc("uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        if (lDiscIssue.getNumberOfValues() > 2) {
          for (int k = 1; k < lDiscIssue.getNumberOfValues() - 1; k++)
          {
            lDiscreteEval = new EvaluatorDiscrete();
            for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
              if (j < k) {
                lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j / k));
              } else {
                lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1 / (lDiscIssue
                  .getNumberOfValues() - k - 1) + 1)));
              }
            }
            lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
            lEvalHyps.add(lEvaluatorHypothesis);
            lEvaluatorHypothesis.setDesc("triangular " + String.valueOf(k));
          }
        }
        lDiscreteEval = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEval.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1) + 1));
        }
        lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEval);
        lEvaluatorHypothesis.setDesc("downhill");
        lEvalHyps.add(lEvaluatorHypothesis);
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
      }
    }
    for (int i = 0; i < this.expectedWeights.length; i++) {
      this.expectedWeights[i] = getExpectedWeight(i);
    }
    normalize(this.expectedWeights);
  }
  
  public double getBidEvaluation(Bid bid)
  {
    try
    {
      return getNormalizedUtility(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  public double getNormalizedUtility(Bid bid)
    throws Exception
  {
    return getNormalizedUtility(bid, false);
  }
  
  public double getNormalizedUtility(Bid bid, boolean debug)
    throws Exception
  {
    double u = getExpectedUtility(bid);
    if ((this.minUtility == null) || (this.maxUtility == null)) {
      findMinMaxUtility();
    }
    return (u - this.minUtility.doubleValue()) / (this.maxUtility.doubleValue() - this.minUtility.doubleValue());
  }
  
  public double getExpectedUtility(Bid bid)
    throws Exception
  {
    double u = 0.0D;
    for (int i = 0; i < this.domain.getIssues().size(); i++) {
      u += this.expectedWeights[i] * getExpectedEvaluationValue(bid, i);
    }
    return u;
  }
  
  public void updateModel(Bid opponentBid)
  {
    if ((!this.useAll) && 
      (this.biddingHistory.contains(opponentBid))) {
      return;
    }
    this.biddingHistory.add(opponentBid);
    if (this.biddingHistory.size() > 1) {
      try
      {
        updateWeights();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    try
    {
      updateEvaluationFunctions();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.previousBidUtility = this.opponentConcessionFunction.getConcession(1.0D, this.negotiationSession.getTime(), 1.0D);
    for (int i = 0; i < this.expectedWeights.length; i++) {
      this.expectedWeights[i] = getExpectedWeight(i);
    }
    normalize(this.expectedWeights);
    try
    {
      findMinMaxUtility();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private void normalize(double[] array)
  {
    double n = 0.0D;
    for (int i = 0; i < array.length; i++) {
      n += array[i];
    }
    if (n == 0.0D)
    {
      for (int i = 0; i < array.length; i++) {
        array[i] = (1.0D / array.length);
      }
      return;
    }
    for (int i = 0; i < array.length; i++) {
      array[i] /= n;
    }
  }
  
  protected void findMinMaxUtility()
    throws Exception
  {
    this.maxUtility = Double.valueOf(getExtremeUtility(Extreme.MAX));
    this.minUtility = Double.valueOf(getExtremeUtility(Extreme.MIN));
  }
  
  public static enum Extreme
  {
    MIN,  MAX;
    
    private Extreme() {}
  }
  
  private double getExtremeUtility(Extreme extreme)
  {
    double u = 0.0D;
    for (int i = 0; i < this.domain.getIssues().size(); i++) {
      u += this.expectedWeights[i] * getExtremeEvaluationValue(i, extreme);
    }
    return u;
  }
  
  private double getExtremeEvaluationValue(int number, Extreme extreme)
  {
    double expectedEval = 0.0D;
    for (EvaluatorHypothesis evaluatorHypothesis : (ArrayList)this.evaluatorHypotheses.get(number)) {
      expectedEval = expectedEval + evaluatorHypothesis.getProbability() * getExtremeEvaluation(evaluatorHypothesis.getEvaluator(), extreme);
    }
    return expectedEval;
  }
  
  public double getExtremeEvaluation(Evaluator evaluator, Extreme extreme)
  {
    double extremeEval = initExtreme(extreme);
    EvaluatorDiscrete discreteEvaluator;
    switch (evaluator.getType())
    {
    case DISCRETE: 
      discreteEvaluator = (EvaluatorDiscrete)evaluator;
      for (ValueDiscrete value : discreteEvaluator.getValues()) {
        try
        {
          switch (extreme)
          {
          case MAX: 
            extremeEval = Math.max(extremeEval, discreteEvaluator.getEvaluation(value).doubleValue());
            break;
          case MIN: 
            extremeEval = Math.min(extremeEval, discreteEvaluator.getEvaluation(value).doubleValue());
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
      break;
    case INTEGER: 
      EvaluatorInteger integerEvaluator = (EvaluatorInteger)evaluator;
      switch (extreme)
      {
      case MAX: 
        extremeEval = Math.max(integerEvaluator.getEvaluation(integerEvaluator.getUpperBound()).doubleValue(), integerEvaluator.getEvaluation(integerEvaluator.getLowerBound()).doubleValue());
        



        break;
      case MIN: 
        extremeEval = Math.min(integerEvaluator.getEvaluation(integerEvaluator.getUpperBound()).doubleValue(), integerEvaluator.getEvaluation(integerEvaluator.getLowerBound()).doubleValue());
      }
      break;
    case REAL: 
      EvaluatorReal realEvaluator = (EvaluatorReal)evaluator;
      switch (extreme)
      {
      case MAX: 
        extremeEval = Math.max(realEvaluator.getEvaluation(realEvaluator.getUpperBound()).doubleValue(), realEvaluator.getEvaluation(realEvaluator.getLowerBound()).doubleValue());
        if (realEvaluator.getFuncType() == EVALFUNCTYPE.TRIANGULAR) {
          extremeEval = Math.max(extremeEval, realEvaluator.getEvaluation(realEvaluator.getTopParam()).doubleValue());
        }
        break;
      case MIN: 
        extremeEval = Math.min(realEvaluator.getEvaluation(realEvaluator.getUpperBound()).doubleValue(), realEvaluator.getEvaluation(realEvaluator.getLowerBound()).doubleValue());
        if (realEvaluator.getFuncType() == EVALFUNCTYPE.TRIANGULAR) {
          extremeEval = Math.min(extremeEval, realEvaluator.getEvaluation(realEvaluator.getTopParam()).doubleValue());
        }
        break;
      }
      break;
    }
    return extremeEval;
  }
  
  private double initExtreme(Extreme extreme)
  {
    switch (extreme)
    {
    case MAX: 
      return Double.MIN_NORMAL;
    case MIN: 
      return Double.MAX_VALUE;
    }
    return 0.0D;
  }
  
  private void updateEvaluationFunctions()
    throws Exception
  {
    this.maxUtility = null;
    this.minUtility = null;
    
    Bid bid = (Bid)this.biddingHistory.get(this.biddingHistory.size() - 1);
    ArrayList<ArrayList<EvaluatorHypothesis>> evaluatorHypotheses = new ArrayList();
    for (int i = 0; i < this.evaluatorHypotheses.size(); i++)
    {
      ArrayList<EvaluatorHypothesis> tmp = new ArrayList();
      for (int j = 0; j < ((ArrayList)this.evaluatorHypotheses.get(i)).size(); j++)
      {
        EvaluatorHypothesis evaluatorHypothesis = new EvaluatorHypothesis(((EvaluatorHypothesis)((ArrayList)this.evaluatorHypotheses.get(i)).get(j)).getEvaluator());
        evaluatorHypothesis.setDesc(((EvaluatorHypothesis)((ArrayList)this.evaluatorHypotheses.get(i)).get(j)).getDesc());
        evaluatorHypothesis.setProbability(((EvaluatorHypothesis)((ArrayList)this.evaluatorHypotheses.get(i)).get(j)).getProbability());
        tmp.add(evaluatorHypothesis);
      }
      evaluatorHypotheses.add(tmp);
    }
    double n;
    double utility;
    for (int i = 0; i < this.domain.getIssues().size(); i++)
    {
      n = 0.0D;
      utility = 0.0D;
      for (EvaluatorHypothesis evaluatorHypothesis : (ArrayList)evaluatorHypotheses.get(i))
      {
        utility = getPartialUtility(bid, i) + getExpectedWeight(i) * evaluatorHypothesis.getEvaluator().getEvaluation(this.utilitySpace, bid, this.utilitySpace.getIssue(i).getNumber()).doubleValue();
        n += evaluatorHypothesis.getProbability() * conditionalDistribution(utility, this.previousBidUtility);
      }
      for (EvaluatorHypothesis evaluatorHypothesis : (ArrayList)evaluatorHypotheses.get(i))
      {
        utility = getPartialUtility(bid, i) + getExpectedWeight(i) * evaluatorHypothesis.getEvaluator().getEvaluation(this.utilitySpace, bid, this.utilitySpace.getIssue(i).getNumber()).doubleValue();
        evaluatorHypothesis.setProbability(evaluatorHypothesis.getProbability() * conditionalDistribution(utility, this.previousBidUtility) / n);
      }
    }
    this.evaluatorHypotheses = evaluatorHypotheses;
  }
  
  private void updateWeights()
    throws Exception
  {
    this.maxUtility = null;
    this.minUtility = null;
    
    Bid bid = (Bid)this.biddingHistory.get(this.biddingHistory.size() - 1);
    ArrayList<ArrayList<WeightHypothesis>> weightHypotheses = new ArrayList();
    for (int i = 0; i < this.weightHypotheses.size(); i++)
    {
      ArrayList<WeightHypothesis> tmp = new ArrayList();
      for (int j = 0; j < ((ArrayList)this.weightHypotheses.get(i)).size(); j++)
      {
        WeightHypothesis weightHypothesis = new WeightHypothesis();
        weightHypothesis.setWeight(((WeightHypothesis)((ArrayList)this.weightHypotheses.get(i)).get(j)).getWeight());
        weightHypothesis.setProbability(((WeightHypothesis)((ArrayList)this.weightHypotheses.get(i)).get(j)).getProbability());
        tmp.add(weightHypothesis);
      }
      weightHypotheses.add(tmp);
    }
    double n;
    double utility;
    for (int i = 0; i < this.domain.getIssues().size(); i++)
    {
      n = 0.0D;
      utility = 0.0D;
      for (WeightHypothesis weightHypothesis : (ArrayList)weightHypotheses.get(i))
      {
        utility = getPartialUtility(bid, i) + weightHypothesis.getWeight() * getExpectedEvaluationValue(bid, i);
        n += weightHypothesis.getProbability() * conditionalDistribution(utility, this.previousBidUtility);
      }
      for (WeightHypothesis weightHypothesis : (ArrayList)weightHypotheses.get(i))
      {
        utility = getPartialUtility(bid, i) + weightHypothesis.getWeight() * getExpectedEvaluationValue(bid, i);
        weightHypothesis.setProbability(weightHypothesis.getProbability() * conditionalDistribution(utility, this.previousBidUtility) / n);
      }
    }
    this.weightHypotheses = weightHypotheses;
  }
  
  private double conditionalDistribution(double utility, double previousBidUtility)
  {
    double x = (previousBidUtility - utility) / previousBidUtility;
    return 1.0D / (this.SIGMA * Math.sqrt(6.283185307179586D)) * Math.exp(-(x * x) / (2.0D * this.SIGMA * this.SIGMA));
  }
  
  private double getExpectedEvaluationValue(Bid bid, int number)
    throws Exception
  {
    double expectedEval = 0.0D;
    for (EvaluatorHypothesis evaluatorHypothesis : (ArrayList)this.evaluatorHypotheses.get(number)) {
      expectedEval = expectedEval + evaluatorHypothesis.getProbability() * evaluatorHypothesis.getEvaluator().getEvaluation(this.utilitySpace, bid, this.utilitySpace.getIssue(number).getNumber()).doubleValue();
    }
    return expectedEval;
  }
  
  private double getPartialUtility(Bid bid, int number)
    throws Exception
  {
    double u = 0.0D;
    for (int i = 0; i < this.domain.getIssues().size(); i++) {
      if (number != i)
      {
        double w = 0.0D;
        for (WeightHypothesis weightHypothesis : (ArrayList)this.weightHypotheses.get(i)) {
          w += weightHypothesis.getProbability() * weightHypothesis.getWeight();
        }
        u += w * getExpectedEvaluationValue(bid, i);
      }
    }
    return u;
  }
  
  public double getExpectedWeight(int number)
  {
    double expectedWeight = 0.0D;
    for (WeightHypothesis weightHypothesis : (ArrayList)this.weightHypotheses.get(number)) {
      expectedWeight += weightHypothesis.getProbability() * weightHypothesis.getWeight();
    }
    return expectedWeight;
  }
  
  public EvaluatorHypothesis getBestHypothesis(int issue)
  {
    double maxEvaluatorProbability = -1.0D;
    EvaluatorHypothesis bestEvaluatorHypothesis = null;
    for (EvaluatorHypothesis evaluatorHypothesis : (ArrayList)this.evaluatorHypotheses.get(issue)) {
      if (evaluatorHypothesis.getProbability() > maxEvaluatorProbability)
      {
        maxEvaluatorProbability = evaluatorHypothesis.getProbability();
        bestEvaluatorHypothesis = evaluatorHypothesis;
      }
    }
    return bestEvaluatorHypothesis;
  }
  
  public Hypothesis getHypothesis(int index)
  {
    return (Hypothesis)((ArrayList)this.evaluatorHypotheses.get(index)).get(index);
  }
  
  public UtilitySpace getOpponentUtilitySpace()
  {
    return new UtilitySpaceAdapter(this, this.domain);
  }
  
  public void cleanUp()
  {
    super.cleanUp();
    this.biddingHistory = null;
    this.evaluatorHypotheses = null;
    this.weightHypotheses = null;
    this.expectedWeights = null;
    this.opponentConcessionFunction = null;
    this.domain = null;
    this.utilitySpace = null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.IAMhagglerModel
 * JD-Core Version:    0.7.1
 */