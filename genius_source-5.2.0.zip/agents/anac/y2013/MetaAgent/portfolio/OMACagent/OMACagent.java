package agents.anac.y2013.MetaAgent.portfolio.OMACagent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class OMACagent
  extends Agent
{
  private Action actionOfPartner = null;
  private double MINIMUM_UTILITY = 0.59D;
  private double resU = 0.0D;
  private double EU = 0.95D;
  private double est_t = 0.0D;
  private double est_u = 0.0D;
  private TimeBidHistory mBidHistory;
  public int intervals = 100;
  public double timeInt = 1.0D / this.intervals;
  public double discount = 1.0D;
  private Bid maxBid = null;
  private double maxBidU = 0.0D;
  public double cTime = 0.0D;
  private int tCount = 0;
  private double nextUti = 0.96D;
  public int numberOfIssues = 0;
  public double discountThreshold = 0.845D;
  public int lenA = 0;
  public double exma;
  public double est_mu;
  public double est_mt;
  public boolean debug = false;
  public boolean detail = false;
  private double maxTime = 180.0D;
  
  public void init()
  {
    if (this.utilitySpace.getReservationValue() != null)
    {
      this.resU = this.utilitySpace.getReservationValue().doubleValue();
      if (this.MINIMUM_UTILITY < this.resU) {
        this.MINIMUM_UTILITY = (this.resU * 1.06D);
      }
    }
    if ((this.utilitySpace.getDiscountFactor() <= 1.0D) && 
      (this.utilitySpace.getDiscountFactor() > 0.0D)) {
      this.discount = this.utilitySpace.getDiscountFactor();
    }
    this.numberOfIssues = this.utilitySpace.getDomain().getIssues().size();
    try
    {
      this.maxBid = this.utilitySpace.getMaxUtilityBid();
      this.maxBidU = this.utilitySpace.getUtility(this.maxBid);
      this.EU *= this.maxBidU;
    }
    catch (Exception e) {}
    this.mBidHistory = new TimeBidHistory(this.utilitySpace, this.discount);
  }
  
  public String getVersion()
  {
    return "1.06";
  }
  
  public String getName()
  {
    return "OMAC_sp2012b";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseBidAction();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        this.cTime = this.timeline.getTime();
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        double offeredUtilFromOpponent = getUtility(partnerBid);
        this.mBidHistory.addOpponentBidnTime(offeredUtilFromOpponent, partnerBid, this.cTime);
        if (this.discount < this.discountThreshold)
        {
          if (this.mBidHistory.isInsideMyBids(partnerBid)) {
            return new Accept(getAgentID());
          }
        }
        else if ((this.cTime > 0.97D) && 
          (this.mBidHistory.isInsideMyBids(partnerBid))) {
          return new Accept(getAgentID());
        }
        action = chooseBidAction();
        Bid myBid = ((Offer)action).getBid();
        double myOfferedUtil = getUtility(myBid);
        if (isAcceptable(offeredUtilFromOpponent, myOfferedUtil, this.cTime, partnerBid)) {
          action = new Accept(getAgentID());
        }
      }
    }
    catch (Exception e)
    {
      if (this.resU != 0.0D) {
        action = new EndNegotiation();
      } else {
        action = new Accept(getAgentID());
      }
    }
    return action;
  }
  
  private boolean isAcceptable(double offeredUtilFromOpponent, double myOfferedUtil, double time, Bid oppBid)
    throws Exception
  {
    if (offeredUtilFromOpponent >= myOfferedUtil) {
      return true;
    }
    return false;
  }
  
  private Action chooseBidAction()
  {
    Bid nextBid = null;
    try
    {
      if (this.cTime <= 0.02D) {
        nextBid = this.maxBid;
      } else {
        nextBid = getFinalBid();
      }
    }
    catch (Exception e) {}
    if (nextBid == null) {
      return new EndNegotiation();
    }
    this.mBidHistory.addMyBid(nextBid);
    
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid getFinalBid()
  {
    Bid bid = null;
    double upper = 1.01D;
    double lower = 0.99D;
    double splitFactor = 3.0D;
    double val = 0.0D;
    double dval = 0.0D;
    int delay = 75;
    double laTime = 0.0D;
    double adp = 1.2D;
    if (this.discount >= this.discountThreshold)
    {
      if (this.cTime <= delay / 100.0D)
      {
        if (this.resU <= 0.3D) {
          return this.maxBid;
        }
        val = this.EU;
        

        dval = val * Math.pow(this.discount, this.cTime);
        bid = genRanBid(val * lower, val * upper);
        
        return bid;
      }
      if (this.cTime > 0.01D * (this.tCount + delay))
      {
        this.nextUti = getNextUti();
        this.tCount += 1;
      }
    }
    else
    {
      if (this.cTime <= this.discount / splitFactor)
      {
        if (this.resU <= 0.3D) {
          return this.maxBid;
        }
        val = this.EU;
        

        dval = val * Math.pow(this.discount, this.cTime);
        bid = genRanBid(val * 0.98D, val * 1.02D);
        
        return bid;
      }
      if (this.cTime > 0.01D * (this.tCount + (int)Math.floor(this.discount / splitFactor * 100.0D)))
      {
        this.nextUti = getNextUti();
        this.tCount += 1;
      }
    }
    if (this.nextUti == -3.0D)
    {
      if (this.resU <= 0.3D) {
        return this.maxBid;
      }
      val = this.EU;
    }
    else if (this.nextUti == -2.0D)
    {
      val = this.est_mu + (this.cTime - this.est_mt) * (this.est_u - this.est_mu) / (this.est_t - this.est_mt);
    }
    else if (this.nextUti == -1.0D)
    {
      val = getOriU(this.cTime);
    }
    laTime = this.mBidHistory.getMCtime() * this.maxTime;
    if ((this.cTime * this.maxTime - laTime > 1.5D) || (this.cTime > 0.995D))
    {
      dval = val * Math.pow(this.discount, this.cTime);
      bid = genRanBid(dval * lower, dval * upper);
    }
    else if (val * lower * adp >= this.maxBidU)
    {
      bid = this.maxBid;
    }
    else
    {
      dval = adp * val * Math.pow(this.discount, this.cTime);
      bid = genRanBid(dval * lower, dval * upper);
    }
    if (bid == null) {
      bid = this.mBidHistory.getMyLastBid();
    }
    if (getUtility(this.mBidHistory.bestOppBid) >= getUtility(bid)) {
      return this.mBidHistory.bestOppBid;
    }
    if (this.cTime > 0.999D) {
      if (getUtility(this.mBidHistory.bestOppBid) > this.MINIMUM_UTILITY * Math.pow(this.discount, this.cTime)) {
        return this.mBidHistory.bestOppBid;
      }
    }
    return bid;
  }
  
  private double getOriU(double t)
  {
    double exp = 1.0D;
    double maxUtil = this.maxBidU;
    double minUtil = 0.69D;
    if (minUtil < this.MINIMUM_UTILITY) {
      minUtil = this.MINIMUM_UTILITY * 1.05D;
    }
    double e1 = 0.033D;
    double e2 = 0.04D;
    double time = t;
    double tMax = this.maxBidU;
    double tMin = this.MINIMUM_UTILITY * 1.05D;
    if (this.discount >= this.discountThreshold)
    {
      exp = minUtil + (1.0D - Math.pow(time, 1.0D / e1)) * (maxUtil - minUtil);
    }
    else
    {
      tMax = Math.pow(this.discount, 0.2D);
      exp = tMin + (1.0D - Math.pow(time, 1.0D / e2)) * (tMax - tMin);
    }
    return exp;
  }
  
  private double getPre()
  {
    int len = 3;
    double[] pmaxList = this.mBidHistory.getTimeBlockList();
    int lenA = (int)Math.floor(this.cTime * 100.0D);
    if (lenA < len) {
      return -1.0D;
    }
    double[] maxList = new double[lenA];
    double[] ma = new double[lenA];
    double[] res = new double[lenA];
    double exma = 0.0D;
    for (int i = 0; i < lenA; i++) {
      maxList[i] = pmaxList[i];
    }
    for (int i = 0; i < len - 1; i++) {
      ma[i] = 0.0D;
    }
    for (int i = len - 1; i < lenA; i++) {
      ma[i] = ((maxList[i] + maxList[(i - 1)] + maxList[(i - 2)]) / 3.0D);
    }
    for (int i = 0; i < lenA; i++) {
      maxList[i] -= ma[i];
    }
    exma = ma[(lenA - 1)] + avg(res) + std(res) * (1.0D - Math.pow(maxList[(lenA - 1)], 4.0D)) * (1.3D + 0.66D * Math.pow(1.0D - this.cTime * this.cTime, 0.4D));
    
    return exma;
  }
  
  public static double sum(double[] arr)
  {
    double sum = 0.0D;
    int len = arr.length;
    for (int i = 0; i < len; i++) {
      sum += arr[i];
    }
    return sum;
  }
  
  public static double avg(double[] arr)
  {
    double avg = 0.0D;
    int len = arr.length;
    avg = sum(arr) / len;
    return avg;
  }
  
  public static double std(double[] arr)
  {
    double std = 0.0D;
    int len = arr.length;
    double ssum = 0.0D;
    for (int i = 0; i < len; i++) {
      ssum += arr[i] * arr[i];
    }
    std = len / (len - 1.0D) * (ssum / len - Math.pow(avg(arr), 2.0D));
    return Math.sqrt(std);
  }
  
  private double getNextUti()
  {
    double utiO = getOriU(this.cTime + this.timeInt);
    this.exma = getPre();
    if (this.exma >= 1.0D) {
      return -3.0D;
    }
    if (this.exma > utiO)
    {
      this.est_t = (this.cTime + this.timeInt);
      this.est_u = this.exma;
      this.est_mu = getOriU(this.cTime);
      this.est_mt = this.cTime;
      return -2.0D;
    }
    return -1.0D;
  }
  
  private Bid genRanBid(double min, double max)
  {
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random randomnr = new Random();
    int counter = 0;
    int limit = 1000;
    double fmax = max;
    
    Bid bid = null;
    do
    {
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          int optionIndex = randomnr.nextInt(lIssueDiscrete
            .getNumberOfValues());
          values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete
            .getValue(optionIndex));
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int optionInd = randomnr.nextInt(lIssueReal
            .getNumberOfDiscretizationSteps() - 1);
          values.put(
            Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal
            .getLowerBound() + 
            
            (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal
            

            .getNumberOfDiscretizationSteps()));
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          
          int optionIndex2 = lIssueInteger.getLowerBound() + randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
            .getLowerBound());
          values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        }
      }
      try
      {
        bid = new Bid(this.utilitySpace.getDomain(), values);
      }
      catch (Exception e) {}
      counter++;
      if (counter > limit)
      {
        limit += 500;
        fmax += 0.005D;
      }
      if (counter > 4000) {
        return this.mBidHistory.getMyLastBid();
      }
    } while ((getUtility(bid) < min) || (getUtility(bid) > fmax));
    return bid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.OMACagent.OMACagent
 * JD-Core Version:    0.7.1
 */