package agents.anac.y2013.MetaAgent.portfolio.IAMhaggler2012.agents2011.southampton.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Random;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class RandomBidCreator
  implements BidCreator
{
  protected Random random;
  
  public RandomBidCreator()
  {
    this.random = new Random();
  }
  
  private Bid getRandomBid(UtilitySpace utilitySpace)
  {
    Domain domain = utilitySpace.getDomain();
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = domain.getIssues();
    Bid bid = null;
    for (Iterator<Issue> iterator = issues.iterator(); iterator.hasNext();)
    {
      Issue issue = (Issue)iterator.next();
      switch (issue.getType())
      {
      case DISCRETE: 
        generateValue(values, (IssueDiscrete)issue);
        break;
      case REAL: 
        generateValue(values, (IssueReal)issue);
        break;
      case INTEGER: 
        generateValue(values, (IssueInteger)issue);
      }
    }
    try
    {
      bid = new Bid(domain, values);
    }
    catch (Exception e) {}
    return bid;
  }
  
  protected void generateValue(HashMap<Integer, Value> values, IssueDiscrete issue)
  {
    int randomDiscrete = this.random.nextInt(issue.getNumberOfValues());
    values.put(Integer.valueOf(issue.getNumber()), issue.getValue(randomDiscrete));
  }
  
  protected void generateValue(HashMap<Integer, Value> values, IssueReal issue)
  {
    double randomReal = issue.getLowerBound() + this.random.nextDouble() * (issue.getUpperBound() - issue.getLowerBound());
    values.put(Integer.valueOf(issue.getNumber()), new ValueReal(randomReal));
  }
  
  protected void generateValue(HashMap<Integer, Value> values, IssueInteger issue)
  {
    int randomInteger = issue.getLowerBound() + this.random.nextInt(issue.getUpperBound() - issue.getLowerBound() + 1);
    values.put(Integer.valueOf(issue.getNumber()), new ValueInteger(randomInteger));
  }
  
  protected Bid getRandomBid(UtilitySpace utilitySpace, double min)
  {
    if (min > 1.0D) {
      return null;
    }
    int i = 0;
    for (;;)
    {
      Bid b = getRandomBid(utilitySpace);
      try
      {
        double util = utilitySpace.getUtility(b);
        if (util >= min) {
          return b;
        }
      }
      catch (Exception e) {}
      i++;
      if (i == 500)
      {
        min -= 0.01D;
        i = 0;
      }
    }
  }
  
  public Bid getRandomBid(UtilitySpace utilitySpace, double min, double max)
  {
    int i = 0;
    for (;;)
    {
      if (max >= 1.0D) {
        return getRandomBid(utilitySpace, min);
      }
      Bid b = getRandomBid(utilitySpace);
      try
      {
        double util = utilitySpace.getUtility(b);
        if ((util >= min) && (util <= max)) {
          return b;
        }
      }
      catch (Exception e) {}
      i++;
      if (i == 500)
      {
        max += 0.01D;
        i = 0;
      }
    }
  }
  
  public Bid getBid(UtilitySpace utilitySpace, double min, double max)
  {
    return getRandomBid(utilitySpace, min, max);
  }
  
  public Bid logBid(Bid opponentBid, double time)
  {
    return null;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.IAMhaggler2012.agents2011.southampton.utils.RandomBidCreator
 * JD-Core Version:    0.7.1
 */