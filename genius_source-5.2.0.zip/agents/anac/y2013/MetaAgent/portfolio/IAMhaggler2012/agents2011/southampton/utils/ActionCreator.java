package agents.anac.y2013.MetaAgent.portfolio.IAMhaggler2012.agents2011.southampton.utils;

import negotiator.Agent;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;

public class ActionCreator
{
  public static Action createOffer(Agent agent, Bid bid)
  {
    return new Offer(agent.getAgentID(), bid);
  }
  
  public static Action createAccept(Agent agent)
  {
    return new Accept(agent.getAgentID());
  }
  
  public static Action createEndNegotiation(Agent agent)
  {
    return new EndNegotiation(agent.getAgentID());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.IAMhaggler2012.agents2011.southampton.utils.ActionCreator
 * JD-Core Version:    0.7.1
 */