package agents.anac.y2013.MetaAgent.portfolio.BRAMAgent2;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class BRAMAgent2
  extends Agent
{
  private final double TIME_TO_CREATE_BIDS_ARRAY = 2.0D;
  private final double FREQUENCY_OF_PROPOSAL = 0.2D;
  private final double THRESHOLD_PERC_FLEXIBILITY_1 = 0.07000000000000001D;
  private final double THRESHOLD_PERC_FLEXIBILITY_2 = 0.15D;
  private final double THRESHOLD_PERC_FLEXIBILITY_3 = 0.3D;
  private final double THRESHOLD_PERC_FLEXIBILITY_4 = 0.6D;
  private final int OPPONENT_ARRAY_SIZE = 10;
  private Action actionOfPartner;
  private Bid bestBid;
  private double maxUtility;
  private ArrayList<Bid> ourBidsArray;
  private ArrayList<Bid> opponentBidsArray;
  private int lastPositionInBidArray;
  private int[] bidsCountProposalArray;
  private int numOfProposalsFromOurBidsArray;
  private double offeredUtility;
  private double threshold;
  private int randomInterval;
  private int randomOffset;
  private ArrayList<ArrayList<Integer>> opponentBidsStatisticsForReal;
  private ArrayList<HashMap<Value, Integer>> opponentBidsStatisticsDiscrete;
  private ArrayList<ArrayList<Integer>> opponentBidsStatisticsForInteger;
  private Bid previousOfferedBid;
  private Random random100;
  private Random random200;
  private Random random300;
  
  public void init()
  {
    this.actionOfPartner = null;
    this.ourBidsArray = new ArrayList();
    this.bidsCountProposalArray = null;
    this.lastPositionInBidArray = 0;
    this.numOfProposalsFromOurBidsArray = 0;
    this.randomInterval = 8;
    this.randomOffset = 4;
    this.opponentBidsArray = new ArrayList();
    initializeDataStructures();
    try
    {
      this.bestBid = this.utilitySpace.getMaxUtilityBid();
      this.maxUtility = this.utilitySpace.getUtilityWithDiscount(this.bestBid, this.timeline);
      this.ourBidsArray.add(this.bestBid);
      this.threshold = this.maxUtility;
      this.previousOfferedBid = this.bestBid;
      
      this.random100 = new Random(100L);
      this.random200 = new Random(200L);
      this.random300 = new Random(300L);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getName()
  {
    return "BRAMAgent 2";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    Bid bid2offer = new Bid();
    this.threshold = getNewThreshold();
    try
    {
      if (this.actionOfPartner == null)
      {
        bid2offer = this.utilitySpace.getMaxUtilityBid();
        action = new Offer(getAgentID(), bid2offer);
      }
      else if ((this.actionOfPartner instanceof Offer))
      {
        this.offeredUtility = this.utilitySpace.getUtilityWithDiscount(((Offer)this.actionOfPartner).getBid(), this.timeline);
        if (this.offeredUtility >= this.threshold)
        {
          action = new Accept(getAgentID());
        }
        else
        {
          Bid bidToRemove = null;
          Bid opponentBid = ((Offer)this.actionOfPartner).getBid();
          Bid bidToOffer = null;
          if (this.opponentBidsArray.size() < 10)
          {
            this.opponentBidsArray.add(opponentBid);
            updateStatistics(opponentBid, false);
            bidToOffer = this.bestBid;
          }
          else
          {
            bidToRemove = (Bid)this.opponentBidsArray.get(0);
            updateStatistics(bidToRemove, true);
            this.opponentBidsArray.remove(0);
            
            this.opponentBidsArray.add(opponentBid);
            updateStatistics(opponentBid, false);
            

            bidToOffer = getBidToOffer();
          }
          if (this.offeredUtility >= this.utilitySpace.getUtilityWithDiscount(bidToOffer, this.timeline)) {
            action = new Accept(getAgentID());
          } else if ((this.offeredUtility < this.utilitySpace.getReservationValueWithDiscount(this.timeline)) && (this.timeline.getTime() > 0.9833333333333333D) && (this.utilitySpace.getReservationValueWithDiscount(this.timeline) > this.utilitySpace.getUtilityWithDiscount(bidToOffer, this.timeline))) {
            action = new EndNegotiation(getAgentID());
          } else {
            action = new Offer(getAgentID(), bidToOffer);
          }
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
      if (this.actionOfPartner != null) {
        System.out.println("BRAMAgent accepted the offer beacuse of an exception");
      }
    }
    return action;
  }
  
  private void updateStatistics(Bid bidToUpdate, boolean toRemove)
  {
    try
    {
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      

      realIndex = 0;
      discreteIndex = 0;
      integerIndex = 0;
      for (Issue lIssue : issues)
      {
        int issueNum = lIssue.getNumber();
        Value v = bidToUpdate.getValue(issueNum);
        switch (lIssue.getType())
        {
        case DISCRETE: 
          if (this.opponentBidsStatisticsDiscrete == null)
          {
            System.out.println("opponentBidsStatisticsDiscrete is NULL");
          }
          else if (this.opponentBidsStatisticsDiscrete.get(discreteIndex) != null)
          {
            int counterPerValue = ((Integer)((HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex)).get(v)).intValue();
            if (toRemove) {
              counterPerValue--;
            } else {
              counterPerValue++;
            }
            ((HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex)).put(v, Integer.valueOf(counterPerValue));
          }
          discreteIndex++;
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int lNumOfPossibleRealValues = lIssueReal.getNumberOfDiscretizationSteps();
          double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNumOfPossibleRealValues;
          double first = lIssueReal.getLowerBound();
          double last = lIssueReal.getLowerBound() + lOneStep;
          double valueReal = ((ValueReal)v).getValue();
          boolean found = false;
          for (int i = 0; (!found) && (i < ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size()); i++)
          {
            if ((valueReal >= first) && (valueReal <= last))
            {
              int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(i)).intValue();
              if (toRemove) {
                countPerValue--;
              } else {
                countPerValue++;
              }
              ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).set(i, Integer.valueOf(countPerValue));
              found = true;
            }
            first = last;
            last += lOneStep;
          }
          if (!found)
          {
            int i = ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size() - 1;
            int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(i)).intValue();
            if (toRemove) {
              countPerValue--;
            } else {
              countPerValue++;
            }
            ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).set(i, Integer.valueOf(countPerValue));
          }
          realIndex++;
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          int valueInteger = ((ValueInteger)v).getValue();
          
          int valueIndex = valueInteger - lIssueInteger.getLowerBound();
          int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex)).get(valueIndex)).intValue();
          if (toRemove) {
            countPerValue--;
          } else {
            countPerValue++;
          }
          ((ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex)).set(valueIndex, Integer.valueOf(countPerValue));
          integerIndex++;
        }
      }
    }
    catch (Exception ex)
    {
      int realIndex;
      int discreteIndex;
      int integerIndex;
      System.out.println("BRAM - Exception in updateStatistics: " + toRemove);
    }
  }
  
  private double getNewThreshold()
  {
    double minUtil = this.utilitySpace.getUtilityWithDiscount((Bid)this.ourBidsArray.get(this.ourBidsArray.size() - 1), this.timeline);
    double maxUtil = this.utilitySpace.getUtilityWithDiscount(this.bestBid, this.timeline);
    double tresholdBestBidDiscount = 0.0D;
    if (this.timeline.getTime() < 0.3333333333333333D) {
      tresholdBestBidDiscount = maxUtil - (maxUtil - minUtil) * 0.07000000000000001D;
    } else if (this.timeline.getTime() < 0.8333333333333334D) {
      tresholdBestBidDiscount = maxUtil - (maxUtil - minUtil) * 0.15D;
    } else if (this.timeline.getTime() < 0.9722222222222222D) {
      tresholdBestBidDiscount = maxUtil - (maxUtil - minUtil) * 0.3D;
    } else {
      tresholdBestBidDiscount = maxUtil - (maxUtil - minUtil) * 0.6D;
    }
    return tresholdBestBidDiscount;
  }
  
  private Bid getBidToOffer()
  {
    Bid bidWithMaxUtility = null;
    try
    {
      double maxUt = this.threshold;
      for (int i = 0; i < 10; i++)
      {
        Bid currBid = createBidByOpponentModeling();
        if (currBid == null)
        {
          System.out.println(" BRAM - currBid in getBidToOffer is NULL");
        }
        else
        {
          double currUtility = this.utilitySpace.getUtilityWithDiscount(currBid, this.timeline);
          if (currUtility > maxUt)
          {
            maxUt = currUtility;
            bidWithMaxUtility = currBid;
          }
        }
      }
      if (bidWithMaxUtility == null) {
        return getBidFromBidsArray();
      }
      return bidWithMaxUtility;
    }
    catch (Exception e)
    {
      System.out.println("BRAM - Exception in GetBidToOffer function");
    }
    return bidWithMaxUtility;
  }
  
  private Bid getBidFromBidsArray()
  {
    if (this.ourBidsArray.size() == 1)
    {
      fillBidsArray(new Date().getTime());
      if (this.ourBidsArray.size() <= 50)
      {
        this.randomInterval = 3;
        this.randomOffset = 1;
      }
      initializeBidsFrequencyArray();
      Collections.sort(this.ourBidsArray, new Comparator()
      {
        public int compare(Bid bid1, Bid bid2)
        {
          double utility1 = 0.0D;
          double utility2 = 0.0D;
          try
          {
            utility1 = BRAMAgent2.this.utilitySpace.getUtility(bid1);
            utility2 = BRAMAgent2.this.utilitySpace.getUtility(bid2);
            if (utility1 > utility2) {
              return -1;
            }
            if (utility1 < utility2) {
              return 1;
            }
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
          return 0;
        }
      });
    }
    this.numOfProposalsFromOurBidsArray += 1;
    Bid bidToOffer = selectCurrentBidFromOurBidsArray();
    return bidToOffer;
  }
  
  private Bid createBidByOpponentModeling()
  {
    Bid bid = new Bid();
    try
    {
      valuesToOfferPerIssue = new HashMap();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      

      discreteIndex = 0;
      realIndex = 0;
      integerIndex = 0;
      for (Issue lIssue : issues)
      {
        int issueNum = lIssue.getNumber();
        int indx = this.random100.nextInt(10);
        int first = 0;
        int last = 0;
        switch (lIssue.getType())
        {
        case DISCRETE: 
          HashMap<Value, Integer> valuesHash = new HashMap();
          if (this.opponentBidsStatisticsDiscrete == null) {
            System.out.println("BRAM - opponentBidsStatisticsDiscrete IS NULL");
          }
          valuesHash = (HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex);
          for (Value v : valuesHash.keySet())
          {
            first = last;
            last = first + ((Integer)valuesHash.get(v)).intValue();
            if ((indx >= first) && (indx < last)) {
              valuesToOfferPerIssue.put(Integer.valueOf(issueNum), v);
            }
          }
          discreteIndex++;
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          ArrayList<Integer> valueList = (ArrayList)this.opponentBidsStatisticsForReal.get(realIndex);
          for (int i = 0; i < valueList.size(); i++)
          {
            first = last;
            last = first + ((Integer)valueList.get(i)).intValue();
            if ((indx >= first) && (indx <= last))
            {
              int lNrOfOptions = lIssueReal.getNumberOfDiscretizationSteps();
              double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNrOfOptions;
              double lowerBound = lIssueReal.getLowerBound();
              double realValueForBid = lowerBound + lOneStep * indx + this.random100.nextDouble() * lOneStep;
              ValueReal valueForBid = new ValueReal(realValueForBid);
              valuesToOfferPerIssue.put(Integer.valueOf(issueNum), valueForBid);
            }
          }
          realIndex++;
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          ArrayList<Integer> integerValueList = (ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex);
          for (int i = 0; i < integerValueList.size(); i++)
          {
            first = last;
            last = first + ((Integer)integerValueList.get(i)).intValue();
            if ((indx >= first) && (indx <= last))
            {
              int valuesLowerBound = lIssueInteger.getLowerBound();
              ValueInteger valueIntegerForBid = new ValueInteger(valuesLowerBound + i);
              valuesToOfferPerIssue.put(Integer.valueOf(issueNum), valueIntegerForBid);
            }
          }
          integerIndex++;
        }
        bid = new Bid(this.utilitySpace.getDomain(), valuesToOfferPerIssue);
      }
    }
    catch (Exception e)
    {
      HashMap<Integer, Value> valuesToOfferPerIssue;
      int discreteIndex;
      int realIndex;
      int integerIndex;
      System.out.println("BRAM - Exception in createBidByOpponentModeling function");
    }
    return bid;
  }
  
  private void initializeDataStructures()
  {
    try
    {
      this.opponentBidsStatisticsForReal = new ArrayList();
      this.opponentBidsStatisticsDiscrete = new ArrayList();
      this.opponentBidsStatisticsForInteger = new ArrayList();
      
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          HashMap<Value, Integer> discreteIssueValuesMap = new HashMap();
          for (int j = 0; j < lIssueDiscrete.getNumberOfValues(); j++)
          {
            Value v = lIssueDiscrete.getValue(j);
            discreteIssueValuesMap.put(v, Integer.valueOf(0));
          }
          this.opponentBidsStatisticsDiscrete.add(discreteIssueValuesMap);
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          ArrayList<Integer> numProposalsPerValue = new ArrayList();
          int lNumOfPossibleValuesInThisIssue = lIssueReal.getNumberOfDiscretizationSteps();
          for (int i = 0; i < lNumOfPossibleValuesInThisIssue; i++) {
            numProposalsPerValue.add(Integer.valueOf(0));
          }
          this.opponentBidsStatisticsForReal.add(numProposalsPerValue);
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          ArrayList<Integer> numOfValueProposals = new ArrayList();
          

          int lNumOfPossibleValuesForThisIssue = lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound() + 1;
          for (int i = 0; i < lNumOfPossibleValuesForThisIssue; i++) {
            numOfValueProposals.add(Integer.valueOf(0));
          }
          this.opponentBidsStatisticsForInteger.add(numOfValueProposals);
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("BRAM - EXCEPTION in initializeDataAtructures");
    }
  }
  
  private void fillBidsArray(double startTime)
  {
    int bidsMaxAmount = getBidMaxAmount();
    int countNewBids = 0;
    while ((new Date().getTime() - startTime < 2.0D) && (countNewBids < bidsMaxAmount)) {
      try
      {
        Bid newBid = getRandomBid();
        if (!this.ourBidsArray.contains(newBid))
        {
          countNewBids++;
          this.ourBidsArray.add(newBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  private int getBidMaxAmount()
  {
    int count = 1;
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int numOfValues = lIssueDiscrete.getNumberOfValues();
        count *= numOfValues;
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        count *= lIssueReal.getNumberOfDiscretizationSteps();
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        
        count *= (lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound() + 1);
      }
    }
    return count;
  }
  
  private Bid getRandomBid()
  {
    Bid bid = null;
    try
    {
      HashMap<Integer, Value> values = new HashMap();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          int optionIndex = this.random200.nextInt(lIssueDiscrete.getNumberOfValues());
          values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int lNrOfOptions = lIssueReal.getNumberOfDiscretizationSteps();
          double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNrOfOptions;
          int lOptionIndex = this.random200.nextInt(lNrOfOptions);
          if (lOptionIndex >= lNrOfOptions) {
            lOptionIndex = lNrOfOptions - 1;
          }
          ValueReal value = new ValueReal(lIssueReal.getLowerBound() + lOneStep * lOptionIndex + this.random200.nextDouble() * lOneStep);
          values.put(Integer.valueOf(lIssueReal.getNumber()), value);
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          
          int numOfPossibleIntVals = lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound();
          int randomIndex = this.random200.nextInt(numOfPossibleIntVals) + lIssueInteger.getLowerBound();
          ValueInteger randomValueInteger = new ValueInteger(randomIndex);
          values.put(Integer.valueOf(lIssue.getNumber()), randomValueInteger);
        }
      }
      bid = new Bid(this.utilitySpace.getDomain(), values);
    }
    catch (Exception ex)
    {
      System.out.println("BRAM - Exception in getRandomBid");
    }
    return bid;
  }
  
  private Bid selectCurrentBidFromOurBidsArray()
  {
    int rndNum = this.random300.nextInt(this.randomInterval) - this.randomOffset;
    int arraySize = this.ourBidsArray.size();
    int newIndex = 0;
    if (this.lastPositionInBidArray + rndNum < 0) {
      newIndex = 0;
    } else if (this.lastPositionInBidArray + rndNum > arraySize - 1) {
      newIndex = arraySize - 1;
    } else {
      newIndex = this.lastPositionInBidArray + rndNum;
    }
    while (this.bidsCountProposalArray[newIndex] / this.numOfProposalsFromOurBidsArray > 0.2D) {
      newIndex++;
    }
    Bid toSend = (Bid)this.ourBidsArray.get(newIndex);
    if (this.utilitySpace.getUtilityWithDiscount(toSend, this.timeline) < this.threshold)
    {
      toSend = this.previousOfferedBid;
      this.bidsCountProposalArray[this.lastPositionInBidArray] += 1;
    }
    else
    {
      this.previousOfferedBid = toSend;
      this.lastPositionInBidArray = newIndex;
      this.bidsCountProposalArray[newIndex] += 1;
    }
    return toSend;
  }
  
  private void initializeBidsFrequencyArray()
  {
    this.bidsCountProposalArray = new int[this.ourBidsArray.size()];
    for (int i = 0; i < this.bidsCountProposalArray.length; i++) {
      this.bidsCountProposalArray[i] = 0;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.BRAMAgent2.BRAMAgent2
 * JD-Core Version:    0.7.1
 */