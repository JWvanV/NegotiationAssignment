package agents.anac.y2013.MetaAgent.portfolio.AgentLG;

import java.util.HashMap;
import negotiator.issue.Issue;
import negotiator.issue.Value;

public class BidStatistic
{
  private HashMap<Value, Integer> valStatis = new HashMap();
  private Issue issue = null;
  private double numVotes = 0.0D;
  
  public BidStatistic(Issue issue)
  {
    this.issue = issue;
  }
  
  public void add(Value v)
  {
    if (this.valStatis.get(v) == null) {
      this.valStatis.put(v, Integer.valueOf(1));
    } else {
      this.valStatis.put(v, Integer.valueOf(((Integer)this.valStatis.get(v)).intValue() + 1));
    }
    this.numVotes += 1.0D;
  }
  
  public Value getMostBided()
  {
    Value maxval = null;
    Integer maxtimes = Integer.valueOf(0);
    for (Value val : this.valStatis.keySet()) {
      if (((Integer)this.valStatis.get(val)).intValue() > maxtimes.intValue())
      {
        maxtimes = (Integer)this.valStatis.get(val);
        maxval = val;
      }
    }
    return maxval;
  }
  
  public int getMostVotedCount()
  {
    Integer maxtimes = Integer.valueOf(0);
    for (Value val : this.valStatis.keySet()) {
      if (((Integer)this.valStatis.get(val)).intValue() > maxtimes.intValue()) {
        maxtimes = (Integer)this.valStatis.get(val);
      }
    }
    return maxtimes.intValue();
  }
  
  public double getValueUtility(Value value)
  {
    double ret = 0.0D;
    if (this.valStatis.get(value) != null) {
      ret = ((Integer)this.valStatis.get(value)).intValue() / getMostVotedCount();
    }
    return ret;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.AgentLG.BidStatistic
 * JD-Core Version:    0.7.1
 */