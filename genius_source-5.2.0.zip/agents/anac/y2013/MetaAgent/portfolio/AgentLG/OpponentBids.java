package agents.anac.y2013.MetaAgent.portfolio.AgentLG;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public class OpponentBids
{
  private ArrayList<Bid> oppBids = new ArrayList();
  private HashMap<Issue, BidStatistic> statistic = new HashMap();
  private Bid maxUtilityBidForMe = null;
  private UtilitySpace utilitySpace;
  
  public void addBid(Bid bid)
  {
    this.oppBids.add(bid);
    try
    {
      for (Issue issue : this.statistic.keySet())
      {
        Value v = bid.getValue(issue.getNumber());
        ((BidStatistic)this.statistic.get(issue)).add(v);
      }
      if (this.oppBids.size() == 1) {
        this.maxUtilityBidForMe = bid;
      } else if (this.utilitySpace.getUtility(this.maxUtilityBidForMe) < this.utilitySpace.getUtility(bid)) {
        this.maxUtilityBidForMe = bid;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public ArrayList<Bid> getOpponentsBids()
  {
    return this.oppBids;
  }
  
  public OpponentBids(UtilitySpace utilitySpace)
  {
    this.utilitySpace = utilitySpace;
    ArrayList<Issue> issues = utilitySpace.getDomain().getIssues();
    for (Issue issue : issues) {
      this.statistic.put(issue, new BidStatistic(issue));
    }
  }
  
  public Bid getMaxUtilityBidForMe()
  {
    return this.maxUtilityBidForMe;
  }
  
  public Value getMostVotedValueForIsuue(Issue issue)
  {
    return ((BidStatistic)this.statistic.get(issue)).getMostBided();
  }
  
  public double getOpponentBidUtility(Domain domain, Bid bid)
  {
    double ret = 0.0D;
    ArrayList<Issue> issues = domain.getIssues();
    for (Issue issue : issues) {
      try
      {
        ret += ((BidStatistic)this.statistic.get(issue)).getValueUtility(bid.getValue(issue.getNumber()));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    System.out.println(ret / domain.getIssues().size());
    return ret;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.AgentLG.OpponentBids
 * JD-Core Version:    0.7.1
 */