package agents.anac.y2013.MetaAgent.portfolio.AgentLG;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class BidChooser
{
  private UtilitySpace utilitySpace;
  private OpponentBids opponentBids;
  private ArrayList<Bid> allBids = null;
  private Bid maxLastOpponentBid;
  private int numPossibleBids = 0;
  private int index = 0;
  private double lastTimeLeft = 0.0D;
  private AgentID agentID;
  private int minSize = 160000;
  private Bid myBestBid = null;
  
  public BidChooser(UtilitySpace utilitySpace, AgentID agentID, OpponentBids OpponentBids)
  {
    this.utilitySpace = utilitySpace;
    this.agentID = agentID;
    this.opponentBids = OpponentBids;
  }
  
  private void initBids()
  {
    this.allBids = getAllBids();
    
    BidsComparator bidsComparator = new BidsComparator(this.utilitySpace);
    


    Collections.sort(this.allBids, bidsComparator);
  }
  
  public Action getNextBid(double time)
  {
    Action currentAction = null;
    try
    {
      Bid newBid = (Bid)this.allBids.get(this.index);
      currentAction = new Offer(this.agentID, newBid);
      this.index += 1;
      if (this.index > this.numPossibleBids) {
        if (time >= 0.9D)
        {
          if (time - this.lastTimeLeft > 0.008D)
          {
            double myBestUtility = this.utilitySpace.getUtility(this.myBestBid);
            double oppBestUtility = this.utilitySpace.getUtility((Bid)this.opponentBids.getOpponentsBids().get(0));
            double avg = (myBestUtility + oppBestUtility) / 2.0D;
            if (this.index >= this.allBids.size())
            {
              this.index = (this.allBids.size() - 1);
            }
            else if (this.utilitySpace.getUtility((Bid)this.allBids.get(this.index)) < avg)
            {
              this.index -= 1;
              double maxUtilty = 0.0D;
              int maxBidIndex = this.numPossibleBids;
              for (int i = this.numPossibleBids; i <= this.index; i++)
              {
                double utiliy = this.opponentBids.getOpponentBidUtility(this.utilitySpace.getDomain(), (Bid)this.allBids.get(i));
                if (utiliy > maxUtilty)
                {
                  maxUtilty = utiliy;
                  maxBidIndex = i;
                }
              }
              this.numPossibleBids = maxBidIndex;
            }
            else
            {
              this.index -= 1;
            }
          }
          else
          {
            this.index = 0;
          }
        }
        else
        {
          this.index = 0;
          double discount = this.utilitySpace.getDiscountFactor();
          if (time - this.lastTimeLeft > 0.05D) {
            if ((this.utilitySpace.getUtility(this.opponentBids.getMaxUtilityBidForMe()) > this.utilitySpace.getUtility(this.maxLastOpponentBid)) || ((discount > 0.0D) && (time - this.lastTimeLeft > 0.1D)))
            {
              double maxUtilty = 0.0D;
              for (int i = 0; i <= this.numPossibleBids; i++)
              {
                double utiliy = this.opponentBids.getOpponentBidUtility(this.utilitySpace.getDomain(), (Bid)this.allBids.get(i));
                System.out.println("UTILITY: " + utiliy);
                if (utiliy > maxUtilty) {
                  maxUtilty = utiliy;
                }
              }
              for (int i = this.numPossibleBids + 1; i < this.allBids.size(); i++)
              {
                double utiliy = this.opponentBids.getOpponentBidUtility(this.utilitySpace.getDomain(), (Bid)this.allBids.get(i));
                if (utiliy >= maxUtilty)
                {
                  this.numPossibleBids = i;
                  break;
                }
              }
              this.maxLastOpponentBid = this.opponentBids.getMaxUtilityBidForMe();
              this.lastTimeLeft = time;
            }
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return currentAction;
  }
  
  public Action getNextOptimicalBid(double time)
  {
    Action currentAction = null;
    Bid newBid = null;
    try
    {
      if (this.allBids == null) {
        initBids();
      }
      newBid = (Bid)this.allBids.get(this.index);
      currentAction = new Offer(this.agentID, newBid);
      this.index += 1;
      double myBestUtility = this.utilitySpace.getUtilityWithDiscount(this.myBestBid, time);
      double oppBestUtility = this.utilitySpace.getUtilityWithDiscount((Bid)this.opponentBids.getOpponentsBids().get(0), time);
      double downBond = myBestUtility - (myBestUtility - oppBestUtility) / 4.0D;
      if ((time - this.lastTimeLeft > 0.1D) && (this.numPossibleBids < this.allBids.size() - 1) && (downBond <= this.utilitySpace.getUtilityWithDiscount((Bid)this.allBids.get(this.numPossibleBids + 1), time)))
      {
        double futureUtility = this.utilitySpace.getUtilityWithDiscount((Bid)this.allBids.get(this.numPossibleBids), time + 0.1D);
        while ((this.utilitySpace.getUtilityWithDiscount((Bid)this.allBids.get(this.numPossibleBids), time) >= futureUtility) && (this.numPossibleBids < this.allBids.size() - 1)) {
          this.numPossibleBids += 1;
        }
        this.lastTimeLeft = time;
      }
      if (this.index > this.numPossibleBids) {
        this.index = 0;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.maxLastOpponentBid = this.opponentBids.getMaxUtilityBidForMe();
    return currentAction;
  }
  
  public Evaluator getMyEvaluator(int issueID)
  {
    return this.utilitySpace.getEvaluator(issueID);
  }
  
  private ArrayList<Bid> getAllBids()
  {
    ArrayList<Bid> bids = new ArrayList();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    

    HashMap<Integer, Value> issusesFirstValue = new HashMap();
    for (Issue issue : issues)
    {
      Value v = (Value)getIsuueValues(issue).get(0);
      issusesFirstValue.put(Integer.valueOf(issue.getNumber()), v);
    }
    try
    {
      bids.add(new Bid(this.utilitySpace.getDomain(), issusesFirstValue));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    for (Issue issue : issues)
    {
      ArrayList<Bid> tempBids = new ArrayList();
      ArrayList<Value> issueValues = getIsuueValues(issue);
      for (Iterator i$ = bids.iterator(); i$.hasNext();)
      {
        bid = (Bid)i$.next();
        for (Value value : issueValues)
        {
          HashMap<Integer, Value> lNewBidValues = getBidValues(bid);
          lNewBidValues.put(Integer.valueOf(issue.getNumber()), value);
          try
          {
            Bid newBid = new Bid(this.utilitySpace.getDomain(), lNewBidValues);
            tempBids.add(newBid);
          }
          catch (Exception e)
          {
            e.printStackTrace();
          }
        }
      }
      Bid bid;
      bids = tempBids;
    }
    double myBestUtility = 1.0D;
    double oppBestUtility = 0.0D;
    try
    {
      this.myBestBid = this.utilitySpace.getMaxUtilityBid();
      myBestUtility = this.utilitySpace.getUtility(this.myBestBid);
      oppBestUtility = this.utilitySpace.getUtility((Bid)this.opponentBids.getOpponentsBids().get(0));
    }
    catch (Exception e1)
    {
      e1.printStackTrace();
    }
    return filterBids(bids, myBestUtility, oppBestUtility, 0.75D);
  }
  
  private ArrayList<Bid> filterBids(ArrayList<Bid> bids, double myBestUtility, double oppBestUtility, double fraction)
  {
    double downBond = myBestUtility - (myBestUtility - oppBestUtility) * fraction;
    ArrayList<Bid> filteredBids = new ArrayList();
    for (Bid bid : bids) {
      try
      {
        double reservation = this.utilitySpace.getReservationValue() != null ? this.utilitySpace.getReservationValue().doubleValue() : 0.0D;
        if ((this.utilitySpace.getUtility(bid) < downBond) || (this.utilitySpace.getUtility(bid) >= reservation)) {
          filteredBids.add(bid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    if (filteredBids.size() < this.minSize) {
      return filteredBids;
    }
    return filterBids(filteredBids, myBestUtility, oppBestUtility, fraction * 0.85D);
  }
  
  private HashMap<Integer, Value> getBidValues(Bid bid)
  {
    HashMap<Integer, Value> bidValues = new HashMap();
    ArrayList<Issue> allIsuues = this.utilitySpace.getDomain().getIssues();
    for (Issue issue : allIsuues) {
      try
      {
        bidValues.put(Integer.valueOf(issue.getNumber()), bid.getValue(issue.getNumber()));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bidValues;
  }
  
  public ArrayList<Value> getIsuueValues(Issue issue)
  {
    Evaluator e = getMyEvaluator(issue.getNumber());
    ArrayList<Value> retValues = new ArrayList();
    switch (e.getType())
    {
    case DISCRETE: 
      EvaluatorDiscrete eD = (EvaluatorDiscrete)e;
      retValues.addAll(eD.getValues());
      break;
    case REAL: 
      EvaluatorReal eR = (EvaluatorReal)e;
      
      double intervalReal = (eR.getUpperBound() - eR.getLowerBound()) / 10.0D;
      for (int i = 0; i <= 10; i++) {
        retValues.add(new ValueReal(eR.getLowerBound() + i * intervalReal));
      }
      break;
    case INTEGER: 
      EvaluatorInteger eI = (EvaluatorInteger)e;
      
      int intervalInteger = (eI.getUpperBound() - eI.getLowerBound()) / 10;
      for (int i = 0; i <= 10; i++) {
        retValues.add(new ValueInteger(eI.getLowerBound() + i * intervalInteger));
      }
    }
    return retValues;
  }
  
  public double getMyBidsMinUtility(double time)
  {
    if (this.allBids == null) {
      initBids();
    }
    return this.utilitySpace.getUtilityWithDiscount((Bid)this.allBids.get(this.numPossibleBids), time);
  }
  
  public Bid getMyminBidfromBids()
  {
    if (this.allBids == null) {
      initBids();
    }
    return (Bid)this.allBids.get(this.numPossibleBids);
  }
  
  public double getUtility(Bid bid)
  {
    try
    {
      return this.utilitySpace.getUtility(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.AgentLG.BidChooser
 * JD-Core Version:    0.7.1
 */