package agents.anac.y2013.MetaAgent.portfolio.CUHKAgent;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class CUHKAgent
  extends Agent
{
  private double totalTime;
  private Action ActionOfOpponent = null;
  private double maximumOfBid;
  private OwnBidHistory ownBidHistory;
  private OpponentBidHistory opponentBidHistory;
  private double minimumUtilityThreshold;
  private double utilitythreshold;
  private double MaximumUtility;
  private double timeLeftBefore;
  private double timeLeftAfter;
  private double maximumTimeOfOpponent;
  private double maximumTimeOfOwn;
  private double discountingFactor;
  private double concedeToDiscountingFactor;
  private double concedeToDiscountingFactor_original;
  private double minConcedeToDiscountingFactor;
  private ArrayList<ArrayList<Bid>> bidsBetweenUtility;
  private boolean concedeToOpponent;
  private boolean toughAgent;
  private double alpha1;
  private Bid bid_maximum_utility;
  private double reservationValue;
  
  public void init()
  {
    try
    {
      this.maximumOfBid = this.utilitySpace.getDomain().getNumberOfPossibleBids();
      this.ownBidHistory = new OwnBidHistory();
      this.opponentBidHistory = new OpponentBidHistory();
      this.bidsBetweenUtility = new ArrayList();
      this.bid_maximum_utility = this.utilitySpace.getMaxUtilityBid();
      
      this.utilitythreshold = this.utilitySpace.getUtility(this.bid_maximum_utility);
      
      this.MaximumUtility = this.utilitythreshold;
      this.timeLeftAfter = 0.0D;
      this.timeLeftBefore = 0.0D;
      this.totalTime = this.timeline.getTotalTime();
      this.maximumTimeOfOpponent = 0.0D;
      this.maximumTimeOfOwn = 0.0D;
      this.minConcedeToDiscountingFactor = 0.08D;
      this.discountingFactor = 1.0D;
      if ((this.utilitySpace.getDiscountFactor() <= 1.0D) && 
        (this.utilitySpace.getDiscountFactor() > 0.0D)) {
        this.discountingFactor = this.utilitySpace.getDiscountFactor();
      }
      chooseUtilityThreshold();
      calculateBidsBetweenUtility();
      chooseConcedeToDiscountingDegree();
      this.opponentBidHistory.initializeDataStructures(this.utilitySpace
        .getDomain());
      this.timeLeftAfter = this.timeline.getCurrentTime();
      this.concedeToOpponent = false;
      this.toughAgent = false;
      this.alpha1 = 2.0D;
      this.reservationValue = 0.0D;
      if (this.utilitySpace.getReservationValue().doubleValue() > 0.0D) {
        this.reservationValue = this.utilitySpace.getReservationValue().doubleValue();
      }
    }
    catch (Exception e)
    {
      System.out.println("initialization error" + e.getMessage());
    }
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.ActionOfOpponent = opponentAction;
  }
  
  public String getVersion()
  {
    return "CUHKAgent_version_2";
  }
  
  public String getName()
  {
    return "CUHKAgent";
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      this.timeLeftBefore = this.timeline.getCurrentTime();
      Bid bid = null;
      if (this.ActionOfOpponent == null)
      {
        bid = this.bid_maximum_utility;
        action = new Offer(getAgentID(), bid);
      }
      else if ((this.ActionOfOpponent instanceof Offer))
      {
        this.opponentBidHistory.updateOpponentModel(((Offer)this.ActionOfOpponent)
          .getBid(), this.utilitySpace
          .getDomain(), this.utilitySpace);
        updateConcedeDegree();
        if (this.ownBidHistory.numOfBidsProposed() == 0)
        {
          bid = this.bid_maximum_utility;
          action = new Offer(getAgentID(), bid);
        }
        else if (estimateRoundLeft(true) > 10)
        {
          bid = BidToOffer();
          Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(((Offer)this.ActionOfOpponent)
            .getBid(), bid));
          Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
          if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
          {
            action = new Accept(getAgentID());
            System.out.println("accept the offer");
          }
          else if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
          {
            action = new EndNegotiation(getAgentID());
            System.out
              .println("we determine to terminate the negotiation");
          }
          else if ((IsAccept.booleanValue()) && (IsTerminate.booleanValue()))
          {
            if (this.utilitySpace.getUtility(((Offer)this.ActionOfOpponent)
              .getBid()) > this.reservationValue)
            {
              action = new Accept(getAgentID());
              System.out
                .println("we accept the offer RANDOMLY");
            }
            else
            {
              action = new EndNegotiation(getAgentID());
              System.out
                .println("we determine to terminate the negotiation RANDOMLY");
            }
          }
          else if (this.concedeToOpponent == true)
          {
            bid = this.opponentBidHistory.getBestBidInHistory();
            action = new Offer(getAgentID(), bid);
            
            this.toughAgent = true;
            this.concedeToOpponent = false;
          }
          else
          {
            action = new Offer(getAgentID(), bid);
            this.toughAgent = false;
          }
        }
        else if ((this.timeline.getTime() > 0.9985000000000001D) && 
          (estimateRoundLeft(true) < 5))
        {
          bid = this.opponentBidHistory.getBestBidInHistory();
          if (this.utilitySpace.getUtility(bid) < 0.85D)
          {
            List<Bid> candidateBids = getBidsBetweenUtility(this.MaximumUtility - 0.15D, this.MaximumUtility - 0.02D);
            if (estimateRoundLeft(true) < 2)
            {
              bid = this.opponentBidHistory.getBestBidInHistory();
              System.out.println("test I " + this.utilitySpace
                .getUtility(bid));
            }
            else
            {
              bid = this.opponentBidHistory.ChooseBid(candidateBids, this.utilitySpace
              
                .getDomain());
            }
            if (bid == null) {
              bid = this.opponentBidHistory.getBestBidInHistory();
            }
          }
          Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(((Offer)this.ActionOfOpponent)
            .getBid(), bid));
          Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
          if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
          {
            action = new Accept(getAgentID());
            System.out.println("accept the offer");
          }
          else if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
          {
            action = new EndNegotiation(getAgentID());
            System.out
              .println("we determine to terminate the negotiation");
          }
          else if ((IsTerminate.booleanValue()) && (IsAccept.booleanValue()))
          {
            if (this.utilitySpace.getUtility(((Offer)this.ActionOfOpponent)
              .getBid()) > this.reservationValue)
            {
              action = new Accept(getAgentID());
              System.out
                .println("we accept the offer RANDOMLY");
            }
            else
            {
              action = new EndNegotiation(getAgentID());
              System.out
                .println("we determine to terminate the negotiation RANDOMLY");
            }
          }
          else if (this.toughAgent == true)
          {
            action = new Accept(getAgentID());
            System.out
              .println("the opponent is tough and the deadline is approching thus we accept the offer");
          }
          else
          {
            action = new Offer(getAgentID(), bid);
            
            System.out
              .println("this is really the last chance" + bid
              .toString() + " with utility of " + this.utilitySpace
              

              .getUtility(bid));
          }
        }
        else
        {
          bid = BidToOffer();
          

          Boolean IsAccept = Boolean.valueOf(AcceptOpponentOffer(((Offer)this.ActionOfOpponent)
            .getBid(), bid));
          Boolean IsTerminate = Boolean.valueOf(TerminateCurrentNegotiation(bid));
          if ((IsAccept.booleanValue()) && (!IsTerminate.booleanValue()))
          {
            action = new Accept(getAgentID());
            System.out.println("accept the offer");
          }
          else if ((IsTerminate.booleanValue()) && (!IsAccept.booleanValue()))
          {
            action = new EndNegotiation(getAgentID());
            System.out
              .println("we determine to terminate the negotiation");
          }
          else if ((IsAccept.booleanValue()) && (IsTerminate.booleanValue()))
          {
            if (this.utilitySpace.getUtility(((Offer)this.ActionOfOpponent)
              .getBid()) > this.reservationValue)
            {
              action = new Accept(getAgentID());
              System.out
                .println("we accept the offer RANDOMLY");
            }
            else
            {
              action = new EndNegotiation(getAgentID());
              System.out
                .println("we determine to terminate the negotiation RANDOMLY");
            }
          }
          else
          {
            action = new Offer(getAgentID(), bid);
          }
        }
      }
      this.ownBidHistory.addBid(bid, this.utilitySpace);
      this.timeLeftAfter = this.timeline.getCurrentTime();
      estimateRoundLeft(false);
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      System.out.println(estimateRoundLeft(false));
      

      action = new EndNegotiation(getAgentID());
    }
    return action;
  }
  
  private Bid BidToOffer()
  {
    Bid bidReturned = null;
    double decreasingAmount_1 = 0.05D;
    double decreasingAmount_2 = 0.25D;
    try
    {
      double maximumOfBid = this.MaximumUtility;
      double minimumOfBid;
      if ((this.discountingFactor == 1.0D) && (this.maximumOfBid > 3000.0D))
      {
        double minimumOfBid = this.MaximumUtility - decreasingAmount_1;
        if ((this.discountingFactor > 1.0D - decreasingAmount_2) && (this.maximumOfBid > 10000.0D)) {
          if (this.timeline.getTime() >= 0.98D) {
            minimumOfBid = this.MaximumUtility - decreasingAmount_2;
          }
        }
        if (this.utilitythreshold > minimumOfBid) {
          this.utilitythreshold = minimumOfBid;
        }
      }
      else
      {
        if (this.timeline.getTime() <= this.concedeToDiscountingFactor)
        {
          double minThreshold = maximumOfBid * this.discountingFactor / Math.pow(this.discountingFactor, this.concedeToDiscountingFactor);
          


          this.utilitythreshold = (maximumOfBid - (maximumOfBid - minThreshold) * Math.pow(this.timeline
            .getTime() / this.concedeToDiscountingFactor, this.alpha1));
        }
        else
        {
          this.utilitythreshold = (maximumOfBid * this.discountingFactor / Math.pow(this.discountingFactor, this.timeline
            .getTime()));
        }
        minimumOfBid = this.utilitythreshold;
      }
      Bid bestBidOfferedByOpponent = this.opponentBidHistory.getBestBidInHistory();
      if ((this.utilitySpace.getUtility(bestBidOfferedByOpponent) >= this.utilitythreshold) || 
        (this.utilitySpace.getUtility(bestBidOfferedByOpponent) >= minimumOfBid)) {
        return bestBidOfferedByOpponent;
      }
      List<Bid> candidateBids = getBidsBetweenUtility(minimumOfBid, maximumOfBid);
      

      bidReturned = this.opponentBidHistory.ChooseBid(candidateBids, this.utilitySpace
        .getDomain());
      if (bidReturned == null)
      {
        System.out.println("no bid is searched warning");
        bidReturned = this.utilitySpace.getMaxUtilityBid();
      }
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "exception in method BidToOffer");
    }
    return bidReturned;
  }
  
  private boolean AcceptOpponentOffer(Bid opponentBid, Bid ownBid)
  {
    double currentUtility = 0.0D;
    double nextRoundUtility = 0.0D;
    double maximumUtility = 0.0D;
    this.concedeToOpponent = false;
    try
    {
      currentUtility = this.utilitySpace.getUtility(opponentBid);
      maximumUtility = this.MaximumUtility;
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method AcceptOpponentOffer part 1");
    }
    try
    {
      nextRoundUtility = this.utilitySpace.getUtility(ownBid);
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method AcceptOpponentOffer part 2");
    }
    if ((currentUtility >= this.utilitythreshold) || (currentUtility >= nextRoundUtility)) {
      return true;
    }
    double predictMaximumUtility = maximumUtility * this.discountingFactor;
    




    double currentMaximumUtility = this.utilitySpace.getUtilityWithDiscount(this.opponentBidHistory
      .getBestBidInHistory(), this.timeline);
    if ((currentMaximumUtility > predictMaximumUtility) && 
      (this.timeline.getTime() > this.concedeToDiscountingFactor)) {
      try
      {
        if (this.utilitySpace.getUtility(opponentBid) >= this.utilitySpace.getUtility(this.opponentBidHistory
          .getBestBidInHistory()) - 0.01D)
        {
          System.out.println("he offered me " + currentMaximumUtility + " we predict we can get at most " + predictMaximumUtility + "we concede now to avoid lower payoff due to conflict");
          



          return true;
        }
        this.concedeToOpponent = true;
        return false;
      }
      catch (Exception e)
      {
        System.out.println("exception in Method AcceptOpponentOffer");
        return true;
      }
    }
    if (currentMaximumUtility > this.utilitythreshold * Math.pow(this.discountingFactor, this.timeline.getTime())) {
      try
      {
        if (this.utilitySpace.getUtility(opponentBid) >= this.utilitySpace.getUtility(this.opponentBidHistory
          .getBestBidInHistory()) - 0.01D) {
          return true;
        }
        System.out.println("test" + this.utilitySpace
          .getUtility(opponentBid) + this.utilitythreshold);
        
        this.concedeToOpponent = true;
        return false;
      }
      catch (Exception e)
      {
        System.out.println("exception in Method AcceptOpponentOffer");
        return true;
      }
    }
    return false;
  }
  
  private boolean TerminateCurrentNegotiation(Bid ownBid)
  {
    double currentUtility = 0.0D;
    double nextRoundUtility = 0.0D;
    double maximumUtility = 0.0D;
    this.concedeToOpponent = false;
    try
    {
      currentUtility = this.reservationValue;
      nextRoundUtility = this.utilitySpace.getUtility(ownBid);
      maximumUtility = this.MaximumUtility;
    }
    catch (Exception e)
    {
      System.out.println(e.getMessage() + "Exception in method TerminateCurrentNegotiation part 1");
    }
    if ((currentUtility >= this.utilitythreshold) || (currentUtility >= nextRoundUtility)) {
      return true;
    }
    double predictMaximumUtility = maximumUtility * this.discountingFactor;
    

    double currentMaximumUtility = this.utilitySpace.getReservationValueWithDiscount(this.timeline);
    if ((currentMaximumUtility > predictMaximumUtility) && 
      (this.timeline.getTime() > this.concedeToDiscountingFactor)) {
      return true;
    }
    return false;
  }
  
  private int estimateRoundLeft(boolean opponent)
  {
    if (opponent == true)
    {
      if (this.timeLeftBefore - this.timeLeftAfter > this.maximumTimeOfOpponent) {
        this.maximumTimeOfOpponent = (this.timeLeftBefore - this.timeLeftAfter);
      }
    }
    else if (this.timeLeftAfter - this.timeLeftBefore > this.maximumTimeOfOwn) {
      this.maximumTimeOfOwn = (this.timeLeftAfter - this.timeLeftBefore);
    }
    if (this.maximumTimeOfOpponent + this.maximumTimeOfOwn == 0.0D) {
      System.out.println("divided by zero exception");
    }
    double round = (this.totalTime - this.timeline.getCurrentTime()) / (this.maximumTimeOfOpponent + this.maximumTimeOfOwn);
    


    return (int)round;
  }
  
  private void calculateBidsBetweenUtility()
  {
    BidIterator myBidIterator = new BidIterator(this.utilitySpace.getDomain());
    try
    {
      double maximumUtility = this.MaximumUtility;
      double minUtility = this.minimumUtilityThreshold;
      int maximumRounds = (int)((maximumUtility - minUtility) / 0.01D);
      for (int i = 0; i < maximumRounds; i++)
      {
        ArrayList<Bid> BidList = new ArrayList();
        
        this.bidsBetweenUtility.add(BidList);
      }
      ((ArrayList)this.bidsBetweenUtility.get(maximumRounds - 1)).add(this.bid_maximum_utility);
      



      int limits = 0;
      if (this.maximumOfBid < 20000.0D) {
        while (myBidIterator.hasNext())
        {
          Bid b = myBidIterator.next();
          for (int i = 0; i < maximumRounds; i++) {
            if (this.utilitySpace.getUtility(b) <= (i + 1) * 0.01D + minUtility) {
              if (this.utilitySpace.getUtility(b) >= i * 0.01D + minUtility)
              {
                ((ArrayList)this.bidsBetweenUtility.get(i)).add(b);
                break;
              }
            }
          }
        }
      }
      while (limits <= 20000)
      {
        Bid b = RandomSearchBid();
        for (int i = 0; i < maximumRounds; i++) {
          if (this.utilitySpace.getUtility(b) <= (i + 1) * 0.01D + minUtility) {
            if (this.utilitySpace.getUtility(b) >= i * 0.01D + minUtility)
            {
              ((ArrayList)this.bidsBetweenUtility.get(i)).add(b);
              break;
            }
          }
        }
        limits++;
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in calculateBidsBetweenUtility()");
      e.printStackTrace();
    }
  }
  
  private Bid RandomSearchBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random random = new Random();
    Bid bid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int optionIndex = random.nextInt(lIssueDiscrete
          .getNumberOfValues());
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete
          .getValue(optionIndex));
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = random.nextInt(lIssueReal
          .getNumberOfDiscretizationSteps() - 1);
        values.put(
          Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal
          .getLowerBound() + 
          
          (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal
          

          .getNumberOfDiscretizationSteps()));
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        
        int optionIndex2 = lIssueInteger.getLowerBound() + random.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
          .getLowerBound());
        values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported");
      }
    }
    bid = new Bid(this.utilitySpace.getDomain(), values);
    return bid;
  }
  
  private List<Bid> getBidsBetweenUtility(double lowerBound, double upperBound)
  {
    List<Bid> bidsInRange = new ArrayList();
    try
    {
      int range = (int)((upperBound - this.minimumUtilityThreshold) / 0.01D);
      int initial = (int)((lowerBound - this.minimumUtilityThreshold) / 0.01D);
      for (int i = initial; i < range; i++) {
        bidsInRange.addAll((Collection)this.bidsBetweenUtility.get(i));
      }
      if (bidsInRange.isEmpty()) {
        bidsInRange.add(this.bid_maximum_utility);
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in getBidsBetweenUtility");
      e.printStackTrace();
    }
    return bidsInRange;
  }
  
  private void chooseUtilityThreshold()
  {
    double discountingFactor = this.discountingFactor;
    if (discountingFactor >= 0.9D) {
      this.minimumUtilityThreshold = 0.0D;
    } else {
      this.minimumUtilityThreshold = 0.0D;
    }
  }
  
  private void chooseConcedeToDiscountingDegree()
  {
    double alpha = 0.0D;
    double beta = 1.5D;
    if (this.discountingFactor > 0.75D) {
      beta = 1.8D;
    } else if (this.discountingFactor > 0.5D) {
      beta = 1.5D;
    } else {
      beta = 1.2D;
    }
    alpha = Math.pow(this.discountingFactor, beta);
    this.concedeToDiscountingFactor = (this.minConcedeToDiscountingFactor + (1.0D - this.minConcedeToDiscountingFactor) * alpha);
    
    this.concedeToDiscountingFactor_original = this.concedeToDiscountingFactor;
    System.out.println("concedeToDiscountingFactor is " + this.concedeToDiscountingFactor + "current time is " + this.timeline
    
      .getTime());
  }
  
  private void updateConcedeDegree()
  {
    double gama = 10.0D;
    double weight = 0.1D;
    
    double opponnetToughnessDegree = this.opponentBidHistory.getConcessionDegree();
    





    this.concedeToDiscountingFactor = (this.concedeToDiscountingFactor_original + weight * (1.0D - this.concedeToDiscountingFactor_original) * Math.pow(opponnetToughnessDegree, gama));
    if (this.concedeToDiscountingFactor >= 1.0D) {
      this.concedeToDiscountingFactor = 1.0D;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.portfolio.CUHKAgent.CUHKAgent
 * JD-Core Version:    0.7.1
 */