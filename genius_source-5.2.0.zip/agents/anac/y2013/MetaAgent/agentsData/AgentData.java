package agents.anac.y2013.MetaAgent.agentsData;

public abstract class AgentData
{
  public abstract String getText();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.agentsData.AgentData
 * JD-Core Version:    0.7.1
 */