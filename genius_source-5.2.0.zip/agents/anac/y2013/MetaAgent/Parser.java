package agents.anac.y2013.MetaAgent;

import agents.anac.y2013.MetaAgent.agentsData.AgentData;
import agents.anac.y2013.MetaAgent.parser.cart.TreeParser;
import agents.anac.y2013.MetaAgent.parser.cart.tree.Node;
import java.util.HashMap;

public class Parser
{
  public static enum Type
  {
    CART,  CARTCLASS,  LINREG,  LOGREG,  NN,  NNCLASS;
    
    private Type() {}
  }
  
  public static double getMean(AgentData agent, HashMap<String, Double> values)
  {
    TreeParser p = new TreeParser(agent);
    Node n = p.Parse();
    
    Node ans = n.getBestNode(values);
    return ans.get_mean();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.Parser
 * JD-Core Version:    0.7.1
 */