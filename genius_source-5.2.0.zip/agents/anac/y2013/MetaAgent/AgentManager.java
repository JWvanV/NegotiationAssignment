package agents.anac.y2013.MetaAgent;

import agents.anac.y2013.MetaAgent.agentsData.AgentData;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataAgentLG;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataBRAMAgent2;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataCUHKAgent;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataIAMhaggler2012;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataOMACagent;
import agents.anac.y2013.MetaAgent.agentsData.agents.DataTheNegotiatorReloaded;
import agents.anac.y2013.MetaAgent.portfolio.AgentLG.AgentLG;
import agents.anac.y2013.MetaAgent.portfolio.AgentMR.AgentMR;
import agents.anac.y2013.MetaAgent.portfolio.BRAMAgent2.BRAMAgent2;
import agents.anac.y2013.MetaAgent.portfolio.CUHKAgent.CUHKAgent;
import agents.anac.y2013.MetaAgent.portfolio.IAMhaggler2012.IAMhaggler2012;
import agents.anac.y2013.MetaAgent.portfolio.OMACagent.OMACagent;
import agents.anac.y2013.MetaAgent.portfolio.thenegotiatorreloaded.TheNegotiatorReloaded;
import java.io.Serializable;
import java.util.AbstractMap.SimpleEntry;
import java.util.HashMap;
import java.util.Set;
import negotiator.Agent;

public class AgentManager
  implements Serializable
{
  HashMap<String, AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Double, Double>>> agents;
  int playsCount = 0;
  int predictionFactor = 5;
  String selectedAgent = "";
  AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Double, Double>> selectedInfo = new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D)));
  double averageUtility = 0.0D;
  double stdev = 0.0D;
  
  public AgentManager()
  {
    this.agents = new HashMap();
    this.agents.put("AgentLG", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
    
    this.agents.put("BRAMAgent2", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
    this.agents.put("CUHKAgent", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
    this.agents.put("IAMhaggler2012", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
    this.agents.put("OMACagent", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
    this.agents.put("TheNegotiatorReloaded", new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(0.0D), Double.valueOf(0.0D))));
  }
  
  private Agent GetAgent(String name)
  {
    if (name.equalsIgnoreCase("AgentLG")) {
      return new AgentLG();
    }
    if (name.equalsIgnoreCase("AgentMR")) {
      return new AgentMR();
    }
    if (name.equalsIgnoreCase("BRAMAgent2")) {
      return new BRAMAgent2();
    }
    if (name.equalsIgnoreCase("CUHKAgent")) {
      return new CUHKAgent();
    }
    if (name.equalsIgnoreCase("IAMhaggler2012")) {
      return new IAMhaggler2012();
    }
    if (name.equalsIgnoreCase("OMACagent")) {
      return new OMACagent();
    }
    if (name.equalsIgnoreCase("TheNegotiatorReloaded")) {
      return new TheNegotiatorReloaded();
    }
    return new CUHKAgent();
  }
  
  public AgentData GetAgentData(String name)
  {
    if (name.equalsIgnoreCase("AgentLG")) {
      return new DataAgentLG();
    }
    if (name.equalsIgnoreCase("AgentMR")) {
      return new DataAgentLG();
    }
    if (name.equalsIgnoreCase("BRAMAgent2")) {
      return new DataBRAMAgent2();
    }
    if (name.equalsIgnoreCase("CUHKAgent")) {
      return new DataCUHKAgent();
    }
    if (name.equalsIgnoreCase("IAMhaggler2012")) {
      return new DataIAMhaggler2012();
    }
    if (name.equalsIgnoreCase("OMACagent")) {
      return new DataOMACagent();
    }
    if (name.equalsIgnoreCase("TheNegotiatorReloaded")) {
      return new DataTheNegotiatorReloaded();
    }
    return new DataCUHKAgent();
  }
  
  public Agent SelectBestAgent()
  {
    String bestAgent = "";
    double bestScore = -1.0D;
    for (String agent : this.agents.keySet())
    {
      AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Double, Double>> information = (AbstractMap.SimpleEntry)this.agents.get(agent);
      double curr = (((Double)((AbstractMap.SimpleEntry)information.getValue()).getValue()).doubleValue() * ((Integer)information.getKey()).intValue() + ((Double)((AbstractMap.SimpleEntry)information.getValue()).getKey()).doubleValue() * this.predictionFactor) / (((Integer)information.getKey()).intValue() + this.predictionFactor);
      double curr2 = Math.sqrt(this.stdev * Math.log(this.playsCount + this.agents.size() * this.predictionFactor) / (((Integer)information.getKey()).intValue() + this.predictionFactor));
      curr += curr2;
      if ((bestScore < curr) || ((bestScore == curr) && (((Integer)((AbstractMap.SimpleEntry)this.agents.get(bestAgent)).getKey()).intValue() > ((Integer)information.getKey()).intValue())))
      {
        bestScore = curr;
        bestAgent = agent;
        this.selectedInfo = information;
      }
    }
    this.selectedAgent = bestAgent;
    










    return GetAgent(this.selectedAgent);
  }
  
  public boolean IsUsed()
  {
    return this.playsCount > this.agents.size();
  }
  
  public Set<String> GetAgents()
  {
    return this.agents.keySet();
  }
  
  public void UpdateUtility(String agent, double util)
  {
    if (agent == "")
    {
      this.selectedInfo = new AbstractMap.SimpleEntry(Integer.valueOf(((Integer)this.selectedInfo.getKey()).intValue() + 1), new AbstractMap.SimpleEntry(((AbstractMap.SimpleEntry)this.selectedInfo.getValue()).getKey(), Double.valueOf((((Double)((AbstractMap.SimpleEntry)this.selectedInfo.getValue()).getValue()).doubleValue() * ((Integer)this.selectedInfo.getKey()).intValue() + util - this.averageUtility) / (((Integer)this.selectedInfo.getKey()).intValue() + 1))));
      


      this.agents.put(this.selectedAgent, this.selectedInfo);
      
      this.playsCount += 1;
    }
    else
    {
      AbstractMap.SimpleEntry<Integer, AbstractMap.SimpleEntry<Double, Double>> info = new AbstractMap.SimpleEntry(Integer.valueOf(0), new AbstractMap.SimpleEntry(Double.valueOf(util), Double.valueOf(0.0D)));
      this.agents.put(agent, info);
    }
  }
  
  public void SetAvgUtil(double avg, double stdev)
  {
    this.averageUtility = avg;
    this.stdev = stdev;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2013.MetaAgent.AgentManager
 * JD-Core Version:    0.7.1
 */