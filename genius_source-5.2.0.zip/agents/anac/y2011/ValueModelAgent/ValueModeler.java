package agents.anac.y2011.ValueModelAgent;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public class ValueModeler
{
  public boolean initialized = false;
  UtilitySpace utilitySpace;
  IssuesDecreases[] issues;
  
  public void initialize(UtilitySpace space, Bid firstBid)
    throws Exception
  {
    this.initialized = true;
    this.utilitySpace = space;
    int issueCount = this.utilitySpace.getDomain().getIssues().size();
    this.issues = new IssuesDecreases[issueCount];
    for (int i = 0; i < issueCount; i++)
    {
      Value value = firstBid.getValue(this.utilitySpace.getIssue(i).getNumber());
      this.issues[i] = new IssuesDecreases(this.utilitySpace);
      this.issues[i].initilize((Issue)this.utilitySpace.getDomain().getIssues().get(i), value, issueCount);
    }
  }
  
  private void normalize()
  {
    for (int i = 0; i < this.issues.length; i++) {
      this.issues[i].normalize(this.issues[i].weight());
    }
  }
  
  private double reliabilityToDevUnits(double reliability)
  {
    if (reliability > 0.0D) {
      return 1.0D / (reliability * reliability) / this.issues.length;
    }
    if (reliability > 0.0D) {
      return 2.0D / reliability / this.issues.length;
    }
    if (reliability > 0.0D) {
      return 4.0D / Math.sqrt(reliability) / this.issues.length;
    }
    return 1000.0D;
  }
  
  public void assumeBidWorth(Bid bid, double expectedDecrease, double stdDev)
    throws Exception
  {
    ValueDecrease[] values = new ValueDecrease[this.issues.length];
    double maxReliableDecrease = 0.0D;
    for (int i = 0; i < this.issues.length; i++)
    {
      Value value = bid.getValue(this.utilitySpace.getIssue(i).getNumber());
      values[i] = this.issues[i].getExpectedDecrease(value);
    }
    double deviationUnit = 0.0D;
    for (int i = 0; i < this.issues.length; i++)
    {
      deviationUnit += reliabilityToDevUnits(values[i].getReliabilty()) * values[i].getDeviance();
      if ((maxReliableDecrease < values[i].getDecrease()) && (values[i].getReliabilty() > 0.8D)) {
        maxReliableDecrease = values[i].getDecrease();
      }
    }
    ValueDecrease origEvaluation = utilityLoss(bid);
    double unitsToMove = (expectedDecrease - origEvaluation.getDecrease()) / deviationUnit;
    for (int i = 0; i < this.issues.length; i++)
    {
      double newVal = values[i].getDecrease() + reliabilityToDevUnits(values[i].getReliabilty()) * values[i].getDeviance() * unitsToMove;
      if ((values[i].getMaxReliabilty() > 0.7D) || (maxReliableDecrease < newVal))
      {
        if (newVal > 0.0D) {
          values[i].updateWithNewValue(newVal, origEvaluation.getReliabilty());
        } else {
          values[i].updateWithNewValue(0.0D, origEvaluation.getReliabilty());
        }
      }
      else {
        values[i].updateWithNewValue(newVal, origEvaluation.getReliabilty());
      }
    }
    normalize();
  }
  
  public ValueDecrease utilityLoss(Bid bid)
    throws Exception
  {
    ValueDecrease[] values = new ValueDecrease[this.issues.length];
    for (int i = 0; i < this.issues.length; i++)
    {
      Value value = bid.getValue(this.utilitySpace.getIssue(i).getNumber());
      values[i] = this.issues[i].getExpectedDecrease(value);
    }
    double stdDev = 0.0D;
    for (int i = 0; i < this.issues.length; i++) {
      stdDev += values[i].getDeviance();
    }
    double decrease = 0.0D;
    for (int i = 0; i < this.issues.length; i++) {
      decrease += values[i].getDecrease();
    }
    double sumSQ = 0.0D;
    for (int i = 0; i < this.issues.length; i++)
    {
      double rel = values[i].getReliabilty();
      rel = rel > 0.0D ? rel : 0.01D;
      sumSQ += 1.0D / rel * (1.0D / rel);
    }
    sumSQ /= this.issues.length;
    double rel = Math.sqrt(1.0D / sumSQ);
    return new ValueDecrease(decrease, rel, stdDev);
  }
  
  public IssuesDecreases getIssue(int index)
  {
    if ((index < this.issues.length) && (index >= 0)) {
      return this.issues[index];
    }
    return this.issues[0];
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.ValueModeler
 * JD-Core Version:    0.7.1
 */