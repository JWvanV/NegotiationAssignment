package agents.anac.y2011.ValueModelAgent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class ValueSeperatedBids
{
  UtilitySpace utilitySpace;
  IssueSeperatedBids[] issues;
  ValueModeler model;
  
  private class ValueBidData
  {
    BidList approvedSorted = new BidList();
    int lastTimeBidden = -1;
    boolean changed = false;
    
    private ValueBidData() {}
    
    void addWrapper(BidWrapper bid)
    {
      this.approvedSorted.addIfNew(bid);
      this.changed = true;
    }
  }
  
  private class IssueSeperatedBids
  {
    public Map<String, ValueSeperatedBids.ValueBidData> values = new HashMap();
    
    private IssueSeperatedBids() {}
  }
  
  public void addApproved(BidWrapper bid)
  {
    for (int i = 0; i < this.issues.length; i++) {
      if (this.issues[i] != null) {
        try
        {
          Value value = bid.bid.getValue(this.utilitySpace.getIssue(i).getNumber());
          
          ValueBidData data = (ValueBidData)this.issues[i].values.get(value.toString());
          data.addWrapper(bid);
        }
        catch (Exception e) {}
      }
    }
  }
  
  public void bidden(Bid bid, int roundID)
  {
    for (int i = 0; i < this.issues.length; i++) {
      if (this.issues[i] != null) {
        try
        {
          Value value = bid.getValue(this.utilitySpace.getIssue(i).getNumber());
          
          ValueBidData data = (ValueBidData)this.issues[i].values.get(value.toString());
          data.lastTimeBidden = roundID;
        }
        catch (Exception e) {}
      }
    }
  }
  
  public void init(UtilitySpace space, ValueModeler model)
  {
    this.model = model;
    this.utilitySpace = space;
    int issueCount = this.utilitySpace.getDomain().getIssues().size();
    this.issues = new IssueSeperatedBids[issueCount];
    for (int i = 0; i < issueCount; i++)
    {
      Issue issue = (Issue)this.utilitySpace.getDomain().getIssues().get(i);
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        this.issues[i] = new IssueSeperatedBids(null);
        IssueDiscrete issueD = (IssueDiscrete)issue;
        int s = issueD.getNumberOfValues();
        for (int j = 0; j < s; j++)
        {
          String key = issueD.getValue(j).toString();
          this.issues[i].values.put(key, new ValueBidData(null));
        }
      }
      else
      {
        this.issues[i] = null;
      }
    }
  }
  
  public BidWrapper explore(int round)
  {
    ValueBidData minData = null;
    int minRound = round;
    int maxBidsAvaliable = 1;
    int issueCount = this.utilitySpace.getDomain().getIssues().size();
    for (int i = 0; i < issueCount; i++)
    {
      Issue issue = (Issue)this.utilitySpace.getDomain().getIssues().get(i);
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        IssueDiscrete issueD = (IssueDiscrete)issue;
        int s = issueD.getNumberOfValues();
        for (int j = 0; j < s; j++)
        {
          String key = issueD.getValue(j).toString();
          ValueBidData data = (ValueBidData)this.issues[i].values.get(key);
          int s2 = data.approvedSorted.bids.size();
          if ((s2 > 0) && ((data.lastTimeBidden < minRound) || ((data.lastTimeBidden == minRound) && (maxBidsAvaliable < s2))))
          {
            minRound = data.lastTimeBidden;
            maxBidsAvaliable = s2;
            minData = data;
          }
        }
      }
    }
    if (minData != null)
    {
      if (minData.changed == true)
      {
        minData.approvedSorted.sortByOpponentUtil(this.model);
        minData.changed = false;
      }
      if (minRound == round) {
        return null;
      }
      for (int i = 0; i < minData.approvedSorted.bids.size(); i++)
      {
        BidWrapper tempBid = (BidWrapper)minData.approvedSorted.bids.get(i);
        if (!tempBid.sentByUs) {
          return tempBid;
        }
      }
      minData.lastTimeBidden = round;
      


      return explore(round);
    }
    return null;
  }
  
  public void clear()
  {
    int issueCount = this.utilitySpace.getDomain().getIssues().size();
    for (int i = 0; i < issueCount; i++)
    {
      Issue issue = (Issue)this.utilitySpace.getDomain().getIssues().get(i);
      if (issue.getType() == ISSUETYPE.DISCRETE)
      {
        IssueDiscrete issueD = (IssueDiscrete)issue;
        int s = issueD.getNumberOfValues();
        for (int j = 0; j < s; j++)
        {
          String key = issueD.getValue(j).toString();
          ValueBidData data = (ValueBidData)this.issues[i].values.get(key);
          data.approvedSorted.bids.clear();
        }
      }
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.ValueSeperatedBids
 * JD-Core Version:    0.7.1
 */