package agents.anac.y2011.ValueModelAgent;

import java.util.ArrayList;
import java.util.Collections;
import negotiator.Bid;

public class BidList
{
  public ArrayList<BidWrapper> bids;
  
  public BidList()
  {
    this.bids = new ArrayList();
  }
  
  public void sortByOurUtil()
  {
    BidWrapper tmp19_16 = ((BidWrapper)this.bids.get(0));tmp19_16.getClass();Collections.sort(this.bids, new BidWrapper.OurUtilityComperator(tmp19_16));
  }
  
  public void sortByOpponentUtil(ValueModeler model)
  {
    for (BidWrapper bid : this.bids) {
      try
      {
        bid.theirUtility = (1.0D - model.utilityLoss(bid.bid).getDecrease());
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    BidWrapper tmp76_73 = ((BidWrapper)this.bids.get(0));tmp76_73.getClass();Collections.sort(this.bids, new BidWrapper.OpponentUtilityComperator(tmp76_73));
  }
  
  public boolean addIfNew(BidWrapper newBid)
  {
    for (int i = 0; i < this.bids.size(); i++) {
      if (((BidWrapper)this.bids.get(i)).bid.equals(newBid.bid))
      {
        ((BidWrapper)this.bids.get(i)).lastSentBid = newBid.lastSentBid;
        return false;
      }
    }
    this.bids.add(newBid);
    
    return true;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.BidList
 * JD-Core Version:    0.7.1
 */