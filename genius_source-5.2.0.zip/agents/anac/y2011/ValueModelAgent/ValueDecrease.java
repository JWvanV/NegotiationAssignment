package agents.anac.y2011.ValueModelAgent;

public class ValueDecrease
{
  private double decrease;
  private double avDev;
  private double reliabilty;
  private int lastSent;
  private double highestReliability;
  private static final double tempralDifferenceGamma = 0.1D;
  
  ValueDecrease(double val, double rel, double dev)
  {
    this.avDev = dev;
    this.reliabilty = rel;
    this.decrease = val;
    this.lastSent = -1;
    this.highestReliability = rel;
  }
  
  public double getDecrease()
  {
    return this.decrease;
  }
  
  public void forceChangeDecrease(double newDecrease)
  {
    this.decrease = newDecrease;
  }
  
  public double getReliabilty()
  {
    return this.reliabilty;
  }
  
  public double getMaxReliabilty()
  {
    return this.reliabilty;
  }
  
  public double getDeviance()
  {
    return this.avDev;
  }
  
  public int lastSent()
  {
    return this.lastSent;
  }
  
  public void sent(int bidIndex)
  {
    this.lastSent = bidIndex;
  }
  
  private double sq(double x)
  {
    return x * x;
  }
  
  public void updateWithNewValue(double newVal, double newReliability)
  {
    if (this.reliabilty != 0.02D)
    {
      double newChunk = newReliability * (1.0D - this.reliabilty);
      double temporalC = this.reliabilty * 0.1D * newReliability;
      newChunk += temporalC;
      double oldChunk = this.reliabilty - temporalC;
      double sumChunk = newChunk + oldChunk;
      

      double newDecrease = (newChunk * newVal + oldChunk * this.decrease) / sumChunk;
      double change = Math.abs(newDecrease - this.decrease);
      
      double newDev = Math.sqrt(
      
        (oldChunk / 2.0D * sq(this.avDev + change) + oldChunk / 2.0D * sq(this.avDev - change) + newChunk * sq(newVal - newDecrease)) / sumChunk);
      double temp = 1.0D - change / (2.0D * newDev);
      this.reliabilty = (oldChunk * (temp > 0.2D ? temp : 0.2D));
      temp = 1.0D - Math.abs(newDecrease - newVal) / (2.0D * newDev);
      this.reliabilty += newChunk * (temp > 0.0D ? temp : 0.0D);
      this.decrease = newDecrease;
      this.avDev = newDev;
      if (this.highestReliability < this.reliabilty) {
        this.highestReliability = this.reliabilty;
      }
    }
    else
    {
      this.decrease = newVal;
      this.reliabilty = newReliability;
      this.avDev = 0.03D;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.ValueDecrease
 * JD-Core Version:    0.7.1
 */