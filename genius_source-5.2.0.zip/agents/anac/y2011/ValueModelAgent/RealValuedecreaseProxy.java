package agents.anac.y2011.ValueModelAgent;

public class RealValuedecreaseProxy
  extends ValueDecrease
{
  private double portion;
  private ValueDecrease worstScale;
  
  RealValuedecreaseProxy(ValueDecrease worstScale, double portion)
  {
    super(0.0D, 0.0D, 0.0D);
    this.portion = portion;
    this.worstScale = worstScale;
  }
  
  public double getDecrease()
  {
    return this.worstScale.getDecrease() * this.portion;
  }
  
  public double getReliabilty()
  {
    return this.worstScale.getReliabilty();
  }
  
  public double getDeviance()
  {
    return this.worstScale.getDeviance() * this.portion;
  }
  
  public int lastSent()
  {
    return this.worstScale.lastSent();
  }
  
  public void sent(int bidIndex)
  {
    this.worstScale.sent(bidIndex);
  }
  
  public void updateWithNewValue(double newVal, double newReliability)
  {
    if (this.portion > 0.0D) {
      this.worstScale.updateWithNewValue(newVal / this.portion, newReliability);
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.RealValuedecreaseProxy
 * JD-Core Version:    0.7.1
 */