package agents.anac.y2011.ValueModelAgent;

import java.util.HashMap;
import java.util.Map;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class IssuesDecreases
{
  private Map<String, ValueDecrease> values;
  private ISSUETYPE type;
  private Issue origin;
  private boolean goingDown;
  
  IssuesDecreases(UtilitySpace space)
  {
    this.values = new HashMap();
  }
  
  public void initilize(Issue issue, Value maximalValue, int issueCount)
  {
    double initWeight = 1.0D / issueCount;
    this.type = issue.getType();
    this.origin = issue;
    double lower;
    double higher;
    double maxValue;
    ValueDecrease worst;
    switch (this.type)
    {
    case DISCRETE: 
      IssueDiscrete issueD = (IssueDiscrete)issue;
      int s = issueD.getNumberOfValues();
      for (int i = 0; i < s; i++)
      {
        String key = issueD.getValue(i).toString();
        ValueDecrease val;
        ValueDecrease val;
        if (key.equals(maximalValue.toString())) {
          val = new ValueDecrease(0.0D, 0.9D, 0.01D);
        } else {
          val = new ValueDecrease(initWeight, 0.02D, initWeight);
        }
        this.values.put(key, val);
      }
      break;
    case REAL: 
      IssueReal issueR = (IssueReal)issue;
      lower = issueR.getLowerBound();
      higher = issueR.getUpperBound();
      maxValue = ((ValueReal)maximalValue).getValue();
      worst = new ValueDecrease(initWeight, 0.1D, initWeight);
      this.values.put("WORST", worst);
      


      this.goingDown = (maxValue < (lower + higher) / 2.0D);
      break;
    case INTEGER: 
      IssueInteger issueI = (IssueInteger)issue;
      lower = issueI.getLowerBound();
      higher = issueI.getUpperBound();
      maxValue = ((ValueInteger)maximalValue).getValue();
      worst = new ValueDecrease(initWeight, 0.1D, initWeight);
      this.values.put("WORST", worst);
      


      this.goingDown = (maxValue < (lower + higher) / 2.0D);
    }
  }
  
  public void normalize(double newWeight)
  {
    double originalMinVal = 1.0D;
    for (ValueDecrease val : this.values.values()) {
      if (originalMinVal > val.getDecrease()) {
        originalMinVal = val.getDecrease();
      }
    }
    double originalMaxVal = weight();
    double changeRatio;
    if (originalMaxVal == originalMinVal)
    {
      for (ValueDecrease val : this.values.values()) {
        val.forceChangeDecrease(newWeight);
      }
    }
    else
    {
      changeRatio = newWeight / (originalMaxVal - originalMinVal);
      for (ValueDecrease val : this.values.values()) {
        val.forceChangeDecrease(
          (val.getDecrease() - originalMinVal) * changeRatio);
      }
    }
  }
  
  public double weight()
  {
    double maximalDecrease = 0.0D;
    for (ValueDecrease val : this.values.values()) {
      if (maximalDecrease < val.getDecrease()) {
        maximalDecrease = val.getDecrease();
      }
    }
    return maximalDecrease;
  }
  
  public ValueDecrease getExpectedDecrease(Value value)
  {
    double lower;
    double higher;
    double curValue;
    double portionOfWorst;
    ValueDecrease worst;
    switch (this.type)
    {
    case DISCRETE: 
      ValueDecrease val = (ValueDecrease)this.values.get(value.toString());
      if (val != null) {
        return val;
      }
      break;
    case REAL: 
      IssueReal issueR = (IssueReal)this.origin;
      lower = issueR.getLowerBound();
      higher = issueR.getUpperBound();
      curValue = ((ValueReal)value).getValue();
      portionOfWorst = (curValue - lower) / (higher - lower);
      if (!this.goingDown) {
        portionOfWorst = 1.0D - portionOfWorst;
      }
      worst = (ValueDecrease)this.values.get("WORST");
      if (worst != null) {
        return new RealValuedecreaseProxy(worst, portionOfWorst);
      }
    case INTEGER: 
      IssueInteger issueI = (IssueInteger)this.origin;
      lower = issueI.getLowerBound();
      higher = issueI.getUpperBound();
      curValue = ((ValueInteger)value).getValue();
      portionOfWorst = (curValue - lower) / (higher - lower);
      if (!this.goingDown) {
        portionOfWorst = 1.0D - portionOfWorst;
      }
      worst = (ValueDecrease)this.values.get("WORST");
      if (worst != null) {
        return new RealValuedecreaseProxy(worst, portionOfWorst);
      }
      break;
    }
    return new ValueDecrease(1.0D, 0.01D, 1.0D);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.IssuesDecreases
 * JD-Core Version:    0.7.1
 */