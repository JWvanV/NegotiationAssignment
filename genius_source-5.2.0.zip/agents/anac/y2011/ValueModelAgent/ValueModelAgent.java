package agents.anac.y2011.ValueModelAgent;

import java.util.ArrayList;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class ValueModelAgent
  extends Agent
{
  private ValueModeler opponentUtilModel = null;
  private BidList allBids = null;
  private BidList approvedBids = null;
  private BidList iteratedBids = null;
  private Action actionOfPartner = null;
  private Action myLastAction = null;
  private Bid myLastBid = null;
  private int bidCount;
  public BidList opponentBids;
  public BidList ourBids;
  private OpponentModeler opponent;
  private double lowestAcceptable;
  private double lowestApproved;
  public double opponentStartbidUtil;
  public double opponentMaxBidUtil;
  private Bid opponentMaxBid;
  public double myMaximumUtility;
  private int amountOfApproved;
  public double noChangeCounter;
  private boolean retreatMode;
  private double concessionInOurUtility;
  private double concessionInTheirUtility;
  private ValueSeperatedBids seperatedBids;
  private final boolean TEST_EQUIVALENCE = false;
  Random random100;
  Random random200;
  int round = 0;
  private Action lAction = null;
  private double opponentUtil;
  
  public void init()
  {
    this.opponentUtilModel = null;
    this.allBids = null;
    this.approvedBids = null;
    this.actionOfPartner = null;
    this.bidCount = 0;
    this.opponentBids = new BidList();
    this.ourBids = new BidList();
    this.iteratedBids = new BidList();
    this.seperatedBids = new ValueSeperatedBids();
    this.lowestAcceptable = 0.7D;
    this.lowestApproved = 1.0D;
    this.amountOfApproved = 0;
    this.opponentMaxBidUtil = 0.0D;
    this.myMaximumUtility = 1.0D;
    this.noChangeCounter = 0.0D;
    this.retreatMode = false;
    this.concessionInOurUtility = 0.0D;
    this.concessionInTheirUtility = 0.0D;
    




    this.random100 = new Random();
    this.random200 = new Random();
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.round += 1;
    this.actionOfPartner = opponentAction;
  }
  
  private void bidSelected(BidWrapper bid)
  {
    bid.sentByUs = true;
    this.ourBids.addIfNew(bid);
    this.myLastBid = bid.bid;
    if (this.opponentUtilModel != null) {
      this.seperatedBids.bidden(bid.bid, this.bidCount);
    }
  }
  
  private void bidSelectedByOpponent(Bid bid)
  {
    BidWrapper opponentBid = new BidWrapper(bid, this.utilitySpace, this.myMaximumUtility);
    
    opponentBid.lastSentBid = this.bidCount;
    opponentBid.sentByThem = true;
    if (this.opponentBids.addIfNew(opponentBid)) {
      this.noChangeCounter = 0.0D;
    } else {
      this.noChangeCounter += 1.0D;
    }
    try
    {
      double opponentUtil = this.utilitySpace.getUtility(bid) / this.myMaximumUtility;
      if (this.opponentMaxBidUtil < opponentUtil)
      {
        this.opponentMaxBidUtil = opponentUtil;
        this.opponentMaxBid = bid;
      }
      if (this.opponentUtilModel.initialized)
      {
        double concession = opponentUtil - this.opponentStartbidUtil;
        if (concession > this.concessionInOurUtility) {
          this.concessionInOurUtility = concession;
        }
        ValueDecrease val = this.opponentUtilModel.utilityLoss(opponentBid.bid);
        
        concession = val.getDecrease();
        if (concession > this.concessionInTheirUtility) {
          this.concessionInTheirUtility = concession;
        }
        this.seperatedBids.bidden(bid, this.bidCount);
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  private boolean setApprovedThreshold(double threshold, boolean clear)
  {
    if (clear)
    {
      this.approvedBids.bids.clear();
      this.seperatedBids.clear();
    }
    int i;
    if (clear) {
      i = 0;
    }
    for (int i = this.amountOfApproved; i < this.allBids.bids.size(); i++)
    {
      if (((BidWrapper)this.allBids.bids.get(i)).ourUtility < threshold) {
        break;
      }
      this.approvedBids.bids.add(this.allBids.bids.get(i));
      this.seperatedBids.addApproved((BidWrapper)this.allBids.bids.get(i));
    }
    this.lowestApproved = threshold;
    boolean added = this.amountOfApproved != i;
    this.amountOfApproved = i;
    return added;
  }
  
  public Action chooseAction()
  {
    Bid opponentBid = null;
    this.lAction = null;
    try
    {
      if (this.allBids == null)
      {
        this.allBids = new BidList();
        this.approvedBids = new BidList();
        this.opponentUtilModel = new ValueModeler();
        this.seperatedBids.init(this.utilitySpace, this.opponentUtilModel);
        this.myMaximumUtility = this.utilitySpace.getUtility(this.utilitySpace.getMaxUtilityBid());
        
        BidIterator iter = new BidIterator(this.utilitySpace.getDomain());
        while (iter.hasNext())
        {
          Bid tmpBid = iter.next();
          try
          {
            BidWrapper wrap = new BidWrapper(tmpBid, this.utilitySpace, this.myMaximumUtility);
            
            this.allBids.bids.add(wrap);
          }
          catch (Exception ex)
          {
            ex.printStackTrace();
            BidWrapper wrap = new BidWrapper(tmpBid, this.utilitySpace, this.myMaximumUtility);
            
            this.allBids.bids.add(wrap);
          }
        }
        this.allBids.sortByOurUtil();
        
        setApprovedThreshold(0.98D, false);
        
        this.iteratedBids.bids.add(this.allBids.bids.get(0));
      }
      if (this.bidCount == 0)
      {
        this.lAction = new Offer(getAgentID(), ((BidWrapper)this.allBids.bids.get(0)).bid);
        bidSelected((BidWrapper)this.allBids.bids.get(0));
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        opponentBid = ((Offer)this.actionOfPartner).getBid();
        this.opponentUtil = (this.utilitySpace.getUtility(opponentBid) / this.myMaximumUtility);
        
        bidSelectedByOpponent(opponentBid);
        if (this.opponent == null)
        {
          this.opponentStartbidUtil = this.opponentUtil;
          this.opponent = new OpponentModeler(this.bidCount, this.utilitySpace, this.timeline, this.ourBids, this.opponentBids, this.opponentUtilModel, this.allBids, this);
          

          this.opponentUtilModel.initialize(this.utilitySpace, opponentBid);
          this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
        }
        else
        {
          this.opponent.tick();
          if (this.noChangeCounter == 0.0D)
          {
            double opponentExpectedBidValue = this.opponent.guessCurrentBidUtil();
            
            this.opponentUtilModel.assumeBidWorth(opponentBid, 1.0D - opponentExpectedBidValue, 0.02D);
          }
        }
        if ((this.timeline.getTime() > 0.9D) && (this.timeline.getTime() <= 0.96D)) {
          chickenGame(0.039D, 0.0D, 0.7D);
        }
        if ((this.timeline.getTime() > 0.96D) && (this.timeline.getTime() <= 0.97D)) {
          chickenGame(0.019D, 0.5D, 0.65D);
        }
        if ((this.timeline.getTime() > 0.98D) && (this.timeline.getTime() <= 0.99D))
        {
          if (this.opponentUtil >= this.lowestApproved - 0.01D) {
            return new Accept(getAgentID());
          }
          if (this.bidCount % 5 == 0) {
            exploreScan();
          } else {
            bestScan();
          }
        }
        if ((this.timeline.getTime() > 0.99D) && (this.timeline.getTime() <= 0.995D)) {
          chickenGame(0.004D, 0.8D, 0.6D);
        }
        if (this.timeline.getTime() > 0.995D)
        {
          if (this.opponentMaxBidUtil > 0.55D)
          {
            if (this.opponentUtil >= this.opponentMaxBidUtil * 0.99D) {
              return new Accept(getAgentID());
            }
            return new Offer(getAgentID(), this.opponentMaxBid);
          }
          bestScan();
        }
        if (this.lAction != null)
        {
          this.myLastAction = this.lAction;
          this.bidCount += 1;
          return this.lAction;
        }
        if ((this.opponentUtil > this.lowestApproved) && ((this.utilitySpace.isDiscounted()) || (this.opponentUtil > 0.975D))) {
          return new Accept(getAgentID());
        }
        if ((this.opponentUtil > this.lowestApproved * 0.99D) && (!this.utilitySpace.isDiscounted()))
        {
          this.lowestApproved += 0.01D;
          setApprovedThreshold(this.lowestApproved, true);
          this.retreatMode = true;
        }
        if ((this.bidCount > 0) && (this.bidCount < 4))
        {
          this.lAction = new Offer(getAgentID(), ((BidWrapper)this.allBids.bids.get(0)).bid);
          bidSelected((BidWrapper)this.allBids.bids.get(this.bidCount));
        }
        if (this.bidCount >= 4)
        {
          double concession = this.opponentUtil - this.opponentStartbidUtil;
          





          double concession2 = 1.0D - this.opponent.guessCurrentBidUtil();
          double minConcession = concession < concession2 ? concession : concession2;
          
          minConcession = minConcessionMaker(minConcession, 1.0D - this.opponentMaxBidUtil);
          if (minConcession > 1.0D - this.lowestApproved)
          {
            if (this.lowestAcceptable > 1.0D - minConcession) {
              this.lowestApproved = this.lowestAcceptable;
            } else {
              this.lowestApproved = (1.0D - minConcession);
            }
            if (this.lowestApproved < this.opponentMaxBidUtil) {
              this.lowestApproved = (this.opponentMaxBidUtil + 0.001D);
            }
            if (setApprovedThreshold(this.lowestApproved, false)) {
              this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
            }
          }
          if (this.bidCount % 5 == 0) {
            exploreScan();
          } else {
            bestScan();
          }
        }
      }
      if (this.lAction == null) {
        this.lAction = this.myLastAction;
      }
    }
    catch (Exception e)
    {
      if (this.myLastBid == null) {
        try
        {
          return new Offer(getAgentID(), this.utilitySpace.getMaxUtilityBid());
        }
        catch (Exception e2)
        {
          return new Accept(getAgentID());
        }
      }
      this.lAction = new Offer(getAgentID(), this.myLastBid);
    }
    this.myLastAction = this.lAction;
    this.bidCount += 1;
    return this.lAction;
  }
  
  public void bestScan()
  {
    this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
    for (int i = 0; i < this.approvedBids.bids.size(); i++)
    {
      BidWrapper tempBid = (BidWrapper)this.approvedBids.bids.get(i);
      if (!tempBid.sentByUs)
      {
        this.lAction = new Offer(getAgentID(), tempBid.bid);
        bidSelected(tempBid);
        break;
      }
    }
    if (this.lAction == null)
    {
      int maxIndex = this.approvedBids.bids.size() / 4;
      BidWrapper tempBid = (BidWrapper)this.approvedBids.bids.get((int)(this.random200.nextDouble() * maxIndex));
      
      this.lAction = new Offer(getAgentID(), tempBid.bid);
      bidSelected(tempBid);
    }
  }
  
  public void exploreScan()
  {
    BidWrapper tempBid = this.seperatedBids.explore(this.bidCount);
    if (tempBid != null)
    {
      this.lAction = new Offer(getAgentID(), tempBid.bid);
      bidSelected(tempBid);
    }
    else
    {
      bestScan();
    }
  }
  
  public void chickenGame(double timeToGive, double concessionPortion, double acceptableThresh)
  {
    double concessionLeft = this.lowestApproved - this.opponentMaxBidUtil;
    double planedThresh = this.lowestApproved - concessionPortion * concessionLeft;
    if (acceptableThresh > planedThresh) {
      planedThresh = acceptableThresh;
    }
    setApprovedThreshold(planedThresh, false);
    this.approvedBids.sortByOpponentUtil(this.opponentUtilModel);
    if (this.opponentUtil >= planedThresh - 0.01D)
    {
      this.lAction = new Accept(getAgentID());
      return;
    }
    if (1.0D - this.timeline.getTime() - timeToGive > 0.0D) {
      sleep(1.0D - this.timeline.getTime() - timeToGive);
    }
    if ((this.retreatMode) || (this.opponentMaxBidUtil >= planedThresh - 0.01D)) {
      this.lAction = new Offer(getAgentID(), this.opponentMaxBid);
    } else {
      this.approvedBids.bids.get(0);
    }
  }
  
  double[] theirMaxUtilities = new double[21];
  double[] ourMinUtilities = new double[21];
  
  private double minConcessionMaker(double minConcession, double concessionLeft)
  {
    this.theirMaxUtilities[0] = this.opponentStartbidUtil;
    this.ourMinUtilities[0] = 1.0D;
    double t = this.timeline.getTime();
    int tind = (int)(this.timeline.getTime() * 20.0D) + 1;
    double segPortion = (t - (tind - 1) * 0.05D) / 0.05D;
    if (this.ourMinUtilities[tind] == 0.0D) {
      this.ourMinUtilities[tind] = 1.0D;
    }
    if (this.ourMinUtilities[(tind - 1)] == 0.0D) {
      this.ourMinUtilities[(tind - 1)] = this.lowestApproved;
    }
    if (this.lowestApproved < this.ourMinUtilities[tind]) {
      this.ourMinUtilities[tind] = this.lowestApproved;
    }
    if (this.opponentMaxBidUtil > this.theirMaxUtilities[tind]) {
      this.theirMaxUtilities[tind] = this.opponentMaxBidUtil;
    }
    double d = this.utilitySpace.getDiscountFactor();
    double defaultVal = 1.0D - this.ourMinUtilities[(tind - 1)];
    if ((tind == 1) || (tind >= 19)) {
      return defaultVal;
    }
    if (this.ourMinUtilities[(tind - 2)] == 0.0D) {
      this.ourMinUtilities[(tind - 2)] = this.lowestApproved;
    }
    boolean theyMoved = this.theirMaxUtilities[tind] - this.theirMaxUtilities[(tind - 2)] > 0.01D;
    
    boolean weMoved = this.ourMinUtilities[(tind - 2)] - this.ourMinUtilities[(tind - 1)] > 0.0D;
    double returnVal = defaultVal;
    if (!this.utilitySpace.isDiscounted())
    {
      if (tind > 2) {
        if (!weMoved) {
          if (!theyMoved) {
            if (tind <= 16)
            {
              returnVal = defaultVal + 0.02D;
              if (returnVal > minConcession * 2.0D / 3.0D) {
                returnVal = minConcession * 2.0D / 3.0D;
              }
            }
          }
        }
      }
      if ((tind > 16) && (!theyMoved))
      {
        returnVal = (concessionLeft - defaultVal) / (21 - tind) + defaultVal;
        if (returnVal > minConcession + 0.05D) {
          returnVal = minConcession + 0.05D;
        }
      }
    }
    else
    {
      double discountEstimate = d * 0.05D;
      double expectedRoundGain = this.theirMaxUtilities[(tind - 1)] - this.theirMaxUtilities[(tind - 2)] - discountEstimate;
      if (tind <= 16)
      {
        returnVal = defaultVal + 0.02D;
        if (defaultVal - expectedRoundGain > returnVal) {
          returnVal = defaultVal - expectedRoundGain;
        }
        if (returnVal > minConcession) {
          returnVal = minConcession;
        }
      }
      else
      {
        returnVal = (concessionLeft - defaultVal) / (21 - tind) + defaultVal;
      }
    }
    returnVal = defaultVal + (returnVal - defaultVal) * segPortion;
    return returnVal;
  }
  
  public String getName()
  {
    return "Value Model Agent";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.ValueModelAgent
 * JD-Core Version:    0.7.1
 */