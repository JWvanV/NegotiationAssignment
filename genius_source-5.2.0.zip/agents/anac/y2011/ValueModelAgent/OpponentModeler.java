package agents.anac.y2011.ValueModelAgent;

import java.util.ArrayList;
import negotiator.Timeline;
import negotiator.utility.UtilitySpace;

public class OpponentModeler
{
  UtilitySpace utilitySpace;
  double lastTime;
  public double delta;
  double discount;
  Timeline timeline;
  BidList ourPastBids;
  BidList theirPastBids;
  BidList allBids;
  ValueModeler vmodel;
  ValueModelAgent agent;
  double paretoRatioEstimation = 5.0D;
  
  public OpponentModeler(int bidCount, UtilitySpace space, Timeline timeline, BidList our, BidList their, ValueModeler vmodeler, BidList allBids, ValueModelAgent agent)
  {
    this.ourPastBids = our;
    this.theirPastBids = their;
    this.utilitySpace = space;
    this.lastTime = (timeline.getTime() * timeline.getTotalTime() * 1000.0D);
    this.discount = this.utilitySpace.getDiscountFactor();
    if (this.discount >= 1.0D) {
      this.discount = 0.0D;
    }
    this.timeline = timeline;
    this.delta = (1.0D / (timeline.getTotalTime() * 1000.0D));
    this.vmodel = vmodeler;
    this.allBids = allBids;
    this.agent = agent;
  }
  
  public void tick()
  {
    double newTime = this.timeline.getTime() * this.timeline.getTotalTime() * 1000.0D;
    this.delta = (0.8D * this.delta + (newTime - this.lastTime) / 5.0D);
  }
  
  private int expectedBidsToConvergence()
  {
    return 10;
  }
  
  public int expectedBidsToTimeout()
  {
    if (this.delta > 0.0D) {
      return (int)((1.0D - this.timeline.getTime()) / this.delta);
    }
    return (int)(1.0D - this.timeline.getTime()) * 1000;
  }
  
  public double expectedDiscountRatioToConvergence()
  {
    double expectedPart = expectedBidsToConvergence() * this.delta;
    if (this.timeline.getTime() + expectedPart > 1.0D) {
      return 1.1D;
    }
    double div = 1.0D - this.discount * expectedPart;
    if (div > 0.0D) {
      return 1.0D / div;
    }
    return 1.1D;
  }
  
  public double guessCurrentBidUtil()
  {
    int s2 = this.theirPastBids.bids.size();
    if (s2 == 0) {
      return 1.0D;
    }
    double sum = 0.0D;
    double count = 0.0D;
    double symetricLowerBound = ((BidWrapper)this.allBids.bids.get(s2)).ourUtility;
    for (int i = s2 - 2; (i >= 0) && (i > s2 - 50); i--)
    {
      ((BidWrapper)this.theirPastBids.bids.get(i)).update(this.vmodel);
      if (((BidWrapper)this.theirPastBids.bids.get(i)).theirUtilityReliability > 0.7D)
      {
        sum += ((BidWrapper)this.theirPastBids.bids.get(i)).theirUtility;
        count += 1.0D;
      }
    }
    double shield = this.timeline.getTime() * 0.6D;
    if (shield < 0.03D) {
      shield = 0.03D;
    }
    double minBound = symetricLowerBound;
    if ((count >= 5.0D) && (sum / count < minBound)) {
      minBound = sum / count;
    }
    if (minBound > 1.0D - shield) {
      return minBound;
    }
    return 1.0D - shield;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.ValueModelAgent.OpponentModeler
 * JD-Core Version:    0.7.1
 */