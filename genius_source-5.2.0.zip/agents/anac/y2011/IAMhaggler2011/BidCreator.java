package agents.anac.y2011.IAMhaggler2011;

import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public abstract interface BidCreator
{
  public abstract Bid getBid(UtilitySpace paramUtilitySpace, double paramDouble1, double paramDouble2);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.IAMhaggler2011.BidCreator
 * JD-Core Version:    0.7.1
 */