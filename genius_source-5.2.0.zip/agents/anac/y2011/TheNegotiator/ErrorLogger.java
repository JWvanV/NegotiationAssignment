package agents.anac.y2011.TheNegotiator;

import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class ErrorLogger
{
  static boolean initialized = false;
  static Logger logger;
  
  public static void log(String error)
  {
    if (!initialized)
    {
      logger = Logger.getLogger("MyLog");
      try
      {
        FileHandler fh = new FileHandler("Errors.html", true);
        logger.addHandler(fh);
        logger.setLevel(Level.ALL);
        SimpleFormatter formatter = new SimpleFormatter();
        fh.setFormatter(formatter);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      initialized = true;
    }
    logger.log(Level.INFO, error + "<br></br>");
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.ErrorLogger
 * JD-Core Version:    0.7.1
 */