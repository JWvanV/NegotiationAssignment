package agents.anac.y2011.TheNegotiator;

import negotiator.Bid;

public class UTBid
  implements Comparable<UTBid>
{
  private Bid bid;
  private double utility;
  private boolean alreadyOffered;
  
  public UTBid(Bid bid, double utility)
  {
    this.bid = bid;
    this.utility = utility;
    this.alreadyOffered = false;
  }
  
  public Bid getBid()
  {
    return this.bid;
  }
  
  public void setBid(Bid bid)
  {
    this.bid = bid;
  }
  
  public double getUtility()
  {
    return this.utility;
  }
  
  public void setUtility(double utility)
  {
    this.utility = utility;
  }
  
  public boolean getAlreadyOffered()
  {
    return this.alreadyOffered;
  }
  
  public void setAlreadyOffered(boolean offered)
  {
    this.alreadyOffered = offered;
  }
  
  public int compareTo(UTBid utbid)
  {
    double otherUtil = utbid.getUtility();
    
    int value = 0;
    if (this.utility < otherUtil) {
      value = 1;
    } else if (this.utility > otherUtil) {
      value = -1;
    }
    return value;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.UTBid
 * JD-Core Version:    0.7.1
 */