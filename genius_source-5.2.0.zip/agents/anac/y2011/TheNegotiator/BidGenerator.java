package agents.anac.y2011.TheNegotiator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Agent;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class BidGenerator
{
  private BidsCollection bidsCollection;
  private Agent agent;
  private double randomMove = 0.300000011920929D;
  private Random random100;
  private final boolean TEST_EQUIVALENCE = false;
  
  public BidGenerator(Agent agent, BidsCollection bidsCollection)
  {
    this.agent = agent;
    this.bidsCollection = bidsCollection;
    createAllBids();
    this.bidsCollection.sortPossibleBids();
    


    this.random100 = new Random();
  }
  
  public Action determineOffer(AgentID agentID, int phase, double threshold)
  {
    Bid bid = null;
    double upperThreshold = this.bidsCollection.getUpperThreshold(threshold, 0.2D);
    if (phase == 1)
    {
      if (this.random100.nextDouble() > this.randomMove) {
        bid = this.bidsCollection.getOwnBidBetween(threshold, upperThreshold);
      } else {
        bid = this.bidsCollection.getOwnBidBetween(upperThreshold - 1.E-005D, 1.1D);
      }
    }
    else
    {
      bid = this.bidsCollection.getBestPartnerBids(threshold);
      if (bid == null) {
        if (this.random100.nextDouble() > this.randomMove) {
          bid = this.bidsCollection.getOwnBidBetween(threshold, upperThreshold);
        } else {
          bid = this.bidsCollection.getOwnBidBetween(upperThreshold - 1.E-005D, 1.1D);
        }
      }
    }
    Action action = new Offer(agentID, bid);
    return action;
  }
  
  private void createAllBids()
  {
    ArrayList<Issue> issues = this.agent.utilitySpace.getDomain().getIssues();
    
    ArrayList<IssueDiscrete> discreteIssues = new ArrayList();
    for (Issue issue : issues) {
      discreteIssues.add((IssueDiscrete)issue);
    }
    ArrayList<ArrayList<Pair<Integer, ValueDiscrete>>> result = generateAllBids(discreteIssues, 0);
    for (ArrayList<Pair<Integer, ValueDiscrete>> bidSet : result)
    {
      HashMap<Integer, Value> values = new HashMap();
      for (Pair<Integer, ValueDiscrete> pair : bidSet) {
        values.put(pair.getFirst(), pair.getSecond());
      }
      try
      {
        Bid bid = new Bid(this.agent.utilitySpace.getDomain(), values);
        double utility = this.agent.utilitySpace.getUtility(bid);
        this.bidsCollection.addPossibleBid(bid, utility);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  private ArrayList<ArrayList<Pair<Integer, ValueDiscrete>>> generateAllBids(ArrayList<IssueDiscrete> issueList, int i)
  {
    if (i == issueList.size())
    {
      ArrayList<ArrayList<Pair<Integer, ValueDiscrete>>> result = new ArrayList();
      result.add(new ArrayList());
      return result;
    }
    ArrayList<ArrayList<Pair<Integer, ValueDiscrete>>> result = new ArrayList();
    ArrayList<ArrayList<Pair<Integer, ValueDiscrete>>> recursive = generateAllBids(issueList, i + 1);
    for (int j = 0; j < ((IssueDiscrete)issueList.get(i)).getValues().size(); j++) {
      for (int k = 0; k < recursive.size(); k++)
      {
        ArrayList<Pair<Integer, ValueDiscrete>> newList = new ArrayList();
        for (Pair<Integer, ValueDiscrete> set : (ArrayList)recursive.get(k)) {
          newList.add(set);
        }
        ValueDiscrete value = (ValueDiscrete)((IssueDiscrete)issueList.get(i)).getValues().get(j);
        int issueNr = ((IssueDiscrete)issueList.get(i)).getNumber();
        newList.add(new Pair(Integer.valueOf(issueNr), value));
        

        result.add(newList);
      }
    }
    return result;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.BidGenerator
 * JD-Core Version:    0.7.1
 */