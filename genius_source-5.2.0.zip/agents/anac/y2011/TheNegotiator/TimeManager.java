package agents.anac.y2011.TheNegotiator;

import java.util.ArrayList;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;

public class TimeManager
{
  private Timeline timeline;
  private final double totalTime = 180.0D;
  private final double[] endPhases1 = { 0.7777777777777778D, 0.1944444444444445D, 0.02777777777777778D };
  private final double[] maxThresArray1 = { 0.0D, 0.0D, 0.0D, 0.0D };
  private final double[] endPhases2 = { 0.0D, 0.0D, 0.0D };
  private final double[] maxThresArray2 = { 0.0D, 0.0D, 0.0D, 0.0D };
  private BidsCollection bidsCollection;
  private final int[] propArray = { 0, 0, 0 };
  private Queue queue = new Queue();
  private int queueSize = 15;
  double lastTime = 0.0D;
  double discount;
  
  public TimeManager(Timeline timeline, double discount, BidsCollection bidsCollection)
  {
    this.timeline = timeline;
    this.bidsCollection = bidsCollection;
    this.discount = discount;
    if (this.discount >= 1.0D) {
      this.discount = 0.0D;
    }
    calculateEndPhaseThresholds();
    if (this.discount != 0.0D)
    {
      calculatePropArray();
      calculateEndPhases();
    }
  }
  
  private void calculateEndPhaseThresholds()
  {
    this.maxThresArray1[0] = ((BidDetails)this.bidsCollection.getPossibleBids().get(0)).getMyUndiscountedUtil();
    this.maxThresArray1[3] = ((BidDetails)this.bidsCollection.getPossibleBids().get(this.bidsCollection.getPossibleBids().size() - 1)).getMyUndiscountedUtil();
    double range = this.maxThresArray1[0] - this.maxThresArray1[3];
    this.maxThresArray1[1] = (this.maxThresArray1[0] - 0.125D * range);
    this.maxThresArray1[2] = (this.maxThresArray1[0] - 0.375D * range);
  }
  
  public int getPhase(double time)
  {
    int phase = 1;
    double[] endPhases = this.endPhases1;
    if ((this.discount != 0.0D) && (time > this.discount)) {
      endPhases = this.endPhases2;
    }
    if (time > endPhases[1] + endPhases[0])
    {
      double lapsedTime = time - this.lastTime;
      this.queue.enqueue(Double.valueOf(lapsedTime));
      if (this.queue.size() > this.queueSize) {
        this.queue.dequeue();
      }
      phase = 3;
    }
    else if (time > endPhases[0])
    {
      phase = 2;
    }
    this.lastTime = time;
    return phase;
  }
  
  public double getThreshold(double time)
  {
    int phase = getPhase(time);
    double threshold = 0.98D;
    double[] maxThresArray = this.maxThresArray1;
    double[] endPhases = this.endPhases1;
    if ((this.discount != 0.0D) && (time > this.discount))
    {
      maxThresArray = this.maxThresArray2;
      endPhases = this.endPhases2;
    }
    double discountActive = this.discount;
    if (time <= this.discount) {
      discountActive = 0.0D;
    }
    switch (phase)
    {
    case 1: 
      threshold = maxThresArray[0] - (time - discountActive) / (endPhases[0] - discountActive) * (maxThresArray[0] - maxThresArray[1]); break;
    case 2: 
      threshold = maxThresArray[1] - (time - endPhases[0]) / endPhases[1] * (maxThresArray[1] - maxThresArray[2]); break;
    case 3: 
      threshold = maxThresArray[2] - (time - endPhases[0] - endPhases[1]) / endPhases[2] * (maxThresArray[2] - maxThresArray[3]); break;
    default: 
      ErrorLogger.log("Unknown phase: " + phase);
    }
    return threshold;
  }
  
  public int getMovesLeft()
  {
    int movesLeft = -1;
    if (this.queue.isEmpty())
    {
      movesLeft = 500;
    }
    else
    {
      Double[] lapsedTimes = this.queue.toArray();
      double total = 0.0D;
      for (int i = 0; i < this.queueSize; i++) {
        if (lapsedTimes[i] != null) {
          total += lapsedTimes[i].doubleValue();
        }
      }
      movesLeft = (int)Math.floor((1.0D - this.timeline.getTime()) / (total / this.queueSize));
    }
    return movesLeft;
  }
  
  public void calculatePropArray()
  {
    ArrayList<BidDetails> posBids = this.bidsCollection.getPossibleBids();
    
    double max = getThreshold(this.discount);
    double min = ((BidDetails)this.bidsCollection.getPossibleBids().get(this.bidsCollection.getPossibleBids().size() - 1)).getMyUndiscountedUtil();
    double range = max - min;
    double rangeStep = range / 3.0D;
    for (int i = 0; i < posBids.size(); i++)
    {
      double util = ((BidDetails)posBids.get(i)).getMyUndiscountedUtil();
      if ((util >= max - rangeStep) && (util <= max)) {
        this.propArray[0] += 1;
      } else if ((util >= max - 2.0D * rangeStep) && (util < max - rangeStep)) {
        this.propArray[1] += 1;
      } else if ((util >= max - 3.0D * rangeStep) && (util < max - 2.0D * rangeStep)) {
        this.propArray[2] += 1;
      }
    }
    ArrayList<BidDetails> bidsCol = this.bidsCollection.getPossibleBids();
    this.maxThresArray2[0] = max;
    if (this.propArray[0] == 0) {
      this.maxThresArray2[1] = ((BidDetails)bidsCol.get(0)).getMyUndiscountedUtil();
    } else {
      this.maxThresArray2[1] = ((BidDetails)bidsCol.get(this.propArray[0] - 1)).getMyUndiscountedUtil();
    }
    if (this.propArray[0] + this.propArray[1] - 1 >= 0) {
      this.maxThresArray2[2] = ((BidDetails)bidsCol.get(this.propArray[0] + this.propArray[1] - 1)).getMyUndiscountedUtil();
    } else {
      this.maxThresArray2[2] = ((BidDetails)bidsCol.get(0)).getMyUndiscountedUtil();
    }
    this.maxThresArray2[3] = min;
  }
  
  public void calculateEndPhases()
  {
    int sum = 0;
    for (int i = 0; i < this.propArray.length; i++) {
      sum += this.propArray[i];
    }
    this.endPhases2[0] = (this.discount + this.propArray[0] / sum * (1.0D - this.discount));
    this.endPhases2[1] = (this.propArray[1] / sum * (1.0D - this.discount));
    this.endPhases2[2] = (this.propArray[2] / sum * (1.0D - this.discount));
  }
  
  public double getTime()
  {
    return this.timeline.getTime();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.TimeManager
 * JD-Core Version:    0.7.1
 */