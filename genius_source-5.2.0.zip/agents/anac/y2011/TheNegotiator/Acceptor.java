package agents.anac.y2011.TheNegotiator;

import java.util.ArrayList;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.utility.UtilitySpace;

public class Acceptor
{
  private UtilitySpace utilitySpace;
  private BidsCollection bidsCollection;
  
  public Acceptor(UtilitySpace utilitySpace, BidsCollection bidsCollection)
  {
    this.utilitySpace = utilitySpace;
    this.bidsCollection = bidsCollection;
  }
  
  public Action determineAccept(int phase, double threshold, double time, int movesLeft)
  {
    Action action = null;
    double utility = 0.0D;
    try
    {
      if (this.bidsCollection.getPartnerBids().size() > 0) {
        utility = this.utilitySpace.getUtility(this.bidsCollection.getPartnerBid(0));
      }
    }
    catch (Exception e) {}
    if ((phase == 1) || (phase == 2))
    {
      if (utility >= threshold) {
        action = new Accept();
      }
    }
    else if (movesLeft >= 15)
    {
      if (utility >= threshold) {
        action = new Accept();
      }
    }
    else if (movesLeft < 15) {
      action = new Accept();
    }
    return action;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.Acceptor
 * JD-Core Version:    0.7.1
 */