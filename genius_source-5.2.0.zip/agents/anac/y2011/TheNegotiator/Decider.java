package agents.anac.y2011.TheNegotiator;

import negotiator.Agent;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class Decider
{
  private BidsCollection bidsCollection;
  private TimeManager timeManager;
  private BidGenerator bidGenerator;
  private Acceptor acceptor;
  private Agent agent;
  
  public Decider(Agent agent)
  {
    this.agent = agent;
    this.bidsCollection = new BidsCollection();
    this.bidGenerator = new BidGenerator(agent, this.bidsCollection);
    this.acceptor = new Acceptor(agent.utilitySpace, this.bidsCollection);
    this.timeManager = new TimeManager(agent.timeline, agent.utilitySpace.getDiscountFactor(), this.bidsCollection);
  }
  
  public void setPartnerMove(Action action)
  {
    if ((action instanceof Offer))
    {
      Bid bid = ((Offer)action).getBid();
      try
      {
        this.bidsCollection.addPartnerBid(bid, this.agent.utilitySpace.getUtility(bid), this.timeManager.getTime());
      }
      catch (Exception e) {}
    }
  }
  
  public Action makeDecision()
  {
    int phase = this.timeManager.getPhase(this.timeManager.getTime());
    int movesLeft = 0;
    if (phase == 3) {
      movesLeft = this.timeManager.getMovesLeft();
    }
    double threshold = this.timeManager.getThreshold(this.timeManager.getTime());
    Action action = this.acceptor.determineAccept(phase, threshold, this.agent.timeline.getTime(), movesLeft);
    if (action == null) {
      action = this.bidGenerator.determineOffer(this.agent.getAgentID(), phase, this.timeManager.getThreshold(this.timeManager.getTime()));
    }
    return action;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.Decider
 * JD-Core Version:    0.7.1
 */