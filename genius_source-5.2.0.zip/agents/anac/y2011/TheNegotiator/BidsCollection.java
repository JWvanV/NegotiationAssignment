package agents.anac.y2011.TheNegotiator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import negotiator.Bid;
import negotiator.bidding.BidDetails;

public class BidsCollection
{
  private ArrayList<BidDetails> partnerBids;
  private ArrayList<BidDetails> possibleBids;
  private Random random200;
  private final boolean TEST_EQUIVALENCE = false;
  
  public BidsCollection()
  {
    this.partnerBids = new ArrayList();
    this.possibleBids = new ArrayList();
    


    this.random200 = new Random(200L);
  }
  
  public ArrayList<BidDetails> getPartnerBids()
  {
    return this.partnerBids;
  }
  
  public ArrayList<BidDetails> getPossibleBids()
  {
    return this.possibleBids;
  }
  
  public void addPartnerBid(Bid bid, double utility, double time)
  {
    BidDetails utbid = new BidDetails(bid, utility, time);
    this.partnerBids.add(0, utbid);
  }
  
  public void addPossibleBid(Bid bid, double utility)
  {
    BidDetails utbid = new BidDetails(bid, utility, -1.0D);
    this.possibleBids.add(utbid);
  }
  
  public void sortPossibleBids()
  {
    Collections.sort(this.possibleBids);
  }
  
  public Bid getPartnerBid(int i)
  {
    Bid bid = null;
    if (i < this.partnerBids.size()) {
      bid = ((BidDetails)this.partnerBids.get(i)).getBid();
    } else {
      ErrorLogger.log("BIDSCOLLECTION: Out of bounds");
    }
    return bid;
  }
  
  public Bid getBestPartnerBids(double threshold)
  {
    ArrayList<BidDetails> temp = this.partnerBids;
    


    Collections.sort(temp);
    
    Bid bid = null;
    
    int count = 0;
    while ((count < temp.size()) && (((BidDetails)temp.get(count)).getMyUndiscountedUtil() >= threshold)) {
      count++;
    }
    if (count > 0) {
      bid = ((BidDetails)temp.get(this.random200.nextInt(count))).getBid();
    }
    return bid;
  }
  
  public Bid getOwnBidBetween(double lowerThres, double upperThres)
  {
    return getOwnBidBetween(lowerThres, upperThres, 0);
  }
  
  public Bid getOwnBidBetween(double lowerThres, double upperThres, int counter)
  {
    int lB = 0;
    int uB = 0;
    Bid bid = null;
    for (int i = 0; i < this.possibleBids.size(); i++)
    {
      double util = ((BidDetails)this.possibleBids.get(i)).getMyUndiscountedUtil();
      if (util > upperThres) {
        uB++;
      }
      if (util >= lowerThres) {
        lB++;
      }
    }
    if (lB == uB)
    {
      if (counter == 1) {
        return ((BidDetails)this.possibleBids.get(0)).getBid();
      }
      bid = getOwnBidBetween(lowerThres, 1.1D, 1);
    }
    else
    {
      if (lB > 0) {
        lB--;
      }
      if (uB + 1 <= lB) {
        uB++;
      }
      int result = uB + (int)(this.random200.nextDouble() * (lB - uB) + 0.5D);
      bid = ((BidDetails)this.possibleBids.get(result)).getBid();
    }
    return bid;
  }
  
  public double getUpperThreshold(double threshold, double percentage)
  {
    int boundary = 0;
    while ((boundary < this.possibleBids.size()) && (((BidDetails)this.possibleBids.get(boundary)).getMyUndiscountedUtil() >= threshold)) {
      boundary++;
    }
    if (boundary > 0) {
      boundary--;
    }
    int index = boundary - (int)Math.ceil(percentage * boundary);
    
    double utility = ((BidDetails)this.possibleBids.get(index)).getMyUndiscountedUtil();
    return utility;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.BidsCollection
 * JD-Core Version:    0.7.1
 */