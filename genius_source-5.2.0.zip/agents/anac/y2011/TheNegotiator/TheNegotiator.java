package agents.anac.y2011.TheNegotiator;

import negotiator.Agent;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Action;

public class TheNegotiator
  extends Agent
{
  private Decider decider;
  
  public void init()
  {
    this.decider = new Decider(this);
  }
  
  public String getVersion()
  {
    return "3.0";
  }
  
  public String getName()
  {
    return "The Negotiator";
  }
  
  public void ReceiveMessage(Action partnerAction)
  {
    this.decider.setPartnerMove(partnerAction);
  }
  
  public Action chooseAction()
  {
    return this.decider.makeDecision();
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.TheNegotiator
 * JD-Core Version:    0.7.1
 */