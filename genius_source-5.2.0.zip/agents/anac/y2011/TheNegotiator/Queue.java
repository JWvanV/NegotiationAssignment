package agents.anac.y2011.TheNegotiator;

public class Queue
{
  private Double[] theArray;
  private int currentSize;
  private int front;
  private int back;
  private static final int DEFAULT_CAPACITY = 15;
  
  public Queue()
  {
    this.theArray = new Double[15];
    makeEmpty();
  }
  
  public boolean isEmpty()
  {
    return this.currentSize == 0;
  }
  
  public void makeEmpty()
  {
    this.currentSize = 0;
    this.front = 0;
    this.back = -1;
  }
  
  public Double dequeue()
  {
    this.currentSize -= 1;
    
    Double returnValue = this.theArray[this.front];
    this.front = increment(this.front);
    return returnValue;
  }
  
  public Double getFront()
  {
    return this.theArray[this.front];
  }
  
  public void enqueue(Double x)
  {
    if (this.currentSize == this.theArray.length) {
      doubleQueue();
    }
    this.back = increment(this.back);
    this.theArray[this.back] = x;
    this.currentSize += 1;
  }
  
  private int increment(int x)
  {
    
    if (x == this.theArray.length) {
      x = 0;
    }
    return x;
  }
  
  private void doubleQueue()
  {
    Double[] newArray = new Double[this.theArray.length * 2];
    for (int i = 0; i < this.currentSize; this.front = increment(this.front))
    {
      newArray[i] = this.theArray[this.front];i++;
    }
    this.theArray = newArray;
    this.front = 0;
    this.back = (this.currentSize - 1);
  }
  
  public int size()
  {
    return this.currentSize;
  }
  
  public Double[] toArray()
  {
    return this.theArray;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.TheNegotiator.Queue
 * JD-Core Version:    0.7.1
 */