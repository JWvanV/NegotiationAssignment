package agents.anac.y2011.Gahboninho;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class IssueManager
{
  Timeline T;
  UtilitySpace US;
  int TotalBiddingPossibilities;
  Bid OpponentBestBid;
  double MyUtilityOnOpponentBestBid = 0.0D;
  double Noise = 0.4D;
  double NextOfferUtility = 1.0D;
  boolean FirstOfferGiven = false;
  TreeMap<Double, Bid> Bids;
  HashMap<Issue, ArrayList<Value>> relevantValuesPerIssue = new HashMap();
  Bid maxBid = null;
  final int PlayerCount = 8;
  OpponnentModel OM;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  private Random random200;
  private Random random300;
  private Random random400;
  boolean InFrenzy = false;
  
  public Bid GetMaxBidWithNoCost()
    throws Exception
  {
    Bid maxBid = this.US.getDomain().getRandomBid(this.random100);
    Bid justBidding = this.US.getDomain().getRandomBid(this.random100);
    for (Issue issue : this.US.getDomain().getIssues())
    {
      double maxUtil = 0.0D;
      int maxUtilValIndex = 0;
      double tmpUtil;
      switch (issue.getType())
      {
      case INTEGER: 
        IssueInteger integerIssue = (IssueInteger)issue;
        
        justBidding.setValue(issue.getNumber(), new ValueInteger(integerIssue.getUpperBound()));
        maxUtil = this.US.getUtility(justBidding);
        
        justBidding.setValue(issue.getNumber(), new ValueInteger(integerIssue.getLowerBound()));
        tmpUtil = this.US.getUtility(justBidding);
        if (maxUtil > tmpUtil) {
          maxBid.setValue(issue.getNumber(), new ValueInteger(integerIssue.getUpperBound()));
        } else {
          maxBid.setValue(issue.getNumber(), new ValueInteger(integerIssue.getLowerBound()));
        }
        break;
      case REAL: 
        IssueReal realIssue = (IssueReal)issue;
        

        justBidding.setValue(issue.getNumber(), new ValueReal(realIssue.getUpperBound()));
        maxUtil = this.US.getUtility(justBidding);
        
        justBidding.setValue(issue.getNumber(), new ValueReal(realIssue.getLowerBound()));
        tmpUtil = this.US.getUtility(justBidding);
        if (maxUtil > tmpUtil) {
          maxBid.setValue(issue.getNumber(), new ValueReal(realIssue.getUpperBound()));
        } else {
          maxBid.setValue(issue.getNumber(), new ValueReal(realIssue.getLowerBound()));
        }
        break;
      case DISCRETE: 
        IssueDiscrete discreteIssue = (IssueDiscrete)issue;
        int size = discreteIssue.getNumberOfValues();
        for (int i = 0; i < size; i++)
        {
          justBidding.setValue(issue.getNumber(), discreteIssue.getValue(i));
          tmpUtil = this.US.getUtility(justBidding);
          if (tmpUtil > maxUtil)
          {
            maxUtilValIndex = i;
            maxUtil = tmpUtil;
          }
        }
        maxBid.setValue(issue.getNumber(), discreteIssue.getValue(maxUtilValIndex));
      }
    }
    return maxBid;
  }
  
  public IssueManager(UtilitySpace US, Timeline T, OpponnentModel om)
  {
    this.random100 = new Random();
    this.random200 = new Random();
    this.random300 = new Random();
    this.random400 = new Random();
    

    this.T = T;
    this.US = US;
    this.OM = om;
    try
    {
      this.maxBid = GetMaxBidWithNoCost();
      double maxBidUtil = US.getUtility(this.maxBid);
      if (maxBidUtil == 0.0D) {
        this.maxBid = this.US.getMaxUtilityBid();
      }
    }
    catch (Exception e)
    {
      try
      {
        this.maxBid = this.US.getMaxUtilityBid();
      }
      catch (Exception e2) {}
    }
    this.Bids = new TreeMap();
    for (int i = 0; i < US.getDomain().getIssues().size(); i++)
    {
      Issue I = (Issue)US.getDomain().getIssue(i);
      if (I.getType() == ISSUETYPE.DISCRETE)
      {
        IssueDiscrete ID = (IssueDiscrete)I;
        
        this.DifferentValuesCountPerIssueNum.put(Integer.valueOf(ID.getNumber()), Integer.valueOf(ID.getNumberOfValues()));
        this.OutgoingValueAppeareancesByIssueNum.put(Integer.valueOf(ID.getNumber()), new TreeMap());
      }
      else if (I.getType() == ISSUETYPE.REAL)
      {
        this.DifferentValuesCountPerIssueNum.put(Integer.valueOf(I.getNumber()), Integer.valueOf(20));
        this.OutgoingValueAppeareancesByIssueNum.put(Integer.valueOf(I.getNumber()), new TreeMap());
      }
      else if (I.getType() == ISSUETYPE.INTEGER)
      {
        IssueInteger II = (IssueInteger)I;
        this.DifferentValuesCountPerIssueNum.put(Integer.valueOf(I.getNumber()), Integer.valueOf(Math.min(20, II.getUpperBound() - II.getLowerBound() + 1)));
        


        this.OutgoingValueAppeareancesByIssueNum.put(Integer.valueOf(I.getNumber()), new TreeMap());
      }
    }
    ClearIncommingStatistics();
  }
  
  void ClearIncommingStatistics()
  {
    for (Issue I : this.US.getDomain().getIssues()) {
      this.IncomingValueAppeareancesByIssueNum.put(Integer.valueOf(I.getNumber()), new TreeMap());
    }
  }
  
  public Bid getMaxBid()
  {
    return this.maxBid;
  }
  
  public double GetDiscountFactor()
  {
    if ((this.US.getDiscountFactor() <= 0.001D) || (this.US.getDiscountFactor() > 1.0D)) {
      return 1.0D;
    }
    return this.US.getDiscountFactor();
  }
  
  private void addPossibleValue(Issue issue, Value val)
  {
    if (!this.relevantValuesPerIssue.containsKey(issue)) {
      this.relevantValuesPerIssue.put(issue, new ArrayList());
    }
    int randIndex = 0;
    if (((ArrayList)this.relevantValuesPerIssue.get(issue)).size() > 0) {
      randIndex = Math.abs(this.random200.nextInt()) % ((ArrayList)this.relevantValuesPerIssue.get(issue)).size();
    }
    ((ArrayList)this.relevantValuesPerIssue.get(issue)).add(randIndex, val);
  }
  
  final double DiscretisationSteps = 20.0D;
  
  private void buildIssueValues(Bid firstOppBid)
    throws Exception
  {
    Bid justBidding = this.US.getDomain().getRandomBid(this.random300);
    for (Issue issue : this.US.getDomain().getIssues())
    {
      int AddedValues = 0;
      
      justBidding.setValue(issue.getNumber(), firstOppBid.getValue(issue.getNumber()));
      double utilityWithOpp = this.US.getEvaluation(issue.getNumber(), justBidding);
      switch (issue.getType())
      {
      case INTEGER: 
        IssueInteger intIssue = (IssueInteger)issue;
        

        int totalSteps = (int)Math.min(19.0D, intIssue.getUpperBound() - intIssue.getLowerBound());
        int iStep = Math.max(1, (intIssue.getUpperBound() - intIssue.getLowerBound()) / totalSteps);
        for (int i = intIssue.getLowerBound(); i <= intIssue.getUpperBound(); i += iStep)
        {
          justBidding.setValue(issue.getNumber(), new ValueInteger(i));
          double utilityWithCurrent = this.US.getEvaluation(issue.getNumber(), justBidding);
          if (utilityWithCurrent >= utilityWithOpp) {
            addPossibleValue(issue, new ValueInteger(i));
          }
        }
        AddedValues += Math.abs(intIssue.getUpperBound() - intIssue.getLowerBound());
        break;
      case REAL: 
        IssueReal realIssue = (IssueReal)issue;
        double oneStep = (realIssue.getUpperBound() - realIssue.getLowerBound()) / 19.0D;
        for (double curr = realIssue.getLowerBound(); curr <= realIssue.getUpperBound(); curr += oneStep)
        {
          justBidding.setValue(issue.getNumber(), new ValueReal(curr));
          double utilityWithCurrent = this.US.getEvaluation(issue.getNumber(), justBidding);
          if (utilityWithCurrent >= utilityWithOpp)
          {
            addPossibleValue(issue, new ValueReal(curr));
            AddedValues += 1000;
          }
        }
        break;
      case DISCRETE: 
        IssueDiscrete discreteIssue = (IssueDiscrete)issue;
        int size = discreteIssue.getNumberOfValues();
        for (int i = 0; i < size; i++)
        {
          ValueDiscrete curr = discreteIssue.getValue(i);
          justBidding.setValue(issue.getNumber(), curr);
          double utilityWithCurrent = this.US.getEvaluation(issue.getNumber(), justBidding);
          if (utilityWithCurrent >= utilityWithOpp)
          {
            addPossibleValue(issue, curr);
            AddedValues++;
          }
        }
      }
      this.EffectiveDomainBids *= AddedValues;
    }
  }
  
  Double BidsCreationTime = Double.valueOf(0.0D);
  double EffectiveDomainBids = 1.0D;
  
  public void learnBids(Bid firstOppBid)
    throws Exception
  {
    buildIssueValues(firstOppBid);
    
    double startTime = this.T.getTime();
    

    Iterator<Map.Entry<Issue, ArrayList<Value>>> MyIssueIterator = this.relevantValuesPerIssue.entrySet().iterator();
    while (MyIssueIterator.hasNext()) {
      this.IssueEntries.add(MyIssueIterator.next());
    }
    BuildBid(new HashMap(), 0, 0.05D * Math.pow(GetDiscountFactor(), 0.6D) + startTime);
    this.BidsCreationTime = Double.valueOf(this.T.getTime() - startTime);
    


    this.NoiseDecreaseRate = (0.01D * this.EffectiveDomainBids / 400.0D);
    this.NoiseDecreaseRate = Math.min(0.015D, this.NoiseDecreaseRate);
    this.NoiseDecreaseRate = Math.max(0.003D, this.NoiseDecreaseRate);
  }
  
  private ArrayList<Map.Entry<Issue, ArrayList<Value>>> IssueEntries = new ArrayList();
  int UtilityCollisionsLeft = 200000;
  
  private void BuildBid(HashMap<Integer, Value> B, int EntrySetIndex, double EndTime)
  {
    if (this.T.getTime() < EndTime)
    {
      Map.Entry<Issue, ArrayList<Value>> currentEntry;
      if (EntrySetIndex < this.IssueEntries.size())
      {
        currentEntry = (Map.Entry)this.IssueEntries.get(EntrySetIndex);
        for (Value v : (ArrayList)currentEntry.getValue())
        {
          B.put(Integer.valueOf(((Issue)currentEntry.getKey()).getNumber()), v);
          BuildBid(B, EntrySetIndex + 1, EndTime);
        }
      }
      else
      {
        try
        {
          Bid newBid = new Bid(this.US.getDomain(), new HashMap(B));
          
          double BidUtil = this.US.getUtility(newBid);
          while ((this.UtilityCollisionsLeft > 0) && (this.Bids.containsKey(Double.valueOf(BidUtil))))
          {
            this.UtilityCollisionsLeft -= 1;
            BidUtil -= 0.002D / (this.random400.nextInt() % 9999999);
          }
          this.Bids.put(Double.valueOf(BidUtil), newBid);
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
  }
  
  public double CompromosingFactor = 0.95D;
  double TimeDiffStart = -1.0D;
  double TimeDiffEnd = -1.0D;
  double RoundCountBeforePanic = 1.0D;
  double PrevRecommendation = 1.0D;
  double MaximalUtilityDecreaseRate = 0.0009D;
  int CountdownToNoiseReestimation;
  
  public double GetNextRecommendedOfferUtility()
  {
    if (!this.FirstOfferGiven)
    {
      this.FirstOfferGiven = true;
      return 1.0D;
    }
    double Time = this.T.getTime();
    double Min = Math.pow(GetDiscountFactor(), 2.0D * Time);
    double Max = Min * (1.0D + 6.0D * this.Noise * Math.pow(GetDiscountFactor(), 5.0D));
    if (Time < 0.85D * GetDiscountFactor())
    {
      Min *= Math.max(this.BestEverOpponentBidUtil, 0.9125D);
    }
    else if (Time <= 0.92D * GetDiscountFactor())
    {
      this.CompromosingFactor = 0.94D;
      Min *= Math.max(this.BestEverOpponentBidUtil, 0.84D);
      
      Max /= Min;
    }
    else if (Time <= 0.94D * GetDiscountFactor())
    {
      this.CompromosingFactor = 0.9300000000000001D;
      Min *= Math.max(this.BestEverOpponentBidUtil, 0.775D);
      Max /= Min;
    }
    else if ((Time <= 0.985D * Min) && ((this.BestEverOpponentBidUtil <= 0.25D) || (Time <= 1.0D - 3.0D * (this.TimeDiffEnd - this.TimeDiffStart) / this.RoundCountBeforePanic)))
    {
      this.CompromosingFactor = 0.91D;
      this.MaximalUtilityDecreaseRate = 0.001D;
      
      Min *= Math.max(this.BestEverOpponentBidUtil, 0.7D);
      Max /= Min;
      
      this.TimeDiffEnd = (this.TimeDiffStart = Time);
    }
    else if ((Time <= 0.9996D) && ((this.BestEverOpponentBidUtil <= 0.25D) || (Time <= 1.0D - 3.0D * (this.TimeDiffEnd - this.TimeDiffStart) / this.RoundCountBeforePanic)))
    {
      this.TimeDiffEnd = Time;
      this.RoundCountBeforePanic += 1.0D;
      
      this.MaximalUtilityDecreaseRate = (0.001D + 0.01D * (Time - 0.985D) / 0.015D);
      if (0.375D > this.BestEverOpponentBidUtil)
      {
        Min *= 0.4375D;
        this.CompromosingFactor = 0.8D;
      }
      else
      {
        Min *= this.BestEverOpponentBidUtil;
        this.CompromosingFactor = 0.95D;
      }
      Max /= Min;
    }
    else
    {
      this.CompromosingFactor = 0.92D;
      if (this.BestEverOpponentBidUtil < 0.25D)
      {
        Min = 0.25D;
        Max = 1.0D;
      }
      else
      {
        Max = Min = this.BestEverOpponentBidUtil;
        this.InFrenzy = true;
      }
      this.MaximalUtilityDecreaseRate = 1.0D;
    }
    Max = Math.max(Max, Min);
    this.NextOfferUtility = Math.min(1.0D, Max - (Max - Min) * this.T.getTime());
    if (this.NextOfferUtility + this.MaximalUtilityDecreaseRate < this.PrevRecommendation) {
      this.NextOfferUtility = (this.PrevRecommendation - this.MaximalUtilityDecreaseRate);
    } else if (this.NextOfferUtility - 0.005D > this.PrevRecommendation) {
      this.NextOfferUtility = (this.PrevRecommendation + 0.005D);
    }
    this.PrevRecommendation = this.NextOfferUtility;
    return this.NextOfferUtility;
  }
  
  public double GetMinimumUtilityToAccept()
  {
    double util1 = this.CompromosingFactor;
    double util2 = GetNextRecommendedOfferUtility();
    return util1 * util2;
  }
  
  String EstimateValue(Issue I, Value v)
    throws Exception
  {
    int ValueIndex;
    switch (I.getType())
    {
    case DISCRETE: 
      ValueDiscrete DV = (ValueDiscrete)v;
      return DV.getValue();
    case INTEGER: 
      ValueIndex = 0;
      IssueInteger II = (IssueInteger)I;
      ValueInteger IV = (ValueInteger)v;
      double Step = II.getUpperBound() - II.getLowerBound();
      if (Step != 0.0D)
      {
        int totalSteps = (int)Math.min(20.0D, II.getUpperBound() - II.getLowerBound() + 1);
        Step /= totalSteps;
        ValueIndex = (int)(IV.getValue() / Step);
      }
      return String.valueOf(ValueIndex);
    case REAL: 
      IssueReal RI = (IssueReal)I;
      ValueReal RV = (ValueReal)v;
      double StepR = RI.getUpperBound() - RI.getLowerBound();
      ValueIndex = 0;
      if (StepR != 0.0D)
      {
        StepR /= 20.0D;
        ValueIndex = (int)(RV.getValue() / StepR);
      }
      return String.valueOf(ValueIndex);
    }
    throw new Exception("illegal issue");
  }
  
  TreeMap<Integer, TreeMap<String, Integer>> IncomingValueAppeareancesByIssueNum = new TreeMap();
  TreeMap<Integer, TreeMap<String, Integer>> OutgoingValueAppeareancesByIssueNum = new TreeMap();
  TreeMap<Integer, Integer> DifferentValuesCountPerIssueNum = new TreeMap();
  int CountdownToStatisticsRefreshing = 20;
  double PreviousAverageDistance = 0.2D;
  double PreviousCountdownOpponentBestBidUtil = 1.0D;
  double BestEverOpponentBidUtil = 0.0D;
  double WorstOpponentBidEvaluatedOpponentUtil = 1.0D;
  double PrevWorstOpponentBidEvaluatedOpponentUtil = 1.0D;
  double PrevRoundWorstOpponentBidEvaluatedOpponentUtil = 1.0D;
  Bid BestEverOpponentBid = null;
  int OutgoingBidsCount = 0;
  
  void AddMyBidToStatistics(Bid OutgoingBid)
    throws Exception
  {
    this.OutgoingBidsCount += 1;
    for (Issue I : this.US.getDomain().getIssues())
    {
      String bidValueEstimation = EstimateValue(I, OutgoingBid.getValue(I.getNumber()));
      if (((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).containsKey(bidValueEstimation)) {
        ((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).put(bidValueEstimation, Integer.valueOf(((Integer)((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).get(bidValueEstimation)).intValue() + 1));
      } else {
        ((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).put(bidValueEstimation, Integer.valueOf(1));
      }
    }
  }
  
  double NoiseDecreaseRate = 0.01D;
  final int CountdownLength = 20;
  
  public void ProcessOpponentBid(Bid IncomingBid)
    throws Exception
  {
    if (this.CountdownToStatisticsRefreshing > 0)
    {
      if (this.US.getUtility(IncomingBid) > this.BestEverOpponentBidUtil)
      {
        this.BestEverOpponentBidUtil = this.US.getUtility(IncomingBid);
        this.BestEverOpponentBid = IncomingBid;
        this.Bids.put(Double.valueOf(this.BestEverOpponentBidUtil), this.BestEverOpponentBid);
      }
      double getopUtil = this.OM.EvaluateOpponentUtility(IncomingBid);
      if (this.PrevRoundWorstOpponentBidEvaluatedOpponentUtil < getopUtil) {
        this.PrevRoundWorstOpponentBidEvaluatedOpponentUtil = getopUtil;
      }
      if (this.WorstOpponentBidEvaluatedOpponentUtil > getopUtil) {
        this.WorstOpponentBidEvaluatedOpponentUtil = getopUtil;
      }
      this.CountdownToStatisticsRefreshing -= 1;
      for (Issue I : this.US.getDomain().getIssues())
      {
        String bidValueEstimation = EstimateValue(I, IncomingBid.getValue(I.getNumber()));
        if (((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).containsKey(bidValueEstimation)) {
          ((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).put(bidValueEstimation, Integer.valueOf(((Integer)((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).get(bidValueEstimation)).intValue() + 1));
        } else {
          ((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).put(bidValueEstimation, Integer.valueOf(1));
        }
      }
    }
    else
    {
      double CurrentSimilarity = 0.0D;
      for (Iterator i$ = this.US.getDomain().getIssues().iterator(); i$.hasNext();)
      {
        I = (Issue)i$.next();
        for (String val : ((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).keySet()) {
          if (((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).containsKey(val))
          {
            float outgoingVal = ((Integer)((TreeMap)this.OutgoingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).get(val)).intValue() / this.OutgoingBidsCount;
            float incomingVal = ((Integer)((TreeMap)this.IncomingValueAppeareancesByIssueNum.get(Integer.valueOf(I.getNumber()))).get(val)).intValue() / 20.0F;
            float diff = outgoingVal - incomingVal;
            float diffSqr = diff * diff;
            
            CurrentSimilarity += 1.0D / this.US.getDomain().getIssues().size() * (1.0D / ((Integer)this.DifferentValuesCountPerIssueNum.get(Integer.valueOf(I.getNumber()))).intValue()) * (1.0F - diffSqr);
          }
        }
      }
      Issue I;
      if (CurrentSimilarity > this.PreviousAverageDistance)
      {
        this.Noise += 0.05D;
      }
      else if ((this.BestEverOpponentBidUtil < this.PreviousCountdownOpponentBestBidUtil) || (this.WorstOpponentBidEvaluatedOpponentUtil < this.PrevWorstOpponentBidEvaluatedOpponentUtil))
      {
        this.Noise += this.NoiseDecreaseRate;
      }
      else
      {
        this.Noise -= this.NoiseDecreaseRate;
        if (this.PrevRoundWorstOpponentBidEvaluatedOpponentUtil > this.WorstOpponentBidEvaluatedOpponentUtil * 1.2D) {
          this.Noise -= this.NoiseDecreaseRate;
        }
        if (CurrentSimilarity * 1.1D < this.PreviousAverageDistance) {
          this.Noise -= this.NoiseDecreaseRate;
        }
      }
      this.Noise = Math.min(Math.max(this.Noise, 0.0D), 1.0D);
      this.PreviousAverageDistance = CurrentSimilarity;
      this.CountdownToStatisticsRefreshing = 20;
      this.PreviousCountdownOpponentBestBidUtil = this.BestEverOpponentBidUtil;
      this.PrevRoundWorstOpponentBidEvaluatedOpponentUtil = 1.0D;
      this.PrevWorstOpponentBidEvaluatedOpponentUtil = this.WorstOpponentBidEvaluatedOpponentUtil;
      ClearIncommingStatistics();
    }
  }
  
  public Bid GenerateBidWithAtleastUtilityOf(double MinUtility)
  {
    Map.Entry<Double, Bid> e = this.Bids.ceilingEntry(Double.valueOf(MinUtility));
    if (e == null) {
      return this.maxBid;
    }
    return (Bid)e.getValue();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Gahboninho.IssueManager
 * JD-Core Version:    0.7.1
 */