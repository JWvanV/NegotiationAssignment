package agents.anac.y2011.Gahboninho;

import java.util.TreeMap;
import negotiator.Agent;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class Gahboninho
  extends Agent
{
  final int PlayerCount = 8;
  boolean WereBidsFiltered = false;
  OpponnentModel OM;
  IssueManager IM;
  
  public void init()
  {
    super.init();
    this.OM = new OpponnentModel(this.utilitySpace, this.timeline);
    this.IM = new IssueManager(this.utilitySpace, this.timeline, this.OM);
    this.IM.Noise *= this.IM.GetDiscountFactor();
  }
  
  public String getName()
  {
    return "Gahboninho V3";
  }
  
  Bid previousBid = null;
  Bid OpponentBid = null;
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.previousBid = this.OpponentBid;
    if ((opponentAction instanceof Offer))
    {
      this.OpponentBid = ((Offer)opponentAction).getBid();
      if (this.previousBid != null) {
        try
        {
          this.IM.ProcessOpponentBid(this.OpponentBid);
          this.OM.UpdateImportance(this.OpponentBid);
        }
        catch (Exception e) {}
      } else {
        try
        {
          this.IM.learnBids(this.OpponentBid);
        }
        catch (Exception e) {}
      }
    }
  }
  
  int RoundCount = 0;
  int FirstActions = 40;
  int TotalFirstActions = 40;
  
  public Action chooseAction()
  {
    try
    {
      if ((this.FirstActions > 0) && (this.OpponentBid != null) && (this.utilitySpace.getUtility(this.OpponentBid) > 0.95D)) {
        return new Accept(getAgentID());
      }
      double threshold = this.IM.GetMinimumUtilityToAccept();
      if ((this.OpponentBid != null) && (this.utilitySpace.getUtility(this.OpponentBid) >= threshold)) {
        return new Accept(getAgentID());
      }
      this.RoundCount += 1;
      if ((!this.WereBidsFiltered) && (
        (this.timeline.getTime() > this.IM.GetDiscountFactor() * 0.9D) || 
        (this.timeline.getTime() + 3.0D * this.IM.BidsCreationTime.doubleValue() > 1.0D)))
      {
        this.WereBidsFiltered = true;
        
        int DesiredBidcount = (int)(this.RoundCount * (1.0D - this.timeline.getTime()));
        if (this.IM.Bids.size() > 200) {
          this.IM.Bids = this.OM.FilterBids(this.IM.Bids, DesiredBidcount);
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if (this.previousBid == null)
    {
      try
      {
        this.IM.AddMyBidToStatistics(this.IM.getMaxBid());
      }
      catch (Exception e2) {}
      return new Offer(getAgentID(), this.IM.getMaxBid());
    }
    Bid myBid;
    if ((this.FirstActions >= 0) && (this.timeline.getTime() < 0.15D))
    {
      double utilDecrease = 0.07499999999999996D / this.TotalFirstActions;
      
      Bid myBid = this.IM.GenerateBidWithAtleastUtilityOf(0.925D + utilDecrease * this.FirstActions);
      this.FirstActions -= 1;
    }
    else
    {
      double threshold = this.IM.GetNextRecommendedOfferUtility();
      myBid = this.IM.GenerateBidWithAtleastUtilityOf(threshold);
      if (this.IM.InFrenzy == true) {
        myBid = this.IM.BestEverOpponentBid;
      }
    }
    try
    {
      this.IM.AddMyBidToStatistics(myBid);
    }
    catch (Exception e2) {}
    return new Offer(getAgentID(), myBid);
  }
  
  public AgentID getAgentID()
  {
    return new AgentID("Gahboninho");
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Gahboninho.Gahboninho
 * JD-Core Version:    0.7.1
 */