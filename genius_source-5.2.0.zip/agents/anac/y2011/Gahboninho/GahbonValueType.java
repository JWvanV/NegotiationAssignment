package agents.anac.y2011.Gahboninho;

import negotiator.issue.Issue;
import negotiator.issue.Value;

public abstract interface GahbonValueType
{
  public abstract void INIT(Issue paramIssue);
  
  public abstract void UpdateImportance(Value paramValue);
  
  public abstract double GetNormalizedVariance();
  
  public abstract int GetUtilitiesCount();
  
  public abstract double GetExpectedUtilityByValue(Value paramValue);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Gahboninho.GahbonValueType
 * JD-Core Version:    0.7.1
 */