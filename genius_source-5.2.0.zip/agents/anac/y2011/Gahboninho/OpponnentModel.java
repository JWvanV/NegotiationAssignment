package agents.anac.y2011.Gahboninho;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class OpponnentModel
{
  UtilitySpace US;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random500;
  private Random random600;
  
  public class IssuePrediction
  {
    public double ExpectedWeight;
    public GahbonValueType Issue;
    public Issue IssueBase;
    public IssuePrediction() {}
    
    class NumericValues
      implements GahbonValueType
    {
      private final int DiscretizationResolution = 21;
      int[] ValueFrequencies;
      double MinValue;
      double MaxValue;
      
      NumericValues() {}
      
      private double TranslateValue(Value V)
      {
        if ((V instanceof ValueInteger)) {
          return ((ValueInteger)V).getValue();
        }
        return ((ValueReal)V).getValue();
      }
      
      private int GetFrequencyIndex(double V)
      {
        return (int)((V - this.MinValue) / (this.MaxValue / 20.0D));
      }
      
      boolean isFirstValue = true;
      double FirstValue;
      double BidFrequencyIndexSum = 0.0D;
      double NormalizedVariance;
      int OpponentBidCountToConsider = 0;
      
      public void UpdateImportance(Value OpponentBid)
      {
        this.OpponentBidCountToConsider += 1;
        double BidValue = TranslateValue(OpponentBid);
        if (this.isFirstValue)
        {
          this.isFirstValue = false;
          if (this.MaxValue - BidValue >= BidValue - this.MinValue) {
            this.FirstValue = this.MaxValue;
          } else {
            this.FirstValue = this.MinValue;
          }
        }
        this.ValueFrequencies[GetFrequencyIndex(BidValue)] += 1;
        this.BidFrequencyIndexSum += GetFrequencyIndex(BidValue);
        
        double AverageFrequencyIndex = this.BidFrequencyIndexSum / this.OpponentBidCountToConsider;
        
        this.NormalizedVariance = 0.0D;
        for (int i = 0; i < 21; i++)
        {
          double Distance = (AverageFrequencyIndex - i) / 20.0D;
          this.NormalizedVariance += this.ValueFrequencies[i] * Distance * Distance;
        }
      }
      
      public double GetNormalizedVariance()
      {
        return this.NormalizedVariance;
      }
      
      public int GetUtilitiesCount()
      {
        getClass();return 21;
      }
      
      public double GetExpectedUtilityByValue(Value V)
      {
        return Math.min(1.0D, Math.max(0.0D, 1.0D - Math.abs(TranslateValue(V) - this.FirstValue)));
      }
      
      public void INIT(Issue I)
      {
        getClass();this.ValueFrequencies = new int[21];
        if (I.getType() == ISSUETYPE.INTEGER)
        {
          IssueInteger II = (IssueInteger)I;
          this.MaxValue = II.getUpperBound();
          this.MinValue = II.getLowerBound();
        }
        else
        {
          IssueReal RI = (IssueReal)I;
          this.MaxValue = RI.getUpperBound();
          this.MinValue = RI.getLowerBound();
        }
      }
    }
    
    class DiscreteValues
      implements GahbonValueType
    {
      TreeMap<ValueDiscrete, Integer> OptionIndexByValue = null;
      TreeMap<Integer, ValueDiscrete> ValueByOptionIndex = null;
      int MostImportantValueOccurrencesAndBonuses = 1;
      int TotalImportanceSum = 0;
      
      DiscreteValues() {}
      
      private double GetOptionImportance(int OptionIndex)
      {
        int FirstOptionBonus = this.UpdatesCount / this.OptionOccurrencesCountByIndex.length;
        if (this.FirstIterationOptionIndex == OptionIndex) {
          return this.OptionOccurrencesCountByIndex[OptionIndex] + FirstOptionBonus;
        }
        return this.OptionOccurrencesCountByIndex[OptionIndex];
      }
      
      int UpdatesCount = 0;
      int FirstIterationOptionIndex = -1;
      int[] OptionOccurrencesCountByIndex = null;
      TreeMap<Integer, Integer> OptionIndexByImportance = new TreeMap();
      double IssueImportanceRankVariance = 0.0D;
      
      public void UpdateImportance(Value OpponentBid)
      {
        this.UpdatesCount += 1;
        
        Integer incommingOptionIndex = (Integer)this.OptionIndexByValue.get(OpponentBid);
        if (-1 == this.FirstIterationOptionIndex) {
          this.FirstIterationOptionIndex = incommingOptionIndex.intValue();
        }
        this.OptionOccurrencesCountByIndex[incommingOptionIndex.intValue()] += 1;
        

        this.OptionIndexByImportance.clear();
        
        this.MostImportantValueOccurrencesAndBonuses = 0;
        this.TotalImportanceSum = 0;
        for (int OptionIndex = 0; OptionIndex < this.OptionOccurrencesCountByIndex.length; OptionIndex++)
        {
          int OptionImportance = (int)GetOptionImportance(OptionIndex);
          this.MostImportantValueOccurrencesAndBonuses = Math.max(this.MostImportantValueOccurrencesAndBonuses, OptionImportance);
          
          this.OptionIndexByImportance.put(Integer.valueOf(OptionImportance), Integer.valueOf(OptionIndex));
          this.TotalImportanceSum += OptionImportance;
        }
        double AverageImportanceRank = 0.0D;
        int currentOptionRank = 0;
        for (Integer currentOptionIndex : this.OptionIndexByImportance.values())
        {
          AverageImportanceRank += currentOptionRank * GetOptionImportance(currentOptionIndex.intValue());
          currentOptionRank++;
        }
        AverageImportanceRank /= this.TotalImportanceSum;
        
        this.IssueImportanceRankVariance = 0.0D;
        currentOptionRank = 0;
        for (Integer currentOptionIndex : this.OptionIndexByImportance.values())
        {
          double CurrentOptionDistance = (AverageImportanceRank - currentOptionRank) / this.OptionOccurrencesCountByIndex.length;
          

          this.IssueImportanceRankVariance += this.OptionOccurrencesCountByIndex[currentOptionIndex.intValue()] * (CurrentOptionDistance * CurrentOptionDistance);
          

          currentOptionRank++;
        }
        this.IssueImportanceRankVariance /= this.TotalImportanceSum;
      }
      
      public double GetNormalizedVariance()
      {
        return this.IssueImportanceRankVariance;
      }
      
      public int GetUtilitiesCount()
      {
        return this.ValueByOptionIndex.size();
      }
      
      public double GetExpectedUtilityByValue(Value V)
      {
        int ValueIndex = ((Integer)this.OptionIndexByValue.get(V)).intValue();
        return GetOptionImportance(ValueIndex) / this.MostImportantValueOccurrencesAndBonuses;
      }
      
      public void INIT(Issue I)
      {
        IssueDiscrete DI = (IssueDiscrete)I;
        this.OptionOccurrencesCountByIndex = new int[DI.getNumberOfValues()];
        
        Comparator<ValueDiscrete> DIComparer = new Comparator()
        {
          public int compare(ValueDiscrete o1, ValueDiscrete o2)
          {
            return o1.value.compareTo(o2.value);
          }
        };
        this.OptionIndexByValue = new TreeMap(DIComparer);
        this.ValueByOptionIndex = new TreeMap();
        for (int ValueIndex = 0; ValueIndex < DI.getNumberOfValues(); ValueIndex++)
        {
          this.OptionOccurrencesCountByIndex[ValueIndex] = 0;
          
          ValueDiscrete V = (ValueDiscrete)DI.getValues().get(ValueIndex);
          this.OptionIndexByValue.put(V, Integer.valueOf(ValueIndex));
        }
      }
    }
    
    public void INIT(Issue I)
    {
      if ((I instanceof IssueDiscrete))
      {
        IssueDiscrete DI = (IssueDiscrete)I;
        String[] values = new String[DI.getValues().size()];
        int ValueIndex = 0;
        for (ValueDiscrete v : DI.getValues()) {
          values[(ValueIndex++)] = new String(v.value);
        }
        this.IssueBase = new IssueDiscrete(DI.getName(), DI.getNumber(), values);
        this.Issue = new DiscreteValues();
        this.Issue.INIT(I);
      }
      else if ((I instanceof IssueReal))
      {
        IssueReal RI = (IssueReal)I;
        this.IssueBase = new IssueReal(RI.getName(), RI.getNumber(), RI.getLowerBound(), RI.getUpperBound());
        this.Issue = new NumericValues();
        this.Issue.INIT(I);
      }
      else if ((I instanceof IssueInteger))
      {
        IssueInteger II = (IssueInteger)I;
        this.IssueBase = new IssueReal(II.getName(), II.getNumber(), II.getLowerBound(), II.getUpperBound());
        this.Issue = new NumericValues();
        this.Issue.INIT(I);
      }
    }
  }
  
  public IssuePrediction[] IssuesByIndex = null;
  public TreeMap<Integer, Integer> IPIndexByIssueNumber = new TreeMap();
  public double TotalIssueOptionsVariance;
  private Timeline timeline;
  
  public OpponnentModel(UtilitySpace utilitySpace, Timeline timeline)
  {
    this.random500 = new Random();
    this.random600 = new Random();
    

    this.US = utilitySpace;
    this.timeline = timeline;
    this.IssuesByIndex = new IssuePrediction[this.US.getDomain().getIssues().size()];
    ArrayList<Issue> IA = this.US.getDomain().getIssues();
    for (int IssueIndex = 0; IssueIndex < IA.size(); IssueIndex++)
    {
      this.IssuesByIndex[IssueIndex] = new IssuePrediction();
      this.IssuesByIndex[IssueIndex].INIT((Issue)IA.get(IssueIndex));
      this.IPIndexByIssueNumber.put(Integer.valueOf(((Issue)IA.get(IssueIndex)).getNumber()), Integer.valueOf(IssueIndex));
    }
  }
  
  TreeMap<String, Bid> OpponentBids = new TreeMap();
  
  public void UpdateImportance(Bid OpponentBid)
    throws Exception
  {
    String bidStr = OpponentBid.toString();
    if (this.OpponentBids.containsKey(bidStr)) {
      return;
    }
    this.OpponentBids.put(bidStr, OpponentBid);
    

    double ZeroVarianceToMinimalVarianceWeight = 3.0D;
    


    this.TotalIssueOptionsVariance = 0.0D;
    
    double MinimalNonZeroVariance = Double.MAX_VALUE;
    int ZeroVarianceIssueCount = 0;
    for (int IssueIndex = 0; IssueIndex < this.IssuesByIndex.length; IssueIndex++)
    {
      int IssueID = this.IssuesByIndex[IssueIndex].IssueBase.getNumber();
      this.IssuesByIndex[IssueIndex].Issue.UpdateImportance(OpponentBid.getValue(IssueID));
      
      double IssueVariance = this.IssuesByIndex[IssueIndex].Issue.GetNormalizedVariance();
      
      this.TotalIssueOptionsVariance += IssueVariance;
      if (0.0D == IssueVariance) {
        ZeroVarianceIssueCount++;
      } else {
        MinimalNonZeroVariance = Math.min(IssueVariance, MinimalNonZeroVariance);
      }
    }
    this.TotalIssueOptionsVariance /= MinimalNonZeroVariance * 0.3333333333333333D;
    


    this.TotalIssueOptionsVariance += ZeroVarianceIssueCount;
    
    double WeightCount = 0.0D;
    if (this.TotalIssueOptionsVariance != ZeroVarianceIssueCount)
    {
      double VarianceUnit = MinimalNonZeroVariance / 3.0D;
      for (int IssueIndex = this.IssuesByIndex.length - 1; IssueIndex >= 0; IssueIndex--)
      {
        if (0.0D == this.IssuesByIndex[IssueIndex].Issue.GetNormalizedVariance()) {
          this.IssuesByIndex[IssueIndex].ExpectedWeight = 1.0D;
        } else {
          this.IssuesByIndex[IssueIndex].ExpectedWeight = (VarianceUnit / this.IssuesByIndex[IssueIndex].Issue.GetNormalizedVariance());
        }
        WeightCount += this.IssuesByIndex[IssueIndex].ExpectedWeight;
      }
    }
    for (int IssueIndex = this.IssuesByIndex.length - 1; IssueIndex >= 0; IssueIndex--) {
      if (this.TotalIssueOptionsVariance == ZeroVarianceIssueCount) {
        this.IssuesByIndex[IssueIndex].ExpectedWeight = (1.0D / this.IssuesByIndex.length);
      } else {
        this.IssuesByIndex[IssueIndex].ExpectedWeight /= WeightCount;
      }
    }
  }
  
  public double EvaluateOpponentUtility(Bid B)
    throws Exception
  {
    double UtilitySum = 0.0D;
    try
    {
      for (int IssueIndex = 0; IssueIndex < this.IssuesByIndex.length; IssueIndex++)
      {
        int IssueID = this.IssuesByIndex[IssueIndex].IssueBase.getNumber();
        UtilitySum += this.IssuesByIndex[IssueIndex].ExpectedWeight * this.IssuesByIndex[IssueIndex].Issue.GetExpectedUtilityByValue(B.getValue(IssueID));
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return UtilitySum;
  }
  
  TreeMap<Integer, TreeMap<String, ValueDiscrete>> ValueTranslation = new TreeMap();
  
  public Value ImproveValue(int IssueNumber, ValueDiscrete ValToImprove)
    throws Exception
  {
    TreeMap<String, ValueDiscrete> ValueTranslator = (TreeMap)this.ValueTranslation.get(Integer.valueOf(IssueNumber));
    ValueDiscrete resultValue = new ValueDiscrete(ValToImprove.toString());
    if (ValueTranslator != null)
    {
      resultValue = (ValueDiscrete)ValueTranslator.get(ValToImprove.toString());
      if (resultValue != null) {
        return resultValue;
      }
    }
    else
    {
      ValueTranslator = new TreeMap();
      this.ValueTranslation.put(Integer.valueOf(IssueNumber), ValueTranslator);
    }
    IssuePrediction IS = this.IssuesByIndex[((Integer)this.IPIndexByIssueNumber.get(Integer.valueOf(IssueNumber))).intValue()];
    Issue I = IS.IssueBase;
    Bid tmpBid = this.US.getDomain().getRandomBid(this.random500);
    tmpBid.setValue(IssueNumber, ValToImprove);
    
    double oppUtilityWithVal = IS.Issue.GetExpectedUtilityByValue(ValToImprove);
    double utilityWithVal = this.US.getEvaluation(IssueNumber, tmpBid);
    if (!(I instanceof IssueDiscrete)) {
      return ValToImprove;
    }
    IssueDiscrete DI = (IssueDiscrete)I;
    

    int size = DI.getNumberOfValues();
    for (int i = 0; i < size; i++)
    {
      ValueDiscrete curr = DI.getValue(i);
      tmpBid.setValue(IssueNumber, curr);
      double myUtilityWithCurrent = this.US.getEvaluation(IssueNumber, tmpBid);
      double oppUtilityWithCurrent = IS.Issue.GetExpectedUtilityByValue(curr);
      if ((myUtilityWithCurrent >= utilityWithVal) && (oppUtilityWithCurrent > oppUtilityWithVal * 1.3D))
      {
        oppUtilityWithVal = oppUtilityWithCurrent;
        resultValue = curr;
      }
    }
    ValueTranslator.put(ValToImprove.toString(), resultValue);
    
    return resultValue;
  }
  
  public Bid ImproveBid(Bid BidToImprove)
    throws Exception
  {
    Bid resultBid = this.US.getDomain().getRandomBid(this.random600);
    for (Issue issue : this.US.getDomain().getIssues()) {
      try
      {
        if (issue.getType() == ISSUETYPE.DISCRETE) {
          resultBid.setValue(issue.getNumber(), ImproveValue(issue.getNumber(), (ValueDiscrete)BidToImprove.getValue(issue.getNumber())));
        } else {
          resultBid.setValue(issue.getNumber(), BidToImprove.getValue(issue.getNumber()));
        }
      }
      catch (Exception e)
      {
        try
        {
          resultBid.setValue(issue.getNumber(), (ValueDiscrete)BidToImprove.getValue(issue.getNumber()));
        }
        catch (Exception E)
        {
          return BidToImprove;
        }
      }
    }
    return resultBid;
  }
  
  public TreeMap<Double, Bid> FilterBids(TreeMap<Double, Bid> Bids, int DesiredResultEntries)
    throws Exception
  {
    TreeMap<Double, Bid> resultBids = new TreeMap();
    Map.Entry<Double, Bid> bidIter = Bids.lastEntry();
    
    double BestKey = ((Double)bidIter.getKey()).doubleValue();
    Bid bestBid = (Bid)bidIter.getValue();
    double bestOppUtil = EvaluateOpponentUtility(bestBid);
    resultBids.put(Double.valueOf(BestKey), bestBid);
    
    bidIter = Bids.lowerEntry(bidIter.getKey());
    while ((bidIter != null) && (this.timeline.getTime() < 0.94D))
    {
      Bid checkedBid = (Bid)bidIter.getValue();
      double checkedKey = this.US.getUtility(checkedBid);
      double checkedOppUtil = EvaluateOpponentUtility(checkedBid);
      if (checkedOppUtil >= bestOppUtil * 0.84D)
      {
        resultBids.put(Double.valueOf(checkedKey), checkedBid);
        if (checkedOppUtil > bestOppUtil)
        {
          bestBid = checkedBid;
          BestKey = checkedKey;
          bestOppUtil = checkedOppUtil;
        }
      }
      bidIter = Bids.lowerEntry(bidIter.getKey());
    }
    if ((resultBids.size() < DesiredResultEntries / 10) || (resultBids.size() < 20)) {
      return Bids;
    }
    return resultBids;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Gahboninho.OpponnentModel
 * JD-Core Version:    0.7.1
 */