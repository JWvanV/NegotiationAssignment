package agents.anac.y2011.Nice_Tit_for_Tat;

import agents.bayesianopponentmodel.BayesianOpponentModelScalable;
import agents.bayesianopponentmodel.OpponentModelUtilSpace;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.bidding.BidDetails;
import negotiator.utility.UtilitySpace;

public class NiceTitForTat
  extends BilateralAgent
{
  private static final double TIME_USED_TO_DETERMINE_OPPONENT_STARTING_POINT = 0.01D;
  private int offeredOpponentBestBid = 0;
  private long DOMAINSIZE;
  private BayesianOpponentModelScalable opponentModel;
  private double myNashUtility;
  private double initialGap;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  
  public String getName()
  {
    return "Nice Tit for Tat Agent";
  }
  
  public String getVersion()
  {
    return "3.14";
  }
  
  public void init()
  {
    super.init();
    prepareOpponentModel();
    this.DOMAINSIZE = this.domain.getNumberOfPossibleBids();
    


    this.random100 = new Random();
    
    log("Domain size: " + this.DOMAINSIZE);
  }
  
  protected void prepareOpponentModel()
  {
    this.opponentModel = new BayesianOpponentModelScalable(this.utilitySpace);
  }
  
  public Bid chooseCounterBid()
  {
    Bid opponentLastBid = getOpponentLastBid();
    
    double time = this.timeline.getTime();
    log("---------- t = " + time + "----------\n");
    if (canUpdateBeliefs(time))
    {
      updateBeliefs(opponentLastBid);
      updateMyNashUtility();
    }
    double myUtilityOfOpponentLastBid = getUtility(opponentLastBid);
    
    double maximumOfferedUtilityByOpponent = this.opponentHistory.getMaximumUtility();
    
    double minimumOfferedUtilityByOpponent = this.opponentHistory.getMinimumUtility();
    
    double minUtilityOfOpponentFirstBids = getMinimumUtilityOfOpponentFirstBids(myUtilityOfOpponentLastBid);
    
    double opponentConcession = maximumOfferedUtilityByOpponent - minUtilityOfOpponentFirstBids;
    




    double opponentConcedeFactor = Math.min(1.0D, opponentConcession / (this.myNashUtility - minUtilityOfOpponentFirstBids));
    
    double myConcession = opponentConcedeFactor * (1.0D - this.myNashUtility);
    
    double myCurrentTargetUtility = 1.0D - myConcession;
    
    log("Min/Max utility offered by opponent was " + 
      round2(minimumOfferedUtilityByOpponent) + "/" + 
      round2(maximumOfferedUtilityByOpponent) + ". (Right now, he offers me " + 
      
      round2(myUtilityOfOpponentLastBid) + ")\n" + "The minimum of his first few bids is " + 
      
      round2(minUtilityOfOpponentFirstBids) + " so his concession is " + 
      round2(opponentConcession) + ", which is at " + 
      percentage(opponentConcedeFactor) + "%\n" + "So I concede the same factor and my concession is " + 
      
      round2(myConcession) + ". Therefore, my current target util is " + 
      
      round2(myCurrentTargetUtility));
    
    this.initialGap = (1.0D - minUtilityOfOpponentFirstBids);
    double gapToNash = Math.max(0.0D, myCurrentTargetUtility - this.myNashUtility);
    
    double bonus = getBonus();
    double tit = bonus * gapToNash;
    myCurrentTargetUtility -= tit;
    log("The gap to Nash is then " + round2(gapToNash) + ". I will add another bonus of " + 
      round2(tit) + " (=" + 
      percentage(bonus) + "%)" + " to have a target util of " + myCurrentTargetUtility);
    

    List<Bid> myBids = getBidsOfUtility(myCurrentTargetUtility);
    Bid myBid = getBestBidForOpponent(myBids);
    myBid = makeAppropriate(myBid);
    log(" so I choose a bid with util " + getUtility(myBid));
    return myBid;
  }
  
  private boolean canUpdateBeliefs(double time)
  {
    if (time > 0.99D) {
      return false;
    }
    if ((isDomainBig()) && 
      (time > 0.5D)) {
      return false;
    }
    return true;
  }
  
  private double getBonus()
  {
    double discountFactor = this.utilitySpace.getDiscountFactor();
    double discountBonus = 0.5D - 0.4D * discountFactor;
    if (discountFactor < 1.0D) {
      log(
      
        "Discount = " + discountFactor + ", so we set discount bonus to " + percentage(discountBonus) + "%.");
    }
    boolean isBigDomain = this.DOMAINSIZE > 3000L;
    double timeBonus = 0.0D;
    double time = this.timeline.getTime();
    double minTime = 0.91D;
    if (isBigDomain) {
      minTime = 0.85D;
    }
    if (time > minTime)
    {
      if (isBigDomain) {
        log("We have a big domain of size " + this.DOMAINSIZE + ", so we start the time bonus from t = " + minTime);
      }
      timeBonus = Math.min(1.0D, 20.0D * (time - minTime));
      log("t = " + round2(time) + ", so we set time bonus to " + 
        percentage(timeBonus) + "%.");
    }
    double bonus = Math.max(discountBonus, timeBonus);
    if (bonus < 0.0D) {
      bonus = 0.0D;
    }
    if (bonus > 1.0D) {
      bonus = 1.0D;
    }
    return bonus;
  }
  
  private void updateMyNashUtility()
  {
    BidSpace bs = null;
    this.myNashUtility = 0.7D;
    try
    {
      double nashMultiplier = getNashMultiplier(this.initialGap);
      if (this.DOMAINSIZE < 200000L)
      {
        bs = new BidSpace(this.utilitySpace, new OpponentModelUtilSpace(this.opponentModel), true, false);
        

        BidPoint nash = bs.getNash();
        if ((nash != null) && (nash.getUtilityA() != null)) {
          this.myNashUtility = nash.getUtilityA().doubleValue();
        }
      }
      this.myNashUtility *= nashMultiplier;
      if (this.myNashUtility > 1.0D) {
        this.myNashUtility = 1.0D;
      }
      if (this.myNashUtility < 0.5D) {
        this.myNashUtility = 0.5D;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private double getNashMultiplier(double gap)
  {
    double mult = 1.4D - 0.6D * gap;
    if (mult < 0.0D) {
      mult = 0.0D;
    }
    return mult;
  }
  
  private void updateBeliefs(Bid opponentLastBid)
  {
    try
    {
      this.opponentModel.updateBeliefs(opponentLastBid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private double getMinimumUtilityOfOpponentFirstBids(double myUtilityOfOpponentLastBid)
  {
    BidHistory firstBids = this.opponentHistory.filterBetweenTime(0.0D, 0.01D);
    double firstBidsMinUtility;
    double firstBidsMinUtility;
    if (firstBids.size() == 0) {
      firstBidsMinUtility = this.opponentHistory.getFirstBidDetails().getMyUndiscountedUtil();
    } else {
      firstBidsMinUtility = firstBids.getMinimumUtility();
    }
    return firstBidsMinUtility;
  }
  
  private Bid makeAppropriate(Bid myPlannedBid)
  {
    Bid bestBidByOpponent = this.opponentHistory.getBestBid();
    
    double bestUtilityByOpponent = getUtility(bestBidByOpponent);
    double myPlannedUtility = getUtility(myPlannedBid);
    if (bestUtilityByOpponent >= myPlannedUtility)
    {
      log("Opponent previously made a better offer to me than my planned util " + myPlannedUtility + ", namely  " + bestUtilityByOpponent + ", so I make that bid instead.");
      



      return bestBidByOpponent;
    }
    return myPlannedBid;
  }
  
  public Bid chooseOpeningBid()
  {
    try
    {
      return this.utilitySpace.getMaxUtilityBid();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return this.utilitySpace.getDomain().getRandomBid(this.random100);
  }
  
  public Bid chooseFirstCounterBid()
  {
    return chooseOpeningBid();
  }
  
  public boolean isAcceptable(Bid plannedBid)
  {
    double time = this.timeline.getTime();
    Bid opponentBid = getOpponentLastBid();
    Bid myNextBid = plannedBid;
    if (utility(opponentBid) >= utility(myNextBid)) {
      return true;
    }
    if (time < 0.98D) {
      return false;
    }
    double offeredUndiscountedUtility = this.opponentHistory.getLastBidDetails().getMyUndiscountedUtil();
    double now = time;
    double timeLeft = 1.0D - now;
    log("<======= new AC ========= (t = " + round3(now) + ", remaining: " + 
      round3(timeLeft) + ")");
    


    BidHistory recentBids = this.opponentHistory.filterBetweenTime(now - timeLeft, now);
    
    int recentBidsSize = recentBids.size();
    int enoughBidsToCome = 10;
    if (isDomainBig()) {
      enoughBidsToCome = 40;
    }
    if (recentBidsSize > enoughBidsToCome)
    {
      log("I expect to see " + recentBidsSize + " more bids. I will only consider accepting when it falls below " + enoughBidsToCome);
      


      return false;
    }
    double window = timeLeft;
    
    BidHistory recentBetterBids = this.opponentHistory.filterBetween(offeredUndiscountedUtility, 1.0D, now - window, now);
    
    int n = recentBetterBids.size();
    double p = timeLeft / window;
    if (p > 1.0D) {
      p = 1.0D;
    }
    double pAllMiss = Math.pow(1.0D - p, n);
    if (n == 0) {
      pAllMiss = 1.0D;
    }
    double pAtLeastOneHit = 1.0D - pAllMiss;
    
    double avg = recentBetterBids.getAverageUtility();
    
    double expectedUtilOfWaitingForABetterBid = pAtLeastOneHit * avg;
    
    log("In the previous time window of size " + window + " I have seen " + n + " better offers (out of a total of " + recentBidsSize + ") than " + 
    
      round2(offeredUndiscountedUtility) + ", with avg util " + 
      round2(avg));
    log("p = " + p + ", so pAtLeastOneHit = " + pAtLeastOneHit);
    log("expectedUtilOfWaitingForABetterBid = " + 
      round2(expectedUtilOfWaitingForABetterBid));
    log("Acceptable? " + (offeredUndiscountedUtility > expectedUtilOfWaitingForABetterBid));
    
    log("========================>\n");
    if (offeredUndiscountedUtility > expectedUtilOfWaitingForABetterBid) {
      return true;
    }
    return false;
  }
  
  protected Action makeAcceptAction()
  {
    log("We are in the final phase because the AC accepted. We have offered the best bid of our opponent " + this.offeredOpponentBestBid + " time(s).");
    



    Bid opponentBid = getOpponentLastBid();
    double offeredUtility = utility(opponentBid);
    double now = this.timeline.getTime();
    double timeLeft = 1.0D - now;
    BidHistory recentBids = this.opponentHistory.filterBetweenTime(now - timeLeft, now);
    
    int expectedBids = recentBids.size();
    Bid bestBid = this.opponentHistory.getBestBid();
    double bestBidUtility = utility(bestBid);
    log("We expect to see " + expectedBids + " more bids. The AC wants to accept the offer of utility " + 
    
      round2(offeredUtility) + " (max offered = " + 
      round2(bestBidUtility) + ").");
    if ((expectedBids > 1) && (bestBidUtility > offeredUtility) && (this.offeredOpponentBestBid <= 3))
    {
      log(
        "Which is not enough, so we will not accept now. Instead, we offer the opponent's best bid so far, which gives us utility " + utility(bestBid));
      this.offeredOpponentBestBid += 1;
      return new Offer(getAgentID(), bestBid);
    }
    log("Therefore, we will accept now.");
    return new Accept(getAgentID());
  }
  
  private double utility(Bid b)
  {
    try
    {
      return this.utilitySpace.getUtility(b);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  protected static void log(String s) {}
  
  public static double round2(double x)
  {
    return Math.round(100.0D * x) / 100.0D;
  }
  
  public static double round3(double x)
  {
    return Math.round(1000.0D * x) / 1000.0D;
  }
  
  public static double percentage(double x)
  {
    return Math.round(1000.0D * x) / 10.0D;
  }
  
  private List<Bid> getBidsOfUtility(double lowerBound, double upperBound)
  {
    int limit = 2;
    
    List<Bid> bidsInRange = new ArrayList();
    BidIterator myBidIterator = new BidIterator(this.domain);
    while (myBidIterator.hasNext())
    {
      Bid b = myBidIterator.next();
      try
      {
        double util = this.utilitySpace.getUtility(b);
        if ((util >= lowerBound) && (util <= upperBound)) {
          bidsInRange.add(b);
        }
        if ((isDomainBig()) && (bidsInRange.size() >= 2)) {
          return bidsInRange;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bidsInRange;
  }
  
  private List<Bid> getBidsOfUtility(double target)
  {
    if (target > 1.0D) {
      target = 1.0D;
    }
    double min = target * 0.98D;
    double max = target + 0.04D;
    do
    {
      max += 0.01D;
      List<Bid> bids = getBidsOfUtility(min, max);
      int size = bids.size();
      
      log(size + " bids found in [" + round2(min) + ", " + round2(max) + "]");
      if ((size > 1) || ((max >= 1.0D) && (size > 0)))
      {
        log(
          size + " bids of target utility " + round2(target) + " found in [" + round2(min) + ", " + round2(max) + "]");
        
        return bids;
      }
    } while (max <= 1.0D);
    ArrayList<Bid> best = new ArrayList();
    best.add(chooseOpeningBid());
    return best;
  }
  
  private boolean isDomainBig()
  {
    return this.DOMAINSIZE > 10000L;
  }
  
  private Bid getBestBidForOpponent(List<Bid> bids)
  {
    BidHistory possibleBidHistory = new BidHistory();
    for (Bid b : bids) {
      try
      {
        double utility = this.opponentModel.getNormalizedUtility(b);
        BidDetails bidDetails = new BidDetails(b, utility, 0.0D);
        possibleBidHistory.add(bidDetails);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    int n = (int)Math.round(bids.size() / 10.0D);
    if (n < 3) {
      n = 3;
    }
    if (n > 20) {
      n = 20;
    }
    BidHistory bestN = possibleBidHistory.getBestBidHistory(n);
    BidDetails randomBestN = bestN.getRandom(this.random100);
    log("Random bid chosen out of the top " + n + " of " + bids.size() + " bids, with opp util: " + 
    
      round2(randomBestN.getMyUndiscountedUtil()));
    return randomBestN.getBid();
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Nice_Tit_for_Tat.NiceTitForTat
 * JD-Core Version:    0.7.1
 */