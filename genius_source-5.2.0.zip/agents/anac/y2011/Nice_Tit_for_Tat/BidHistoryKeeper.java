package agents.anac.y2011.Nice_Tit_for_Tat;

import negotiator.Bid;

public abstract interface BidHistoryKeeper
{
  public abstract BidHistory getOpponentHistory();
  
  public abstract Bid getMyLastBid();
  
  public abstract Bid getMySecondLastBid();
  
  public abstract Bid getOpponentLastBid();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Nice_Tit_for_Tat.BidHistoryKeeper
 * JD-Core Version:    0.7.1
 */