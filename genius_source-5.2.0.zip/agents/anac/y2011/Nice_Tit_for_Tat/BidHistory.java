package agents.anac.y2011.Nice_Tit_for_Tat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.bidding.BidDetails;
import negotiator.bidding.BidDetailsSorterUtility;
import negotiator.utility.UtilitySpace;

public class BidHistory
  implements Iterable<BidDetails>
{
  List<BidDetails> history;
  private final boolean TEST_EQUIVALENCE = false;
  
  public BidHistory()
  {
    this.history = new ArrayList();
  }
  
  public BidHistory(BidHistory b)
  {
    this.history = new ArrayList(b.getHistory());
  }
  
  public BidHistory(UtilitySpace u)
  {
    this();
    Domain domain = u.getDomain();
    BidIterator myBidIterator = new BidIterator(domain);
    while (myBidIterator.hasNext())
    {
      Bid b = myBidIterator.next();
      double utility = 0.0D;
      try
      {
        utility = u.getUtility(b);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      BidDetails bidDetails = new BidDetails(b, utility, 0.0D);
      add(bidDetails);
    }
  }
  
  public BidHistory filterBetweenTime(double minT, double maxT)
  {
    return filterBetween(0.0D, 1.0D, minT, maxT);
  }
  
  public BidHistory filterBetween(double minU, double maxU, double minT, double maxT)
  {
    BidHistory bidHistory = new BidHistory();
    for (BidDetails b : this.history) {
      if ((minU < b.getMyUndiscountedUtil()) && (b.getMyUndiscountedUtil() <= maxU) && (minT < b.getTime()) && (b.getTime() <= maxT)) {
        bidHistory.add(b);
      }
    }
    return bidHistory;
  }
  
  public void add(BidDetails b)
  {
    this.history.add(b);
  }
  
  public BidDetails getLastBidDetails()
  {
    if (this.history.isEmpty()) {
      return null;
    }
    BidDetails bidDetails = (BidDetails)this.history.get(size() - 1);
    return bidDetails;
  }
  
  public BidDetails getFirstBidDetails()
  {
    if (this.history.isEmpty()) {
      return null;
    }
    BidDetails bidDetails = (BidDetails)this.history.get(0);
    return bidDetails;
  }
  
  public Bid getLastBid()
  {
    BidDetails lastBidDetails = getLastBidDetails();
    if (lastBidDetails == null) {
      return null;
    }
    return lastBidDetails.getBid();
  }
  
  public Bid getSecondLastBid()
  {
    if (this.history.size() < 2) {
      return null;
    }
    return ((BidDetails)this.history.get(this.history.size() - 2)).getBid();
  }
  
  public int size()
  {
    return this.history.size();
  }
  
  public List<BidDetails> getHistory()
  {
    return this.history;
  }
  
  public BidDetails getBidDetailsOfUtility(double u)
  {
    double minDistance = -1.0D;
    BidDetails closestBid = null;
    for (BidDetails b : this.history)
    {
      double utility = b.getMyUndiscountedUtil();
      if ((Math.abs(utility - u) <= minDistance) || (minDistance == -1.0D))
      {
        minDistance = Math.abs(utility - u);
        closestBid = b;
      }
    }
    return closestBid;
  }
  
  public double getMaximumUtility()
  {
    double max = -1.0D;
    for (BidDetails b : this.history)
    {
      double utility = b.getMyUndiscountedUtil();
      if ((utility >= max) || (max == -1.0D)) {
        max = utility;
      }
    }
    return max;
  }
  
  public double getMinimumUtility()
  {
    double min = -1.0D;
    for (BidDetails b : this.history)
    {
      double utility = b.getMyUndiscountedUtil();
      if ((utility <= min) || (min == -1.0D)) {
        min = utility;
      }
    }
    return min;
  }
  
  public Bid getBestBid()
  {
    BidDetails bestBidDetails = getBestBidDetails();
    if (bestBidDetails == null) {
      return null;
    }
    return bestBidDetails.getBid();
  }
  
  public BidDetails getBestBidDetails()
  {
    double max = -1.0D;
    BidDetails bestBid = null;
    for (BidDetails b : this.history)
    {
      double utility = b.getMyUndiscountedUtil();
      if ((utility >= max) || (max == -1.0D))
      {
        max = utility;
        bestBid = b;
      }
    }
    return bestBid;
  }
  
  public BidHistory getBestBidHistory(int n)
  {
    BidHistory copySortedToUtility = getCopySortedToUtility();
    BidHistory best = new BidHistory();
    int i = 0;
    for (BidDetails b : copySortedToUtility)
    {
      best.add(b);
      i++;
      if (i >= n) {
        break;
      }
    }
    return best;
  }
  
  public BidDetails getRandom()
  {
    int size = size();
    if (size == 0) {
      return null;
    }
    int index = new Random().nextInt(size);
    return (BidDetails)this.history.get(index);
  }
  
  public BidDetails getRandom(Random r)
  {
    int size = size();
    if (size == 0) {
      return null;
    }
    int index = r.nextInt(size);
    return (BidDetails)this.history.get(index);
  }
  
  public double getAverageUtility()
  {
    int size = size();
    if (size == 0) {
      return 0.0D;
    }
    double totalUtil = 0.0D;
    for (BidDetails b : this.history) {
      totalUtil += b.getMyUndiscountedUtil();
    }
    return totalUtil / size;
  }
  
  public void sortToUtility()
  {
    Collections.sort(this.history, new BidDetailsSorterUtility());
  }
  
  public BidHistory getCopySortedToUtility()
  {
    BidHistory bidHistoryCopy = new BidHistory(this);
    bidHistoryCopy.sortToUtility();
    return bidHistoryCopy;
  }
  
  public String toString()
  {
    return "" + this.history;
  }
  
  public Iterator<BidDetails> iterator()
  {
    return this.history.iterator();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Nice_Tit_for_Tat.BidHistory
 * JD-Core Version:    0.7.1
 */