package agents.anac.y2011.Nice_Tit_for_Tat;

import java.io.PrintStream;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.bidding.BidDetails;
import negotiator.utility.UtilitySpace;

public abstract class BilateralAgent
  extends Agent
  implements BidHistoryKeeper
{
  private static final boolean LOGGING = false;
  protected Domain domain;
  private Action opponentAction;
  protected BidHistory myHistory;
  protected BidHistory opponentHistory;
  
  public void init()
  {
    this.domain = this.utilitySpace.getDomain();
    this.myHistory = new BidHistory();
    this.opponentHistory = new BidHistory();
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.opponentAction = opponentAction;
    if ((opponentAction instanceof Offer))
    {
      Bid bid = ((Offer)opponentAction).getBid();
      double time = this.timeline.getTime();
      double myUndiscountedUtility = getUndiscountedUtility(bid);
      BidDetails bidDetails = new BidDetails(bid, myUndiscountedUtility, time);
      
      this.opponentHistory.add(bidDetails);
    }
  }
  
  protected double getUndiscountedUtility(Bid bid)
  {
    double myUndiscountedUtility = 0.0D;
    try
    {
      myUndiscountedUtility = this.utilitySpace.getUtility(bid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return myUndiscountedUtility;
  }
  
  public Action chooseAction()
  {
    Bid opponentLastBid = getOpponentLastBid();
    Action myAction = null;
    if (opponentLastBid == null)
    {
      Bid openingBid = chooseOpeningBid();
      myAction = new Offer(getAgentID(), openingBid);
    }
    else if (getMyLastBid() == null)
    {
      Bid firstCounterBid = chooseFirstCounterBid();
      if (isAcceptable(firstCounterBid)) {
        myAction = makeAcceptAction();
      } else {
        myAction = new Offer(getAgentID(), firstCounterBid);
      }
    }
    else if ((this.opponentAction instanceof Offer))
    {
      Bid counterBid = chooseCounterBid();
      if (isAcceptable(counterBid)) {
        myAction = makeAcceptAction();
      } else {
        myAction = new Offer(getAgentID(), counterBid);
      }
      if (myAction == null) {
        myAction = new Offer(getAgentID(), counterBid);
      }
    }
    remember(myAction);
    return myAction;
  }
  
  protected Action makeAcceptAction()
  {
    Action myAction = new Accept(getAgentID());
    return myAction;
  }
  
  private void remember(Action myAction)
  {
    if ((myAction instanceof Offer))
    {
      Bid myLastBid = ((Offer)myAction).getBid();
      double time = this.timeline.getTime();
      double myUndiscountedUtility = getUndiscountedUtility(myLastBid);
      BidDetails bidDetails = new BidDetails(myLastBid, myUndiscountedUtility, time);
      
      this.myHistory.add(bidDetails);
    }
  }
  
  public abstract boolean isAcceptable(Bid paramBid);
  
  public abstract Bid chooseCounterBid();
  
  public abstract Bid chooseOpeningBid();
  
  public abstract Bid chooseFirstCounterBid();
  
  public Bid getMyLastBid()
  {
    return this.myHistory.getLastBid();
  }
  
  public Bid getMySecondLastBid()
  {
    return this.myHistory.getSecondLastBid();
  }
  
  public BidHistory getOpponentHistory()
  {
    return this.opponentHistory;
  }
  
  public Bid getOpponentLastBid()
  {
    return this.opponentHistory.getLastBid();
  }
  
  public int getRound()
  {
    return this.myHistory.size() + this.opponentHistory.size();
  }
  
  protected static void log(String s)
  {
    System.out.println(s);
  }
  
  public static double round2(double x)
  {
    return Math.round(100.0D * x) / 100.0D;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.Nice_Tit_for_Tat.BilateralAgent
 * JD-Core Version:    0.7.1
 */