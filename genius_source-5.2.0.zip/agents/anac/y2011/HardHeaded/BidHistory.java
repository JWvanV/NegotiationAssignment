package agents.anac.y2011.HardHeaded;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class BidHistory
{
  private List<Map.Entry<Double, Bid>> myBids;
  private List<Bid> opponentBids;
  private UtilitySpace utilitySpace;
  
  public BidHistory(UtilitySpace utilSpace)
  {
    this.utilitySpace = utilSpace;
    this.myBids = new ArrayList();
    this.opponentBids = new ArrayList();
  }
  
  public void addMyBid(Map.Entry<Double, Bid> pBid)
  {
    if (pBid == null) {
      throw new IllegalArgumentException("pBid can't be null.");
    }
    this.myBids.add(pBid);
  }
  
  public int getMyBidCount()
  {
    return this.myBids.size();
  }
  
  public Map.Entry<Double, Bid> getMyBid(int pIndex)
  {
    return (Map.Entry)this.myBids.get(pIndex);
  }
  
  public Map.Entry<Double, Bid> getMyLastBid()
  {
    Map.Entry<Double, Bid> result = null;
    if (getMyBidCount() > 0) {
      result = (Map.Entry)this.myBids.get(getMyBidCount() - 1);
    }
    return result;
  }
  
  public void addOpponentBid(Bid pBid)
  {
    if (pBid == null) {
      throw new IllegalArgumentException("vBid can't be null.");
    }
    this.opponentBids.add(pBid);
  }
  
  public int getOpponentBidCount()
  {
    return this.opponentBids.size();
  }
  
  public Bid getOpponentBid(int pIndex)
  {
    return (Bid)this.opponentBids.get(pIndex);
  }
  
  public Bid getOpponentLastBid()
  {
    Bid result = null;
    if (getOpponentBidCount() > 0) {
      result = (Bid)this.opponentBids.get(getOpponentBidCount() - 1);
    }
    return result;
  }
  
  public Bid getOpponentSecondLastBid()
  {
    Bid result = null;
    if (getOpponentBidCount() > 1) {
      result = (Bid)this.opponentBids.get(getOpponentBidCount() - 2);
    }
    return result;
  }
  
  public HashMap<Integer, Integer> BidDifference(Bid first, Bid second)
  {
    HashMap<Integer, Integer> diff = new HashMap();
    try
    {
      for (Issue i : this.utilitySpace.getDomain().getIssues()) {
        diff.put(Integer.valueOf(i.getNumber()), Integer.valueOf(((ValueDiscrete)first.getValue(i.getNumber())).equals((ValueDiscrete)second.getValue(i.getNumber())) ? 0 : 1));
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    return diff;
  }
  
  public HashMap<Integer, Integer> BidDifferenceofOpponentsLastTwo()
  {
    if (getOpponentBidCount() < 2) {
      throw new ArrayIndexOutOfBoundsException();
    }
    return BidDifference(getOpponentLastBid(), getOpponentSecondLastBid());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.HardHeaded.BidHistory
 * JD-Core Version:    0.7.1
 */