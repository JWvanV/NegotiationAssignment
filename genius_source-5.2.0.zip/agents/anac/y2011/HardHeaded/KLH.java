package agents.anac.y2011.HardHeaded;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TreeMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Objective;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class KLH
  extends Agent
{
  private BidHistory bidHistory;
  private BidSelector BSelector;
  private double MINIMUM_BID_UTILITY = 0.585D;
  private final int TOP_SELECTED_BIDS = 4;
  private final double LEARNING_COEF = 0.2D;
  private final int LEARNING_VALUE_ADDITION = 1;
  private final double UTILITY_TOLORANCE = 0.01D;
  private double Ka = 0.05D;
  private double e = 0.05D;
  private double discountF = 1.0D;
  private double lowestYetUtility = 1.0D;
  private LinkedList<Map.Entry<Double, Bid>> offerQueue = null;
  private Bid opponentLastBid = null;
  private boolean firstRound = true;
  private Domain domain = null;
  private UtilitySpace oppUtility = null;
  private int numberOfIssues = 0;
  private double maxUtil = 1.0D;
  private double minUtil = this.MINIMUM_BID_UTILITY;
  private Bid opponentbestbid = null;
  private Map.Entry<Double, Bid> opponentbestentry;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  private Random random200;
  int round;
  
  public void init()
  {
    this.BSelector = new BidSelector(this.utilitySpace);
    this.bidHistory = new BidHistory(this.utilitySpace);
    this.oppUtility = new UtilitySpace(this.utilitySpace);
    this.offerQueue = new LinkedList();
    this.domain = this.utilitySpace.getDomain();
    this.numberOfIssues = this.domain.getIssues().size();
    if ((this.utilitySpace.getDiscountFactor() <= 1.0D) && (this.utilitySpace.getDiscountFactor() > 0.0D)) {
      this.discountF = this.utilitySpace.getDiscountFactor();
    }
    Map.Entry<Double, Bid> highestBid = this.BSelector.BidList.lastEntry();
    try
    {
      this.maxUtil = this.utilitySpace.getUtility((Bid)highestBid.getValue());
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.random100 = new Random();
    this.random200 = new Random();
    



















    double w = 1.0D / this.numberOfIssues;
    for (Map.Entry<Objective, Evaluator> e : this.oppUtility.getEvaluators())
    {
      this.oppUtility.unlock((Objective)e.getKey());
      ((Evaluator)e.getValue()).setWeight(w);
      try
      {
        for (ValueDiscrete vd : ((IssueDiscrete)e.getKey()).getValues()) {
          ((EvaluatorDiscrete)e.getValue()).setEvaluation(vd, 1);
        }
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
    if (this.utilitySpace.getReservationValue() != null) {
      this.MINIMUM_BID_UTILITY = this.utilitySpace.getReservationValue().doubleValue();
    }
  }
  
  public String getVersion()
  {
    return "1.2";
  }
  
  public String getName()
  {
    return "HardHeaded";
  }
  
  public void ReceiveMessage(Action pAction)
  {
    if ((pAction instanceof Offer))
    {
      this.opponentLastBid = ((Offer)pAction).getBid();
      this.bidHistory.addOpponentBid(this.opponentLastBid);
      updateLearner();
      try
      {
        if (this.opponentbestbid == null) {
          this.opponentbestbid = this.opponentLastBid;
        } else if (this.utilitySpace.getUtility(this.opponentLastBid) > this.utilitySpace.getUtility(this.opponentbestbid)) {
          this.opponentbestbid = this.opponentLastBid;
        }
        double opbestvalue = ((Double)this.BSelector.BidList.floorEntry(Double.valueOf(this.utilitySpace.getUtility(this.opponentbestbid))).getKey()).doubleValue();
        while (!((Bid)this.BSelector.BidList.floorEntry(Double.valueOf(opbestvalue)).getValue()).equals(this.opponentbestbid)) {
          opbestvalue = ((Double)this.BSelector.BidList.lowerEntry(Double.valueOf(opbestvalue)).getKey()).doubleValue();
        }
        this.opponentbestentry = this.BSelector.BidList.floorEntry(Double.valueOf(opbestvalue));
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }
  
  private void updateLearner()
  {
    if (this.bidHistory.getOpponentBidCount() < 2) {
      return;
    }
    int numberOfUnchanged = 0;
    HashMap<Integer, Integer> lastDiffSet = this.bidHistory.BidDifferenceofOpponentsLastTwo();
    for (Integer i : lastDiffSet.keySet()) {
      if (((Integer)lastDiffSet.get(i)).intValue() == 0) {
        numberOfUnchanged++;
      }
    }
    double goldenValue = 0.2D / this.numberOfIssues;
    
    double totalSum = 1.0D + goldenValue * numberOfUnchanged;
    
    double maximumWeight = 1.0D - this.numberOfIssues * goldenValue / totalSum;
    for (Integer i : lastDiffSet.keySet()) {
      if ((((Integer)lastDiffSet.get(i)).intValue() == 0) && (this.oppUtility.getWeight(i.intValue()) < maximumWeight)) {
        this.oppUtility.setWeight(this.domain.getObjective(i.intValue()), (this.oppUtility.getWeight(i.intValue()) + goldenValue) / totalSum);
      } else {
        this.oppUtility.setWeight(this.domain.getObjective(i.intValue()), this.oppUtility.getWeight(i.intValue()) / totalSum);
      }
    }
    try
    {
      for (Map.Entry<Objective, Evaluator> e : this.oppUtility.getEvaluators()) {
        ((EvaluatorDiscrete)e.getValue()).setEvaluation(this.opponentLastBid.getValue(((IssueDiscrete)e.getKey()).getNumber()), 1 + ((EvaluatorDiscrete)e.getValue()).getEvaluationNotNormalized((ValueDiscrete)this.opponentLastBid.getValue(((IssueDiscrete)e.getKey()).getNumber())).intValue());
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  public double get_p()
  {
    double time = this.timeline.getTime();
    
    double p = 1.0D;
    double step_point = this.discountF;
    double tempMax = this.maxUtil;
    double tempMin = this.minUtil;
    double tempE = this.e;
    double ignoreDiscountThreshold = 0.9D;
    if (step_point >= ignoreDiscountThreshold)
    {
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow(time / step_point, 1.0D / this.e);
      p = this.minUtil + (1.0D - Fa) * (this.maxUtil - this.minUtil);
    }
    else if (time <= step_point)
    {
      tempE = this.e / step_point;
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow(time / step_point, 1.0D / tempE);
      tempMin += Math.abs(tempMax - tempMin) * step_point;
      p = tempMin + (1.0D - Fa) * (tempMax - tempMin);
    }
    else
    {
      tempE = 30.0D;
      double Fa = this.Ka + (1.0D - this.Ka) * Math.pow((time - step_point) / (1.0D - step_point), 1.0D / tempE);
      

      tempMax = tempMin + Math.abs(tempMax - tempMin) * step_point;
      p = tempMin + (1.0D - Fa) * (tempMax - tempMin);
    }
    return p;
  }
  
  public Action chooseAction()
  {
    this.round += 1;
    Map.Entry<Double, Bid> newBid = null;
    Action newAction = null;
    
    double p = get_p();
    try
    {
      if (this.firstRound)
      {
        this.firstRound = (!this.firstRound);
        newBid = this.BSelector.BidList.lastEntry();
        this.offerQueue.add(newBid);
      }
      else if ((this.offerQueue.isEmpty()) || (this.offerQueue == null))
      {
        TreeMap<Double, Bid> newBids = new TreeMap();
        newBid = this.BSelector.BidList.lowerEntry(this.bidHistory.getMyLastBid().getKey());
        
        newBids.put(newBid.getKey(), newBid.getValue());
        if (((Double)newBid.getKey()).doubleValue() < p)
        {
          int indexer = this.bidHistory.getMyBidCount();
          indexer = (int)Math.floor(indexer * this.random100.nextDouble());
          
          newBids.remove(newBid.getKey());
          newBids.put(this.bidHistory.getMyBid(indexer).getKey(), this.bidHistory.getMyBid(indexer).getValue());
        }
        double firstUtil = ((Double)newBid.getKey()).doubleValue();
        
        Map.Entry<Double, Bid> addBid = this.BSelector.BidList.lowerEntry(Double.valueOf(firstUtil));
        
        double addUtil = ((Double)addBid.getKey()).doubleValue();
        int count = 0;
        while ((firstUtil - addUtil < 0.01D) && (addUtil >= p))
        {
          newBids.put(Double.valueOf(addUtil), addBid.getValue());
          addBid = this.BSelector.BidList.lowerEntry(Double.valueOf(addUtil));
          addUtil = ((Double)addBid.getKey()).doubleValue();
          count += 1;
        }
        if (newBids.size() <= 4)
        {
          this.offerQueue.addAll(newBids.entrySet());
        }
        else
        {
          int addedSofar = 0;
          Map.Entry<Double, Bid> bestBid = null;
          while (addedSofar <= 4)
          {
            bestBid = newBids.lastEntry();
            for (Map.Entry<Double, Bid> e : newBids.entrySet()) {
              if (this.oppUtility.getUtility((Bid)e.getValue()) > this.oppUtility.getUtility((Bid)bestBid.getValue())) {
                bestBid = e;
              }
            }
            this.offerQueue.add(bestBid);
            newBids.remove(bestBid.getKey());
            addedSofar++;
          }
        }
        if (((Double)((Map.Entry)this.offerQueue.getFirst()).getKey()).doubleValue() < ((Double)this.opponentbestentry.getKey()).doubleValue()) {
          this.offerQueue.addFirst(this.opponentbestentry);
        }
      }
      if ((this.offerQueue.isEmpty()) || (this.offerQueue == null))
      {
        Bid bestBid1 = this.domain.getRandomBid(this.random200);
        if ((this.opponentLastBid != null) && (this.utilitySpace.getUtility(bestBid1) <= this.utilitySpace.getUtility(this.opponentLastBid)))
        {
          newAction = new Accept(getAgentID());
        }
        else if (bestBid1 == null)
        {
          newAction = new Accept(getAgentID());
        }
        else
        {
          newAction = new Offer(getAgentID(), bestBid1);
          if (this.utilitySpace.getUtility(bestBid1) < this.lowestYetUtility) {
            this.lowestYetUtility = this.utilitySpace.getUtility(bestBid1);
          }
        }
      }
      if ((this.opponentLastBid != null) && ((this.utilitySpace.getUtility(this.opponentLastBid) > this.lowestYetUtility) || (this.utilitySpace.getUtility((Bid)((Map.Entry)this.offerQueue.getFirst()).getValue()) <= this.utilitySpace.getUtility(this.opponentLastBid))))
      {
        newAction = new Accept(getAgentID());
      }
      else
      {
        Map.Entry<Double, Bid> offer = (Map.Entry)this.offerQueue.remove();
        this.bidHistory.addMyBid(offer);
        if (((Double)offer.getKey()).doubleValue() < this.lowestYetUtility) {
          this.lowestYetUtility = this.utilitySpace.getUtility((Bid)offer.getValue());
        }
        newAction = new Offer(getAgentID(), (Bid)offer.getValue());
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return newAction;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2011.HardHeaded.KLH
 * JD-Core Version:    0.7.1
 */