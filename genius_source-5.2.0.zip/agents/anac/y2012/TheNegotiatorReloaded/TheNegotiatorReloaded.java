package agents.anac.y2012.TheNegotiatorReloaded;

import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.boaframework.NegotiationSession;
import negotiator.boaframework.OpponentModel;
import negotiator.boaframework.acceptanceconditions.anac2012.AC_TheNegotiatorReloaded;
import negotiator.boaframework.agent.BOAagent;
import negotiator.boaframework.offeringstrategy.anac2012.TheNegotiatorReloaded_Offering;
import negotiator.boaframework.omstrategy.NullStrategy;
import negotiator.boaframework.opponentmodel.IAMhagglerBayesianModel;
import negotiator.boaframework.opponentmodel.NoModel;
import negotiator.utility.UtilitySpace;

public class TheNegotiatorReloaded
  extends BOAagent
{
  public void agentSetup()
  {
    try
    {
      if (this.negotiationSession.getUtilitySpace().getDomain().getNumberOfPossibleBids() < 200000L) {
        this.opponentModel = new IAMhagglerBayesianModel();
      } else {
        this.opponentModel = new NoModel();
      }
      this.opponentModel.init(this.negotiationSession, null);
      this.omStrategy = new NullStrategy(this.negotiationSession, 0.35D);
      this.offeringStrategy = new TheNegotiatorReloaded_Offering(this.negotiationSession, this.opponentModel, this.omStrategy);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.acceptConditions = new AC_TheNegotiatorReloaded(this.negotiationSession, this.offeringStrategy, 1.0D, 0.0D, 1.05D, 0.0D, 0.98D, 0.99D);
  }
  
  public String getName()
  {
    return "TheNegotiator Reloaded";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.TheNegotiatorReloaded.TheNegotiatorReloaded
 * JD-Core Version:    0.7.1
 */