package agents.anac.y2012.OMACagent;

import java.util.ArrayList;
import java.util.List;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.utility.UtilitySpace;

public class TimeBidHistory
{
  private List<Bid> fMyBids;
  private List<Bid> fOpponentBids;
  public List<Double> fTimes;
  public int curIndex = 0;
  public int curLength = 0;
  private double discount = 0.0D;
  protected UtilitySpace fUtilitySpace;
  public double est_t = 0.0D;
  public double est_u = 0.0D;
  public double maxU = -1.0D;
  public int pMaxIndex = 0;
  public Bid bestOppBid = null;
  public double[] maxBlock;
  public List<Integer> newMC;
  
  public TimeBidHistory(UtilitySpace pUtilitySpace, double dis)
  {
    this.discount = dis;
    this.fMyBids = new ArrayList();
    this.fTimes = new ArrayList();
    this.newMC = new ArrayList();
    this.fUtilitySpace = pUtilitySpace;
    
    this.maxBlock = new double[100];
    for (int i = 0; i < 100; i++) {
      this.maxBlock[i] = 0.0D;
    }
  }
  
  public void addMyBid(Bid pBid)
  {
    if (pBid == null) {
      throw new IllegalArgumentException("pBid can't be null.");
    }
    this.fMyBids.add(pBid);
  }
  
  public int getMyBidCount()
  {
    return this.fMyBids.size();
  }
  
  public Bid getMyBid(int pIndex)
  {
    return (Bid)this.fMyBids.get(pIndex);
  }
  
  public Bid getMyLastBid()
  {
    Bid result = null;
    if (getMyBidCount() > 0) {
      result = (Bid)this.fMyBids.get(getMyBidCount() - 1);
    }
    return result;
  }
  
  public boolean isInsideMyBids(Bid a)
  {
    boolean result = false;
    for (int i = 0; i < getMyBidCount(); i++) {
      if (a.equals(getMyBid(i))) {
        result = true;
      }
    }
    return result;
  }
  
  public void addOpponentBidnTime(double oppU, Bid pBid, double time)
  {
    double undisOppU = oppU / Math.pow(this.discount, time);
    double nTime = time;
    if (pBid == null) {
      throw new IllegalArgumentException("vBid can't be null.");
    }
    this.fTimes.add(Double.valueOf(time));
    if (undisOppU > this.maxU)
    {
      this.maxU = undisOppU;
      
      this.pMaxIndex = (this.fTimes.size() - 1);
      this.bestOppBid = pBid;
      this.newMC.add(Integer.valueOf(this.pMaxIndex));
    }
    if (nTime >= 1.0D) {
      nTime = 0.9999900000000001D;
    }
    if (this.maxBlock[((int)Math.floor(nTime * 100.0D))] < undisOppU) {
      this.maxBlock[((int)Math.floor(nTime * 100.0D))] = undisOppU;
    }
  }
  
  public double[] getTimeBlockList()
  {
    return this.maxBlock;
  }
  
  public int getOpponentBidCount()
  {
    return this.fOpponentBids.size();
  }
  
  public Bid getOpponentBid(int pIndex)
  {
    return (Bid)this.fOpponentBids.get(pIndex);
  }
  
  public Bid getOpponentLastBid()
  {
    Bid result = null;
    if (getOpponentBidCount() > 0) {
      result = (Bid)this.fOpponentBids.get(getOpponentBidCount() - 1);
    }
    return result;
  }
  
  public double getMyUtility(Bid b)
  {
    try
    {
      return this.fUtilitySpace.getUtility(b);
    }
    catch (Exception e) {}
    return 0.0D;
  }
  
  public double getOpponentUtility(Bid b)
  {
    try
    {
      return this.fUtilitySpace.getUtility(b);
    }
    catch (Exception e) {}
    return 0.0D;
  }
  
  public ArrayList<Issue> getIssues()
  {
    return this.fUtilitySpace.getDomain().getIssues();
  }
  
  public double getFeaMC(double time)
  {
    int len = this.newMC.size();
    double dif = 1.0D;
    if (len >= 3)
    {
      dif = ((Double)this.fTimes.get(((Integer)this.newMC.get(len - 1)).intValue())).doubleValue() - ((Double)this.fTimes.get(((Integer)this.newMC.get(len - 3)).intValue())).doubleValue();
      dif /= 2.0D;
    }
    else if (len >= 2)
    {
      dif = ((Double)this.fTimes.get(((Integer)this.newMC.get(len - 1)).intValue())).doubleValue() - ((Double)this.fTimes.get(((Integer)this.newMC.get(len - 2)).intValue())).doubleValue();
    }
    else
    {
      dif = 0.0D;
    }
    return dif;
  }
  
  public double getMCtime()
  {
    if (this.newMC.size() == 0) {
      return 0.0D;
    }
    return ((Double)this.fTimes.get(((Integer)this.newMC.get(this.newMC.size() - 1)).intValue())).doubleValue();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.OMACagent.TimeBidHistory
 * JD-Core Version:    0.7.1
 */