package agents.anac.y2012.AgentMR;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class AgentMR
  extends Agent
{
  private boolean EQUIVALENCE_TEST = true;
  private Random random100;
  private Action actionOfPartner = null;
  private ArrayList<Bid> bidRunk = new ArrayList();
  private ArrayList<Double> observationUtility = new ArrayList();
  private HashMap<Bid, Double> bidTables = new HashMap();
  private static final double MINIMUM_ACCEPT_P = 0.965D;
  private static boolean firstOffer;
  private static boolean forecastTime = true;
  private static boolean discountFactor;
  private static double minimumBidUtility;
  private static double minimumOffereDutil;
  private static Bid offereMaxBid = null;
  private static double offereMaxUtility;
  private static double firstOffereUtility;
  private int currentBidNumber = 0;
  private int lastBidNumber = 1;
  private double sigmoidGain;
  private double sigmoidX;
  private double reservation = 0.0D;
  private double alpha;
  private double percent;
  private double p = 0.9D;
  
  public void init()
  {
    try
    {
      firstOffer = true;
      getDiscountFactor();
      getReservationFactor();
      updateMinimumBidUtility(0.0D);
      Bid b = this.utilitySpace.getMaxUtilityBid();
      this.bidTables.put(b, Double.valueOf(getUtility(b)));
      this.bidRunk.add(b);
      if (discountFactor)
      {
        this.sigmoidGain = -3.0D;
        this.percent = 0.55D;
      }
      else
      {
        this.sigmoidGain = -5.0D;
        this.percent = 0.7D;
      }
      if (this.EQUIVALENCE_TEST) {
        this.random100 = new Random(100L);
      } else {
        this.random100 = new Random();
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getVersion()
  {
    return "1.2";
  }
  
  public String getName()
  {
    return "AgentMR";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = new Offer(getAgentID(), this.utilitySpace.getMaxUtilityBid());
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        

        double time = this.timeline.getTime();
        double offeredutil;
        double offeredutil;
        if (discountFactor) {
          offeredutil = getUtility(partnerBid) * (1.0D / Math.pow(this.utilitySpace.getDiscountFactor(), time));
        } else {
          offeredutil = getUtility(partnerBid);
        }
        if (firstOffer)
        {
          offereMaxBid = partnerBid;
          offereMaxUtility = offeredutil;
          firstOffereUtility = offeredutil;
          
          this.observationUtility.add(Double.valueOf(offeredutil));
          if (offeredutil > 0.5D) {
            this.p = 0.9D;
          } else {
            this.p = 0.8D;
          }
          firstOffer = !firstOffer;
        }
        updateMinimumBidUtility(time);
        if (offeredutil > offereMaxUtility)
        {
          offereMaxBid = partnerBid;
          offereMaxUtility = offeredutil;
          
          this.observationUtility.add(Double.valueOf(offeredutil));
          if ((time > 0.5D) && (!discountFactor)) {
            newupdateSigmoidFunction();
          }
        }
        if ((time > 0.5D) && (forecastTime))
        {
          updateSigmoidFunction();
          forecastTime = !forecastTime;
        }
        double P = Paccept(offeredutil, time);
        if ((P > 0.965D) || (offeredutil > minimumBidUtility) || 
          (this.bidRunk.contains(partnerBid)))
        {
          action = new Accept(getAgentID());
        }
        else if (offereMaxUtility > minimumBidUtility)
        {
          action = new Offer(getAgentID(), offereMaxBid);
        }
        else if (time > 0.985D)
        {
          if (offereMaxUtility > this.reservation)
          {
            action = new Offer(getAgentID(), offereMaxBid);
          }
          else
          {
            action = new Offer(getAgentID(), (Bid)this.bidRunk.get(this.bidRunk.size() - this.lastBidNumber));
            
            this.lastBidNumber += 1;
          }
        }
        else if (offeredutil > minimumOffereDutil)
        {
          HashMap<Bid, Double> getBids = getBidTable(1);
          if (getBids.size() >= 1)
          {
            this.currentBidNumber = 0;
            this.bidRunk.clear();
            this.bidTables = getBids;
            sortBid(getBids);
          }
          else
          {
            getBids = getBidTable(2);
            if (getBids.size() >= 1)
            {
              sortBid(getBids);
              Bid maxBid = getMaxBidUtility(getBids);
              this.currentBidNumber = this.bidRunk.indexOf(maxBid);
            }
          }
          action = new Offer(getAgentID(), (Bid)this.bidRunk.get(this.currentBidNumber));
          if (this.currentBidNumber + 1 < this.bidRunk.size()) {
            this.currentBidNumber += 1;
          }
        }
        else
        {
          HashMap<Bid, Double> getBids = getBidTable(2);
          if (getBids.size() >= 1)
          {
            sortBid(getBids);
            Bid maxBid = getMaxBidUtility(getBids);
            
            this.currentBidNumber = this.bidRunk.indexOf(maxBid);
          }
          action = new Offer(getAgentID(), (Bid)this.bidRunk.get(this.currentBidNumber));
          if (this.currentBidNumber + 1 < this.bidRunk.size()) {
            this.currentBidNumber += 1;
          } else {
            this.currentBidNumber = 0;
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private void getReservationFactor()
  {
    if (this.utilitySpace.getReservationValue() != null) {
      this.reservation = this.utilitySpace.getReservationValue().doubleValue();
    }
  }
  
  private void getDiscountFactor()
  {
    discountFactor = this.utilitySpace.isDiscounted();
  }
  
  private void newupdateSigmoidFunction()
  {
    double latestObservation = ((Double)this.observationUtility.get(this.observationUtility
      .size() - 1)).doubleValue();
    double concessionPercent = Math.abs(latestObservation - firstOffereUtility) / (1.0D - firstOffereUtility);
    

    double modPercent = Math.abs(minimumOffereDutil - firstOffereUtility) / (1.0D - firstOffereUtility);
    if (modPercent < concessionPercent) {
      this.percent = concessionPercent;
    }
  }
  
  private void updateSigmoidFunction()
  {
    int observationSize = this.observationUtility.size();
    double latestObservation = ((Double)this.observationUtility.get(observationSize - 1)).doubleValue();
    double concessionPercent = Math.abs(latestObservation - firstOffereUtility) / (1.0D - firstOffereUtility);
    if (discountFactor)
    {
      if ((concessionPercent < 0.2D) || (observationSize < 3))
      {
        this.percent = 0.35D;
        this.sigmoidGain = -2.0D;
      }
      else
      {
        this.percent = 0.45D;
      }
    }
    else if ((concessionPercent < 0.2D) || (observationSize < 3))
    {
      this.percent = 0.5D;
      this.sigmoidGain = -4.0D;
    }
    else if (concessionPercent > 0.6D)
    {
      this.percent = 0.8D;
      this.sigmoidGain = -6.0D;
    }
    else
    {
      this.percent = 0.6D;
    }
  }
  
  private Bid getMaxBidUtility(HashMap<Bid, Double> bidTable)
  {
    Double maxBidUtility = Double.valueOf(0.0D);
    Bid maxBid = null;
    for (Bid b : bidTable.keySet()) {
      if (getUtility(b) > maxBidUtility.doubleValue())
      {
        maxBidUtility = Double.valueOf(getUtility(b));
        maxBid = b;
      }
    }
    return maxBid;
  }
  
  private void updateMinimumBidUtility(double time)
  {
    this.alpha = ((1.0D - firstOffereUtility) * this.percent);
    
    double mbuInfimum = firstOffereUtility + this.alpha;
    if (mbuInfimum >= 1.0D) {
      mbuInfimum = 0.999D;
    } else if (mbuInfimum <= 0.7D) {
      mbuInfimum = 0.7D;
    }
    this.sigmoidX = (1.0D - 1.0D / this.sigmoidGain * Math.log(mbuInfimum / (1.0D - mbuInfimum)));
    

    minimumBidUtility = 1.0D - 1.0D / (1.0D + Math.exp(this.sigmoidGain * (time - this.sigmoidX)));
    if (minimumBidUtility < this.reservation) {
      minimumBidUtility = this.reservation;
    }
    minimumOffereDutil = minimumBidUtility * this.p;
  }
  
  private void sortBid(HashMap<Bid, Double> getBids)
  {
    for (Bid bid : getBids.keySet())
    {
      this.bidTables.put(bid, Double.valueOf(getUtility(bid)));
      this.bidRunk.add(bid);
    }
    if (!this.EQUIVALENCE_TEST) {
      Collections.sort(this.bidRunk, new Comparator()
      {
        public int compare(Bid o1, Bid o2)
        {
          return (int)Math.ceil(
            -(((Double)AgentMR.this.bidTables.get(o1)).doubleValue() - ((Double)AgentMR.this.bidTables.get(o2)).doubleValue()));
        }
      });
    }
  }
  
  private Bid clone(Bid source)
    throws Exception
  {
    HashMap<Integer, Value> hash = new HashMap();
    for (Issue i : this.utilitySpace.getDomain().getIssues()) {
      hash.put(Integer.valueOf(i.getNumber()), source.getValue(i.getNumber()));
    }
    return new Bid(this.utilitySpace.getDomain(), hash);
  }
  
  private HashMap<Bid, Double> getBidTable(int flag)
    throws Exception
  {
    HashMap<Bid, Double> getBids = new HashMap();
    

    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Bid standardBid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        for (ValueDiscrete value : lIssueDiscrete.getValues())
        {
          if (flag == 0) {
            standardBid = this.utilitySpace.getMaxUtilityBid();
          } else if (flag == 1) {
            standardBid = ((Offer)this.actionOfPartner).getBid();
          } else {
            standardBid = (Bid)this.bidRunk.get(this.currentBidNumber);
          }
          standardBid = clone(standardBid);
          standardBid.setValue(lIssue.getNumber(), value);
          double utility = getUtility(standardBid);
          if ((utility > minimumBidUtility) && 
            (!this.bidRunk.contains(standardBid))) {
            getBids.put(standardBid, Double.valueOf(utility));
          }
        }
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = this.random100.nextInt(lIssueReal
          .getNumberOfDiscretizationSteps() - 1);
        





        Value pValue = new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps());
        standardBid.setValue(lIssueReal.getNumber(), pValue);
        double utility = getUtility(standardBid);
        getBids.put(standardBid, Double.valueOf(utility));
        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        
        int optionIndex2 = lIssueInteger.getLowerBound() + this.random100.nextInt(lIssueInteger.getUpperBound() - lIssueInteger
          .getLowerBound());
        Value pValue2 = new ValueInteger(optionIndex2);
        standardBid.setValue(lIssueInteger.getNumber(), pValue2);
        double utility2 = getUtility(standardBid);
        getBids.put(standardBid, Double.valueOf(utility2));
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by AgentMR");
      }
    }
    return getBids;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.AgentMR.AgentMR
 * JD-Core Version:    0.7.1
 */