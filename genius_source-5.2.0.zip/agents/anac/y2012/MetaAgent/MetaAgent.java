package agents.anac.y2012.MetaAgent;

import agents.anac.y2010.AgentSmith.AgentSmith;
import agents.anac.y2011.AgentK2.Agent_K2;
import agents.anac.y2011.BramAgent.BRAMAgent;
import agents.anac.y2011.Gahboninho.Gahboninho;
import agents.anac.y2011.HardHeaded.KLH;
import agents.anac.y2011.TheNegotiator.TheNegotiator;
import agents.anac.y2011.ValueModelAgent.ValueModelAgent;
import agents.anac.y2012.MetaAgent.agents.Chameleon.Chameleon;
import agents.anac.y2012.MetaAgent.agents.DNAgent.DNAgent;
import agents.anac.y2012.MetaAgent.agents.GYRL.GYRL;
import agents.anac.y2012.MetaAgent.agents.LYY.LYYAgent;
import agents.anac.y2012.MetaAgent.agents.MrFriendly.MrFriendly;
import agents.anac.y2012.MetaAgent.agents.ShAgent.ShAgent;
import agents.anac.y2012.MetaAgent.agents.SimpleAgentNew.SimpleAgentNew;
import agents.anac.y2012.MetaAgent.agents.WinnerAgent.WinnerAgent2;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import negotiator.Agent;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Objective;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.EVALUATORTYPE;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class MetaAgent
  extends Agent
{
  private Agent myAgent;
  private String myAgentName;
  private boolean agentInit;
  private Action actionOfPartner;
  private boolean first;
  double[] params;
  double opponentFirstBid;
  
  public void init()
  {
    this.agentInit = false;
    this.first = false;
    this.opponentFirstBid = 0.0D;
    Domain d = this.utilitySpace.getDomain();
    this.myAgentName = "";
  }
  
  private String[][] getRegression()
  {
    String[][] reg = new String[18][12];
    reg[0] = "IAMcrazyhaggler,0.077,0,0.137,0.000000000,0.015,0,0,0,1.311,-0.03,0.556".split(",");
    
    reg[1] = "LYYAgent,-1.22,-0.016,0.23,0.000000000,0.027,0.026,1.042,1.372,1.482,0,0.572".split(",");
    
    reg[2] = "Chameleon,-2.185,-0.024,0.303,0.000000000,0.017,0.055,2.013,2.184,1.692,0,0.502".split(",");
    
    reg[3] = "AgentSmith,-2.075,-0.018,0.333,-0.000000410,0,0.05,1.938,2.027,1.428,0,0.565".split(",");
    
    reg[4] = "GYRL,-1.663,0,0.348,0.000000000,0.029,0.028,1.327,1.668,1.327,0,0.609".split(",");
    
    reg[5] = "Gahboninho,0.309,-0.024,0.337,0.000000248,0,0,0,0,0.495,0,0.451".split(",");
    
    reg[6] = "ValueModelAgent,-1.401,-0.022,0.441,-0.000000206,0,0.044,1.328,1.231,1.629,0,0.49".split(",");
    
    reg[7] = "Nice Tit-for-Tat Agent,-0.018,-0.014,0.422,-0.000000381,0,0,0.198,0,0.549,0,0.529".split(",");
    
    reg[8] = "HardHeaded,-2.012,-0.035,0.319,0.000000172,0,0.053,2.107,2.136,1.547,0,0.392".split(",");
    
    reg[9] = "WinnerAgent,-1.741,0,0.248,0.000000000,0.031,0.03,1.428,1.796,1.742,0,0.599".split(",");
    
    reg[10] = "AgentK2,-1.027,-0.012,0.246,0.000000000,0.019,0.022,1.083,1.127,1.097,0,0.531".split(",");
    
    reg[11] = "TheNegotiator,-0.159,0.017,0.307,0.000000000,0,0.015,0,0,0.92,0.03,0.665".split(",");
    
    reg[12] = "IAMhaggler2011,0.256,0,0.166,0.000000224,0.017,-0.011,0,0,0.347,0,0.543".split(",");
    
    reg[13] = "DNAgent,-0.581,-0.024,0.732,0.000000000,0,0.01,0.61,0,1.141,0,0.237".split(",");
    
    reg[14] = "BRAMAgent,-0.764,0,0.232,0.000000250,0,0.035,0.842,0.708,0.7,0,0.538".split(",");
    
    reg[15] = "MrFriendly,-1.721,-0.025,0.194,-0.000000429,0,0.054,1.814,1.711,1.488,0,0.498".split(",");
    
    reg[16] = "ShAgent,-2.072,-0.021,0,0.000000476,0.069,-0.055,2.336,2.805,1.743,0,0.412".split(",");
    
    reg[17] = "SimpleAgent,-1.359,0,0.287,-0.000000180,0.028,0.016,1.16,1.524,0.86,0,0.588".split(",");
    
    return reg;
  }
  
  private void getDomainParams()
  {
    this.params = new double[10];
    Domain d = this.utilitySpace.getDomain();
    ArrayList<Issue> a = d.getIssues();
    
    this.params[0] = a.size();
    this.params[1] = (this.utilitySpace.getDiscountFactor() == 0.0D ? 1.0D : this.utilitySpace.getDiscountFactor());
    
    int min = Integer.MAX_VALUE;int max = -1;int size = 1;
    


    double EU = 0.0D;double stdevU = 0.0D;double stdevW = 0.0D;double sW = 0.0D;double ssW = 0.0D;double countW = 0.0D;
    Iterator<Map.Entry<Objective, Evaluator>> issue = this.utilitySpace.getEvaluators().iterator();
    
    List<Double> ssWList = new ArrayList();
    while (issue.hasNext())
    {
      Map.Entry<Objective, Evaluator> entry = (Map.Entry)issue.next();
      Evaluator e = (Evaluator)entry.getValue();
      double weight = e.getWeight();
      countW += 1.0D;
      sW += weight;
      ssWList.add(Double.valueOf(weight));
      double tempEU = 0.0D;double tempStdevU = 0.0D;
      if (e.getType() == EVALUATORTYPE.DISCRETE)
      {
        Iterator<ValueDiscrete> v = ((EvaluatorDiscrete)e).getValues().iterator();
        
        List<Double> s = new ArrayList();
        double sumU = 0.0D;
        while (v.hasNext())
        {
          ValueDiscrete vd = (ValueDiscrete)v.next();
          try
          {
            double val = ((EvaluatorDiscrete)e).getEvaluation(vd).doubleValue();
            s.add(Double.valueOf(val));
            sumU += val;
          }
          catch (Exception e1)
          {
            e1.printStackTrace();
          }
        }
        int currSize = s.size();
        min = min > currSize ? currSize : min;
        max = max < currSize ? currSize : max;
        size *= currSize;
        tempEU = sumU / currSize;
        Iterator<Double> valIt = s.iterator();
        while (valIt.hasNext()) {
          tempStdevU += Math.pow(((Double)valIt.next()).doubleValue() - tempEU, 2.0D);
        }
        tempStdevU = Math.sqrt(tempStdevU / (currSize - 1.0D));
      }
      else if (e.getType() == EVALUATORTYPE.INTEGER)
      {
        tempEU = (((EvaluatorInteger)e).getUpperBound() + ((EvaluatorInteger)e).getLowerBound()) / 2.0D;
        
        tempStdevU = Math.sqrt((Math.pow(((EvaluatorInteger)e).getUpperBound() - tempEU, 2.0D) + Math.pow(((EvaluatorInteger)e).getLowerBound() - tempEU, 2.0D)) / 2.0D);
      }
      else if (e.getType() == EVALUATORTYPE.REAL)
      {
        tempEU = (((EvaluatorReal)e).getUpperBound() + ((EvaluatorReal)e).getLowerBound()) / 2.0D;
        
        tempStdevU = Math.sqrt((Math.pow(((EvaluatorReal)e).getUpperBound() - tempEU, 2.0D) + Math.pow(((EvaluatorReal)e).getLowerBound() - tempEU, 2.0D)) / 2.0D);
      }
      else
      {
        tempEU = 0.5D;
        tempStdevU = 0.0D;
      }
      EU += tempEU * weight;
      stdevU += tempStdevU * weight;
    }
    Iterator<Double> wIt = ssWList.iterator();
    double avgW = sW / countW;
    while (wIt.hasNext()) {
      ssW += Math.pow(((Double)wIt.next()).doubleValue() - avgW, 2.0D);
    }
    stdevW = countW <= 1.0D ? 0.0D : Math.sqrt(ssW / (countW - 1.0D));
    this.params[2] = size;
    this.params[3] = min;
    this.params[4] = max;
    this.params[5] = EU;
    this.params[6] = stdevU;
    this.params[7] = stdevW;
    this.params[8] = (this.first ? 1.0D : 0.0D);
    this.params[9] = this.opponentFirstBid;
  }
  
  private String getBestAgent()
  {
    double lambda = 70.0D;
    double sumExp = 0.0D;
    
    String ans = null;
    getDomainParams();
    String[][] reg = getRegression();
    double maxResult = 0.0D;
    int bestIndex = -1;
    List<String> agents = new ArrayList();
    double[] agentsResults = new double[reg.length];
    for (int k = 0; k < reg.length; k++)
    {
      agents.add(k, reg[k][0]);
      double regressionResult = 0.0D;
      double[] regression = new double[this.params.length + 1];
      for (int i = 0; i < regression.length; i++)
      {
        regression[i] = Double.parseDouble(reg[k][(i + 1)]);
        if (i > 0) {
          regressionResult += regression[i] * this.params[(i - 1)];
        } else {
          regressionResult += regression[i];
        }
      }
      if ((!reg[k][0].equalsIgnoreCase("Nice Tit-for-Tat Agent")) && (!reg[k][0].equalsIgnoreCase("IAMhaggler2011")) && (!reg[k][0].equalsIgnoreCase("IAMcrazyhaggler"))) {
        agentsResults[k] = Math.exp(regressionResult * lambda);
      } else {
        agentsResults[k] = 0.0D;
      }
      sumExp += agentsResults[k];
    }
    double rand = Math.random();double totalValue = 0.0D;
    for (int i = 0; i < agentsResults.length; i++)
    {
      agentsResults[i] /= sumExp;
      totalValue += agentsResults[i];
      if (rand < totalValue)
      {
        bestIndex = i;
        break;
      }
    }
    ans = (String)agents.get(bestIndex);
    this.myAgentName = ans;
    return ans;
  }
  
  private Agent selectAgent(String name)
  {
    Agent a = new KLH();
    if (name.equalsIgnoreCase("IAMcrazyhaggler")) {
      return a;
    }
    if (name.equalsIgnoreCase("LYYAgent")) {
      return new LYYAgent();
    }
    if (name.equalsIgnoreCase("Chameleon")) {
      return new Chameleon();
    }
    if (name.equalsIgnoreCase("AgentSmith")) {
      return new AgentSmith();
    }
    if (name.equalsIgnoreCase("GYRL")) {
      return new GYRL();
    }
    if (name.equalsIgnoreCase("Gahboninho")) {
      return new Gahboninho();
    }
    if (name.equalsIgnoreCase("ValueModelAgent")) {
      return new ValueModelAgent();
    }
    if (name.equalsIgnoreCase("Nice Tit-for-Tat Agent")) {
      return a;
    }
    if (name.equalsIgnoreCase("HardHeaded")) {
      return new KLH();
    }
    if (name.equalsIgnoreCase("WinnerAgent")) {
      return new WinnerAgent2();
    }
    if (name.equalsIgnoreCase("AgentK2")) {
      return new Agent_K2();
    }
    if (name.equalsIgnoreCase("TheNegotiator")) {
      return new TheNegotiator();
    }
    if (name.equalsIgnoreCase("IAMhaggler2011")) {
      return a;
    }
    if (name.equalsIgnoreCase("DNAgent")) {
      return new DNAgent();
    }
    if (name.equalsIgnoreCase("BRAMAgent")) {
      return new BRAMAgent();
    }
    if (name.equalsIgnoreCase("MrFriendly")) {
      return new MrFriendly();
    }
    if (name.equalsIgnoreCase("ShAgent")) {
      return new ShAgent();
    }
    if (name.equalsIgnoreCase("simpleAgent")) {
      return new SimpleAgentNew();
    }
    return a;
  }
  
  public Action chooseAction()
  {
    try
    {
      if (!this.agentInit)
      {
        if (this.actionOfPartner == null)
        {
          this.first = true;
          return new Offer(this, this.utilitySpace.getMaxUtilityBid());
        }
        this.agentInit = true;
        if ((this.actionOfPartner instanceof Offer)) {
          this.opponentFirstBid = this.utilitySpace.getUtility(((Offer)this.actionOfPartner).getBid());
        }
        this.myAgent = selectAgent(getBestAgent());
        this.myAgent.internalInit(0, 1, this.startTime, this.totalTime, this.timeline, this.utilitySpace, this.parametervalues);
        

        this.myAgent.setName(getName());
        this.myAgent.setAgentID(getAgentID());
        this.myAgent.init();
        
        this.myAgent.ReceiveMessage(this.actionOfPartner);
      }
      Action a = this.myAgent.chooseAction();
      if (a == null) {
        return new Offer(this, this.utilitySpace.getMaxUtilityBid());
      }
      double time = this.timeline.getTime();
      if (((a instanceof Offer)) && (this.utilitySpace.getReservationValueWithDiscount(time) >= this.utilitySpace.getUtilityWithDiscount(((Offer)a).getBid(), time))) {}
      return new EndNegotiation();
    }
    catch (Exception e) {}
    return null;
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
    if (this.agentInit) {
      this.myAgent.ReceiveMessage(opponentAction);
    }
  }
  
  public String getName()
  {
    if ((this.myAgentName == null) || (this.myAgentName == "")) {
      return "Meta-Agent 2012";
    }
    return "Meta-Agent 2012: " + this.myAgentName;
  }
  
  public String getVersion()
  {
    return "1.42";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.MetaAgent
 * JD-Core Version:    0.7.1
 */