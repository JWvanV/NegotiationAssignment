package agents.anac.y2012.MetaAgent.agents.ShAgent;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class ShAgent
  extends Agent
{
  private Action actionOfPartner;
  private Bid partnerFirstBid;
  private Bid partnerBestBid;
  private double threshold;
  private Bid maxUtilityBid;
  private OpponentModel opponentModel;
  private UtilityAnalyzer utilAnalyzer;
  
  public ShAgent()
  {
    this.actionOfPartner = null;
    this.partnerFirstBid = null;
    this.partnerBestBid = null;
    

    this.maxUtilityBid = null;
  }
  
  public void init()
  {
    this.opponentModel = new OpponentModel(this.utilitySpace, this.timeline);
    try
    {
      this.maxUtilityBid = this.utilitySpace.getMaxUtilityBid();
    }
    catch (Exception e) {}
    this.utilAnalyzer = new UtilityAnalyzer(this.utilitySpace, this.maxUtilityBid);
  }
  
  public String getVersion()
  {
    return "1.1.1";
  }
  
  public String getName()
  {
    return "ShAgent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null)
      {
        action = new Offer(getAgentID(), this.maxUtilityBid);
      }
      else if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        
        this.opponentModel.receiveNewOpponentBid(partnerBid);
        if (this.partnerFirstBid == null) {
          this.partnerFirstBid = partnerBid;
        }
        setBestBid(partnerBid);
        
        this.threshold = calculateThreshold();
        if (isAcceptable(partnerBid))
        {
          action = new Accept(getAgentID());
        }
        else
        {
          Bid ourOffer = this.utilAnalyzer.GetClosestOffer(partnerBid, this.threshold);
          
          action = new Offer(getAgentID(), ourOffer);
        }
      }
    }
    catch (Exception e)
    {
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private void setBestBid(Bid bid)
  {
    if (this.partnerBestBid == null)
    {
      this.partnerBestBid = bid;
    }
    else
    {
      double newUtil = getUtilityWithoutDiscount(bid);
      
      double oldUtil = getUtilityWithoutDiscount(this.partnerBestBid);
      if (newUtil > oldUtil) {
        this.partnerBestBid = bid;
      }
    }
  }
  
  private boolean isAcceptable(Bid partnerBid)
  {
    return getUtility(partnerBid) >= this.threshold;
  }
  
  private double calculateThreshold()
    throws Exception
  {
    double top = getUtility(this.maxUtilityBid);
    



    double bottom = getUtility(this.partnerFirstBid);
    

    double l = top - bottom;
    



    double timeFactor = getTimeFactor();
    


    double hardThreshold = bottom + l * timeFactor;
    

    return getUtilityWithDiscount(hardThreshold);
  }
  
  protected double getTimeFactor()
  {
    double t = this.timeline.getTime();
    double d = this.utilitySpace.getDiscountFactor();
    d = (d <= 0.0D) || (d > 1.0D) ? 1.0D : d;
    

    return Math.pow(1.0D - t, t / 4.0D) - (1.0D - d) * t;
  }
  
  private double getUtilityWithoutDiscount(Bid bid)
  {
    double d = this.utilitySpace.getDiscountFactor();
    d = (d <= 0.0D) || (d > 1.0D) ? 1.0D : d;
    return getUtility(bid) / Math.pow(d, this.timeline.getTime());
  }
  
  private double getUtilityWithDiscount(double util)
  {
    double t = this.timeline.getTime();
    double d = this.utilitySpace.getDiscountFactor();
    d = (d <= 0.0D) || (d > 1.0D) ? 1.0D : d;
    return util * Math.pow(d, t);
  }
  
  private class UtilityAnalyzer
  {
    private UtilitySpace utilitySpace;
    private ArrayList<Issue> allIssues;
    private HashMap<Issue, ArrayList<Value>> preferredValuesPerIssue = new HashMap();
    private HashMap<Issue, HashMap<Value, Double>> utilityPerValuePerIssue = new HashMap();
    private Bid bid;
    
    public UtilityAnalyzer(UtilitySpace space, Bid maxUtilityBid)
    {
      this.utilitySpace = space;
      this.allIssues = this.utilitySpace.getDomain().getIssues();
      this.bid = Clone(maxUtilityBid);
      try
      {
        BuildValuePreferences();
      }
      catch (Exception localException) {}
      ???;
    }
    
    private void BuildValuePreferences()
      throws Exception
    {
      for (final Issue issue : this.allIssues)
      {
        this.utilityPerValuePerIssue.put(issue, new HashMap());
        

        ArrayList<Value> values = new ArrayList();
        switch (ShAgent.1.$SwitchMap$negotiator$issue$ISSUETYPE[issue.getType().ordinal()])
        {
        case 1: 
          IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
          int numOptions = issueDiscrete.getNumberOfValues();
          for (int i = 0; i < numOptions; i++)
          {
            Value value = issueDiscrete.getValue(i);
            values.add(value);
            updateUtilityForSpecificValue(issue, value);
          }
          break;
        case 2: 
          IssueReal issueReal = (IssueReal)issue;
          int numOptions = issueReal.getNumberOfDiscretizationSteps() - 1;
          



          double step = (issueReal.getUpperBound() - issueReal.getLowerBound()) / issueReal.getNumberOfDiscretizationSteps();
          for (double dVal = issueReal.getLowerBound(); dVal <= issueReal.getUpperBound(); dVal += step)
          {
            Value value = new ValueReal(dVal);
            values.add(value);
            updateUtilityForSpecificValue(issue, value);
          }
          break;
        case 3: 
          IssueInteger issueInteger = (IssueInteger)issue;
          for (int i = issueInteger.getLowerBound(); i <= issueInteger.getUpperBound(); i++)
          {
            Value value = new ValueInteger(i);
            values.add(value);
            updateUtilityForSpecificValue(issue, value);
          }
        }
        Collections.sort(values, new Comparator()
        {
          public int compare(Value o1, Value o2)
          {
            return Double.compare(
              ((Double)((HashMap)ShAgent.UtilityAnalyzer.this.utilityPerValuePerIssue.get(issue)).get(o1)).doubleValue(), 
              ((Double)((HashMap)ShAgent.UtilityAnalyzer.this.utilityPerValuePerIssue.get(issue)).get(o2)).doubleValue());
          }
        });
        this.preferredValuesPerIssue.put(issue, values);
      }
    }
    
    private void updateUtilityForSpecificValue(Issue issue, Value value)
      throws Exception
    {
      this.bid.setValue(issue.getNumber(), value);
      
      double util = this.utilitySpace.getWeight(issue.getNumber()) * this.utilitySpace.getEvaluation(issue.getNumber(), this.bid);
      ((HashMap)this.utilityPerValuePerIssue.get(issue)).put(value, Double.valueOf(util));
    }
    
    private class OfferStep
      implements Comparable<OfferStep>
    {
      public double UtilOffset;
      public Issue Issue;
      public Value Value;
      
      public OfferStep(double utilOffset, Issue issue, Value value)
      {
        this.UtilOffset = utilOffset;
        this.Issue = issue;
        this.Value = value;
      }
      
      public int compareTo(OfferStep other)
      {
        return Double.compare(this.UtilOffset, other.UtilOffset);
      }
    }
    
    private Bid Clone(Bid source)
    {
      Bid clone = null;
      try
      {
        HashMap<Integer, Value> map = new HashMap();
        for (Issue issue : this.allIssues) {
          map.put(Integer.valueOf(issue.getNumber()), source
            .getValue(issue.getNumber()));
        }
        clone = new Bid(this.utilitySpace.getDomain(), map);
      }
      catch (Exception e) {}
      return clone;
    }
    
    public Bid StepCloser(Bid lastOffer)
      throws Exception
    {
      Bid offer = Clone(lastOffer);
      
      int issueCount = this.allIssues.size();
      List<OfferStep> steps = new ArrayList(issueCount);
      for (Issue issue : this.allIssues)
      {
        OfferStep step = GetOfferStepInIssue(lastOffer, issue);
        steps.add(step);
      }
      Collections.sort(steps, Collections.reverseOrder());
      

      double totalOffset = 0.0D;
      for (int i = 0; i < issueCount; i++) {
        totalOffset += ((OfferStep)steps.get(i)).UtilOffset;
      }
      Random random = new Random();
      double randomValue = random.nextDouble() * totalOffset;
      
      OfferStep bestStep = (OfferStep)steps.get(0);
      for (int i = 0; i < issueCount; i++)
      {
        randomValue -= ((OfferStep)steps.get(i)).UtilOffset;
        if (randomValue < 0.0D)
        {
          bestStep = (OfferStep)steps.get(i);
          break;
        }
      }
      offer.setValue(bestStep.Issue.getNumber(), bestStep.Value);
      
      return offer;
    }
    
    private OfferStep GetOfferStepInIssue(Bid lastOffer, Issue issue)
      throws Exception
    {
      int i = issue.getNumber();
      

      ArrayList<Value> issueValues = (ArrayList)this.preferredValuesPerIssue.get(issue);
      






      double oldUtil = 0.0D;
      double newUtil = 0.0D;
      switch (ShAgent.1.$SwitchMap$negotiator$issue$ISSUETYPE[issue.getType().ordinal()])
      {
      case 1: 
      case 3: 
        Value oldValue = lastOffer.getValue(i);
        int oldIndex = issueValues.indexOf(oldValue);
        
        int newIndex = Math.min(issueValues.size() - 1, oldIndex + 1);
        Value newValue = (Value)issueValues.get(newIndex);
        
        oldUtil = ((Double)((HashMap)this.utilityPerValuePerIssue.get(issue)).get(oldValue)).doubleValue();
        newUtil = ((Double)((HashMap)this.utilityPerValuePerIssue.get(issue)).get(newValue)).doubleValue();
        break;
      case 2: 
        IssueReal issueReal = (IssueReal)issue;
        
        Value oldValue = lastOffer.getValue(i);
        int oldIndex = issueValues.indexOf(oldValue);
        
        this.bid.setValue(issue.getNumber(), oldValue);
        
        oldUtil = this.utilitySpace.getWeight(issue.getNumber()) * this.utilitySpace.getEvaluation(issue.getNumber(), this.bid);
        

        double dOldValue = ((ValueReal)oldValue).getValue();
        

        double step = (issueReal.getUpperBound() - issueReal.getLowerBound()) / issueReal.getNumberOfDiscretizationSteps();
        Value newValue = new ValueReal(Math.min(dOldValue + step, issueReal
          .getUpperBound()));
        
        this.bid.setValue(issue.getNumber(), newValue);
        
        newUtil = this.utilitySpace.getWeight(issue.getNumber()) * this.utilitySpace.getEvaluation(issue.getNumber(), this.bid);
        

        Value newValueDown = new ValueReal(Math.max(dOldValue - step, issueReal
          .getLowerBound()));
        this.bid.setValue(issue.getNumber(), newValueDown);
        

        double newUtilDown = this.utilitySpace.getWeight(issue.getNumber()) * this.utilitySpace.getEvaluation(issue.getNumber(), this.bid);
        if (newUtilDown > newUtil)
        {
          newUtil = newUtilDown;
          newValue = newValueDown;
        }
        break;
      default: 
        throw new Exception("Unknown issue type");
      }
      Value newValue;
      int oldIndex;
      Value oldValue;
      double utilOffset = newUtil - oldUtil;
      
      OfferStep step = new OfferStep(utilOffset, issue, newValue);
      return step;
    }
    
    public Bid GetClosestOffer(Bid lastBid, double threshold)
      throws Exception
    {
      Bid offer = null;
      Bid lastOffer = Clone(lastBid);
      do
      {
        offer = StepCloser(lastOffer);
        lastOffer = offer;
      } while (this.utilitySpace.getUtility(offer) < threshold);
      return offer;
    }
  }
  
  private class OpponentModel
  {
    private ArrayList<Issue> allIssues;
    private HashMap<Issue, ArrayList<Value>> opponentPrefferedValuePerIssue = new HashMap();
    private Timeline timeline;
    private double[] previousTurnTimesArr = new double[100];
    private int turnNumber = 0;
    private double lastTurnStartTime = 0.0D;
    
    public OpponentModel(UtilitySpace utilitySpace, Timeline timeline)
    {
      this.timeline = timeline;
      
      this.allIssues = utilitySpace.getDomain().getIssues();
      for (Issue issue : this.allIssues) {
        this.opponentPrefferedValuePerIssue.put(issue, new ArrayList());
      }
    }
    
    public void receiveNewOpponentBid(Bid bid)
    {
      manageTiming();
      for (Issue issue : this.allIssues) {
        try
        {
          Value value = bid.getValue(issue.getNumber());
          if (!((ArrayList)this.opponentPrefferedValuePerIssue.get(issue)).contains(value)) {
            ((ArrayList)this.opponentPrefferedValuePerIssue.get(issue)).add(value);
          }
        }
        catch (Exception e) {}
      }
    }
    
    private void manageTiming()
    {
      double currTime = this.timeline.getTime();
      
      this.previousTurnTimesArr[(this.turnNumber % this.previousTurnTimesArr.length)] = (currTime - this.lastTurnStartTime);
      

      this.turnNumber += 1;
      
      this.lastTurnStartTime = currTime;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.ShAgent.ShAgent
 * JD-Core Version:    0.7.1
 */