package agents.anac.y2012.MetaAgent.agents.SimpleAgentNew;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class SimpleAgentNew
  extends Agent
{
  private Action actionOfPartner;
  private final int FIRST_THR = 180;
  private final int SECOND_THR = 90;
  private final int THIRD_THR = 30;
  private final int FOURTH_THR = 1;
  private final int FIFTH_THR = 0;
  private final int MAX_BID_TIME = 5;
  private final int TEMP_FIRST_THR = 360;
  private static double MAX_UTILITY = 0.0D;
  Map<Bid, Integer> offeredBidsCounterMap;
  Map<Bid, Integer> rejectedBidsCounterMap;
  Map<Value, Integer> itemsCounterMap;
  
  public SimpleAgentNew()
  {
    this.actionOfPartner = null;
    




    this.FIRST_THR = 180;
    this.SECOND_THR = 90;
    this.THIRD_THR = 30;
    this.FOURTH_THR = 1;
    this.FIFTH_THR = 0;
    this.MAX_BID_TIME = 5;
    this.TEMP_FIRST_THR = 360;
    

    this.offeredBidsCounterMap = new HashMap();
    this.rejectedBidsCounterMap = new HashMap();
    this.itemsCounterMap = new HashMap();
  }
  
  public void init()
  {
    super.init();
    try
    {
      Bid maxBid = this.utilitySpace.getMaxUtilityBid();
      MAX_UTILITY = this.utilitySpace.getUtility(maxBid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public void init(int sessionNumberP, int sessionTotalNumberP, Date startTimeP, Integer totalTimeP, UtilitySpace us) {}
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseMaxBidAction();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        if (this.offeredBidsCounterMap.get(partnerBid) == null) {
          this.offeredBidsCounterMap.put(partnerBid, Integer.valueOf(0));
        }
        this.offeredBidsCounterMap.put(partnerBid, Integer.valueOf(((Integer)this.offeredBidsCounterMap.get(partnerBid)).intValue() + 1));
        ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
        for (Issue lIssue : issues)
        {
          Value issueVal = partnerBid.getValue(lIssue.getNumber());
          if (this.itemsCounterMap.get(issueVal) == null) {
            this.itemsCounterMap.put(issueVal, Integer.valueOf(0));
          }
          this.itemsCounterMap.put(issueVal, 
            Integer.valueOf(((Integer)this.itemsCounterMap.get(issueVal)).intValue() + 1));
        }
        double time = (new Date().getTime() - this.startTime.getTime()) / 1000.0D;
        boolean accept = acceptStrategy(partnerBid, time);
        if (accept) {
          action = new Accept(getAgentID());
        } else {
          action = chooseBidAction(time);
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private double getWeight(Bid bid)
  {
    double weight = 0.0D;
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    for (Issue lIssue : issues)
    {
      IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
      double maxCounter = 0.0D;
      for (int i = 0; i < lIssueDiscrete.getNumberOfValues(); i++)
      {
        int itemCounter = getItemCounter(lIssueDiscrete.getValue(i));
        if (itemCounter > maxCounter) {
          maxCounter = itemCounter;
        }
      }
      try
      {
        Value issueVal = bid.getValue(lIssue.getNumber());
        if (this.itemsCounterMap.get(issueVal) == null) {
          return -1.0D;
        }
        int counter = ((Integer)this.itemsCounterMap.get(issueVal)).intValue();
        weight += counter / maxCounter;
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return weight;
  }
  
  private int getItemCounter(ValueDiscrete value)
  {
    if (this.itemsCounterMap.get(value) == null) {
      return 0;
    }
    return ((Integer)this.itemsCounterMap.get(value)).intValue();
  }
  
  private boolean acceptStrategy(Bid partnerBid, double time)
  {
    double currentTime = 180.0D - time;
    try
    {
      double offeredUtility = this.utilitySpace.getUtility(partnerBid);
      if (currentTime >= 90.0D)
      {
        double minRelativeUtility = (1.0D - time / 360.0D) * MAX_UTILITY;
        return offeredUtility >= minRelativeUtility;
      }
      if ((currentTime < 90.0D) && (currentTime > 1.0D))
      {
        double minRelativeUtility = (180.0D - time) / 90.0D * MAX_UTILITY;
        if (minRelativeUtility <= 0.66D) {
          minRelativeUtility *= 1.5D;
        }
        System.out.println("second iterval, minutility=" + minRelativeUtility);
        
        return offeredUtility >= minRelativeUtility;
      }
      if (currentTime <= 1.0D) {
        return offeredUtility > 0.0D;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return false;
  }
  
  private Action chooseMaxBidAction()
  {
    Bid maxBid = null;
    try
    {
      maxBid = this.utilitySpace.getMaxUtilityBid();
    }
    catch (Exception e)
    {
      System.out.println("Problem with received bid:" + e.getMessage() + ". cancelling bidding");
    }
    if (maxBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), maxBid);
  }
  
  private Action chooseBidAction(double time)
  {
    double currentTime = 180.0D - time;
    
    Bid nextBid = null;
    List<Bid> bidsLst = getAllBids();
    if (currentTime > 90.0D)
    {
      double utilityToSearch = 0.96D;
      nextBid = FindClosestBid(utilityToSearch, bidsLst);
    }
    else if ((currentTime <= 90.0D) && (currentTime >= 85.0D))
    {
      try
      {
        nextBid = this.utilitySpace.getMaxUtilityBid();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else if ((currentTime < 85.0D) && (currentTime >= 30.0D))
    {
      double utilityToSearch = (180.0D - time) / 90.0D * MAX_UTILITY;
      if (utilityToSearch <= 0.66D) {
        utilityToSearch *= 1.5D;
      }
      System.out.println("utility to search for proposa" + utilityToSearch);
      
      nextBid = FindClosestBid(utilityToSearch, bidsLst);
      try
      {
        System.out.println("found bid utility" + this.utilitySpace
          .getUtility(nextBid));
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else if ((currentTime >= 25.0D) && (currentTime < 30.0D))
    {
      try
      {
        nextBid = this.utilitySpace.getMaxUtilityBid();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else if ((currentTime >= 1.0D) && (currentTime < 25.0D))
    {
      try
      {
        nextBid = this.utilitySpace.getMaxUtilityBid();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    else if (currentTime >= 0.0D)
    {
      try
      {
        nextBid = this.utilitySpace.getMaxUtilityBid();
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    if (this.rejectedBidsCounterMap.get(nextBid) == null) {
      this.rejectedBidsCounterMap.put(nextBid, Integer.valueOf(0));
    }
    this.rejectedBidsCounterMap.put(nextBid, Integer.valueOf(((Integer)this.rejectedBidsCounterMap.get(nextBid)).intValue() + 1));
    
    Bid opponentBid = getOpponentBestBid();
    try
    {
      System.out.println(this.utilitySpace.getUtility(nextBid));
      System.out.println(this.utilitySpace.getUtility(opponentBid));
      System.out.println("-------");
      if (this.utilitySpace.getUtility(nextBid) < this.utilitySpace.getUtility(opponentBid)) {
        return new Offer(getAgentID(), opponentBid);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid getOpponentBestBid()
  {
    Set<Bid> opponentBidsSet = this.offeredBidsCounterMap.keySet();
    List<Bid> opponentBidsLst = new ArrayList();
    opponentBidsLst.addAll(opponentBidsSet);
    Collections.sort(opponentBidsLst, new BidComparator());
    
    Bid maxBid = (Bid)opponentBidsLst.get(0);
    for (int i = 0; (i < opponentBidsLst.size()) && (i < 5); i++) {
      try
      {
        if (this.utilitySpace.getUtility((Bid)opponentBidsLst.get(i)) < this.utilitySpace.getUtility(maxBid)) {
          maxBid = (Bid)opponentBidsLst.get(i);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return maxBid;
  }
  
  private Bid FindClosestBid(double utilityToSearch, List<Bid> bidsLst)
  {
    double foundUtility = 0.0D;
    int foundBidIndex = 0;
    for (int i = 0; i < bidsLst.size(); i++)
    {
      Bid currentBid = (Bid)bidsLst.get(i);
      double currentBidUtility = getUtility(currentBid);
      if ((currentBidUtility <= utilityToSearch) && (currentBidUtility > foundUtility))
      {
        foundUtility = currentBidUtility;
        foundBidIndex = i;
      }
    }
    return (Bid)bidsLst.get(foundBidIndex);
  }
  
  private List<Bid> getAllBids()
  {
    List<List<ValueDiscrete>> allLst = new ArrayList();
    List<Integer> issuesIdLst = new ArrayList();
    
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    for (Issue lIssue : issues)
    {
      issuesIdLst.add(Integer.valueOf(lIssue.getNumber()));
      switch (lIssue.getType())
      {
      case DISCRETE: 
        lIssueDiscrete = (IssueDiscrete)lIssue;
        if (allLst.isEmpty())
        {
          for (int i = 0; i < lIssueDiscrete.getNumberOfValues(); i++)
          {
            l = new ArrayList();
            l.add(lIssueDiscrete.getValue(i));
            allLst.add(l);
          }
        }
        else
        {
          List<List<ValueDiscrete>> tempValuesLst = new ArrayList();
          tempValuesLst.addAll(allLst);
          allLst = new ArrayList();
          for (List<ValueDiscrete> oldLst : tempValuesLst) {
            for (int i = 0; i < lIssueDiscrete.getNumberOfValues(); i++)
            {
              List<ValueDiscrete> l = new ArrayList();
              l.addAll(oldLst);
              l.add(lIssueDiscrete.getValue(i));
              allLst.add(l);
            }
          }
        }
        break;
      }
    }
    IssueDiscrete lIssueDiscrete;
    List<ValueDiscrete> l;
    Object bidsLst = convertValuesListToBids(allLst, issuesIdLst);
    
    return (List<Bid>)bidsLst;
  }
  
  private List<Bid> convertValuesListToBids(List<List<ValueDiscrete>> lst, List<Integer> issuesIdLst)
  {
    List<Bid> bidsLst = new ArrayList();
    try
    {
      for (List<ValueDiscrete> valuesLst : lst)
      {
        HashMap<Integer, Value> values = new HashMap();
        for (int i = 0; i < valuesLst.size(); i++) {
          values.put(issuesIdLst.get(i), valuesLst.get(i));
        }
        bidsLst.add(new Bid(this.utilitySpace.getDomain(), values));
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bidsLst;
  }
  
  class BidComparator
    implements Comparator
  {
    BidComparator() {}
    
    public int compare(Object bid1, Object bid2)
    {
      double bid1Weight = SimpleAgentNew.this.getWeight((Bid)bid1);
      double bid2Weight = SimpleAgentNew.this.getWeight((Bid)bid2);
      if (bid1Weight > bid2Weight) {
        return 1;
      }
      if (bid1Weight < bid2Weight) {
        return -1;
      }
      return 0;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.SimpleAgentNew.SimpleAgentNew
 * JD-Core Version:    0.7.1
 */