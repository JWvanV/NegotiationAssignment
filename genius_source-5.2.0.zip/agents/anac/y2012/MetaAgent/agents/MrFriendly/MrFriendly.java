package agents.anac.y2012.MetaAgent.agents.MrFriendly;

import java.io.PrintStream;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class MrFriendly
  extends Agent
{
  private static final double FIRST_TIME_BOUNDARY = 0.9D;
  private static final double MIN_OPPONENT_BIDS_FOR_MODEL = 100.0D;
  private static final double RESERVATION_VALUE = 0.3D;
  private double alwaysAcceptUtility;
  private OpponentModel opponentModel;
  private BidTable bidTable;
  private boolean discountedDomain = false;
  private double discountFactor;
  
  public void init()
  {
    double minimumBidUtility = 0.3D;
    try
    {
      this.alwaysAcceptUtility = getUtility(this.utilitySpace.getMaxUtilityBid());
      if (this.alwaysAcceptUtility < minimumBidUtility) {
        minimumBidUtility = 0.0D;
      }
    }
    catch (Exception e)
    {
      this.alwaysAcceptUtility = 1.0D;
    }
    this.discountFactor = this.utilitySpace.getDiscountFactor();
    this.discountedDomain = this.utilitySpace.isDiscounted();
    this.opponentModel = new OpponentModel(this.utilitySpace.getDomain().getIssues(), this.discountFactor, this.timeline);
    
    this.bidTable = new BidTable(this, this.utilitySpace, minimumBidUtility, this.opponentModel);
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.bidTable.addOpponentAction(opponentAction);
  }
  
  public Action chooseAction()
  {
    Bid bid = null;
    Action action = null;
    try
    {
      Bid partnerBid = this.bidTable.getLastOpponentBid();
      if (partnerBid != null)
      {
        double offeredUtility = getUtility(partnerBid);
        
        double acceptNowUtil = this.discountedDomain ? this.alwaysAcceptUtility * Math.pow(this.discountFactor, this.timeline.getTime()) : this.alwaysAcceptUtility;
        if ((offeredUtility >= acceptNowUtil) || (this.bidTable.weHaveOfferedThisBefore(partnerBid))) {
          return new Accept(getAgentID());
        }
      }
      if ((this.discountedDomain) && (this.timeline.getTime() > 0.5D))
      {
        if ((this.timeline.getTime() < 0.9D) && ((this.bidTable.getNumberOfOpponentBids() < 100.0D) || ((this.opponentModel.isStalling(this.bidTable.getConsecutiveBidsDifferent())) && (!weAreStalling()))))
        {
          bid = this.bidTable.getBestBid();
        }
        else
        {
          bid = this.bidTable.getBestBidUsingModel();
          

          this.bidTable.removeBid(bid);
        }
      }
      else if ((this.timeline.getTime() < 0.9D) && ((this.bidTable.getNumberOfOpponentBids() < 100.0D) || (this.opponentModel.isStalling(this.bidTable.getConsecutiveBidsDifferent()))))
      {
        bid = this.bidTable.getBestBid();
      }
      else
      {
        bid = this.bidTable.getBestBidUsingModel();
        

        this.bidTable.removeBid(bid);
      }
      action = new Offer(getAgentID(), bid);
      

      this.bidTable.addOwnBid(bid);
      

      this.alwaysAcceptUtility = Math.max(this.alwaysAcceptUtility, getUtility(bid));
      if (this.alwaysAcceptUtility < this.bidTable.getMinimumBidUtility()) {
        this.alwaysAcceptUtility = this.bidTable.getMinimumBidUtility();
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in chooseAction:" + e.getMessage());
      try
      {
        Bid bestBid = this.utilitySpace.getMaxUtilityBid();
        Action offer = new Offer(getAgentID(), bestBid);
        action = offer;
      }
      catch (Exception e2)
      {
        System.out.println("Exception in chooseAction while retrieving best bid of the domain: " + e2.getMessage());
        


        action = new Accept(getAgentID());
      }
    }
    return action;
  }
  
  private boolean weAreStalling()
  {
    return this.bidTable.weAreStalling();
  }
  
  public String getVersion()
  {
    return "5.0";
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.MrFriendly.MrFriendly
 * JD-Core Version:    0.7.1
 */