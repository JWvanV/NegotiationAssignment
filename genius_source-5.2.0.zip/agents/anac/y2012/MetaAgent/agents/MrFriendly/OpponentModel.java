package agents.anac.y2012.MetaAgent.agents.MrFriendly;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.ValueDiscrete;

public class OpponentModel
{
  private HashMap<Issue, Integer> issueChanged;
  private HashMap<Issue, HashMap<String, Integer>> valuesOffered;
  private HashMap<Issue, ArrayList<Double>> relativeFrequency;
  private int bidCounter;
  private ArrayList<Issue> issueList;
  private boolean isProperlyInitialized;
  private HashMap<Issue, Double> issueWeights;
  private double[] kernel;
  private boolean discountedDomain;
  private double discountFactor;
  private Timeline timeline;
  
  public OpponentModel(ArrayList<Issue> iList, double discountFactor, Timeline tl)
  {
    this.issueList = iList;
    this.issueChanged = new HashMap();
    this.valuesOffered = new HashMap();
    this.relativeFrequency = new HashMap();
    this.issueWeights = new HashMap();
    this.bidCounter = 0;
    this.isProperlyInitialized = true;
    for (Issue i : this.issueList)
    {
      this.issueChanged.put(i, Integer.valueOf(0));
      addValuesOffered(i);
      this.relativeFrequency.put(i, new ArrayList());
    }
    this.kernel = new double[100];
    for (int i = 1; i < 101; i++) {
      this.kernel[(i - 1)] = (-5.0D + 0.1D * i);
    }
    this.discountFactor = discountFactor;
    if ((discountFactor != 0.0D) && (discountFactor != 1.0D)) {
      this.discountedDomain = true;
    }
    this.timeline = tl;
  }
  
  private void updateModel(Bid nextBid)
    throws Exception
  {
    this.bidCounter += 1;
    for (Issue issue : this.issueList)
    {
      HashMap<String, Integer> hm = (HashMap)this.valuesOffered.get(issue);
      


      int c = ((Integer)hm.get(((ValueDiscrete)nextBid.getValue(issue.getNumber())).getValue())).intValue() + 1;
      hm.put(((ValueDiscrete)nextBid.getValue(issue.getNumber())).getValue(), Integer.valueOf(c));
      this.valuesOffered.put(issue, hm);
      

      ((ArrayList)this.relativeFrequency.get(issue)).add(Double.valueOf(c / this.bidCounter));
    }
    double[] expectedValue = new double[100];
    double totalValue = 0.0D;
    for (Issue i : this.issueList)
    {
      double[] probabilityDensity = new double[100];
      ArrayList<Double> frequencyComponents = (ArrayList)this.relativeFrequency.get(i);
      for (Iterator i$ = frequencyComponents.iterator(); i$.hasNext();)
      {
        double d = ((Double)i$.next()).doubleValue();
        for (int index = 0; index < 100; index++) {
          probabilityDensity[index] += Math.exp(-Math.pow(this.kernel[index] - d, 2.0D) / 2.0D) / (index + 1);
        }
      }
      expectedValue[i.getNumber()] = 0.0D;
      for (int j = 0; j < 100; j++) {
        expectedValue[i.getNumber()] += this.kernel[j] * probabilityDensity[j] / 100.0D;
      }
      totalValue += expectedValue[i.getNumber()];
    }
    for (Issue i : this.issueList) {
      this.issueWeights.put(i, Double.valueOf(expectedValue[i.getNumber()] / totalValue));
    }
  }
  
  public HashMap<Issue, Double> getIssueWeights()
  {
    return this.issueWeights;
  }
  
  public String getPreferredValueForIssue(Issue i)
  {
    int max = 0;
    String current = "";
    for (Map.Entry<String, Integer> e : ((HashMap)this.valuesOffered.get(i)).entrySet()) {
      if (((Integer)e.getValue()).intValue() >= max)
      {
        current = (String)e.getKey();
        max = ((Integer)e.getValue()).intValue();
      }
    }
    return current;
  }
  
  public double getEstimatedUtility(Bid bid)
  {
    double totalUtil = 0.0D;
    for (Issue i : this.issueList)
    {
      IssueDiscrete id = (IssueDiscrete)i;
      HashMap<String, Integer> valueCounts = (HashMap)this.valuesOffered.get(i);
      int maxcount = 0;
      for (ValueDiscrete vald : id.getValues()) {
        maxcount = ((Integer)valueCounts.get(vald.getValue())).intValue() > maxcount ? ((Integer)valueCounts.get(vald.getValue())).intValue() : maxcount;
      }
      try
      {
        totalUtil += ((Integer)valueCounts.get(((ValueDiscrete)bid.getValue(i.getNumber())).getValue())).intValue() / maxcount * ((Double)this.issueWeights.get(i)).doubleValue();
      }
      catch (Exception e)
      {
        return -1.0D;
      }
    }
    if (this.discountedDomain) {
      totalUtil *= Math.pow(this.discountFactor, this.timeline.getTime());
    }
    return totalUtil;
  }
  
  public boolean isProperlyInitialized()
  {
    return this.isProperlyInitialized;
  }
  
  private void addValuesOffered(Issue i)
  {
    switch (i.getType())
    {
    case DISCRETE: 
      IssueDiscrete id = (IssueDiscrete)i;
      List<ValueDiscrete> valsD = id.getValues();
      HashMap<String, Integer> counters = new HashMap();
      for (ValueDiscrete v : valsD) {
        counters.put(v.getValue(), Integer.valueOf(0));
      }
      this.valuesOffered.put(i, counters);
      break;
    case REAL: 
      this.isProperlyInitialized = false;
      break;
    case INTEGER: 
      this.isProperlyInitialized = false;
    }
  }
  
  public void addOpponentBid(Bid lastOpponentBid)
  {
    try
    {
      updateModel(lastOpponentBid);
    }
    catch (Exception e) {}
  }
  
  public boolean isStalling(int consecutiveDiff)
  {
    return consecutiveDiff < 3;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.MrFriendly.OpponentModel
 * JD-Core Version:    0.7.1
 */