package agents.anac.y2012.MetaAgent.agents.MrFriendly;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.actions.Action;
import negotiator.actions.Offer;

public class BidHistoryTracker
{
  private ArrayList<Bid> bidListOpponent;
  private ArrayList<Bid> bidListSelf;
  private int consecutiveBidsDifferent;
  private int ourStallingCoefficient;
  
  public BidHistoryTracker()
  {
    this.bidListOpponent = new ArrayList();
    this.bidListSelf = new ArrayList();
    this.consecutiveBidsDifferent = 0;
    this.ourStallingCoefficient = 0;
  }
  
  public void addOpponentAction(Action action)
  {
    if ((action instanceof Offer))
    {
      Offer offer = (Offer)action;
      Bid bid = offer.getBid();
      if (bidAlreadyDoneByOpponent(bid)) {
        this.consecutiveBidsDifferent = 0;
      } else {
        this.consecutiveBidsDifferent += 1;
      }
      this.bidListOpponent.add(bid);
    }
  }
  
  public void addOwnBid(Bid bid)
  {
    if (bidAlreadyDoneByMyself(bid)) {
      this.ourStallingCoefficient += 1;
    } else {
      this.ourStallingCoefficient = 0;
    }
    if (bid != null) {
      this.bidListSelf.add(bid);
    }
  }
  
  public Bid getLastOpponentBid()
  {
    return getLastBidOf(this.bidListOpponent);
  }
  
  public Bid getLastOwnBid()
  {
    return getLastBidOf(this.bidListSelf);
  }
  
  private Bid getLastBidOf(ArrayList<Bid> list)
  {
    Bid result = null;
    if (!list.isEmpty()) {
      result = (Bid)list.get(list.size() - 1);
    }
    return result;
  }
  
  public boolean bidAlreadyDoneByMyself(Bid bid)
  {
    return this.bidListSelf.contains(bid);
  }
  
  private boolean bidAlreadyDoneByOpponent(Bid bid)
  {
    return this.bidListOpponent.contains(bid);
  }
  
  public int getNumberOfOpponentBids()
  {
    return this.bidListOpponent.size();
  }
  
  public int getConsecutiveBidsDifferent()
  {
    return this.consecutiveBidsDifferent;
  }
  
  public int getOurStallingCoefficient()
  {
    return this.ourStallingCoefficient;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.MrFriendly.BidHistoryTracker
 * JD-Core Version:    0.7.1
 */