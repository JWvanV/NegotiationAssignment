package agents.anac.y2012.MetaAgent.agents.MrFriendly;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class BidTable
{
  private Agent agent;
  private UtilitySpace utilitySpace;
  private HashMap<Integer, Bid> bidTable;
  private ArrayList<Bid> topXBids;
  private HashMap<Integer, Double> utilityTable;
  private HashMap<Integer, Double> estimatedOpponentUtilityTable;
  private int counter;
  private double minimumBidUtility;
  private Bid bestOpponentBid;
  private OpponentModel opponentModel;
  private BidHistoryTracker bidHistoryTracker;
  private static final double OFFERED_UTIL_DECAY = 0.99D;
  private static final double TOP_BIDS_PERCENTAGE = 0.005D;
  
  public BidTable(Agent a, UtilitySpace us, double mbu, OpponentModel opponentModel)
  {
    this.agent = a;
    this.utilitySpace = us;
    this.bestOpponentBid = null;
    setMinimumBidUtility(mbu);
    this.opponentModel = opponentModel;
    
    this.bidTable = new HashMap();
    this.topXBids = new ArrayList();
    this.utilityTable = new HashMap();
    this.estimatedOpponentUtilityTable = new HashMap();
    
    this.counter = 0;
    this.bidHistoryTracker = new BidHistoryTracker();
    
    initializeTables();
  }
  
  private void initializeTables()
  {
    fillBidsArray();
    fillTopXHash();
  }
  
  public void setMinimumBidUtility(double mbu)
  {
    if ((mbu <= 1.05D) && (mbu >= 0.0D)) {
      this.minimumBidUtility = mbu;
    } else {
      this.minimumBidUtility = 0.0D;
    }
  }
  
  public double getMinimumBidUtility()
  {
    return this.minimumBidUtility;
  }
  
  public boolean weHaveOfferedThisBefore(Bid bid)
  {
    return this.bidHistoryTracker.bidAlreadyDoneByMyself(bid);
  }
  
  public Bid getBestBid()
  {
    checkIfBidTableIsNotEmpty();
    Random rnd = new Random();
    int index = rnd.nextInt(this.topXBids.size());
    if (index > -1) {
      return (Bid)this.topXBids.get(index);
    }
    return (Bid)this.bidTable.get(getIndexByUtility((Double)Collections.max(this.utilityTable.values())));
  }
  
  public Bid getBestBidUsingModel()
  {
    checkIfBidTableIsNotEmpty();
    if (!this.opponentModel.isProperlyInitialized()) {
      return getBestBid();
    }
    if (getLastOwnBid() == null) {
      return (Bid)this.bidTable.get(getIndexByUtility((Double)Collections.max(this.utilityTable.values())));
    }
    int indexBestBid = getIndexParetoBid();
    if (indexBestBid == -1)
    {
      double hi = this.agent.getUtility(getLastOwnBid());
      double lo = this.minimumBidUtility;
      double desiredValue = lo + 0.99D * (hi - lo);
      return (Bid)this.bidTable.get(getIndexAroundUtility(Double.valueOf(desiredValue), Double.valueOf(0.01D)));
    }
    return (Bid)this.bidTable.get(Integer.valueOf(indexBestBid));
  }
  
  private int getIndexParetoBid()
  {
    double hi = this.agent.getUtility(getLastOwnBid());
    double lo = this.minimumBidUtility;
    
    double desiredValue = lo + 0.99D * (hi - lo);
    if (hi < lo) {
      desiredValue = lo;
    }
    Set<Map.Entry<Integer, Double>> my_util_entryset = this.utilityTable.entrySet();
    double maxOpponentUtility = 0.0D;
    int index = -1;
    for (Map.Entry<Integer, Double> entry : my_util_entryset) {
      if ((((Double)entry.getValue()).doubleValue() >= desiredValue) && 
        (((Double)this.estimatedOpponentUtilityTable.get(entry.getKey())).doubleValue() > maxOpponentUtility))
      {
        index = ((Integer)entry.getKey()).intValue();
        maxOpponentUtility = ((Double)this.estimatedOpponentUtilityTable.get(Integer.valueOf(index))).doubleValue();
      }
    }
    return index;
  }
  
  private void updateEstimatedOpponentUtilityTable()
  {
    Set<Map.Entry<Integer, Bid>> entryset = this.bidTable.entrySet();
    for (Map.Entry<Integer, Bid> entry : entryset) {
      this.estimatedOpponentUtilityTable.put(entry.getKey(), Double.valueOf(this.opponentModel.getEstimatedUtility((Bid)entry.getValue())));
    }
  }
  
  public void updateBidTable()
  {
    ArrayList<Integer> indexesToDelete = new ArrayList();
    


    Set<Map.Entry<Integer, Double>> entrySet = this.utilityTable.entrySet();
    for (Map.Entry<Integer, Double> entry : entrySet) {
      if (((Double)entry.getValue()).doubleValue() < this.minimumBidUtility)
      {
        this.bidTable.remove(entry.getKey());
        indexesToDelete.add(entry.getKey());
      }
    }
    for (Integer entry : indexesToDelete)
    {
      this.utilityTable.remove(entry);
      if (this.estimatedOpponentUtilityTable.size() > 0) {
        this.estimatedOpponentUtilityTable.remove(entry);
      }
    }
  }
  
  public void removeBid(Bid bid)
  {
    int index = -1;
    for (Map.Entry<Integer, Bid> entry : this.bidTable.entrySet()) {
      if (((Bid)entry.getValue()).equals(bid))
      {
        index = ((Integer)entry.getKey()).intValue();
        break;
      }
    }
    if (index != -1)
    {
      Object bidTableRemove = this.bidTable.remove(Integer.valueOf(index));
      Object utilityTableRemove = this.utilityTable.remove(Integer.valueOf(index));
      Object opponentTableRemove = this.estimatedOpponentUtilityTable.remove(Integer.valueOf(index));
      if (bidTableRemove == null) {
        System.out.println("Error: unable to remove bid from bidTable, because it is not found.");
      }
      if (utilityTableRemove == null) {
        System.out.println("Error: unable to remove the utility from utilityTable, because it is not found.");
      }
      if (opponentTableRemove == null) {
        System.out.println("Error: unable to remove the utility from estimatedOpponentUtilityTable, because it is not found.");
      }
    }
    else
    {
      System.out.println("Error: unable to remove bid, because it is not found.");
    }
  }
  
  public void addOpponentAction(Action action)
  {
    this.bidHistoryTracker.addOpponentAction(action);
    
    this.opponentModel.addOpponentBid(getLastOpponentBid());
    
    updateMinimumBidUtility();
    
    updateEstimatedOpponentUtilityTable();
    if ((this.bestOpponentBid == null) || (this.agent.getUtility(getLastOpponentBid()) > this.agent.getUtility(this.bestOpponentBid))) {
      this.bestOpponentBid = getLastOpponentBid();
    }
  }
  
  private void updateMinimumBidUtility()
  {
    Bid justReceivedBid = getLastOpponentBid();
    if (justReceivedBid != null)
    {
      double justReceivedBidUtility = this.agent.getUtility(justReceivedBid);
      if (justReceivedBidUtility > getMinimumBidUtility())
      {
        setMinimumBidUtility(justReceivedBidUtility);
        updateBidTable();
      }
    }
  }
  
  private Integer getIndexByUtility(Double utility)
  {
    for (Map.Entry<Integer, Double> entry : this.utilityTable.entrySet()) {
      if (((Double)entry.getValue()).equals(utility)) {
        return (Integer)entry.getKey();
      }
    }
    return Integer.valueOf(-1);
  }
  
  private Integer getIndexAroundUtility(Double utility, Double margin)
  {
    for (Map.Entry<Integer, Double> entry : this.utilityTable.entrySet()) {
      if ((((Double)entry.getValue()).doubleValue() >= utility.doubleValue() - margin.doubleValue()) && (((Double)entry.getValue()).doubleValue() <= utility.doubleValue() + margin.doubleValue())) {
        return (Integer)entry.getKey();
      }
    }
    return getIndexAroundUtility(utility, Double.valueOf(margin.doubleValue() * 2.0D));
  }
  
  public Bid getLastOpponentBid()
  {
    return this.bidHistoryTracker.getLastOpponentBid();
  }
  
  public Bid getLastOwnBid()
  {
    return this.bidHistoryTracker.getLastOwnBid();
  }
  
  public Bid getBestOpponentBidSoFar()
  {
    return this.bestOpponentBid;
  }
  
  public int getNumberOfOpponentBids()
  {
    return this.bidHistoryTracker.getNumberOfOpponentBids();
  }
  
  public int getConsecutiveBidsDifferent()
  {
    return this.bidHistoryTracker.getConsecutiveBidsDifferent();
  }
  
  public void addOwnBid(Bid bid)
  {
    this.bidHistoryTracker.addOwnBid(bid);
  }
  
  private void checkIfBidTableIsNotEmpty()
  {
    if (this.bidTable.isEmpty()) {
      initializeTables();
    }
  }
  
  private void fillBidsArray()
  {
    this.bidTable = new HashMap();
    this.utilityTable = new HashMap();
    this.topXBids = new ArrayList();
    this.counter = 0;
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    HashMap<Integer, Value> valueset = new HashMap();
    recursiveArrayFiller(issues, 0, valueset);
  }
  
  private void recursiveArrayFiller(ArrayList<Issue> issues, int depth, HashMap<Integer, Value> valueset)
  {
    if (depth < issues.size())
    {
      Issue theIssue = (Issue)issues.get(depth);
      IssueDiscrete theIssueDiscrete;
      switch (theIssue.getType())
      {
      case DISCRETE: 
        theIssueDiscrete = (IssueDiscrete)theIssue;
        List<ValueDiscrete> vals = theIssueDiscrete.getValues();
        for (ValueDiscrete v : vals)
        {
          valueset.put(Integer.valueOf(theIssueDiscrete.getNumber()), v);
          recursiveArrayFiller(issues, depth + 1, valueset);
        }
        break;
      case REAL: 
        IssueReal theIssueReal = (IssueReal)theIssue;
        double lo = theIssueReal.getLowerBound();
        double hi = theIssueReal.getUpperBound();
        int steps = theIssueReal.getNumberOfDiscretizationSteps();
        for (double i = lo; i <= hi; i += (hi - lo) / steps)
        {
          valueset.put(Integer.valueOf(theIssueReal.getNumber()), new ValueReal(i));
          recursiveArrayFiller(issues, depth + 1, valueset);
        }
        break;
      case INTEGER: 
        IssueInteger theIssueInteger = (IssueInteger)theIssue;
        for (int i = theIssueInteger.getLowerBound(); i <= theIssueInteger.getUpperBound(); i++)
        {
          valueset.put(Integer.valueOf(theIssueInteger.getNumber()), new ValueInteger(i));
          recursiveArrayFiller(issues, depth + 1, valueset);
        }
      }
    }
    else if (depth == issues.size())
    {
      try
      {
        HashMap<Integer, Value> valuesetClone = (HashMap)valueset.clone();
        Bid bid = new Bid(this.utilitySpace.getDomain(), valuesetClone);
        if (this.agent.getUtility(bid) > this.minimumBidUtility)
        {
          this.bidTable.put(Integer.valueOf(this.counter), bid);
          this.utilityTable.put(Integer.valueOf(this.counter), Double.valueOf(this.agent.getUtility(bid)));
          this.counter += 1;
        }
      }
      catch (Exception e)
      {
        System.out.println("Exception in " + getClass().getName() + " while creating a new Bid object: not all issues in the domain are assigned a value.\n" + e.getStackTrace());
      }
    }
    else
    {
      System.out.println("OOPS! SOMETHING WENT WRONG! depth can never be higher than issues.size()");
    }
  }
  
  private void fillTopXHash()
  {
    this.topXBids = new ArrayList();
    
    ArrayList as = new ArrayList(this.bidTable.entrySet());
    
    int number = Math.max((int)Math.ceil(this.bidTable.size() * 0.005D), Math.min(this.bidTable.size(), 4));
    

    Collections.sort(as, new Comparator()
    {
      public int compare(Map.Entry e1, Map.Entry e2)
      {
        int iFirst = ((Integer)e1.getKey()).intValue();
        int iSecond = ((Integer)e2.getKey()).intValue();
        Double utilFirst = (Double)BidTable.this.utilityTable.get(Integer.valueOf(iFirst));
        Double utilSecond = (Double)BidTable.this.utilityTable.get(Integer.valueOf(iSecond));
        return utilSecond.compareTo(utilFirst);
      }
    });
    for (int i = 0; i < number; i++) {
      this.topXBids.add((Bid)((Map.Entry)as.get(i)).getValue());
    }
    int size = this.topXBids.size();
  }
  
  public boolean weAreStalling()
  {
    return this.bidHistoryTracker.getOurStallingCoefficient() > 10;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.MrFriendly.BidTable
 * JD-Core Version:    0.7.1
 */