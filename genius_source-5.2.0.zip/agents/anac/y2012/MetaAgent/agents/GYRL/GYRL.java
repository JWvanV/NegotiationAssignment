package agents.anac.y2012.MetaAgent.agents.GYRL;

import java.util.Date;
import java.util.HashMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.UtilitySpace;

public class GYRL
  extends Agent
{
  private Action actionOfPartner = null;
  private double MaxUtility;
  private double MinUtility;
  private HashMap<AgentParameterVariable, AgentParamValue> params;
  boolean initMe = false;
  
  public void init(int sessionNumberP, int sessionTotalNumberP, Date startTimeP, Integer totalTimeP, UtilitySpace us)
  {
    super.init();
    super.internalInit(sessionNumberP, sessionTotalNumberP, startTimeP, totalTimeP, this.timeline, us, this.params);
    super.setName("GYRL 2.0");
    this.initMe = false;
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    double time = this.timeline.getTime();
    
    double AcceptanceLimit = 2.0D * time * time - 2.0D * time + 1.0D;
    if (AcceptanceLimit > 0.9D) {
      AcceptanceLimit = 0.9D;
    }
    double offerLimit = AcceptanceLimit;
    if (time > 0.98D)
    {
      AcceptanceLimit = 0.5D;
      offerLimit = 0.6D;
    }
    if ((time > 0.96D) && (time < 0.98D))
    {
      offerLimit = 0.75D;
      AcceptanceLimit = 0.75D;
    }
    if (!this.initMe)
    {
      try
      {
        Bid maxUtility = this.utilitySpace.getMaxUtilityBid();
        this.MaxUtility = this.utilitySpace.getUtility(maxUtility);
        this.MinUtility = this.MaxUtility;
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
      this.initMe = true;
    }
    Action action = null;
    Bid bid2offer = new Bid();
    try
    {
      if (this.actionOfPartner == null)
      {
        bid2offer = this.utilitySpace.getMaxUtilityBid();
        action = new Offer(getAgentID(), bid2offer);
      }
      else if ((this.actionOfPartner instanceof Offer))
      {
        double offeredUtility = this.utilitySpace.getUtility(((Offer)this.actionOfPartner).getBid());
        if (this.MaxUtility == this.MinUtility)
        {
          this.MinUtility = offeredUtility;
          action = new Offer(getAgentID(), this.utilitySpace.getMaxUtilityBid());
        }
        else if (offeredUtility >= this.MinUtility + (this.MaxUtility - this.MinUtility) * AcceptanceLimit)
        {
          action = new Accept(getAgentID());
        }
        else
        {
          Bid newOffer = this.utilitySpace.getDomain().getRandomBid();
          while (this.utilitySpace.getUtility(newOffer) <= this.MinUtility + (this.MaxUtility - this.MinUtility) * offerLimit) {
            newOffer = this.utilitySpace.getDomain().getRandomBid();
          }
          action = new Offer(getAgentID(), newOffer);
        }
      }
    }
    catch (Exception e)
    {
      action = new Accept(getAgentID());
    }
    return action;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.GYRL.GYRL
 * JD-Core Version:    0.7.1
 */