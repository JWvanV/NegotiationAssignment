package agents.anac.y2012.MetaAgent.agents.Chameleon;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class Chameleon
  extends Agent
{
  private static final double MAX_WEIGHT_CHANGE = 1.0D;
  private static final double EPS = 1.E-005D;
  private List<Strategy> strategies;
  private List<Double> strategyWeights;
  private int currentStrategy;
  private Bid lastBid;
  private Bid lastChameleonBid;
  private double lastChameleonBidTime;
  
  public static abstract interface Strategy
  {
    public abstract void init(UtilitySpace paramUtilitySpace);
    
    public abstract void receiveOpponentBid(Bid paramBid, double paramDouble);
    
    public abstract Bid respondToBid(double paramDouble);
  }
  
  public static abstract class BaseStrategy
    implements Chameleon.Strategy
  {
    private static final int MAX_RANDOM_BID_SEARCH_TRIES = 10000;
    private Bid maxUtilityBid;
    private double maxUtility;
    private UtilitySpace utilitySpace;
    private Map<Bid, Double> opponentBids;
    private Map<Bid, Double> opponentBidTimes;
    private Bid lastOpponentBid;
    private double lastOpponentBidTime;
    private Random random;
    
    public void init(UtilitySpace utilitySpace)
    {
      this.utilitySpace = utilitySpace;
      try
      {
        this.maxUtilityBid = utilitySpace.getMaxUtilityBid();
        this.maxUtility = utilitySpace.getUtility(this.maxUtilityBid);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      this.opponentBids = new HashMap();
      this.opponentBidTimes = new HashMap();
      this.random = new Random();
    }
    
    protected Bid getMaxUtilityBid()
    {
      return this.maxUtilityBid;
    }
    
    protected double getMaxUtility()
    {
      return this.maxUtility;
    }
    
    protected UtilitySpace getUtilitySpace()
    {
      return this.utilitySpace;
    }
    
    protected Bid searchRandomBidWithMinimalUtility(double minimalUtility)
    {
      HashMap<Integer, Value> values = new HashMap();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      int numTries = 0;
      
      Bid bid = null;
      
      int combinations = 1;
      for (Issue lIssue : issues) {
        switch (Chameleon.1.$SwitchMap$negotiator$issue$ISSUETYPE[lIssue.getType().ordinal()])
        {
        case 1: 
          combinations *= ((IssueDiscrete)lIssue).getNumberOfValues();
          
          break;
        case 2: 
          combinations *= ((IssueReal)lIssue).getNumberOfDiscretizationSteps();
          
          break;
        case 3: 
          combinations *= (((IssueInteger)lIssue).getUpperBound() - ((IssueInteger)lIssue).getLowerBound());
        }
      }
      try
      {
        do
        {
          for (Issue lIssue : issues) {
            switch (Chameleon.1.$SwitchMap$negotiator$issue$ISSUETYPE[lIssue.getType().ordinal()])
            {
            case 1: 
              IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
              int optionIndex = this.random.nextInt(lIssueDiscrete.getNumberOfValues());
              
              values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
              
              break;
            case 2: 
              IssueReal lIssueReal = (IssueReal)lIssue;
              int optionInd = this.random.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
              
              values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
              








              break;
            case 3: 
              IssueInteger lIssueInteger = (IssueInteger)lIssue;
              int optionIndex2 = lIssueInteger.getLowerBound() + this.random.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
              


              values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
              

              break;
            default: 
              throw new Exception("issue type " + lIssue.getType() + " not supported");
            }
          }
          bid = new Bid(this.utilitySpace.getDomain(), values);
          numTries++;
        } while ((this.utilitySpace.getUtility(bid) < minimalUtility) && (numTries <= 10000));
        if (this.utilitySpace.getUtility(bid) < minimalUtility) {
          return getMaxUtilityBid();
        }
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      return bid;
    }
    
    protected Bid getLastOpponentBid()
    {
      return this.lastOpponentBid;
    }
    
    protected double getLastOpponentBidTime()
    {
      return this.lastOpponentBidTime;
    }
    
    public void receiveOpponentBid(Bid bid, double receiveTime)
    {
      try
      {
        this.lastOpponentBid = bid;
        this.lastOpponentBidTime = receiveTime;
        this.opponentBids.put(bid, Double.valueOf(this.utilitySpace.getUtility(bid)));
        this.opponentBidTimes.put(bid, Double.valueOf(receiveTime));
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
    }
    
    protected Map<Bid, Double> getOpponentBids()
    {
      return this.opponentBids;
    }
    
    protected Random getRandom()
    {
      return this.random;
    }
  }
  
  public class MirrorStrategy
    extends Chameleon.BaseStrategy
  {
    private Bid secondToLastBid;
    private double secondToLastBidTime;
    private double targetUtility;
    
    public MirrorStrategy() {}
    
    public void init(UtilitySpace utilitySpace)
    {
      super.init(utilitySpace);
      this.targetUtility = 1.0D;
    }
    
    public void receiveOpponentBid(Bid bid, double receiveTime)
    {
      this.secondToLastBid = getLastOpponentBid();
      this.secondToLastBidTime = Chameleon.this.timeline.getTime();
      super.receiveOpponentBid(bid, receiveTime);
    }
    
    public Bid respondToBid(double currentTime)
    {
      if ((this.secondToLastBid == null) || (getLastOpponentBid() == null)) {
        return getMaxUtilityBid();
      }
      try
      {
        double lastBidUtilityNow = getUtilitySpace().getUtilityWithDiscount(getLastOpponentBid(), currentTime);
        

        double lastBidUtilityThen = getUtilitySpace().getUtilityWithDiscount(getLastOpponentBid(), getLastOpponentBidTime());
        

        double secondToLastBidUtilityThen = getUtilitySpace().getUtilityWithDiscount(this.secondToLastBid, this.secondToLastBidTime);
        

        double lastChameleonBidUtilityThen = getUtilitySpace().getUtilityWithDiscount(Chameleon.this.lastChameleonBid, Chameleon.this.lastChameleonBidTime);
        

        double currentDiscount = Chameleon.this.getDiscount(currentTime);
        double willingToAcceptUtilityNotDiscounted = lastChameleonBidUtilityThen + lastBidUtilityThen - secondToLastBidUtilityThen;
        

        this.targetUtility = Math.max(willingToAcceptUtilityNotDiscounted, lastBidUtilityNow / currentDiscount);
        
        this.targetUtility = Math.max(this.targetUtility, 1.0D - currentTime * 0.3D);
        this.targetUtility = Math.min(this.targetUtility, 1.0D);
        if (lastBidUtilityNow >= this.targetUtility) {
          return null;
        }
        return searchRandomBidWithMinimalUtility(this.targetUtility);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      return null;
    }
  }
  
  public static class StubbornStrategy
    extends Chameleon.BaseStrategy
  {
    public Bid respondToBid(double currentTime)
    {
      if (getLastOpponentBid() == null) {
        return getMaxUtilityBid();
      }
      double desiredUtility = 0.0D;
      try
      {
        double lastOpponentUtility = getUtilitySpace().getUtility(getLastOpponentBid());
        if ((currentTime >= 0.0D) && (currentTime < 0.333D)) {
          return getMaxUtilityBid();
        }
        if ((currentTime >= 0.333D) && (currentTime < 0.666D)) {
          desiredUtility = getMaxUtility() * 0.9D;
        } else if ((currentTime >= 0.666D) && (currentTime <= 0.95D)) {
          desiredUtility = (currentTime - 0.666D) / 0.334D * 0.1D * getMaxUtility() + 0.8D * getMaxUtility();
        } else {
          desiredUtility = 0.7D * currentTime + 0.3D;
        }
        if ((lastOpponentUtility >= desiredUtility) && (currentTime >= 0.666D)) {
          return null;
        }
        if (lastOpponentUtility >= 1.05D * desiredUtility) {
          return null;
        }
        if ((currentTime >= 0.95D) && (lastOpponentUtility >= 0.8D * desiredUtility)) {
          return null;
        }
        return searchRandomBidWithMinimalUtility(desiredUtility);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      return searchRandomBidWithMinimalUtility(desiredUtility);
    }
  }
  
  public static class PiggyBackStrategy
    extends Chameleon.BaseStrategy
  {
    private static final int REASONABLE_NUMBER_OF_ISSUES = 15;
    private static final int REASONABLE_NUMBER_OF_TRIALS = 10000;
    private Bid bestNeighbour;
    private double bestNeighbourUtility;
    
    public void init(UtilitySpace utilitySpace)
    {
      super.init(utilitySpace);
      this.bestNeighbourUtility = 0.0D;
      this.bestNeighbour = null;
    }
    
    private Bid searchBidInNeighbourhoodOf(Bid bid)
    {
      ArrayList<Issue> issues = getUtilitySpace().getDomain().getIssues();
      
      HashMap<Integer, Value> values = new HashMap();
      int[] modifications = new int[issues.size()];
      
      Bid maxUtilityBid = null;
      int sum = 0;int numTrials = 0;
      
      boolean tooManyIssues = getUtilitySpace().getDomain().getIssues().size() > 15;
      for (int i = 0; i < issues.size(); i++) {
        modifications[i] = 0;
      }
      try
      {
        maxUtilityBid = bid;
        double maxUtility = getUtilitySpace().getUtility(bid);
        boolean ready;
        do
        {
          values = new HashMap();
          for (int j = 0; j < issues.size(); j++)
          {
            Issue lIssue = (Issue)issues.get(j);
            int no = lIssue.getNumber();
            int optionIndex = 0;
            int bidValue;
            switch (Chameleon.1.$SwitchMap$negotiator$issue$ISSUETYPE[lIssue.getType().ordinal()])
            {
            case 1: 
              IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
              bidValue = lIssueDiscrete.getValueIndex((ValueDiscrete)bid.getValue(no));
              switch (modifications[j])
              {
              case 0: 
                optionIndex = bidValue;
                break;
              case 1: 
                if (bidValue > 0) {
                  optionIndex = bidValue - 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              case 2: 
                if (bidValue + 1 < lIssueDiscrete.getValues().size()) {
                  optionIndex = bidValue + 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              }
              values.put(Integer.valueOf(no), lIssueDiscrete.getValue(optionIndex));
              break;
            case 2: 
              IssueReal lIssueReal = (IssueReal)lIssue;
              double step = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lIssueReal.getNumberOfDiscretizationSteps();
              


              bidValue = (int)Math.round((((ValueReal)bid.getValue(no)).getValue() - lIssueReal.getLowerBound()) / step);
              switch (modifications[j])
              {
              case 0: 
                optionIndex = bidValue;
                break;
              case 1: 
                if (bidValue > 0) {
                  optionIndex = bidValue - 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              case 2: 
                if (bidValue + 1 < lIssueReal.getNumberOfDiscretizationSteps()) {
                  optionIndex = bidValue + 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              }
              values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionIndex / lIssueReal.getNumberOfDiscretizationSteps()));
              








              break;
            case 3: 
              IssueInteger lIssueInteger = (IssueInteger)lIssue;
              bidValue = ((ValueInteger)bid.getValue(no)).getValue();
              switch (modifications[j])
              {
              case 0: 
                optionIndex = bidValue;
                break;
              case 1: 
                if (bidValue > lIssueInteger.getLowerBound()) {
                  optionIndex = bidValue - 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              case 2: 
                if (bidValue + 1 < lIssueInteger.getUpperBound()) {
                  optionIndex = bidValue + 1;
                } else {
                  optionIndex = bidValue;
                }
                break;
              }
              values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex));
              

              break;
            default: 
              throw new Exception("issue type " + lIssue.getType() + " not supported");
            }
          }
          Bid currentBid = new Bid(getUtilitySpace().getDomain(), values);
          double utility = getUtilitySpace().getUtility(currentBid);
          if (utility > maxUtility)
          {
            maxUtilityBid = currentBid;
            maxUtility = utility;
          }
          ready = false;
          if (!tooManyIssues)
          {
            i = 0;
            for (sum = 0; i < issues.size(); i++) {
              sum += modifications[i];
            }
            if (sum < 2 * issues.size()) {
              for (i = 0; i < issues.size(); i++)
              {
                modifications[i] += 1;
                if (modifications[i] != 3) {
                  break;
                }
                modifications[i] = 0;
              }
            }
            ready = sum < 2 * issues.size();
          }
          else
          {
            numTrials++;
            for (i = 0; i < issues.size(); i++) {
              modifications[i] = getRandom().nextInt(3);
            }
            ready = numTrials < 10000;
          }
        } while (!ready);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      return maxUtilityBid;
    }
    
    public Bid respondToBid(double currentTime)
    {
      if (getLastOpponentBid() == null) {
        return getMaxUtilityBid();
      }
      try
      {
        double targetUtility = 1.0D - currentTime * 0.2D;
        double lastOpponentBidUtility = getUtilitySpace().getUtility(getLastOpponentBid());
        if ((lastOpponentBidUtility >= targetUtility) || ((currentTime >= 0.85D) && (lastOpponentBidUtility >= 0.85D * targetUtility))) {
          return null;
        }
        Bid neighbour = searchBidInNeighbourhoodOf(getLastOpponentBid());
        double neighbourUtility = getUtilitySpace().getUtility(neighbour);
        if (neighbourUtility > this.bestNeighbourUtility)
        {
          this.bestNeighbourUtility = neighbourUtility;
          this.bestNeighbour = neighbour;
        }
        if (this.bestNeighbourUtility >= targetUtility) {
          return this.bestNeighbour;
        }
        return searchRandomBidWithMinimalUtility(targetUtility);
      }
      catch (Exception ex)
      {
        ex.printStackTrace();
      }
      return null;
    }
  }
  
  public String getVersion()
  {
    return "0.1";
  }
  
  private List<Strategy> getStrategies()
  {
    this.strategies = new ArrayList();
    this.strategies.add(new StubbornStrategy());
    this.strategies.add(new MirrorStrategy());
    this.strategies.add(new PiggyBackStrategy());
    return this.strategies;
  }
  
  public void init()
  {
    this.strategies = getStrategies();
    for (Strategy strategy : this.strategies) {
      strategy.init(this.utilitySpace);
    }
    this.strategyWeights = new ArrayList();
    for (int i = 0; i < this.strategies.size(); i++) {
      this.strategyWeights.add(Double.valueOf(1.0D / this.strategies.size()));
    }
    this.currentStrategy = pickAStrategy();
  }
  
  private int pickAStrategy()
  {
    double[] probabilities = new double[this.strategies.size() + 1];
    

    probabilities[0] = 0.0D;
    for (int i = 0; i < this.strategies.size(); i++) {
      probabilities[(i + 1)] = (probabilities[i] + ((Double)this.strategyWeights.get(i)).doubleValue());
    }
    probabilities[this.strategies.size()] = 1.0D;
    

    double rand = Math.random();
    for (int i = 0; i < this.strategies.size(); i++) {
      if ((probabilities[i] <= rand) && (rand < probabilities[(i + 1)])) {
        return i;
      }
    }
    return -1;
  }
  
  private double getDiscount(double time)
  {
    double discount = this.utilitySpace.getDiscountFactor();
    if ((discount <= 0.0D) || (discount >= 1.0D)) {
      return 1.0D;
    }
    return Math.pow(discount, time);
  }
  
  private void printWeights() {}
  
  private void adjustCurrentStrategy(Bid bid, double time)
  {
    try
    {
      double bidUtility = this.utilitySpace.getUtility(bid);
      double lastBidUtility = this.utilitySpace.getUtility(this.lastBid);
      double changeInUtility = bidUtility / lastBidUtility - 1.0D;
      if (changeInUtility > 0.0D) {
        encourageStrategyForPositiveChangeInUtility(changeInUtility);
      } else if (changeInUtility < 0.0D) {
        penalizeStrategyForNegativeChangeInUtility(changeInUtility);
      }
      for (int i = 0; i < this.strategyWeights.size(); i++) {
        if (Math.abs(((Double)this.strategyWeights.get(i)).doubleValue() - 1.0D) < 1.E-005D)
        {
          int saveCurrentStrategy = this.currentStrategy;
          this.currentStrategy = i;
          penalizeStrategyForNegativeChangeInUtility(-0.2D);
          this.currentStrategy = saveCurrentStrategy;
          break;
        }
      }
      this.currentStrategy = pickAStrategy();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  private void encourageStrategyForPositiveChangeInUtility(double changeInUtility)
  {
    double strategyWeight = ((Double)this.strategyWeights.get(this.currentStrategy)).doubleValue();
    if (Math.abs(1.0D - strategyWeight) <= 1.E-005D) {
      return;
    }
    double percent = changeInUtility;
    percent = Math.min(percent, 1.0D);
    if (Math.abs(strategyWeight) > 1.E-005D) {
      percent = Math.min(percent, (1.0D - strategyWeight) / strategyWeight);
    }
    printWeights();
    

    double sumWeights = 0.0D;
    for (int i = 0; i < this.strategies.size(); i++)
    {
      double w = ((Double)this.strategyWeights.get(i)).doubleValue();
      if (i != this.currentStrategy) {
        if (Math.abs(w) <= 1.E-005D)
        {
          sumWeights += w;
        }
        else
        {
          w -= w * strategyWeight / (1.0D - strategyWeight) * percent;
          this.strategyWeights.set(i, Double.valueOf(w));
          sumWeights += w;
        }
      }
    }
    this.strategyWeights.set(this.currentStrategy, Double.valueOf(1.0D - sumWeights));
    
    printWeights();
  }
  
  private void penalizeStrategyForNegativeChangeInUtility(double changeInUtility)
  {
    double strategyWeight = ((Double)this.strategyWeights.get(this.currentStrategy)).doubleValue();
    boolean[] takenIntoAccount = new boolean[this.strategies.size()];
    double sumTakenIntoAccount = 0.0D;
    int numTakenIntoAccount = 0;
    

    double percent = -changeInUtility;
    percent = Math.min(percent, 1.0D);
    for (int i = 0; i < this.strategies.size(); i++)
    {
      double w = ((Double)this.strategyWeights.get(i)).doubleValue();
      if (i == this.currentStrategy)
      {
        takenIntoAccount[i] = false;
      }
      else if (Math.abs(w) <= 1.E-005D)
      {
        takenIntoAccount[i] = true;
      }
      else if (Math.abs(w - 1.0D) <= 1.E-005D)
      {
        takenIntoAccount[i] = false;
      }
      else
      {
        percent = Math.min(percent, (1.0D - w) * (1.0D - strategyWeight) / (w * strategyWeight));
        
        takenIntoAccount[i] = true;
      }
    }
    for (int i = 0; i < this.strategies.size(); i++) {
      if (takenIntoAccount[i] != 0)
      {
        sumTakenIntoAccount += ((Double)this.strategyWeights.get(i)).doubleValue();
        numTakenIntoAccount++;
      }
    }
    printWeights();
    

    double sumWeights = 0.0D;
    for (int i = 0; i < this.strategies.size(); i++)
    {
      double w = ((Double)this.strategyWeights.get(i)).doubleValue();
      if (i != this.currentStrategy) {
        if (takenIntoAccount[i] == 0)
        {
          sumWeights += w;
        }
        else
        {
          if (Math.abs(sumTakenIntoAccount) > 1.E-005D) {
            w += w * strategyWeight / sumTakenIntoAccount * percent;
          } else {
            w += strategyWeight * percent / numTakenIntoAccount;
          }
          this.strategyWeights.set(i, Double.valueOf(w));
          sumWeights += w;
        }
      }
    }
    this.strategyWeights.set(this.currentStrategy, Double.valueOf(1.0D - sumWeights));
    
    printWeights();
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    if ((opponentAction instanceof Offer))
    {
      Offer offer = (Offer)opponentAction;
      Bid bid = offer.getBid();
      double time = this.timeline.getTime();
      for (Strategy strategy : this.strategies) {
        strategy.receiveOpponentBid(bid, time);
      }
      if (this.lastBid != null) {
        adjustCurrentStrategy(bid, time);
      }
      this.lastBid = bid;
    }
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      Strategy strategy = (Strategy)this.strategies.get(this.currentStrategy);
      Bid responseBid = strategy.respondToBid(this.timeline.getTime());
      if (responseBid == null) {
        return new Accept(getAgentID());
      }
      this.lastChameleonBid = responseBid;
      this.lastChameleonBidTime = this.timeline.getTime();
      return new Offer(getAgentID(), responseBid);
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
      action = new Accept(getAgentID());
    }
    return action;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.Chameleon.Chameleon
 * JD-Core Version:    0.7.1
 */