package agents.anac.y2012.MetaAgent.agents.DNAgent;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class DNAgent
  extends Agent
{
  private Action actionOfPartner = null;
  private static double MINIMUM_BID_UTILITY = 0.5D;
  private static int POPULATION_SIZE_DEFAULT = 300;
  private static int TOURNAMENT_SELECTION_DEFAULT = 15;
  private static int SELECTION_DEFAULT = 100;
  private static int MUTATION_DEFAULT = 100;
  private static int CROSSOVER_DEFAULT = 100;
  private ArrayList<Bid> population;
  private ArrayList<Bid> partnerBids;
  private Bid referenceBid;
  private int populationSize;
  private int tournamentSize;
  private int selectionSize;
  private int mutationSize;
  private int crossoverSize;
  private double currentAspirationLevel;
  private double minimumOfferedUtil;
  public static Logger logger;
  
  static
  {
    try
    {
      boolean append = true;
      FileHandler fh = new FileHandler("TestLog.log", append);
      
      fh.setFormatter(new SimpleFormatter());
      logger = Logger.getLogger("TestLog");
      logger.addHandler(fh);
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
  }
  
  public void init()
  {
    if (this.utilitySpace.getReservationValue() != null) {
      MINIMUM_BID_UTILITY = this.utilitySpace.getReservationValue().doubleValue();
    }
    this.populationSize = POPULATION_SIZE_DEFAULT;
    this.tournamentSize = TOURNAMENT_SELECTION_DEFAULT;
    this.selectionSize = SELECTION_DEFAULT;
    this.crossoverSize = CROSSOVER_DEFAULT;
    this.mutationSize = MUTATION_DEFAULT;
    
    this.currentAspirationLevel = MINIMUM_BID_UTILITY;
    
    this.partnerBids = new ArrayList();
    this.minimumOfferedUtil = 1.0D;
    try
    {
      this.population = createInitialPopulation();
    }
    catch (Exception e)
    {
      logger.severe(e.getMessage());
    }
  }
  
  public String getVersion()
  {
    return "CCU";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = proposeBid();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        
        this.partnerBids.add(partnerBid);
        double offeredUtilFromOpponent = getUtility(partnerBid);
        if (this.referenceBid == null) {
          this.referenceBid = partnerBid;
        }
        if (getUtility(this.referenceBid) < offeredUtilFromOpponent) {
          this.referenceBid = partnerBid;
        }
        if (this.currentAspirationLevel < offeredUtilFromOpponent) {
          this.currentAspirationLevel = offeredUtilFromOpponent;
        }
        this.population = updatePopulation(this.partnerBids);
        
        action = proposeBid();
        Bid myBid = ((Offer)action).getBid();
        double myOfferedUtil = getUtility(myBid);
        if (myOfferedUtil < this.minimumOfferedUtil) {
          myOfferedUtil = this.minimumOfferedUtil;
        }
        if (this.minimumOfferedUtil <= offeredUtilFromOpponent) {
          action = new Accept(getAgentID());
        }
      }
    }
    catch (Exception e)
    {
      logger.severe(e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private ArrayList<Bid> createInitialPopulation()
    throws Exception
  {
    ArrayList<Bid> newPopulation = new ArrayList();
    for (int i = 0; i < this.populationSize; i++) {
      newPopulation.add(getRandomBid());
    }
    return newPopulation;
  }
  
  private ArrayList<Bid> updatePopulation(ArrayList<Bid> partnerBids)
    throws Exception
  {
    ArrayList<Bid> parents = null;
    ArrayList<Bid> crossover = null;
    ArrayList<Bid> mutation = null;
    ArrayList<Bid> newPopulation = new ArrayList();
    

    parents = performSelection(this.selectionSize);
    



    crossover = performCrossover(parents, partnerBids, this.crossoverSize);
    

    mutation = performMutation(parents, this.mutationSize);
    

    newPopulation.addAll(parents);
    newPopulation.addAll(crossover);
    newPopulation.addAll(mutation);
    


    return newPopulation;
  }
  
  private ArrayList<Bid> performSelection(int selectionNumber)
    throws Exception
  {
    ArrayList<Bid> selection = new ArrayList();
    ArrayList<Bid> sorted = new ArrayList();
    


    sorted.add(this.population.get(0));
    for (int i = 1; i < this.population.size(); i++)
    {
      Bid toInsert = (Bid)this.population.get(i);
      boolean inserted = false;
      double toInsertFitness = getFitness(toInsert);
      for (int j = 0; j < sorted.size(); j++)
      {
        double positionFitness = getFitness((Bid)sorted.get(j));
        if (toInsertFitness > positionFitness)
        {
          sorted.add(j, toInsert);
          inserted = true;
          break;
        }
      }
      if (!inserted) {
        sorted.add(toInsert);
      }
    }
    for (int k = 0; k < selectionNumber; k++) {
      selection.add(sorted.get(k));
    }
    return selection;
  }
  
  private ArrayList<Bid> performCrossover(ArrayList<Bid> fathers, ArrayList<Bid> mothers, int crossoverNumber)
    throws Exception
  {
    ArrayList<Bid> crossover = new ArrayList();
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random rand = new Random();
    while (crossover.size() < crossoverNumber)
    {
      int indexFather = rand.nextInt(fathers.size());
      int indexMother = rand.nextInt(mothers.size());
      
      Bid father = (Bid)fathers.get(indexFather);
      Bid mother = (Bid)mothers.get(indexMother);
      
      Bid son = null;
      for (Issue lIssue : issues)
      {
        int issueIndex = lIssue.getNumber();
        if (rand.nextBoolean()) {
          values.put(Integer.valueOf(issueIndex), father.getValue(issueIndex));
        } else {
          values.put(Integer.valueOf(issueIndex), mother.getValue(issueIndex));
        }
      }
      son = new Bid(this.utilitySpace.getDomain(), values);
      if (getUtility(son) >= this.currentAspirationLevel) {
        crossover.add(son);
      }
    }
    return crossover;
  }
  
  private ArrayList<Bid> performMutation(ArrayList<Bid> parents, int mutationNumber)
    throws Exception
  {
    ArrayList<Bid> mutation = new ArrayList();
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random rand = new Random();
    while (mutation.size() < mutationNumber)
    {
      Bid parent = (Bid)parents.get(rand.nextInt(parents.size()));
      
      Bid son = null;
      

      int mutateIssue = rand.nextInt(issues.size());
      int currentIssue = 0;
      for (Issue lIssue : issues)
      {
        if (currentIssue == mutateIssue)
        {
          switch (lIssue.getType())
          {
          case DISCRETE: 
            IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
            int optionIndex = rand.nextInt(lIssueDiscrete.getNumberOfValues());
            
            values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
            
            break;
          case REAL: 
            IssueReal lIssueReal = (IssueReal)lIssue;
            int optionInd = rand.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
            
            values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
            







            break;
          case INTEGER: 
            IssueInteger lIssueInteger = (IssueInteger)lIssue;
            int optionIndex2 = lIssueInteger.getLowerBound() + rand.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
            

            values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
            
            break;
          default: 
            throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
          }
        }
        else
        {
          int issueIndex = lIssue.getNumber();
          values.put(Integer.valueOf(issueIndex), parent.getValue(issueIndex));
        }
        currentIssue += 1;
      }
      son = new Bid(this.utilitySpace.getDomain(), values);
      if (getUtility(son) >= this.currentAspirationLevel) {
        mutation.add(son);
      }
    }
    return mutation;
  }
  
  private double getFitness(Bid bid)
    throws Exception
  {
    if (this.referenceBid == null) {
      return this.utilitySpace.getUtility(bid);
    }
    double myTime = this.timeline.getTime();
    double discount = this.utilitySpace.getDiscountFactor();
    if ((discount <= 0.0D) || (discount >= 1.0D)) {
      discount = 1.0D;
    }
    double beta = Math.pow(1.0D - myTime, 1.0D / (3.5D * discount * discount));
    

    return beta * this.utilitySpace.getUtility(bid) + (1.0D - beta) * getSimilarity(bid, this.referenceBid) / this.utilitySpace.getDomain().getIssues().size();
  }
  
  private Action proposeBid()
  {
    Bid nextBid = null;
    Random rand = new Random();
    try
    {
      for (int i = 0; i < this.tournamentSize; i++)
      {
        int dice = rand.nextInt(this.population.size());
        Bid candidateBid = (Bid)this.population.get(dice);
        if (nextBid == null) {
          nextBid = candidateBid;
        } else if (getFitness(candidateBid) > getFitness(nextBid)) {
          nextBid = candidateBid;
        }
      }
    }
    catch (Exception e) {}
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private double getSimilarity(Bid aBid, Bid anotherBid)
    throws Exception
  {
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    double similarity = 0.0D;
    for (Issue lIssue : issues)
    {
      int issueID;
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        issueID = lIssueDiscrete.getNumber();
        if (((ValueDiscrete)aBid.getValue(issueID)).getValue().equals(((ValueDiscrete)anotherBid.getValue(issueID)).getValue())) {
          similarity += 1.0D;
        }
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        issueID = lIssueReal.getNumber();
        similarity += 1.0D - Math.abs(((ValueReal)aBid.getValue(issueID)).getValue() - ((ValueReal)anotherBid.getValue(issueID)).getValue()) / (lIssueReal.getUpperBound() - lIssueReal.getLowerBound());
        



        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        issueID = lIssueInteger.getNumber();
        similarity += 1 - Math.abs(((ValueInteger)aBid.getValue(issueID)).getValue() - ((ValueInteger)anotherBid.getValue(issueID)).getValue()) / (lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
        



        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
      }
    }
    return similarity;
  }
  
  private Bid getRandomBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    


    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    Random randomnr = new Random();
    




    Bid bid = null;
    do
    {
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          int optionIndex = randomnr.nextInt(lIssueDiscrete.getNumberOfValues());
          
          values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
          
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int optionInd = randomnr.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
          
          values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
          






          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          int optionIndex2 = lIssueInteger.getLowerBound() + randomnr.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
          

          values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
          
          break;
        default: 
          throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
        }
      }
      bid = new Bid(this.utilitySpace.getDomain(), values);
    } while (getUtility(bid) < MINIMUM_BID_UTILITY);
    return bid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.DNAgent.DNAgent
 * JD-Core Version:    0.7.1
 */