package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

public class DiscreteKey
  extends Key
{
  String key;
  
  public DiscreteKey(String k)
  {
    this.key = k;
  }
  
  public boolean equals(Object obj)
  {
    DiscreteKey k = (DiscreteKey)obj;
    return this.key.equals(k.key);
  }
  
  public int hashCode()
  {
    return this.key.hashCode();
  }
  
  public String toString()
  {
    return this.key;
  }
  
  public boolean contains(Object obj)
  {
    return this.key.equals(obj);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.DiscreteKey
 * JD-Core Version:    0.7.1
 */