package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

public abstract class Key
{
  public abstract boolean contains(Object paramObject);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.Key
 * JD-Core Version:    0.7.1
 */