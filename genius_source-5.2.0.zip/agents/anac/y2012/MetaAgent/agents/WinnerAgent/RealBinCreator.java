package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.util.ArrayList;
import java.util.Vector;
import negotiator.issue.ValueReal;

public class RealBinCreator
  extends BinCreator
{
  double epsilon = 0.01D;
  
  public ArrayList<DiscretisizedKey> createBins(double min, double max)
  {
    this.numOfBins = Math.max((int)(this.percentageOfRange * (max - min)), this.numConst);
    double binSize = (max - min) / this.numOfBins;
    ArrayList<DiscretisizedKey> bins = new ArrayList();
    for (int i = 0; i < this.numOfBins; i++)
    {
      DiscretisizedKey bin = new DiscretisizedKey(min, min + binSize);
      min += binSize;
      bins.add(bin);
    }
    this.epsilon = (binSize / 5.0D);
    return bins;
  }
  
  public Vector<ValueReal> createValuesVector(double min, double max)
  {
    ArrayList<DiscretisizedKey> bins = createBins(min, max);
    Vector<ValueReal> vectorOfVals = new Vector();
    for (DiscretisizedKey bin : bins)
    {
      vectorOfVals.add(new ValueReal(bin.getMin() + this.epsilon));
      vectorOfVals.add(new ValueReal(bin.getMax() - this.epsilon));
      vectorOfVals.add(new ValueReal((bin.getMax() + bin.getMin()) / 2.0D));
    }
    return vectorOfVals;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.RealBinCreator
 * JD-Core Version:    0.7.1
 */