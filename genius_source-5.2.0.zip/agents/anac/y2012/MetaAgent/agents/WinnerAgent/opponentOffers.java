package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class opponentOffers
{
  private Hashtable<Issue, Hashtable<Key, Integer>> _offers;
  private ArrayList<Issue> _issues;
  private Hashtable<Issue, List<Key>> _sortedValuesKeys;
  private int _totalNumOfOffers;
  private Hashtable<Issue, Double> _issueWeights;
  private Hashtable<Issue, Hashtable<Key, Double>> _valuesUtil;
  private double _ourAvgUtilFromOppOffers;
  private double _ourMaxUtilFromOppOffers;
  private double _oppConcessionRate;
  private UtilitySpace _utilitySpace;
  private double _avgFlag;
  private ArrayList<Set<Bid>> _oppoentOffersByUtility;
  
  public opponentOffers(UtilitySpace utilitySpace, double avgFlag)
  {
    this._avgFlag = avgFlag;
    this._utilitySpace = utilitySpace;
    this._offers = new Hashtable();
    this._sortedValuesKeys = new Hashtable();
    this._issues = this._utilitySpace.getDomain().getIssues();
    this._totalNumOfOffers = 0;
    this._ourAvgUtilFromOppOffers = 0.0D;
    this._ourMaxUtilFromOppOffers = 0.0D;
    this._oppConcessionRate = 1.0D;
    this._issueWeights = new Hashtable();
    this._valuesUtil = new Hashtable();
    intializeOpponentOffersSets();
    try
    {
      for (Issue lIssue : this._issues)
      {
        this._sortedValuesKeys.put(lIssue, new ArrayList());
        

        Hashtable<Key, Integer> h = new Hashtable();
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          for (Value v : lIssueDiscrete.getValues())
          {
            DiscreteKey k = new DiscreteKey(v.toString());
            h.put(k, Integer.valueOf(0));
            ((List)this._sortedValuesKeys.get(lIssue)).add(k);
          }
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          BinCreator bcReal = new RealBinCreator();
          ArrayList<DiscretisizedKey> realBins = bcReal.createBins(lIssueReal.getLowerBound(), lIssueReal.getUpperBound());
          for (DiscretisizedKey key : realBins)
          {
            h.put(key, Integer.valueOf(0));
            ((List)this._sortedValuesKeys.get(lIssue)).add(key);
          }
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          BinCreator bcInt = new IntBinCreator();
          ArrayList<DiscretisizedKey> intBins = bcInt.createBins(lIssueInteger.getLowerBound(), lIssueInteger.getUpperBound());
          for (DiscretisizedKey key : intBins)
          {
            h.put(key, Integer.valueOf(0));
            ((List)this._sortedValuesKeys.get(lIssue)).add(key);
          }
          break;
        default: 
          throw new Exception("issue type " + lIssue.getType() + " not supported by this agent");
        }
        this._offers.put(lIssue, h);
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private void updateValuesList(Issue lIssue, Key updatedVal)
  {
    Integer updatedValCount = (Integer)((Hashtable)this._offers.get(lIssue)).get(updatedVal);
    List<Key> keys = (List)this._sortedValuesKeys.get(lIssue);
    keys.remove(updatedVal);
    
    int index = -1;
    Integer currentValCount = Integer.valueOf(100000);
    while ((updatedValCount.intValue() < currentValCount.intValue()) && (index < keys.size() - 1))
    {
      index++;
      Key currKey = (Key)keys.get(index);
      currentValCount = (Integer)((Hashtable)this._offers.get(lIssue)).get(currKey);
    }
    if (index < keys.size()) {
      keys.add(index, updatedVal);
    } else {
      keys.add(updatedVal);
    }
  }
  
  public boolean updateBid(Bid b)
    throws Exception
  {
    this._totalNumOfOffers += 1;
    double utilForUsFromBid = this._utilitySpace.getUtility(b);
    double prevAvgUtil = this._ourAvgUtilFromOppOffers;
    this._ourAvgUtilFromOppOffers = ((this._ourAvgUtilFromOppOffers * (this._totalNumOfOffers - 1) + utilForUsFromBid) / this._totalNumOfOffers);
    this._oppConcessionRate = Math.max(1.0D, this._ourAvgUtilFromOppOffers / prevAvgUtil);
    if (utilForUsFromBid > this._ourMaxUtilFromOppOffers) {
      this._ourMaxUtilFromOppOffers = utilForUsFromBid;
    }
    for (Issue lIssue : this._issues)
    {
      int issueNum = lIssue.getNumber();
      Value v = b.getValue(issueNum);
      Integer currentCount = Integer.valueOf(0);
      double realVal;
      Enumeration<Key> realKeys;
      switch (v.getType())
      {
      case DISCRETE: 
        DiscreteKey k = new DiscreteKey(v.toString());
        currentCount = (Integer)((Hashtable)this._offers.get(lIssue)).get(k);
        ((Hashtable)this._offers.get(lIssue)).put(k, currentCount = Integer.valueOf(currentCount.intValue() + 1));
        updateValuesList(lIssue, k);
        break;
      case REAL: 
        realVal = ((ValueReal)v).getValue();
        realKeys = ((Hashtable)this._offers.get(lIssue)).keys();
      case INTEGER: 
      default: 
        while (realKeys.hasMoreElements())
        {
          DiscretisizedKey currKey = (DiscretisizedKey)realKeys.nextElement();
          if (currKey.isInRange(realVal))
          {
            currentCount = (Integer)((Hashtable)this._offers.get(lIssue)).get(currKey);
            ((Hashtable)this._offers.get(lIssue)).put(currKey, currentCount = Integer.valueOf(currentCount.intValue() + 1));
          }
          updateValuesList(lIssue, currKey);
          continue;
          

          double intVal = ((ValueInteger)v).getValue();
          Enumeration<Key> intKeys = ((Hashtable)this._offers.get(lIssue)).keys();
          while (intKeys.hasMoreElements())
          {
            DiscretisizedKey currKey = (DiscretisizedKey)intKeys.nextElement();
            if (currKey.isInRange(intVal))
            {
              currentCount = (Integer)((Hashtable)this._offers.get(lIssue)).get(currKey);
              ((Hashtable)this._offers.get(lIssue)).put(currKey, currentCount = Integer.valueOf(currentCount.intValue() + 1));
            }
            updateValuesList(lIssue, currKey);
            continue;
            
            throw new Exception("issue type " + lIssue.getType() + " not supported by this agent");
          }
        }
      }
    }
    if (utilForUsFromBid >= 0.5D)
    {
      int indexInArray = (int)Math.floor((utilForUsFromBid - 0.5D) * 20.0D);
      ((Set)this._oppoentOffersByUtility.get(indexInArray)).add(b);
    }
    return this._ourAvgUtilFromOppOffers >= this._avgFlag;
  }
  
  public double getOurAvgUtilFromOppOffers()
  {
    return this._ourAvgUtilFromOppOffers;
  }
  
  public double getOurMaxUtilFromOppOffers()
  {
    return this._ourMaxUtilFromOppOffers;
  }
  
  public double getOppConcessionRate()
  {
    return this._oppConcessionRate;
  }
  
  public double getOpponentUtility(Bid b)
  {
    if (this._totalNumOfOffers == 0) {
      return 0.0D;
    }
    double oppUtil = 0.0D;
    try
    {
      for (Issue currIssue : this._issues)
      {
        Value currVal = b.getValue(currIssue.getNumber());
        double realVal;
        Enumeration<Key> realKeys;
        switch (currVal.getType())
        {
        case DISCRETE: 
          DiscreteKey k = new DiscreteKey(currVal.toString());
          oppUtil += ((Double)this._issueWeights.get(currIssue)).doubleValue() * ((Double)((Hashtable)this._valuesUtil.get(currIssue)).get(k)).doubleValue();
          
          break;
        case REAL: 
          realVal = ((ValueReal)currVal).getValue();
          realKeys = ((Hashtable)this._offers.get(currIssue)).keys();
        case INTEGER: 
        default: 
          while (realKeys.hasMoreElements())
          {
            DiscretisizedKey currKey = (DiscretisizedKey)realKeys.nextElement();
            if (currKey.isInRange(realVal))
            {
              oppUtil += ((Double)this._issueWeights.get(currIssue)).doubleValue() * ((Double)((Hashtable)this._valuesUtil.get(currIssue)).get(currKey)).doubleValue();
            }
            else
            {
              continue;double intVal = ((ValueInteger)currVal).getValue();
              Enumeration<Key> intKeys = ((Hashtable)this._offers.get(currIssue)).keys();
              while (intKeys.hasMoreElements())
              {
                DiscretisizedKey currKey = (DiscretisizedKey)intKeys.nextElement();
                if (currKey.isInRange(intVal))
                {
                  oppUtil += ((Double)this._issueWeights.get(currIssue)).doubleValue() * ((Double)((Hashtable)this._valuesUtil.get(currIssue)).get(currKey)).doubleValue();
                }
                else
                {
                  continue;throw new Exception("issue type " + currIssue.getType() + " not supported by this agent");
                }
              }
            }
          }
        }
      }
      return oppUtil;
    }
    catch (Exception e)
    {
      System.out.println("Exception in get opponent utility: " + e.getMessage());
    }
    return 0.0D;
  }
  
  private Hashtable<Issue, Double> getIssueWeights()
  {
    Hashtable<Issue, Double> weights = new Hashtable();
    double totalNormalizedCount = totalNormalizedCounts();
    for (Issue currIssue : this._issues)
    {
      double currNormalaizedCount = ((Integer)((Hashtable)this._offers.get(currIssue)).get(((List)this._sortedValuesKeys.get(currIssue)).get(0))).intValue();
      double currNormalaizedWeight = currNormalaizedCount / totalNormalizedCount;
      weights.put(currIssue, Double.valueOf(currNormalaizedWeight));
    }
    return weights;
  }
  
  private double totalNormalizedCounts()
  {
    double totalNormalizedCount = 0.0D;
    for (Issue currIssue : this._issues) {
      totalNormalizedCount += ((Integer)((Hashtable)this._offers.get(currIssue)).get(((List)this._sortedValuesKeys.get(currIssue)).get(0))).intValue();
    }
    return totalNormalizedCount;
  }
  
  private double getValueUtility(Issue issue, Key value)
  {
    double utility = 0.0D;
    double valueCount = ((Integer)((Hashtable)this._offers.get(issue)).get(value)).intValue();
    utility = valueCount / this._totalNumOfOffers;
    return utility;
  }
  
  public void updateWeightsAndUtils()
  {
    this._issueWeights = getIssueWeights();
    try
    {
      for (Issue currIssue : this._issues)
      {
        Hashtable<Key, Double> utils = new Hashtable();
        for (Key k : (List)this._sortedValuesKeys.get(currIssue)) {
          utils.put(k, new Double(getValueUtility(currIssue, k)));
        }
        this._valuesUtil.put(currIssue, utils);
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in updateWeightsAndUtils: " + e.getMessage());
    }
  }
  
  public List<Issue> getIssuesByCounts()
  {
    List<Issue> sortedIssues = new ArrayList();
    try
    {
      currIssueMaxCount = Integer.valueOf(1000000);
      for (Issue newIssue : this._issues)
      {
        List<Key> newIssuekeys = (List)this._sortedValuesKeys.get(newIssue);
        int index = 0;
        Integer newIssueMaxCount = (Integer)((Hashtable)this._offers.get(newIssue)).get(newIssuekeys.get(0));
        while ((newIssueMaxCount.intValue() < currIssueMaxCount.intValue()) && (index < sortedIssues.size()))
        {
          Issue currIssue = (Issue)sortedIssues.get(index);
          List<Key> currIssuekeys = (List)this._sortedValuesKeys.get(currIssue);
          currIssueMaxCount = (Integer)((Hashtable)this._offers.get(currIssue)).get(currIssuekeys.get(0));
          index++;
        }
        if (index < sortedIssues.size())
        {
          sortedIssues.add(index, newIssue);
          index = 0;
        }
        else
        {
          sortedIssues.add(newIssue);
          index = 0;
        }
      }
    }
    catch (Exception e)
    {
      Integer currIssueMaxCount;
      System.out.println("Exception in getIssuesByCounts:" + e.getMessage());
      return null;
    }
    return sortedIssues;
  }
  
  public void printUtilityFunction()
  {
    Iterator<Map.Entry<Issue, Double>> it = this._issueWeights.entrySet().iterator();
    while (it.hasNext())
    {
      Map.Entry<Issue, Double> currEntry = (Map.Entry)it.next();
      Issue currIssue = (Issue)currEntry.getKey();
      System.out.println("Issue: " + currIssue.getName() + " weight: " + currEntry.getValue());
      
      Iterator<Map.Entry<Key, Double>> valueIt = ((Hashtable)this._valuesUtil.get(currIssue)).entrySet().iterator();
      while (valueIt.hasNext())
      {
        Map.Entry<Key, Double> currValueEntry = (Map.Entry)valueIt.next();
        System.out.println(" value " + currValueEntry.getKey() + "\t\tutility: " + currValueEntry.getValue() + "\t\tcount " + ((Hashtable)this._offers.get(currIssue)).get(currValueEntry.getKey()));
      }
    }
  }
  
  public Vector<Bid> getOpponentBidsAboveThreshold(double threshold)
  {
    Vector<Bid> bids = new Vector();
    int stopIndex = (int)Math.floor((threshold - 0.5D) * 20.0D);
    try
    {
      for (int i = 10; i >= stopIndex; i--)
      {
        Set<Bid> currSet = (Set)this._oppoentOffersByUtility.get(i);
        for (Bid b : currSet) {
          if ((i != stopIndex) || (this._utilitySpace.getUtility(b) > threshold)) {
            bids.add(b);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bids;
  }
  
  private void intializeOpponentOffersSets()
  {
    this._oppoentOffersByUtility = new ArrayList();
    for (int i = 0; i < 11; i++) {
      this._oppoentOffersByUtility.add(i, new HashSet());
    }
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    sb.append("-----------Opponent Offers----------\n");
    Iterator<Map.Entry<Issue, Hashtable<Key, Integer>>> issueIterator = this._offers.entrySet().iterator();
    while (issueIterator.hasNext())
    {
      Map.Entry<Issue, Hashtable<Key, Integer>> currEntry = (Map.Entry)issueIterator.next();
      Issue currIssue = (Issue)currEntry.getKey();
      sb.append("Issue: " + currIssue + "\n");
      Hashtable<Key, Integer> currValues = (Hashtable)currEntry.getValue();
      Iterator<Map.Entry<Key, Integer>> valueIterator = currValues.entrySet().iterator();
      while (valueIterator.hasNext())
      {
        Map.Entry<Key, Integer> currValueEntry = (Map.Entry)valueIterator.next();
        Key currKey = (Key)currValueEntry.getKey();
        sb.append("Value: " + currKey + " Count: " + currValueEntry.getValue() + "\n");
      }
      List<Key> sortedKeys = (List)this._sortedValuesKeys.get(currIssue);
      sb.append("sorted values size: " + sortedKeys.size() + "\n");
      sb.append("sorted values: " + sortedKeys.toString() + "\n");
    }
    return sb.toString();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.opponentOffers
 * JD-Core Version:    0.7.1
 */