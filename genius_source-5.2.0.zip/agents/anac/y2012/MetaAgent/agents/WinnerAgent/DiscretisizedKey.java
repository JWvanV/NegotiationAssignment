package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

public class DiscretisizedKey
  extends Key
{
  private double min;
  private double max;
  
  public DiscretisizedKey(double mn, double mx)
  {
    this.min = mn;
    this.max = mx;
  }
  
  public boolean isInRange(double val)
  {
    if ((val >= this.min) && (val <= this.max)) {
      return true;
    }
    return false;
  }
  
  public double getMin()
  {
    return this.min;
  }
  
  public void setMin(double min)
  {
    this.min = min;
  }
  
  public double getMax()
  {
    return this.max;
  }
  
  public void setMax(double max)
  {
    this.max = max;
  }
  
  public boolean equals(Object obj)
  {
    DiscretisizedKey k = (DiscretisizedKey)obj;
    if ((this.min == k.min) && (this.max == k.max)) {
      return true;
    }
    return false;
  }
  
  public int hashCode()
  {
    String s = Double.toString(this.min) + Double.toString(this.max);
    return s.hashCode();
  }
  
  public String toString()
  {
    String s = this.min + "-" + this.max;
    return s;
  }
  
  public boolean contains(Object obj)
  {
    return ((obj instanceof Number)) && (isInRange(((Double)obj).doubleValue()));
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.DiscretisizedKey
 * JD-Core Version:    0.7.1
 */