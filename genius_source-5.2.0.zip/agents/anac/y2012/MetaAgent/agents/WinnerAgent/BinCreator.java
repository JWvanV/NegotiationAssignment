package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.util.ArrayList;
import java.util.Vector;
import negotiator.issue.Value;

public abstract class BinCreator
{
  int numOfBins;
  double percentageOfRange = 0.02D;
  int numConst = 5;
  
  public abstract ArrayList<DiscretisizedKey> createBins(double paramDouble1, double paramDouble2);
  
  public abstract Vector<? extends Value> createValuesVector(double paramDouble1, double paramDouble2);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.BinCreator
 * JD-Core Version:    0.7.1
 */