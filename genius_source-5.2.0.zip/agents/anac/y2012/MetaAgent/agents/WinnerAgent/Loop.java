package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.util.HashMap;
import java.util.Vector;

public class Loop<T>
{
  private Loop<T> _nextLoop;
  private Vector<T> _vec;
  private HashMap<Integer, Integer> _indexMap;
  
  public Loop(Vector<T> vec, HashMap<Integer, Integer> indexMap)
  {
    this._vec = vec;
    this._indexMap = indexMap;
    this._nextLoop = null;
  }
  
  public Loop(Vector<T> vec, HashMap<Integer, Integer> indexMap, Loop<T> next)
  {
    this(vec, indexMap);
    this._nextLoop = next;
  }
  
  public Loop<T> setNext(Vector<T> vec)
  {
    this._nextLoop = new Loop(vec, this._indexMap);
    return this._nextLoop;
  }
  
  public void iteration(HashMap<Integer, T> outerLoop, int index, Vector<HashMap<Integer, T>> cartesianProd, int limit)
  {
    for (T o : this._vec)
    {
      if (cartesianProd.size() >= limit) {
        break;
      }
      HashMap<Integer, T> innerMap = new HashMap();
      innerMap.putAll(outerLoop);
      innerMap.put(this._indexMap.get(Integer.valueOf(index)), o);
      if (this._nextLoop != null) {
        this._nextLoop.iteration(innerMap, index + 1, cartesianProd, limit);
      } else {
        cartesianProd.add(innerMap);
      }
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.Loop
 * JD-Core Version:    0.7.1
 */