package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.util.ArrayList;
import java.util.Vector;
import negotiator.issue.ValueInteger;

public class IntBinCreator
  extends BinCreator
{
  public ArrayList<DiscretisizedKey> createBins(double min, double max)
  {
    int nextInterval = 1;
    this.numConst = Math.min(this.numConst, (int)(max - min));
    this.numOfBins = Math.max((int)(this.percentageOfRange * (max - min)), this.numConst);
    int binSize = (int)((max - min) / this.numOfBins);
    ArrayList<DiscretisizedKey> bins = new ArrayList();
    if (binSize == 1) {
      nextInterval = 0;
    }
    for (int i = 0; i < this.numOfBins; i++)
    {
      DiscretisizedKey bin = new DiscretisizedKey(min, Math.min(min + binSize, max));
      min = min + binSize + nextInterval;
      bins.add(bin);
    }
    return bins;
  }
  
  public Vector<ValueInteger> createValuesVector(double min, double max)
  {
    ArrayList<DiscretisizedKey> bins = createBins(min, max);
    Vector<ValueInteger> vectorOfVals = new Vector();
    boolean takeMin = true;
    for (DiscretisizedKey bin : bins)
    {
      if (takeMin) {
        vectorOfVals.add(new ValueInteger((int)bin.getMin()));
      } else {
        vectorOfVals.add(new ValueInteger((int)bin.getMax()));
      }
      vectorOfVals.add(new ValueInteger((int)(bin.getMax() + bin.getMin()) / 2));
      takeMin = !takeMin;
    }
    return vectorOfVals;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.IntBinCreator
 * JD-Core Version:    0.7.1
 */