package agents.anac.y2012.MetaAgent.agents.WinnerAgent;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.Vector;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.UtilitySpace;

public class WinnerAgent2
  extends Agent
{
  private Action actionOfPartner = null;
  private Vector<Offer> _allReasonableOffers = null;
  private Offer[] _myOffers;
  private int _currentActionsIndex;
  private opponentOffers _opponentOffers;
  private int _numOfPhases;
  private int _nextPhase;
  private double _minimumAcceptenceUtility = 0.9D;
  private final double _finalMinimalAcceptedUtility = 0.65D;
  private final double _zeroSumMinimumAcceptence = 0.5D;
  private double _minimumJointUtility = 0.85D;
  private final int _numOfPredefinedOffers = 20;
  private double _discountFactor;
  private double _ourConcession;
  private final double _ourMinWeight = 0.7D;
  private final double _notZeroSumThreshold = 0.8D;
  private boolean _notZeroSumFlag = false;
  private double _zeroSumUtil = 0.1D;
  private int _initialNumOfPhases = 7;
  private int _maxNumOfPhases = 20;
  private final double _randomlySelectProb = 0.3D;
  
  public void init()
  {
    this._opponentOffers = new opponentOffers(this.utilitySpace, 0.8D);
    this._allReasonableOffers = (this._allReasonableOffers == null ? createSortedOffersArray() : this._allReasonableOffers);
    
    this._myOffers = randomlySelectOffers(1.0D);
    this._currentActionsIndex = 0;
    this._nextPhase = 1;
    

    this._discountFactor = this.utilitySpace.getDiscountFactor();
    if ((this._discountFactor == 0.0D) || (this._discountFactor == 1.0D))
    {
      this._numOfPhases = this._initialNumOfPhases;
      this._discountFactor = 1.0D;
    }
    else
    {
      this._numOfPhases = ((int)Math.min(
        Math.round(this._initialNumOfPhases / this._discountFactor), this._maxNumOfPhases));
    }
    this._ourConcession = (0.25D / (this._numOfPhases - 1));
  }
  
  private Vector<Offer> createSortedOffersArray()
  {
    Set<Bid> bids = new HashSet();
    try
    {
      ArrayList<Vector<? extends Value>> issuesVec = createIssueVec();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      HashMap<Integer, Integer> indexMap = new HashMap();
      for (int i = 0; i < issues.size(); i++) {
        indexMap.put(Integer.valueOf(i), Integer.valueOf(((Issue)issues.get(i)).getNumber()));
      }
      Loop FirstLoop = new Loop((Vector)issuesVec.get(0), indexMap);
      Loop currentLoop = FirstLoop;
      for (int i = 1; i < issuesVec.size(); i++)
      {
        newLoop = currentLoop.setNext((Vector)issuesVec.get(i));
        currentLoop = newLoop;
      }
      Vector<HashMap<Integer, Value>> bidsMap = new Vector();
      FirstLoop.iteration(new HashMap(), 0, bidsMap, 10000);
      for (Loop newLoop = bidsMap.iterator(); newLoop.hasNext();)
      {
        map = (HashMap)newLoop.next();
        Bid bid = new Bid(this.utilitySpace.getDomain(), map);
        bids.add(bid);
      }
      HashMap<Integer, Value> map;
      Vector<Offer> offers = new Vector();
      for (Bid bid : bids) {
        if (this.utilitySpace.getUtility(bid) >= 0.5D) {
          offers.add(new Offer(getAgentID(), bid));
        }
      }
      sortOffersByJointUtilities(offers, 1.0D);
      
      return offers;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  private ArrayList<Vector<? extends Value>> createIssueVec()
    throws Exception
  {
    ArrayList<Vector<? extends Value>> issuesVec = new ArrayList();
    for (Issue lIssue : this.utilitySpace.getDomain().getIssues()) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        Vector<Value> discreteVec = new Vector();
        for (ValueDiscrete v : lIssueDiscrete.getValues()) {
          discreteVec.add(v);
        }
        issuesVec.add(discreteVec);
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        BinCreator bcReal = new RealBinCreator();
        Vector<? extends Value> realVec = bcReal.createValuesVector(lIssueReal
          .getLowerBound(), lIssueReal.getUpperBound());
        issuesVec.add(realVec);
        break;
      case INTEGER: 
        IssueInteger lIssueInt = (IssueInteger)lIssue;
        
        BinCreator bcInt = new IntBinCreator();
        Vector<? extends Value> intVec = bcInt.createValuesVector(lIssueInt
          .getLowerBound(), lIssueInt.getUpperBound());
        issuesVec.add(intVec);
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by this agent");
      }
    }
    return issuesVec;
  }
  
  private Offer[] randomlySelectOffers(double w)
  {
    Set<Integer> offersIndex = new HashSet();
    try
    {
      offersIndex.add(Integer.valueOf(0));
      int currOfferInd = 1;
      int maxTries = 5000;
      int maxIndex = this._allReasonableOffers.size();
      while ((offersIndex.size() < 20) && 
        (maxIndex > offersIndex.size()))
      {
        maxTries--;
        if (maxTries <= 0) {
          break;
        }
        if ((currOfferInd >= this._allReasonableOffers.size()) || 
        


          (getJointUtility(
          (Offer)this._allReasonableOffers.get(currOfferInd), w) < this._minimumJointUtility))
        {
          maxIndex = currOfferInd;
          currOfferInd = 1;
        }
        if (this.utilitySpace.getUtility(((Offer)this._allReasonableOffers.get(currOfferInd))
          .getBid()) >= this._minimumAcceptenceUtility) {
          if (Math.random() <= 0.3D + 0.05D * this._nextPhase + 0.01D * currOfferInd) {
            offersIndex.add(Integer.valueOf(currOfferInd));
          }
        }
        currOfferInd++;
      }
      Vector<Bid> opponentGoodBids = this._opponentOffers.getOpponentBidsAboveThreshold(this._minimumAcceptenceUtility);
      


      Offer[] offers = new Offer[offersIndex.size() + opponentGoodBids.size()];
      currOfferInd = 0;
      for (Bid b : opponentGoodBids) {
        offers[(currOfferInd++)] = new Offer(getAgentID(), b);
      }
      for (Integer i : offersIndex) {
        offers[(currOfferInd++)] = ((Offer)this._allReasonableOffers.get(i.intValue()));
      }
      return offers;
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return null;
  }
  
  public String getVersion()
  {
    return "1.5";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  private void sortOffersByJointUtilities(Vector<Offer> toSort, final double w)
  {
    Collections.sort(toSort, new Comparator()
    {
      public int compare(Offer o1, Offer o2)
      {
        try
        {
          double o1Utility = WinnerAgent2.this.utilitySpace.getUtility(o1.getBid());
          double o2Utility = WinnerAgent2.this.utilitySpace.getUtility(o2.getBid());
          double o1OpUtility = WinnerAgent2.this._opponentOffers.getOpponentUtility(o1
            .getBid());
          double o2OpUtility = WinnerAgent2.this._opponentOffers.getOpponentUtility(o2
            .getBid());
          int ans;
          if (w == 1.0D)
          {
            int ans;
            if (o1Utility > o2Utility)
            {
              ans = -1;
            }
            else
            {
              int ans;
              if (o1Utility == o2Utility) {
                ans = o1OpUtility >= o2OpUtility ? -1 : 1;
              } else {
                ans = 1;
              }
            }
          }
          else
          {
            double o1mixedUtility = WinnerAgent2.this.getJointUtility(o1, w);
            double o2mixedUtility = WinnerAgent2.this.getJointUtility(o2, w);
            double o1Inequality = WinnerAgent2.this.getOfferInequality(o1);
            double o2Inequality = WinnerAgent2.this.getOfferInequality(o2);
            int ans;
            if ((WinnerAgent2.this._nextPhase <= 3) || ((o1Inequality <= 0.3D) && (o2Inequality <= 0.3D)))
            {
              int ans;
              if (o1mixedUtility > o2mixedUtility)
              {
                ans = -1;
              }
              else
              {
                int ans;
                if (o1mixedUtility == o2mixedUtility)
                {
                  int ans;
                  if (o1OpUtility > o2OpUtility) {
                    ans = -1;
                  } else {
                    ans = 1;
                  }
                }
                else
                {
                  ans = 1;
                }
              }
            }
            else
            {
              int ans;
              if ((o1Inequality > 0.3D) && (o2Inequality > 0.3D))
              {
                int ans;
                if (o1OpUtility > o2OpUtility) {
                  ans = -1;
                } else {
                  ans = 1;
                }
              }
              else
              {
                int ans;
                if (o1Inequality > 0.3D) {
                  ans = 1;
                }
              }
            }
          }
          return -1;
        }
        catch (Exception e)
        {
          e.printStackTrace();
          if (WinnerAgent2.this._opponentOffers.getOpponentUtility(o1.getBid()) >= WinnerAgent2.this._opponentOffers.getOpponentUtility(o2.getBid())) {
            tmpTernaryOp = -1;
          }
        }
        return 1;
      }
    });
  }
  
  private double getJointUtility(Offer o, double w)
  {
    double mixedUtility = 0.0D;
    try
    {
      if (w == 1.0D) {
        mixedUtility = this.utilitySpace.getUtility(o.getBid());
      } else {
        mixedUtility = w * this.utilitySpace.getUtility(o.getBid()) + (1.0D - w) * this._opponentOffers.getOpponentUtility(o
          .getBid());
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return mixedUtility;
  }
  
  private double getOfferInequality(Offer o)
  {
    double diff = 0.0D;
    try
    {
      diff = Math.abs(this.utilitySpace.getUtility(o.getBid()) - this._opponentOffers
        .getOpponentUtility(o.getBid()));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return diff;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.timeline.getTime() > this._nextPhase / this._numOfPhases)
      {
        double ourWeight = Math.max(0.7D, 1.0D - 0.05D * this._nextPhase);
        this._minimumJointUtility -= 0.05D;
        





        double assumedBestOfferWeGetNext = this._opponentOffers.getOurMaxUtilFromOppOffers() * Math.max(this._opponentOffers.getOppConcessionRate(), 1.1D) * Math.pow(this._discountFactor, (this._nextPhase + 1) / this._numOfPhases);
        
        this._minimumAcceptenceUtility = Math.max(this._minimumAcceptenceUtility - this._ourConcession, 
          Math.min(this._minimumAcceptenceUtility - this._ourConcession, assumedBestOfferWeGetNext));
        

        this._minimumAcceptenceUtility = Math.max(0.65D, this._minimumAcceptenceUtility);
        




        this._opponentOffers.updateWeightsAndUtils();
        if (this._opponentOffers.getOurAvgUtilFromOppOffers() <= this._zeroSumUtil) {
          this._minimumAcceptenceUtility = Math.max(this._minimumAcceptenceUtility - 0.05D, 0.5D);
        }
        updateBids(ourWeight);
        

        this._nextPhase += 1;
      }
      if (this.actionOfPartner == null)
      {
        action = this._myOffers[updateIndex()];
      }
      else if ((this.actionOfPartner instanceof Offer))
      {
        Offer proposed = (Offer)this.actionOfPartner;
        if ((this._opponentOffers.updateBid(proposed.getBid())) && 
          (!this._notZeroSumFlag)) {
          updateNotZeroSum();
        }
        if (this.utilitySpace.getUtility(proposed.getBid()) > this._minimumAcceptenceUtility) {
          action = new Accept();
        } else {
          action = this._myOffers[updateIndex()];
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private void updateNotZeroSum()
  {
    double opponentAvgUtil = this._opponentOffers.getOurAvgUtilFromOppOffers();
    this._minimumAcceptenceUtility = Math.max(this._minimumAcceptenceUtility, opponentAvgUtil);
    
    this._minimumJointUtility = Math.max(this._minimumJointUtility, opponentAvgUtil);
    this._ourConcession = 0.01D;
    this._notZeroSumFlag = true;
  }
  
  private int updateIndex()
  {
    int curr = this._currentActionsIndex;
    this._currentActionsIndex = (this._currentActionsIndex++ % this._myOffers.length);
    if (Math.random() <= 0.3D) {
      shuffle(this._myOffers);
    }
    return curr;
  }
  
  public void updateBids(double ourW)
    throws Exception
  {
    sortOffersByJointUtilities(this._allReasonableOffers, ourW);
    this._myOffers = randomlySelectOffers(ourW);
    this._currentActionsIndex = 0;
  }
  
  public void shuffle(Offer[] array)
  {
    Random rng = new Random();
    for (int i = array.length; i > 1; i--)
    {
      int j = rng.nextInt(i);
      

      Offer tmp = array[j];
      array[j] = array[(i - 1)];
      array[(i - 1)] = tmp;
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.MetaAgent.agents.WinnerAgent.WinnerAgent2
 * JD-Core Version:    0.7.1
 */