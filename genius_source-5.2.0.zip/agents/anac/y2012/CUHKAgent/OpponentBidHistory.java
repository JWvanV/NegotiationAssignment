package agents.anac.y2012.CUHKAgent;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class OpponentBidHistory
{
  private ArrayList<Bid> bidHistory;
  private ArrayList<ArrayList<Integer>> opponentBidsStatisticsForReal;
  private ArrayList<HashMap<Value, Integer>> opponentBidsStatisticsDiscrete;
  private ArrayList<ArrayList<Integer>> opponentBidsStatisticsForInteger;
  private int maximumBidsStored = 100;
  private HashMap<Bid, Integer> bidCounter = new HashMap();
  private Bid bid_maximum_from_opponent;
  
  public OpponentBidHistory()
  {
    this.bidHistory = new ArrayList();
    this.opponentBidsStatisticsForReal = new ArrayList();
    this.opponentBidsStatisticsDiscrete = new ArrayList();
    this.opponentBidsStatisticsForInteger = new ArrayList();
  }
  
  public void addBid(Bid bid, UtilitySpace utilitySpace)
  {
    if (this.bidHistory.indexOf(bid) == -1) {
      this.bidHistory.add(bid);
    }
    try
    {
      if (this.bidHistory.size() == 1) {
        this.bid_maximum_from_opponent = ((Bid)this.bidHistory.get(0));
      } else if (utilitySpace.getUtility(bid) > utilitySpace.getUtility(this.bid_maximum_from_opponent)) {
        this.bid_maximum_from_opponent = bid;
      }
    }
    catch (Exception e)
    {
      System.out.println("error in addBid method" + e.getMessage());
    }
  }
  
  public Bid getBestBidInHistory()
  {
    return this.bid_maximum_from_opponent;
  }
  
  public void initializeDataStructures(Domain domain)
  {
    try
    {
      ArrayList<Issue> issues = domain.getIssues();
      for (Issue lIssue : issues) {
        switch (lIssue.getType())
        {
        case DISCRETE: 
          IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
          HashMap<Value, Integer> discreteIssueValuesMap = new HashMap();
          for (int j = 0; j < lIssueDiscrete.getNumberOfValues(); j++)
          {
            Value v = lIssueDiscrete.getValue(j);
            discreteIssueValuesMap.put(v, Integer.valueOf(0));
          }
          this.opponentBidsStatisticsDiscrete.add(discreteIssueValuesMap);
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          ArrayList<Integer> numProposalsPerValue = new ArrayList();
          int lNumOfPossibleValuesInThisIssue = lIssueReal.getNumberOfDiscretizationSteps();
          for (int i = 0; i < lNumOfPossibleValuesInThisIssue; i++) {
            numProposalsPerValue.add(Integer.valueOf(0));
          }
          this.opponentBidsStatisticsForReal.add(numProposalsPerValue);
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          ArrayList<Integer> numOfValueProposals = new ArrayList();
          

          int lNumOfPossibleValuesForThisIssue = lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound() + 1;
          for (int i = 0; i < lNumOfPossibleValuesForThisIssue; i++) {
            numOfValueProposals.add(Integer.valueOf(0));
          }
          this.opponentBidsStatisticsForInteger.add(numOfValueProposals);
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("EXCEPTION in initializeDataAtructures");
    }
  }
  
  public void updateOpponentModel(Bid bidToUpdate, Domain domain, UtilitySpace utilitySpace)
  {
    addBid(bidToUpdate, utilitySpace);
    if (this.bidCounter.get(bidToUpdate) == null)
    {
      this.bidCounter.put(bidToUpdate, Integer.valueOf(1));
    }
    else
    {
      int counter = ((Integer)this.bidCounter.get(bidToUpdate)).intValue();
      counter++;
      this.bidCounter.put(bidToUpdate, Integer.valueOf(counter));
    }
    if (this.bidHistory.size() <= this.maximumBidsStored) {
      updateStatistics(bidToUpdate, false, domain);
    }
  }
  
  private void updateStatistics(Bid bidToUpdate, boolean toRemove, Domain domain)
  {
    try
    {
      ArrayList<Issue> issues = domain.getIssues();
      

      realIndex = 0;
      discreteIndex = 0;
      integerIndex = 0;
      for (Issue lIssue : issues)
      {
        int issueNum = lIssue.getNumber();
        Value v = bidToUpdate.getValue(issueNum);
        switch (lIssue.getType())
        {
        case DISCRETE: 
          if (this.opponentBidsStatisticsDiscrete == null)
          {
            System.out.println("opponentBidsStatisticsDiscrete is NULL");
          }
          else if (this.opponentBidsStatisticsDiscrete.get(discreteIndex) != null)
          {
            int counterPerValue = ((Integer)((HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex)).get(v)).intValue();
            if (toRemove) {
              counterPerValue--;
            } else {
              counterPerValue++;
            }
            ((HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex)).put(v, Integer.valueOf(counterPerValue));
          }
          discreteIndex++;
          break;
        case REAL: 
          IssueReal lIssueReal = (IssueReal)lIssue;
          int lNumOfPossibleRealValues = lIssueReal.getNumberOfDiscretizationSteps();
          double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNumOfPossibleRealValues;
          double first = lIssueReal.getLowerBound();
          double last = lIssueReal.getLowerBound() + lOneStep;
          double valueReal = ((ValueReal)v).getValue();
          boolean found = false;
          for (int i = 0; (!found) && (i < ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size()); i++)
          {
            if ((valueReal >= first) && (valueReal <= last))
            {
              int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(i)).intValue();
              if (toRemove) {
                countPerValue--;
              } else {
                countPerValue++;
              }
              ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).set(i, Integer.valueOf(countPerValue));
              found = true;
            }
            first = last;
            last += lOneStep;
          }
          if (!found)
          {
            int i = ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size() - 1;
            int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(i)).intValue();
            if (toRemove) {
              countPerValue--;
            } else {
              countPerValue++;
            }
            ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).set(i, Integer.valueOf(countPerValue));
          }
          realIndex++;
          break;
        case INTEGER: 
          IssueInteger lIssueInteger = (IssueInteger)lIssue;
          int valueInteger = ((ValueInteger)v).getValue();
          
          int valueIndex = valueInteger - lIssueInteger.getLowerBound();
          int countPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex)).get(valueIndex)).intValue();
          if (toRemove) {
            countPerValue--;
          } else {
            countPerValue++;
          }
          ((ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex)).set(valueIndex, Integer.valueOf(countPerValue));
          integerIndex++;
        }
      }
    }
    catch (Exception e)
    {
      int realIndex;
      int discreteIndex;
      int integerIndex;
      System.out.println("Exception in updateStatistics: " + e.getMessage());
    }
  }
  
  public Bid ChooseBid(List<Bid> candidateBids, Domain domain)
  {
    int upperSearchLimit = 200;
    
    int maxIndex = -1;
    Random ran = new Random();
    ArrayList<Issue> issues = domain.getIssues();
    int maxFrequency = 0;
    int realIndex = 0;
    int discreteIndex = 0;
    int integerIndex = 0;
    if (candidateBids.size() >= upperSearchLimit)
    {
      List<Bid> bids = new ArrayList();
      for (int i = 0; i < upperSearchLimit; i++)
      {
        int issueIndex = ran.nextInt(candidateBids.size());
        bids.add(candidateBids.get(issueIndex));
      }
      candidateBids = bids;
    }
    try
    {
      for (int i = 0; i < candidateBids.size(); i++)
      {
        int maxValue = 0;
        realIndex = discreteIndex = integerIndex = 0;
        for (int j = 0; j < issues.size(); j++)
        {
          Value v = ((Bid)candidateBids.get(i)).getValue(((Issue)issues.get(j)).getNumber());
          switch (((Issue)issues.get(j)).getType())
          {
          case DISCRETE: 
            if (this.opponentBidsStatisticsDiscrete.get(discreteIndex) != null)
            {
              int counterPerValue = ((Integer)((HashMap)this.opponentBidsStatisticsDiscrete.get(discreteIndex)).get(v)).intValue();
              maxValue += counterPerValue;
            }
            discreteIndex++;
            break;
          case REAL: 
            IssueReal lIssueReal = (IssueReal)issues.get(j);
            int lNumOfPossibleRealValues = lIssueReal.getNumberOfDiscretizationSteps();
            double lOneStep = (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) / lNumOfPossibleRealValues;
            double first = lIssueReal.getLowerBound();
            double last = lIssueReal.getLowerBound() + lOneStep;
            double valueReal = ((ValueReal)v).getValue();
            boolean found = false;
            for (int k = 0; (!found) && (k < ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size()); k++)
            {
              if ((valueReal >= first) && (valueReal <= last))
              {
                int counterPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(k)).intValue();
                maxValue += counterPerValue;
                found = true;
              }
              first = last;
              last += lOneStep;
            }
            if (!found)
            {
              int k = ((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).size() - 1;
              int counterPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForReal.get(realIndex)).get(k)).intValue();
              maxValue += counterPerValue;
            }
            realIndex++;
            break;
          case INTEGER: 
            IssueInteger lIssueInteger = (IssueInteger)issues.get(j);
            int valueInteger = ((ValueInteger)v).getValue();
            int valueIndex = valueInteger - lIssueInteger.getLowerBound();
            int counterPerValue = ((Integer)((ArrayList)this.opponentBidsStatisticsForInteger.get(integerIndex)).get(valueIndex)).intValue();
            maxValue += counterPerValue;
            integerIndex++;
          }
        }
        if (maxValue > maxFrequency)
        {
          maxFrequency = maxValue;
          maxIndex = i;
        }
        else if ((maxValue == maxFrequency) && 
          (ran.nextDouble() < 0.5D))
        {
          maxFrequency = maxValue;
          maxIndex = i;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in choosing a bid");
      System.out.println(e.getMessage() + "---" + discreteIndex);
    }
    if (maxIndex == -1) {
      return (Bid)candidateBids.get(ran.nextInt(candidateBids.size()));
    }
    if (ran.nextDouble() < 0.95D) {
      return (Bid)candidateBids.get(maxIndex);
    }
    return (Bid)candidateBids.get(ran.nextInt(candidateBids.size()));
  }
  
  public Bid chooseBestFromHistory(UtilitySpace utilitySpace)
  {
    double max = -1.0D;
    Bid maxBid = null;
    try
    {
      for (Bid bid : this.bidHistory) {
        if (max < utilitySpace.getUtility(bid))
        {
          max = utilitySpace.getUtility(bid);
          maxBid = bid;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("ChooseBestfromhistory exception");
    }
    return maxBid;
  }
  
  public double concedeDegree(UtilitySpace utilitySpace)
  {
    int numOfBids = this.bidHistory.size();
    HashMap<Bid, Integer> bidCounter = new HashMap();
    try
    {
      for (int i = 0; i < numOfBids; i++) {
        if (bidCounter.get(this.bidHistory.get(i)) == null)
        {
          bidCounter.put(this.bidHistory.get(i), Integer.valueOf(1));
        }
        else
        {
          int counter = ((Integer)bidCounter.get(this.bidHistory.get(i))).intValue();
          counter++;
          bidCounter.put(this.bidHistory.get(i), Integer.valueOf(counter));
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("ChooseBestfromhistory exception");
    }
    return bidCounter.size() / utilitySpace.getDomain().getNumberOfPossibleBids();
  }
  
  public int getSize()
  {
    int numOfBids = this.bidHistory.size();
    HashMap<Bid, Integer> bidCounter = new HashMap();
    try
    {
      for (int i = 0; i < numOfBids; i++) {
        if (bidCounter.get(this.bidHistory.get(i)) == null)
        {
          bidCounter.put(this.bidHistory.get(i), Integer.valueOf(1));
        }
        else
        {
          int counter = ((Integer)bidCounter.get(this.bidHistory.get(i))).intValue();
          counter++;
          bidCounter.put(this.bidHistory.get(i), Integer.valueOf(counter));
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("getSize exception");
    }
    return bidCounter.size();
  }
  
  public double getConcessionDegree()
  {
    int numOfBids = this.bidHistory.size();
    double numOfDistinctBid = 0.0D;
    int historyLength = 10;
    double concessionDegree = 0.0D;
    if (numOfBids - historyLength > 0)
    {
      try
      {
        for (int j = numOfBids - historyLength; j < numOfBids; j++) {
          if (((Integer)this.bidCounter.get(this.bidHistory.get(j))).intValue() == 1) {
            numOfDistinctBid += 1.0D;
          }
        }
        concessionDegree = Math.pow(numOfDistinctBid / historyLength, 2.0D);
      }
      catch (Exception e)
      {
        System.out.println("getConcessionDegree exception");
      }
    }
    else
    {
      numOfDistinctBid = getSize();
      concessionDegree = Math.pow(numOfDistinctBid / historyLength, 2.0D);
    }
    return concessionDegree;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.CUHKAgent.OpponentBidHistory
 * JD-Core Version:    0.7.1
 */