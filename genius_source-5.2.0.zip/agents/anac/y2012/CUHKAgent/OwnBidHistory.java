package agents.anac.y2012.CUHKAgent;

import java.io.PrintStream;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class OwnBidHistory
{
  private ArrayList<Bid> BidHistory;
  private Bid minBidInHistory;
  
  public OwnBidHistory()
  {
    this.BidHistory = new ArrayList();
  }
  
  public void addBid(Bid bid, UtilitySpace utilitySpace)
  {
    if (this.BidHistory.indexOf(bid) == -1) {
      this.BidHistory.add(bid);
    }
    try
    {
      if (this.BidHistory.size() == 1) {
        this.minBidInHistory = ((Bid)this.BidHistory.get(0));
      } else if (utilitySpace.getUtility(bid) < utilitySpace.getUtility(this.minBidInHistory)) {
        this.minBidInHistory = bid;
      }
    }
    catch (Exception e)
    {
      System.out.println("error in addBid method of OwnBidHistory class" + e.getMessage());
    }
  }
  
  protected Bid GetMinBidInHistory()
  {
    return this.minBidInHistory;
  }
  
  protected Bid getLastBid()
  {
    if (this.BidHistory.size() >= 1) {
      return (Bid)this.BidHistory.get(this.BidHistory.size() - 1);
    }
    return null;
  }
  
  public int numOfBidsProposed()
  {
    return this.BidHistory.size();
  }
  
  protected Bid chooseLowestBidInHistory(UtilitySpace utilitySpace)
  {
    double minUtility = 100.0D;
    Bid minBid = null;
    try
    {
      for (Bid bid : this.BidHistory) {
        if (utilitySpace.getUtility(bid) < minUtility)
        {
          minUtility = utilitySpace.getUtility(bid);
          minBid = bid;
        }
      }
    }
    catch (Exception e)
    {
      System.out.println("Exception in chooseLowestBidInHistory");
    }
    return minBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.CUHKAgent.OwnBidHistory
 * JD-Core Version:    0.7.1
 */