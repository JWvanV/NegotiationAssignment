package agents.anac.y2012.IAMhaggler2012.utility;

import java.util.Enumeration;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Objective;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorInteger;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class SouthamptonUtilitySpace
{
  UtilitySpace us;
  
  public SouthamptonUtilitySpace(UtilitySpace us)
  {
    this.us = us;
  }
  
  public final Bid getMaxUtilityBid()
    throws Exception
  {
    HashMap<Integer, Value> bid = new HashMap();
    
    Objective root = this.us.getDomain().getObjectivesRoot();
    Enumeration<Objective> issueEnum = root.getPreorderIssueEnumeration();
    while (issueEnum.hasMoreElements())
    {
      Objective is = (Objective)issueEnum.nextElement();
      bid.put(Integer.valueOf(is.getNumber()), getMaxValue(is.getNumber()));
    }
    return new Bid(this.us.getDomain(), bid);
  }
  
  private Value getMaxValue(int pIssueIndex)
  {
    Evaluator lEvaluator = this.us.getEvaluator(pIssueIndex);
    if (lEvaluator.getClass() == EvaluatorDiscrete.class) {
      return ((EvaluatorDiscrete)lEvaluator).getMaxValue();
    }
    if (lEvaluator.getClass() == EvaluatorInteger.class) {
      return getMaxValueInteger((EvaluatorInteger)lEvaluator);
    }
    if (lEvaluator.getClass() == EvaluatorReal.class) {
      return getMaxValueReal((EvaluatorReal)lEvaluator);
    }
    return null;
  }
  
  private Value getMaxValueInteger(EvaluatorInteger eval)
  {
    double utility = 0.0D;
    switch (eval.getFuncType())
    {
    case LINEAR: 
      utility = maxLinear(eval.getSlope(), eval.getOffset());
      if (utility < eval.getLowerBound()) {
        utility = eval.getLowerBound();
      } else if (utility > eval.getUpperBound()) {
        utility = eval.getUpperBound();
      }
      break;
    default: 
      return null;
    }
    return new ValueInteger((int)utility);
  }
  
  private Value getMaxValueReal(EvaluatorReal eval)
  {
    double utility = 0.0D;
    switch (eval.getFuncType())
    {
    case LINEAR: 
      utility = maxLinear(eval.getLinearParam(), eval.getConstantParam());
      if (utility < eval.getLowerBound()) {
        utility = eval.getLowerBound();
      } else if (utility > eval.getUpperBound()) {
        utility = eval.getUpperBound();
      }
      break;
    case CONSTANT: 
      utility = eval.getLowerBound();
      break;
    case TRIANGULAR: 
    case TRIANGULAR_VARIABLE_TOP: 
      utility = maxTriangular(eval.getLinearParam(), eval.getConstantParam(), eval.getTopParam());
      break;
    default: 
      return null;
    }
    return new ValueReal(utility);
  }
  
  private static double maxLinear(double coef1, double coef0)
  {
    if (coef1 > 0.0D) {
      return Double.MAX_VALUE;
    }
    return Double.MIN_NORMAL;
  }
  
  private static double maxTriangular(double lowerBound, double upperBound, double top)
  {
    return top;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.utility.SouthamptonUtilitySpace
 * JD-Core Version:    0.7.1
 */