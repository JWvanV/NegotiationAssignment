package agents.anac.y2012.IAMhaggler2012;

import agents.anac.y2012.IAMhaggler2012.agents2011.IAMhaggler2011;
import agents.anac.y2012.IAMhaggler2012.utility.SouthamptonUtilitySpace;
import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.utility.UtilitySpace;

public class IAMhaggler2012
  extends IAMhaggler2011
{
  private SouthamptonUtilitySpace sus;
  
  public void init()
  {
    this.debug = false;
    super.init();
    this.sus = new SouthamptonUtilitySpace(this.utilitySpace);
  }
  
  protected Bid proposeInitialBid()
    throws Exception
  {
    Bid b = this.sus.getMaxUtilityBid();
    if (this.utilitySpace.getUtilityWithDiscount(b, this.timeline) < this.utilitySpace.getReservationValueWithDiscount(this.timeline)) {
      return null;
    }
    return b;
  }
  
  protected Bid proposeNextBid(Bid opponentBid)
    throws Exception
  {
    Bid b = super.proposeNextBid(opponentBid);
    if (this.utilitySpace.getUtilityWithDiscount(b, this.timeline) < this.utilitySpace.getReservationValueWithDiscount(this.timeline)) {
      return proposeInitialBid();
    }
    return b;
  }
  
  protected double getTarget(double opponentUtility, double time)
  {
    return Math.max(this.utilitySpace.getReservationValueWithDiscount(time), 
      super.getTarget(opponentUtility, time));
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.IAMhaggler2012
 * JD-Core Version:    0.7.1
 */