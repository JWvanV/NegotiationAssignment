package agents.anac.y2012.IAMhaggler2012.agents2011;

import negotiator.Agent;
import negotiator.Timeline;

public abstract class VersionIndependentAgent
  extends Agent
  implements VersionIndependentAgentInterface
{
  public double getTime()
  {
    return this.timeline.getTime();
  }
  
  public double adjustDiscountFactor(double discountFactor)
  {
    return discountFactor;
  }
  
  public void setOpponentTime(long time) {}
  
  public void setOurTime(long time) {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.agents2011.VersionIndependentAgent
 * JD-Core Version:    0.7.1
 */