package agents.anac.y2012.IAMhaggler2012.agents2011;

import Jama.Matrix;
import agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils.ActionCreator;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Random;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public abstract class SouthamptonAgent
  extends VersionIndependentAgent
{
  private static enum ActionType
  {
    ACCEPT,  BREAKOFF,  OFFER,  START;
    
    private ActionType() {}
  }
  
  protected double MAXIMUM_ASPIRATION = 0.9D;
  private Action messageOpponent;
  
  public String getVersion()
  {
    return "2.0";
  }
  
  protected Action myLastAction = null;
  protected Bid myLastBid = null;
  protected Bid opponentPreviousBid = null;
  protected double acceptMultiplier = 1.02D;
  private boolean opponentIsHardHead;
  private ArrayList<Bid> opponentBids;
  private ArrayList<Bid> myPreviousBids;
  protected boolean debug;
  
  public final Action chooseAction(long ourTime, long opponentTime)
  {
    setOurTime(ourTime);
    setOpponentTime(opponentTime);
    return chooseAction(false);
  }
  
  public final Action chooseAction()
  {
    return chooseAction(true);
  }
  
  private final Action chooseAction(boolean recordTimes)
  {
    Action chosenAction = null;
    Bid opponentBid = null;
    log("Choose action");
    try
    {
      switch (getActionType(this.messageOpponent))
      {
      case OFFER: 
        opponentBid = ((Offer)this.messageOpponent).getBid();
        chosenAction = handleOffer(opponentBid);
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null)
        {
          Bid b = proposeInitialBid();
          if (b == null) {
            chosenAction = new EndNegotiation();
          } else {
            chosenAction = new Offer(getAgentID(), b);
          }
        }
        else
        {
          chosenAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      log("Exception in chooseAction:" + e.getMessage());
      e.printStackTrace();
      chosenAction = ActionCreator.createOffer(this, this.myLastBid);
    }
    this.myLastAction = chosenAction;
    if ((this.myLastAction instanceof Offer))
    {
      Bid b = ((Offer)this.myLastAction).getBid();
      this.myPreviousBids.add(b);
      this.myLastBid = b;
    }
    return chosenAction;
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
  }
  
  private ActionType getActionType(Action action)
  {
    ActionType actionType = ActionType.START;
    if ((action instanceof Offer)) {
      actionType = ActionType.OFFER;
    } else if ((action instanceof Accept)) {
      actionType = ActionType.ACCEPT;
    } else if ((action instanceof EndNegotiation)) {
      actionType = ActionType.BREAKOFF;
    }
    return actionType;
  }
  
  public int getAgentNo()
  {
    if (getName() == "Agent A") {
      return 1;
    }
    if (getName() == "Agent B") {
      return 2;
    }
    return 0;
  }
  
  private ArrayList<Bid> getBidsInRange(double lowerBound, double upperBound)
    throws Exception
  {
    ArrayList<Bid> bidsInRange = new ArrayList();
    BidIterator iter = new BidIterator(this.utilitySpace.getDomain());
    while (iter.hasNext())
    {
      Bid tmpBid = iter.next();
      double util = 0.0D;
      try
      {
        util = this.utilitySpace.getUtility(tmpBid);
        if ((util >= lowerBound) && (util <= upperBound)) {
          bidsInRange.add(tmpBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bidsInRange;
  }
  
  protected Bid getRandomBidInRange(double lowerBound, double upperBound)
    throws Exception
  {
    ArrayList<Bid> bidsInRange = getBidsInRange(lowerBound, upperBound);
    
    int index = new Random().nextInt(bidsInRange.size() - 1);
    
    return (Bid)bidsInRange.get(index);
  }
  
  private Action handleOffer(Bid opponentBid)
    throws Exception
  {
    Action chosenAction = null;
    if (this.myLastAction == null)
    {
      Bid b = proposeInitialBid();
      if (b == null)
      {
        chosenAction = ActionCreator.createEndNegotiation(this);
      }
      else
      {
        this.myLastBid = b;
        chosenAction = ActionCreator.createOffer(this, b);
      }
    }
    else if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.utilitySpace.getUtility(this.myLastBid))
    {
      chosenAction = ActionCreator.createAccept(this);
      log("Opponent's bid is good enough compared to my last bid, ACCEPTED.");
      this.opponentBids.add(opponentBid);
      this.opponentPreviousBid = opponentBid;
    }
    else if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.MAXIMUM_ASPIRATION)
    {
      chosenAction = ActionCreator.createAccept(this);
      log("Utility of opponent bid: " + this.utilitySpace.getUtility(opponentBid));
      
      log("acceptMultiplier: " + this.acceptMultiplier);
      log("MAXIMUM_ASPIRATION: " + this.MAXIMUM_ASPIRATION);
      log("Opponent's bid is good enough compared to my maximum aspiration, ACCEPTED.");
      this.opponentBids.add(opponentBid);
      this.opponentPreviousBid = opponentBid;
    }
    else
    {
      Bid plannedBid = proposeNextBid(opponentBid);
      if (plannedBid == null) {
        chosenAction = ActionCreator.createEndNegotiation(this);
      } else {
        chosenAction = ActionCreator.createOffer(this, plannedBid);
      }
      if (opponentBid == null) {
        logError("opponentBid is null");
      }
      if (plannedBid == null) {
        logError("plannedBid is null");
      }
      if (this.utilitySpace.getUtility(opponentBid) * this.acceptMultiplier >= this.utilitySpace.getUtility(plannedBid))
      {
        chosenAction = ActionCreator.createAccept(this);
        log("Opponent's bid is good enough compared to my planned bid, ACCEPTED");
      }
      this.opponentBids.add(opponentBid);
      this.opponentPreviousBid = opponentBid;
    }
    return chosenAction;
  }
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastBid = null;
    this.myLastAction = null;
    
    log(this.utilitySpace.toString());
    
    this.myPreviousBids = new ArrayList();
    this.opponentBids = new ArrayList();
    this.opponentIsHardHead = true;
  }
  
  public final void log(String message)
  {
    if (this.debug) {
      System.out.println(message);
    }
  }
  
  public final void logError(String message)
  {
    if (this.debug) {
      System.err.println(message);
    }
  }
  
  public final void flushLog()
  {
    if (this.debug) {
      System.out.flush();
    }
  }
  
  public final void log(Matrix matrix)
  {
    if (this.debug) {
      matrix.print(7, 4);
    }
  }
  
  protected abstract Bid proposeInitialBid()
    throws Exception;
  
  protected abstract Bid proposeNextBid(Bid paramBid)
    throws Exception;
  
  public final void ReceiveMessage(Action opponentAction, long ourTime, long opponentTime)
  {
    setOurTime(ourTime);
    setOpponentTime(opponentTime);
    ReceiveMessage(opponentAction, true);
  }
  
  public final void ReceiveMessage(Action opponentAction)
  {
    ReceiveMessage(opponentAction, true);
  }
  
  private final void ReceiveMessage(Action opponentAction, boolean recordTimes)
  {
    if (opponentAction == null)
    {
      log("Received (null) from opponent.");
    }
    else
    {
      log("--------------------------------------------------------------------------------");
      log("Received " + opponentAction.toString() + " from opponent.");
      if ((opponentAction instanceof Offer))
      {
        OfferReceived((Offer)opponentAction);
        try
        {
          log("It has a utility of " + this.utilitySpace.getUtility(((Offer)opponentAction).getBid()));
          if ((this.opponentIsHardHead) && (this.opponentBids.size() > 0) && (Math.abs(this.utilitySpace.getUtility((Bid)this.opponentBids.get(0)) - this.utilitySpace.getUtility(((Offer)opponentAction).getBid())) > 0.02D))
          {
            log("Opponent of " + getName() + " no longer considered to be hardheaded");
            
            this.opponentIsHardHead = false;
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
    this.messageOpponent = opponentAction;
  }
  
  public void OfferReceived(Offer opponentAction) {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.agents2011.SouthamptonAgent
 * JD-Core Version:    0.7.1
 */