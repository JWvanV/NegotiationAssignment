package agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils;

import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public abstract interface BidCreator
{
  public abstract Bid getBid(UtilitySpace paramUtilitySpace, double paramDouble1, double paramDouble2);
  
  public abstract Bid logBid(Bid paramBid, double paramDouble);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils.BidCreator
 * JD-Core Version:    0.7.1
 */