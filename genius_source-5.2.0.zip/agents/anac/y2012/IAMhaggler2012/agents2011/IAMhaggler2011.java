package agents.anac.y2012.IAMhaggler2012.agents2011;

import Jama.Matrix;
import agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils.BidCreator;
import agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils.Pair;
import agents.anac.y2012.IAMhaggler2012.agents2011.southampton.utils.RandomBidCreator;
import java.io.PrintStream;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
import uk.ac.soton.ecs.gp4j.bmc.BasicPrior;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessMixture;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessMixturePrediction;
import uk.ac.soton.ecs.gp4j.bmc.GaussianProcessRegressionBMC;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.CovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.Matern3CovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.NoiseCovarianceFunction;
import uk.ac.soton.ecs.gp4j.gp.covariancefunctions.SumCovarianceFunction;

public class IAMhaggler2011
  extends SouthamptonAgent
{
  protected double RISK_PARAMETER = 1.0D;
  private Matrix utilitySamples;
  private Matrix timeSamples;
  private Matrix utility;
  private GaussianProcessRegressionBMC regression;
  private double lastRegressionTime = 0.0D;
  private double lastRegressionUtility = 1.0D;
  private ArrayList<Double> opponentTimes = new ArrayList();
  private ArrayList<Double> opponentUtilities = new ArrayList();
  private double maxUtilityInTimeSlot;
  private int lastTimeSlot = -1;
  private Matrix means;
  private Matrix variances;
  private double maxUtility;
  private Bid bestReceivedBid;
  private double previousTargetUtility;
  protected BidCreator bidCreator;
  private double intercept;
  private Matrix matrixTimeSamplesAdjust;
  private double maxOfferedUtility = Double.MIN_NORMAL;
  private double minOfferedUtility = Double.MAX_VALUE;
  
  public IAMhaggler2011()
  {
    this.debug = true;
  }
  
  public void init()
  {
    log("Run init...");
    try
    {
      super.init();
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    double discountingFactor = 0.5D;
    try
    {
      discountingFactor = adjustDiscountFactor(this.utilitySpace
        .getDiscountFactor());
    }
    catch (Exception ex)
    {
      logError("Unable to get discounting factor, assuming 0.5");
      ex.printStackTrace();
    }
    if (discountingFactor == 0.0D) {
      discountingFactor = 1.0D;
    }
    log("Discounting factor is " + discountingFactor);
    makeUtilitySamples(100);
    makeTimeSamples(100);
    Matrix discounting = generateDiscountingFunction(discountingFactor);
    Matrix risk = generateRiskFunction(this.RISK_PARAMETER);
    this.utility = risk.arrayTimes(discounting);
    
    log(this.utility);
    
    log("Setting up GP");
    flushLog();
    
    BasicPrior[] bps = { new BasicPrior(11, 0.252D, 0.5D), new BasicPrior(11, 0.166D, 0.5D), new BasicPrior(1, 0.01D, 1.0D) };
    


    CovarianceFunction cf = new SumCovarianceFunction(new CovarianceFunction[] {Matern3CovarianceFunction.getInstance(), NoiseCovarianceFunction.getInstance() });
    
    this.regression = new GaussianProcessRegressionBMC();
    this.regression.setCovarianceFunction(cf);
    this.regression.setPriors(bps);
    


    this.maxUtility = 0.0D;
    this.previousTargetUtility = 1.0D;
    
    this.bidCreator = new RandomBidCreator();
    
    log("init complete.");
    flushLog();
  }
  
  public String getName()
  {
    return "IAMhaggler2012";
  }
  
  private void makeUtilitySamples(int m)
  {
    double[] utilitySamplesArray = new double[m];
    for (int i = 0; i < utilitySamplesArray.length; i++) {
      utilitySamplesArray[i] = (1.0D - (i + 0.5D) / (m + 1.0D));
    }
    this.utilitySamples = new Matrix(utilitySamplesArray, utilitySamplesArray.length);
  }
  
  private void makeTimeSamples(int n)
  {
    double[] timeSamplesArray = new double[n + 1];
    for (int i = 0; i < timeSamplesArray.length; i++) {
      timeSamplesArray[i] = (i / n);
    }
    this.timeSamples = new Matrix(timeSamplesArray, 1);
  }
  
  protected Bid proposeInitialBid()
    throws Exception
  {
    return this.utilitySpace.getMaxUtilityBid();
  }
  
  protected Bid proposeNextBid(Bid opponentBid)
    throws Exception
  {
    double opponentUtility = this.utilitySpace.getUtility(opponentBid);
    if (opponentUtility > this.maxUtility)
    {
      this.bestReceivedBid = opponentBid;
      this.maxUtility = opponentUtility;
    }
    log("Opponent utility is " + opponentUtility);
    
    double targetUtility = getTarget(opponentUtility, getTime());
    
    log("Target utility is " + targetUtility);
    if ((targetUtility <= this.maxUtility) && (this.previousTargetUtility > this.maxUtility)) {
      return this.bestReceivedBid;
    }
    this.previousTargetUtility = targetUtility;
    
    flushLog();
    

    return this.bidCreator.getBid(this.utilitySpace, targetUtility - 0.025D, targetUtility + 0.025D);
  }
  
  protected double getTarget(double opponentUtility, double time)
  {
    log("++>>> IAMhaggler 2011 <<<++");
    
    log("getTarget: " + opponentUtility);
    
    this.maxOfferedUtility = Math.max(this.maxOfferedUtility, opponentUtility);
    this.minOfferedUtility = Math.min(this.minOfferedUtility, opponentUtility);
    

    int timeSlot = (int)Math.floor(time * 36.0D);
    
    boolean regressionUpdateRequired = false;
    if (this.lastTimeSlot == -1) {
      regressionUpdateRequired = true;
    }
    if (timeSlot != this.lastTimeSlot)
    {
      if (this.lastTimeSlot != -1)
      {
        this.opponentTimes.add(Double.valueOf((this.lastTimeSlot + 0.5D) / 36.0D));
        if (this.opponentUtilities.size() == 0)
        {
          this.intercept = Math.max(0.5D, this.maxUtilityInTimeSlot);
          double[] timeSamplesAdjust = new double[this.timeSamples.getColumnDimension()];
          int i = 0;
          double gradient = 0.9D - this.intercept;
          for (double d : this.timeSamples.getRowPackedCopy()) {
            timeSamplesAdjust[(i++)] = (this.intercept + gradient * d);
          }
          this.matrixTimeSamplesAdjust = new Matrix(timeSamplesAdjust, timeSamplesAdjust.length);
        }
        this.opponentUtilities.add(Double.valueOf(this.maxUtilityInTimeSlot));
        
        regressionUpdateRequired = true;
      }
      this.lastTimeSlot = timeSlot;
      
      this.maxUtilityInTimeSlot = 0.0D;
    }
    log("intercept: " + this.intercept);
    

    this.maxUtilityInTimeSlot = Math.max(this.maxUtilityInTimeSlot, opponentUtility);
    if (timeSlot == 0) {
      return 1.0D - time / 2.0D;
    }
    if (regressionUpdateRequired)
    {
      double gradient = 0.9D - this.intercept;
      GaussianProcessMixture predictor;
      GaussianProcessMixture predictor;
      if (this.lastTimeSlot == -1)
      {
        predictor = this.regression.calculateRegression(new double[0], new double[0]);
      }
      else
      {
        double x;
        double y;
        try
        {
          x = ((Double)this.opponentTimes.get(this.opponentTimes.size() - 1)).doubleValue();
          y = ((Double)this.opponentUtilities.get(this.opponentUtilities.size() - 1)).doubleValue();
        }
        catch (Exception ex)
        {
          System.err.println("Error getting x or y. Aiming for previous target utility of " + this.previousTargetUtility);
          return this.previousTargetUtility;
        }
        predictor = this.regression.updateRegression(new Matrix(new double[] { x }, 1), new Matrix(new double[] { y - this.intercept - gradient * x }, 1));
      }
      GaussianProcessMixturePrediction prediction = predictor.calculatePrediction(this.timeSamples.transpose());
      

      this.means = prediction.getMean().plus(this.matrixTimeSamplesAdjust);
      this.variances = prediction.getVariance();
      
      log(this.means.transpose());
      log(this.variances.transpose());
    }
    Pair<Matrix, Matrix> acceptMatrices = generateProbabilityAccept(this.means, this.variances, time);
    
    Matrix probabilityAccept = (Matrix)acceptMatrices.fst;
    Matrix cumulativeAccept = (Matrix)acceptMatrices.snd;
    
    Matrix probabilityExpectedUtility = probabilityAccept.arrayTimes(this.utility);
    Matrix cumulativeExpectedUtility = cumulativeAccept.arrayTimes(this.utility);
    if (regressionUpdateRequired)
    {
      log(probabilityAccept);
      log(cumulativeAccept);
      log(probabilityExpectedUtility);
      log(cumulativeExpectedUtility);
    }
    Object bestAgreement = getExpectedBestAgreement(probabilityExpectedUtility, cumulativeExpectedUtility, time);
    
    double bestTime = ((Double)((Pair)bestAgreement).fst).doubleValue();
    double bestUtility = ((Double)((Pair)bestAgreement).snd).doubleValue();
    
    double targetUtility = this.lastRegressionUtility + (time - this.lastRegressionTime) * (bestUtility - this.lastRegressionUtility) / (bestTime - this.lastRegressionTime);
    


    log(time + "," + bestTime + "," + bestUtility + "," + this.lastRegressionTime + "," + this.lastRegressionUtility + "," + targetUtility);
    

    this.lastRegressionUtility = targetUtility;
    this.lastRegressionTime = time;
    
    log("-->>> IAMhaggler 2011 <<<--");
    
    return limitConcession(targetUtility);
  }
  
  private double limitConcession(double targetUtility)
  {
    double limit = 1.0D - (this.maxOfferedUtility - this.minOfferedUtility + 0.1D);
    if (limit > targetUtility)
    {
      log("Limiting concession to " + limit);
      return limit;
    }
    return targetUtility;
  }
  
  private Matrix generateDiscountingFunction(double discountingFactor)
  {
    double[] discountingSamples = this.timeSamples.getRowPackedCopy();
    
    double[][] m = new double[this.utilitySamples.getRowDimension()][this.timeSamples.getColumnDimension()];
    for (int i = 0; i < m.length; i++) {
      for (int j = 0; j < m[i].length; j++) {
        m[i][j] = Math.pow(discountingFactor, discountingSamples[j]);
      }
    }
    return new Matrix(m);
  }
  
  private Pair<Matrix, Matrix> generateProbabilityAccept(Matrix mean, Matrix variance, double time)
  {
    for (int i = 0; i < this.timeSamples.getColumnDimension(); i++) {
      if (this.timeSamples.get(0, i) > time) {
        break;
      }
    }
    Matrix cumulativeAccept = new Matrix(this.utilitySamples.getRowDimension(), this.timeSamples.getColumnDimension(), 0.0D);
    
    Matrix probabilityAccept = new Matrix(this.utilitySamples.getRowDimension(), this.timeSamples.getColumnDimension(), 0.0D);
    
    double interval = 1.0D / this.utilitySamples.getRowDimension();
    for (; i < this.timeSamples.getColumnDimension(); i++)
    {
      double s = Math.sqrt(2.0D * variance.get(i, 0));
      double m = mean.get(i, 0);
      
      double minp = 1.0D - 0.5D * (1.0D + erf((this.utilitySamples.get(0, 0) + interval / 2.0D - m) / s));
      
      double maxp = 1.0D - 0.5D * (1.0D + erf((this.utilitySamples.get(this.utilitySamples.getRowDimension() - 1, 0) - interval / 2.0D - m) / s));
      for (int j = 0; j < this.utilitySamples.getRowDimension(); j++)
      {
        double utility = this.utilitySamples.get(j, 0);
        double p = 1.0D - 0.5D * (1.0D + erf((utility - m) / s));
        
        double p1 = 1.0D - 0.5D * (1.0D + erf((utility - interval / 2.0D - m) / s));
        
        double p2 = 1.0D - 0.5D * (1.0D + erf((utility + interval / 2.0D - m) / s));
        

        cumulativeAccept.set(j, i, (p - minp) / (maxp - minp));
        probabilityAccept.set(j, i, (p1 - p2) / (maxp - minp));
      }
    }
    return new Pair(probabilityAccept, cumulativeAccept);
  }
  
  private double erf(double x)
  {
    if (x > 6.0D) {
      return 1.0D;
    }
    if (x < -6.0D) {
      return -1.0D;
    }
    try
    {
      double d = Erf.erf(x);
      if (d > 1.0D) {
        return 1.0D;
      }
      if (d < -1.0D) {
        return -1.0D;
      }
      return d;
    }
    catch (MaxIterationsExceededException e)
    {
      if (x > 0.0D) {
        return 1.0D;
      }
      return -1.0D;
    }
    catch (MathException e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  protected Matrix generateRiskFunction(double riskParameter)
  {
    double mmin = generateRiskFunction(riskParameter, 0.0D);
    double mmax = generateRiskFunction(riskParameter, 1.0D);
    double range = mmax - mmin;
    
    double[] riskSamples = this.utilitySamples.getColumnPackedCopy();
    
    double[][] m = new double[this.utilitySamples.getRowDimension()][this.timeSamples.getColumnDimension()];
    for (int i = 0; i < m.length; i++)
    {
      double val;
      double val;
      if (range == 0.0D) {
        val = riskSamples[i];
      } else {
        val = (generateRiskFunction(riskParameter, riskSamples[i]) - mmin) / range;
      }
      for (int j = 0; j < m[i].length; j++) {
        m[i][j] = val;
      }
    }
    return new Matrix(m);
  }
  
  protected double generateRiskFunction(double riskParameter, double utility)
  {
    return Math.pow(utility, riskParameter);
  }
  
  private Pair<Double, Double> getExpectedBestAgreement(Matrix probabilityExpectedValues, Matrix cumulativeExpectedValues, double time)
  {
    log("probabilityExpectedValues is " + probabilityExpectedValues.getRowDimension() + "x" + probabilityExpectedValues.getColumnDimension());
    log("time is " + time);
    Matrix probabilityFutureExpectedValues = getFutureExpectedValues(probabilityExpectedValues, time);
    Matrix cumulativeFutureExpectedValues = getFutureExpectedValues(cumulativeExpectedValues, time);
    
    log("probabilityFutureExpectedValues is " + probabilityFutureExpectedValues.getRowDimension() + "x" + probabilityFutureExpectedValues.getColumnDimension());
    
    double[][] probabilityFutureExpectedValuesArray = probabilityFutureExpectedValues.getArray();
    double[][] cumulativeFutureExpectedValuesArray = cumulativeFutureExpectedValues.getArray();
    
    Double bestX = null;
    Double bestY = null;
    
    double[] colSums = new double[probabilityFutureExpectedValuesArray[0].length];
    double bestColSum = 0.0D;
    int bestCol = 0;
    for (int x = 0; x < probabilityFutureExpectedValuesArray[0].length; x++)
    {
      colSums[x] = 0.0D;
      for (int y = 0; y < probabilityFutureExpectedValuesArray.length; y++) {
        colSums[x] += probabilityFutureExpectedValuesArray[y][x];
      }
      if (colSums[x] >= bestColSum)
      {
        bestColSum = colSums[x];
        bestCol = x;
      }
    }
    log(new Matrix(colSums, 1));
    
    int bestRow = 0;
    double bestRowValue = 0.0D;
    for (int y = 0; y < cumulativeFutureExpectedValuesArray.length; y++)
    {
      double expectedValue = cumulativeFutureExpectedValuesArray[y][bestCol];
      if (expectedValue > bestRowValue)
      {
        bestRowValue = expectedValue;
        bestRow = y;
      }
    }
    bestX = Double.valueOf(this.timeSamples.get(0, bestCol + probabilityExpectedValues
      .getColumnDimension() - probabilityFutureExpectedValues
      .getColumnDimension()));
    bestY = Double.valueOf(this.utilitySamples.get(bestRow, 0));
    
    log("About to return the best agreement at " + bestX + ", " + bestY);
    return new Pair(bestX, bestY);
  }
  
  private Matrix getFutureExpectedValues(Matrix expectedValues, double time)
  {
    for (int i = 0; i < this.timeSamples.getColumnDimension(); i++) {
      if (this.timeSamples.get(0, i) > time) {
        break;
      }
    }
    return expectedValues.getMatrix(0, expectedValues
      .getRowDimension() - 1, i, expectedValues
      .getColumnDimension() - 1);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.IAMhaggler2012.agents2011.IAMhaggler2011
 * JD-Core Version:    0.7.1
 */