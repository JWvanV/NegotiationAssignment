package agents.anac.y2012.AgentLG;

import java.util.ArrayList;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class AgentLG
  extends Agent
{
  private Bid myLastBid = null;
  private Bid oponnetLastBid = null;
  private BidChooser bidChooser = null;
  private OpponentBids oppenentsBid;
  private boolean bidLast = false;
  
  public Action chooseAction()
  {
    Action currentAction = null;
    try
    {
      double time = this.timeline.getTime();
      if ((this.myLastBid == null) || (this.oponnetLastBid == null))
      {
        this.myLastBid = this.utilitySpace.getMaxUtilityBid();
        currentAction = new Offer(getAgentID(), this.myLastBid);
      }
      else
      {
        double opponentUtility = this.utilitySpace.getUtilityWithDiscount(this.oponnetLastBid, time);
        
        double myUtility = this.utilitySpace.getUtilityWithDiscount(this.myLastBid, time);
        if ((opponentUtility >= myUtility * 0.99D) || ((time > 0.999D) && (opponentUtility >= myUtility * 0.9D)) || (this.bidChooser.getMyBidsMinUtility(time) <= opponentUtility))
        {
          currentAction = new Accept(getAgentID());
        }
        else if (this.bidLast)
        {
          currentAction = new Offer(getAgentID(), this.myLastBid);
        }
        else if (time < 0.6D)
        {
          currentAction = this.bidChooser.getNextOptimicalBid(time);
        }
        else if (time >= 0.9995000000000001D)
        {
          this.myLastBid = this.oppenentsBid.getMaxUtilityBidForMe();
          if (this.utilitySpace.getUtilityWithDiscount(this.myLastBid, time) < this.utilitySpace.getReservationValueWithDiscount(time)) {
            this.myLastBid = this.bidChooser.getMyminBidfromBids();
          }
          currentAction = new Offer(getAgentID(), this.myLastBid);
        }
        else
        {
          currentAction = this.bidChooser.getNextBid(time);
        }
      }
      if ((currentAction instanceof Offer))
      {
        this.myLastBid = ((Offer)currentAction).getBid();
        if (this.oppenentsBid.getOpponentsBids().contains(this.myLastBid)) {
          this.bidLast = true;
        }
      }
    }
    catch (Exception e)
    {
      currentAction = new Accept(getAgentID());
    }
    return currentAction;
  }
  
  public String getName()
  {
    return "AgentLG";
  }
  
  public void init()
  {
    this.oppenentsBid = new OpponentBids(this.utilitySpace);
    this.bidChooser = new BidChooser(this.utilitySpace, getAgentID(), this.oppenentsBid);
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    if ((opponentAction instanceof Offer))
    {
      this.oponnetLastBid = ((Offer)opponentAction).getBid();
      try
      {
        this.oppenentsBid.addBid(((Offer)opponentAction).getBid());
        this.oppenentsBid.getOpponentBidUtility(this.utilitySpace.getDomain(), this.oponnetLastBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  public String getVersion()
  {
    return "1.1";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.AgentLG.AgentLG
 * JD-Core Version:    0.7.1
 */