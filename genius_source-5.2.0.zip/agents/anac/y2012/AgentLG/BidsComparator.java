package agents.anac.y2012.AgentLG;

import java.util.Comparator;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class BidsComparator
  implements Comparator<Bid>
{
  private UtilitySpace utilitySpace;
  
  public BidsComparator(UtilitySpace utilitySpace)
  {
    this.utilitySpace = utilitySpace;
  }
  
  public int compare(Bid arg0, Bid arg1)
  {
    try
    {
      if (this.utilitySpace.getUtility(arg0) < this.utilitySpace.getUtility(arg1)) {
        return 1;
      }
      if (this.utilitySpace.getUtility(arg0) == this.utilitySpace.getUtility(arg1)) {
        return 0;
      }
    }
    catch (Exception e) {}
    return -1;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2012.AgentLG.BidsComparator
 * JD-Core Version:    0.7.1
 */