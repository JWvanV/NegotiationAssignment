package agents.anac.y2010.AgentK;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class Agent_K
  extends Agent
{
  private Action partner = null;
  private HashMap<Bid, Double> offeredBidMap;
  private double target;
  private double bidTarget;
  private double sum;
  private double sum2;
  private int rounds;
  private double tremor;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  private Random random200;
  private Random random300;
  private Random random400;
  
  public void init()
  {
    this.offeredBidMap = new HashMap();
    this.target = 1.0D;
    this.bidTarget = 1.0D;
    this.sum = 0.0D;
    this.sum2 = 0.0D;
    this.rounds = 0;
    this.tremor = 2.0D;
    






    this.random100 = new Random();
    this.random200 = new Random();
    this.random300 = new Random();
    this.random400 = new Random();
  }
  
  public String getVersion()
  {
    return "0.314";
  }
  
  public String getName()
  {
    return "Agent_K";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.partner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.partner == null) {
        action = selectBid();
      }
      if ((this.partner instanceof Offer))
      {
        Bid offeredBid = ((Offer)this.partner).getBid();
        
        double p = acceptProbability(offeredBid);
        if (p > this.random100.nextDouble()) {
          action = new Accept(getAgentID());
        } else {
          action = selectBid();
        }
      }
    }
    catch (Exception e)
    {
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private Action selectBid()
  {
    Bid nextBid = null;
    
    ArrayList<Bid> bidTemp = new ArrayList();
    for (Bid bid : this.offeredBidMap.keySet()) {
      if (((Double)this.offeredBidMap.get(bid)).doubleValue() > this.target) {
        bidTemp.add(bid);
      }
    }
    int size = bidTemp.size();
    if (size > 0)
    {
      int sindex = (int)Math.floor(this.random200.nextDouble() * size);
      nextBid = (Bid)bidTemp.get(sindex);
    }
    else
    {
      double searchUtil = 0.0D;
      try
      {
        int loop = 0;
        while (searchUtil < this.bidTarget)
        {
          if (loop > 500)
          {
            this.bidTarget -= 0.01D;
            loop = 0;
          }
          nextBid = searchBid();
          searchUtil = this.utilitySpace.getUtility(nextBid);
          loop++;
        }
      }
      catch (Exception e) {}
    }
    if (nextBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  private Bid searchBid()
    throws Exception
  {
    HashMap<Integer, Value> values = new HashMap();
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    
    Bid bid = null;
    for (Issue lIssue : issues) {
      switch (lIssue.getType())
      {
      case DISCRETE: 
        IssueDiscrete lIssueDiscrete = (IssueDiscrete)lIssue;
        int optionIndex = this.random300.nextInt(lIssueDiscrete.getNumberOfValues());
        
        values.put(Integer.valueOf(lIssue.getNumber()), lIssueDiscrete.getValue(optionIndex));
        
        break;
      case REAL: 
        IssueReal lIssueReal = (IssueReal)lIssue;
        int optionInd = this.random300.nextInt(lIssueReal.getNumberOfDiscretizationSteps() - 1);
        
        values.put(Integer.valueOf(lIssueReal.getNumber()), new ValueReal(lIssueReal.getLowerBound() + (lIssueReal.getUpperBound() - lIssueReal.getLowerBound()) * optionInd / lIssueReal.getNumberOfDiscretizationSteps()));
        






        break;
      case INTEGER: 
        IssueInteger lIssueInteger = (IssueInteger)lIssue;
        int optionIndex2 = lIssueInteger.getLowerBound() + this.random300.nextInt(lIssueInteger.getUpperBound() - lIssueInteger.getLowerBound());
        

        values.put(Integer.valueOf(lIssueInteger.getNumber()), new ValueInteger(optionIndex2));
        
        break;
      default: 
        throw new Exception("issue type " + lIssue.getType() + " not supported by SimpleAgent2");
      }
    }
    bid = new Bid(this.utilitySpace.getDomain(), values);
    return bid;
  }
  
  double acceptProbability(Bid offeredBid)
    throws Exception
  {
    double offeredUtility = this.utilitySpace.getUtility(offeredBid);
    this.offeredBidMap.put(offeredBid, Double.valueOf(offeredUtility));
    
    this.sum += offeredUtility;
    this.sum2 += offeredUtility * offeredUtility;
    this.rounds += 1;
    
    double mean = this.sum / this.rounds;
    
    double variance = this.sum2 / this.rounds - mean * mean;
    
    double deviation = Math.sqrt(variance * 12.0D);
    if (Double.isNaN(deviation)) {
      deviation = 0.0D;
    }
    double time = this.timeline.getTime();
    double t = time * time * time;
    if ((offeredUtility < 0.0D) || (offeredUtility > 1.05D)) {
      throw new Exception("utility " + offeredUtility + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (offeredUtility > 1.0D) {
      offeredUtility = 1.0D;
    }
    double estimateMax = mean + (1.0D - mean) * deviation;
    
    double alpha = 1.0D + this.tremor + 10.0D * mean - 2.0D * this.tremor * mean;
    double beta = alpha + this.random400.nextDouble() * this.tremor - this.tremor / 2.0D;
    
    double preTarget = 1.0D - Math.pow(time, alpha) * (1.0D - estimateMax);
    double preTarget2 = 1.0D - Math.pow(time, beta) * (1.0D - estimateMax);
    
    double ratio = (deviation + 0.1D) / (1.0D - preTarget);
    if ((Double.isNaN(ratio)) || (ratio > 2.0D)) {
      ratio = 2.0D;
    }
    double ratio2 = (deviation + 0.1D) / (1.0D - preTarget2);
    if ((Double.isNaN(ratio2)) || (ratio2 > 2.0D)) {
      ratio2 = 2.0D;
    }
    this.target = (ratio * preTarget + 1.0D - ratio);
    this.bidTarget = (ratio2 * preTarget2 + 1.0D - ratio2);
    
    double m = t * -300.0D + 400.0D;
    if (this.target > estimateMax)
    {
      double r = this.target - estimateMax;
      double f = 1.0D / (r * r);
      if ((f > m) || (Double.isNaN(f))) {
        f = m;
      }
      double app = r * f / m;
      this.target -= app;
    }
    else
    {
      this.target = estimateMax;
    }
    if (this.bidTarget > estimateMax)
    {
      double r = this.bidTarget - estimateMax;
      double f = 1.0D / (r * r);
      if ((f > m) || (Double.isNaN(f))) {
        f = m;
      }
      double app = r * f / m;
      this.bidTarget -= app;
    }
    else
    {
      this.bidTarget = estimateMax;
    }
    double utilityEvaluation = offeredUtility - estimateMax;
    double satisfy = offeredUtility - this.target;
    
    double p = Math.pow(time, alpha) / 5.0D + utilityEvaluation + satisfy;
    if (p < 0.1D) {
      p = 0.0D;
    }
    return p;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentK.Agent_K
 * JD-Core Version:    0.7.1
 */