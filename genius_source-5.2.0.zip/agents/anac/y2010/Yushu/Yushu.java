package agents.anac.y2010.Yushu;

import java.util.Date;
import java.util.LinkedList;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.bidding.BidDetails;
import negotiator.utility.UtilitySpace;

public class Yushu
  extends Agent
{
  private double eagerness = 1.2D;
  private Action actionOfOpponent = null;
  private Bid myLastBid = null;
  private LinkedList<Bid> opponentHistory;
  private LinkedList<Double> opponentUtis;
  private LinkedList<Integer> bestTenBids;
  private LinkedList<Bid> myHistory;
  private LinkedList<Double> resptimes;
  Bid suggestBid = null;
  Bid BESTBID = null;
  double topponentBidU = 0.0D;
  double roundleft;
  Date rstime = null;
  double HPOSSIBLEU = 0.0D;
  double ACCEPTABLEU = 1.0D;
  double previousTime = 0.0D;
  Random random100;
  Random random200;
  private final boolean TEST_EQUIVALENCE = false;
  
  public void init()
  {
    this.actionOfOpponent = null;
    this.myLastBid = null;
    this.opponentHistory = new LinkedList();
    this.opponentUtis = new LinkedList();
    this.myHistory = new LinkedList();
    this.resptimes = new LinkedList();
    this.suggestBid = null;
    this.bestTenBids = new LinkedList();
    this.topponentBidU = 0.0D;
    this.rstime = null;
    this.ACCEPTABLEU = 1.0D;
    



    this.random100 = new Random();
    this.random200 = new Random();
    try
    {
      this.BESTBID = this.utilitySpace.getMaxUtilityBid();
      this.HPOSSIBLEU = this.utilitySpace.getUtility(this.BESTBID);
    }
    catch (Exception e)
    {
      this.HPOSSIBLEU = 1.0D;
    }
  }
  
  public String getVersion()
  {
    return "2";
  }
  
  public String getName()
  {
    return "Yushu";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfOpponent = opponentAction;
  }
  
  public Action chooseAction()
  {
    double targetuti = -1.0D;
    this.resptimes.add(Double.valueOf(this.timeline.getTime() - this.previousTime));
    this.previousTime = this.timeline.getTime();
    Action action = null;
    try
    {
      if (this.actionOfOpponent == null)
      {
        Bid initialbid = this.BESTBID;
        action = new Offer(getAgentID(), initialbid);
      }
      else if ((this.actionOfOpponent instanceof Offer))
      {
        Bid opponentBid = ((Offer)this.actionOfOpponent).getBid();
        double utiop = this.utilitySpace.getUtility(opponentBid);
        this.opponentHistory.add(opponentBid);
        this.opponentUtis.add(Double.valueOf(utiop));
        this.topponentBidU += utiop;
        updateBelief(opponentBid, utiop);
        if (this.myLastBid == null) {
          targetuti = 1.0D;
        } else {
          targetuti = getTargetUtility();
        }
        boolean accept = false;
        if (((utiop >= targetuti ? 1 : 0) | (utiop >= this.ACCEPTABLEU ? 1 : 0)) != 0)
        {
          if (this.suggestBid == null) {
            accept = true;
          }
          if (this.roundleft < 8.0D) {
            accept = true;
          }
          if (((this.suggestBid != null ? 1 : 0) & (this.roundleft > 8.0D ? 1 : 0)) != 0)
          {
            double utit = this.utilitySpace.getUtility(this.suggestBid);
            if (utit <= utiop) {
              accept = true;
            }
          }
        }
        if (accept)
        {
          action = new Accept(getAgentID());
        }
        else
        {
          Bid mynextBid;
          Bid mynextBid;
          if (this.suggestBid != null)
          {
            mynextBid = this.suggestBid;
          }
          else
          {
            Bid mynextBid;
            if (targetuti >= this.HPOSSIBLEU) {
              mynextBid = this.utilitySpace.getMaxUtilityBid();
            } else {
              mynextBid = getNextBid(targetuti);
            }
          }
          action = new Offer(getAgentID(), mynextBid);
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      targetuti = getTargetUtility();
      try
      {
        Bid mynextBid = getNextBid(targetuti);
        action = new Offer(getAgentID(), mynextBid);
      }
      catch (Exception es)
      {
        e.printStackTrace();
        action = new Accept(getAgentID());
      }
    }
    if ((action instanceof Offer))
    {
      this.myLastBid = ((Offer)action).getBid();
      this.myHistory.add(this.myLastBid);
    }
    return action;
  }
  
  public double getTargetUtility()
  {
    double tround = Math.max(averResT(), averLastTResT(3));
    
    double lefttime = 1.0D - this.timeline.getTime();
    
    this.roundleft = (lefttime / tround);
    if (this.roundleft > 6.7D) {
      Utility.MINIMUM_BID_UTILITY = 0.9300000000000001D * this.HPOSSIBLEU;
    } else if (this.roundleft > 5.0D) {
      Utility.MINIMUM_BID_UTILITY = 0.9D * this.HPOSSIBLEU;
    } else if (lefttime > 3.0D * tround) {
      Utility.MINIMUM_BID_UTILITY = 0.86D * this.HPOSSIBLEU;
    } else if (lefttime > 2.3D * tround) {
      Utility.MINIMUM_BID_UTILITY = 0.8D * this.HPOSSIBLEU;
    } else {
      Utility.MINIMUM_BID_UTILITY = 0.6D * this.HPOSSIBLEU;
    }
    if (lefttime < 15.0D * tround) {
      this.ACCEPTABLEU = (0.92D * this.HPOSSIBLEU);
    } else {
      this.ACCEPTABLEU = (0.96D * this.HPOSSIBLEU);
    }
    double averopu = 0.0D;double averopui = 0.0D;
    if (this.opponentHistory.size() > 0) {
      averopui = this.topponentBidU / this.opponentHistory.size();
    }
    averopu = Math.max(0.3D, averopui);
    
    double rte = 20.0D + (1.0D - averopu) / 0.1D * 20.0D;
    if (((lefttime < rte * tround ? 1 : 0) & (this.opponentHistory.size() > 3 ? 1 : 0) & (averopu < 0.75D ? 1 : 0)) != 0) {
      Utility.MINIMUM_BID_UTILITY -= (0.75D - averopu) / 2.5D;
    }
    Utility.MINIMUM_BID_UTILITY = Math.max(0.5D, Utility.MINIMUM_BID_UTILITY);
    
    double time = this.timeline.getTime();
    
    Utility.MINIMUM_BID_UTILITY *= (Math.min(0.75D, averopu) / 3.0D + 0.75D);
    
    Utility.MINIMUM_BID_UTILITY = Math.max(Utility.MINIMUM_BID_UTILITY, averopu);
    
    double targetuti = this.HPOSSIBLEU - (this.HPOSSIBLEU - Utility.MINIMUM_BID_UTILITY) * Math.pow(time, this.eagerness);
    if (lefttime < 1.6D * tround)
    {
      this.suggestBid = ((Bid)this.opponentHistory.get(((Integer)this.bestTenBids.getFirst()).intValue()));
      return targetuti;
    }
    if (lefttime > 50.0D * tround) {
      targetuti = Math.max(targetuti, ((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getFirst()).intValue())).doubleValue() * 1.001D);
    }
    if (((lefttime < 10.0D * tround ? 1 : 0) & (((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getFirst()).intValue())).doubleValue() > targetuti * 0.95D ? 1 : 0) | (((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getFirst()).intValue())).doubleValue() >= targetuti ? 1 : 0)) != 0)
    {
      double newtargetuti = targetuti;
      if (((lefttime < 10.0D * tround ? 1 : 0) & (((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getFirst()).intValue())).doubleValue() > targetuti * 0.95D ? 1 : 0)) != 0) {
        newtargetuti = targetuti * 0.95D;
      }
      boolean offered = false;
      int length = Math.min(this.myHistory.size(), 4);
      for (int i = this.myHistory.size() - 1; i >= this.myHistory.size() - length; i--) {
        if (((Bid)this.myHistory.get(i)).equals((Bid)this.opponentHistory.get(((Integer)this.bestTenBids.getFirst()).intValue()))) {
          offered = true;
        }
      }
      if (offered)
      {
        LinkedList<Integer> candidates = new LinkedList();
        for (int i = 0; i < this.bestTenBids.size(); i++) {
          if (((Double)this.opponentUtis.get(((Integer)this.bestTenBids.get(i)).intValue())).doubleValue() >= newtargetuti) {
            candidates.add(this.bestTenBids.get(i));
          }
        }
        int indexc = (int)(this.random100.nextDouble() * candidates.size());
        this.suggestBid = ((Bid)this.opponentHistory.get(((Integer)candidates.get(indexc)).intValue()));
      }
      else
      {
        this.suggestBid = ((Bid)this.opponentHistory.get(((Integer)this.bestTenBids.getFirst()).intValue()));
      }
      targetuti = newtargetuti;
    }
    return targetuti;
  }
  
  private Bid getNextBid(double targetuti)
    throws Exception
  {
    Bid nextBid = null;
    double maxdiff = Double.MAX_VALUE;
    double tempmaxdiff = Double.MAX_VALUE;
    
    LinkedList<BidDetails> candidates = new LinkedList();
    BidIterator bidsIter = new BidIterator(this.utilitySpace.getDomain());
    while (bidsIter.hasNext())
    {
      Bid tmpBid = bidsIter.next();
      double utitemp = this.utilitySpace.getUtility(tmpBid);
      double vlowbound;
      double vlowbound;
      if (this.roundleft > 30.0D) {
        vlowbound = Math.max(((Double)this.opponentUtis.get(((Integer)this.bestTenBids.get(0)).intValue())).doubleValue(), targetuti);
      } else {
        vlowbound = 0.96D * targetuti;
      }
      if (((utitemp > vlowbound ? 1 : 0) & (utitemp < 1.08D * targetuti ? 1 : 0)) != 0) {
        candidates.add(new BidDetails(tmpBid, this.utilitySpace.getUtility(tmpBid), this.timeline.getTime()));
      }
      double currentdiff = Math.abs(utitemp - targetuti);
      if (currentdiff < tempmaxdiff) {
        tempmaxdiff = currentdiff;
      }
      if (((currentdiff < maxdiff ? 1 : 0) & (utitemp > targetuti ? 1 : 0)) != 0)
      {
        maxdiff = currentdiff;
        nextBid = tmpBid;
      }
    }
    if (this.myHistory.size() > 10)
    {
      candidates.add(new BidDetails(nextBid, this.utilitySpace.getUtility(nextBid), this.timeline.getTime()));
      




      int indexc = (int)(this.random200.nextDouble() * candidates.size());
      nextBid = ((BidDetails)candidates.get(indexc)).getBid();
    }
    return nextBid;
  }
  
  public void updateBelief(Bid opponentBid, double uti)
  {
    int index = this.opponentHistory.size() - 1;
    if (this.bestTenBids.size() == 0)
    {
      this.bestTenBids.add(Integer.valueOf(index));
    }
    else
    {
      LinkedList<Integer> newlist = new LinkedList();
      if (uti > ((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getFirst()).intValue())).doubleValue())
      {
        newlist.add(Integer.valueOf(index));
        for (int j = 0; j < this.bestTenBids.size(); j++) {
          newlist.add(this.bestTenBids.get(j));
        }
        this.bestTenBids = newlist;
      }
      else if (uti <= ((Double)this.opponentUtis.get(((Integer)this.bestTenBids.getLast()).intValue())).doubleValue())
      {
        this.bestTenBids.add(Integer.valueOf(index));
      }
      else
      {
        for (int i = 1; i < this.bestTenBids.size(); i++) {
          if (((uti <= ((Double)this.opponentUtis.get(((Integer)this.bestTenBids.get(i - 1)).intValue())).doubleValue() ? 1 : 0) & (uti > ((Double)this.opponentUtis.get(((Integer)this.bestTenBids.get(i)).intValue())).doubleValue() ? 1 : 0)) != 0)
          {
            for (int j = 0; j < i; j++) {
              newlist.add(this.bestTenBids.get(j));
            }
            newlist.add(Integer.valueOf(index));
            for (int j = i; j < this.bestTenBids.size(); j++) {
              newlist.add(this.bestTenBids.get(j));
            }
            break;
          }
        }
        this.bestTenBids = newlist;
      }
    }
    if (this.bestTenBids.size() > 10) {
      this.bestTenBids.removeLast();
    }
  }
  
  public double averResT()
  {
    if (this.resptimes.size() == 0) {
      return 0.0D;
    }
    double total = 0.0D;
    for (int i = 0; i < this.resptimes.size(); i++) {
      total += ((Double)this.resptimes.get(i)).doubleValue();
    }
    return total / this.resptimes.size();
  }
  
  public double averLastTResT(int length)
  {
    if (this.resptimes.size() < length) {
      return 0.0D;
    }
    double total = 0.0D;
    for (int i = this.resptimes.size() - 1; i > this.resptimes.size() - length - 1; i--) {
      total += ((Double)this.resptimes.get(i)).doubleValue();
    }
    return total / length;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Yushu.Yushu
 * JD-Core Version:    0.7.1
 */