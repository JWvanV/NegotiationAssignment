package agents.anac.y2010.Nozomi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashMap<Ljava.lang.Integer;Lnegotiator.issue.Value;>;
import java.util.Iterator;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.ISSUETYPE;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class Nozomi
  extends Agent
{
  private Bid maxUtilityBid;
  private double maxUtility;
  private Bid prevBid;
  private Bid restoreBid;
  private double minGap;
  private Action actionOfPartner;
  private Bid prevPartnerBid;
  private Bid maxUtilityPartnerBid;
  private double maxUtilityOfPartnerBid;
  private double maxCompromiseUtility;
  private boolean compromise;
  private boolean updateMaxPartnerUtility;
  private int continuousCompromiseBid;
  private int continuousPartnerCompromiseBid;
  private int continuousKeep;
  private int measureT;
  private int bidNumber;
  private double prevAverageUtility;
  private double averageUtility;
  private double averagePartnerUtility;
  private double prevAveragePartnerUtility;
  private static double COMPROMISE_PROBABILITY = 0.7D;
  private static double KEEP_PROBABILITY = 0.15D;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  private Random random200;
  
  public Nozomi()
  {
    this.maxUtilityBid = null;
    this.maxUtility = 0.0D;
    this.prevBid = null;
    this.restoreBid = null;
    this.minGap = 0.0D;
    this.actionOfPartner = null;
    this.prevPartnerBid = null;
    this.maxUtilityPartnerBid = null;
    this.maxUtilityOfPartnerBid = 0.0D;
    this.maxCompromiseUtility = 1.0D;
    this.compromise = false;
    this.updateMaxPartnerUtility = false;
    this.continuousCompromiseBid = 0;
    this.continuousPartnerCompromiseBid = 0;
    this.continuousKeep = 0;
    this.measureT = 1;
    this.bidNumber = 0;
    this.prevAverageUtility = 0.0D;
    this.averageUtility = 0.0D;
    this.averagePartnerUtility = 0.0D;
    this.prevAveragePartnerUtility = 0.0D;
    

    this.TEST_EQUIVALENCE = false;
  }
  
  private static enum BidType
  {
    COMPROMISE,  KEEP,  APPROACH,  RESTORE,  RANDOM;
    
    private BidType() {}
  }
  
  public void init()
  {
    try
    {
      this.maxUtilityBid = this.utilitySpace.getMaxUtilityBid();
      this.maxUtility = this.utilitySpace.getUtility(this.maxUtilityBid);
      this.prevAverageUtility = this.maxUtility;
      this.maxCompromiseUtility = (this.maxUtility * 0.95D);
      this.restoreBid = this.maxUtilityBid;
      this.minGap = this.utilitySpace.getDomain().getIssues().size();
      




      this.random100 = new Random();
      this.random200 = new Random();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public String getName()
  {
    return "Nozomi";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null)
      {
        action = new Offer(getAgentID(), this.maxUtilityBid);
        this.prevBid = this.maxUtilityBid;
      }
      else if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        if (isAccept(partnerBid)) {
          action = new Accept(getAgentID());
        } else {
          action = chooseBidAction(partnerBid);
        }
        this.prevPartnerBid = partnerBid;
      }
    }
    catch (Exception e)
    {
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private Action chooseBidAction(Bid partnerBid)
  {
    Action action = null;
    try
    {
      if (this.prevPartnerBid == null)
      {
        this.maxUtilityPartnerBid = partnerBid;
        this.maxUtilityOfPartnerBid = this.utilitySpace.getUtility(partnerBid);
        action = new Offer(getAgentID(), this.maxUtilityBid);
        
        this.prevBid = this.maxUtilityBid;
      }
      else
      {
        this.bidNumber += 1;
        
        double prevPartnerUtility = this.utilitySpace.getUtility(this.prevPartnerBid);
        double partnerUtility = this.utilitySpace.getUtility(partnerBid);
        
        this.averagePartnerUtility += partnerUtility;
        if (partnerUtility < prevPartnerUtility)
        {
          if (this.continuousPartnerCompromiseBid < 0) {
            this.continuousPartnerCompromiseBid = 0;
          }
          this.continuousPartnerCompromiseBid += 1;
        }
        else if (partnerUtility > prevPartnerUtility)
        {
          if (this.continuousPartnerCompromiseBid > 0) {
            this.continuousPartnerCompromiseBid = 0;
          }
          this.continuousPartnerCompromiseBid -= 1;
        }
        else
        {
          this.continuousPartnerCompromiseBid = 0;
        }
        double time = this.timeline.getTime() * 100.0D;
        if (this.maxUtilityOfPartnerBid > this.maxCompromiseUtility) {
          this.maxCompromiseUtility = this.maxUtilityOfPartnerBid;
        }
        if ((time > 90.0D) && (this.maxCompromiseUtility - this.maxUtilityOfPartnerBid < 0.1D)) {
          this.maxCompromiseUtility = ((this.maxCompromiseUtility * 7.0D + this.maxUtilityOfPartnerBid * 3.0D) / 10.0D);
        }
        if (this.maxCompromiseUtility > this.maxUtility * 0.95D) {
          this.maxCompromiseUtility = (this.maxUtility * 0.95D);
        }
        Bid nextBid = this.prevBid;
        BidType bidType = chooseBidType(partnerBid);
        switch (bidType)
        {
        case RESTORE: 
          nextBid = this.restoreBid;
          break;
        case APPROACH: 
          nextBid = getApproachBid(partnerBid);
          if ((this.utilitySpace.getUtility(nextBid) < this.maxCompromiseUtility) || 
            (this.utilitySpace.getUtility(nextBid) > this.maxCompromiseUtility * 105.0D / 95.0D)) {
            nextBid = getBetweenBid(nextBid, partnerBid, this.maxCompromiseUtility, this.maxCompromiseUtility * 105.0D / 95.0D);
          }
          break;
        case COMPROMISE: 
          nextBid = getCompromiseBid(partnerBid);
          if (this.utilitySpace.getUtility(nextBid) < this.maxCompromiseUtility) {
            nextBid = getBetweenBid(nextBid, partnerBid, this.maxCompromiseUtility, this.maxCompromiseUtility * 105.0D / 95.0D);
          }
          if (this.continuousCompromiseBid < 0) {
            this.continuousCompromiseBid = 0;
          }
          this.continuousCompromiseBid += 1;
          break;
        case KEEP: 
          nextBid = this.prevBid;
          this.continuousCompromiseBid /= 2;
        }
        if (this.utilitySpace.getUtility(nextBid) <= this.utilitySpace.getUtility(this.prevBid) / 2.0D)
        {
          nextBid = getApproachBid(partnerBid);
          if ((this.utilitySpace.getUtility(nextBid) < this.maxCompromiseUtility) || 
            (this.utilitySpace.getUtility(nextBid) > this.maxCompromiseUtility * 105.0D / 95.0D)) {
            nextBid = getBetweenBid(nextBid, partnerBid, this.maxCompromiseUtility, this.maxCompromiseUtility * 105.0D / 95.0D);
          }
        }
        if (((this.utilitySpace.getUtility(nextBid) >= this.maxCompromiseUtility) && 
          (this.utilitySpace.getUtility(nextBid) <= this.maxCompromiseUtility * 105.0D / 95.0D)) || ((this.continuousKeep < 20) || 
          
          (this.utilitySpace.getUtility(nextBid) <= this.utilitySpace.getUtility(this.prevBid) / 2.0D) || 
          (this.utilitySpace.getUtility(nextBid) < this.maxUtilityOfPartnerBid))) {
          nextBid = this.restoreBid;
        }
        this.averageUtility += this.utilitySpace.getUtility(nextBid);
        if (this.continuousKeep <= 0) {
          updateRestoreBid(nextBid);
        }
        if (time > this.measureT * 3.0D)
        {
          checkCompromise(time);
          this.averageUtility = 0.0D;
          this.averagePartnerUtility = 0.0D;
          this.bidNumber = 1;
          this.measureT += 1;
        }
        if (this.utilitySpace.getUtility(nextBid) == this.utilitySpace.getUtility(this.prevBid)) {
          this.continuousKeep += 1;
        } else {
          this.continuousKeep = 0;
        }
        if ((this.continuousKeep > 30) && (time > 90.0D))
        {
          this.maxCompromiseUtility *= 0.99D;
          this.continuousKeep = 0;
        }
        this.prevBid = nextBid;
        action = new Offer(getAgentID(), nextBid);
      }
    }
    catch (Exception e)
    {
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private void checkCompromise(double time)
  {
    this.averageUtility /= this.bidNumber;
    this.averagePartnerUtility /= this.bidNumber;
    
    double diff = this.prevAverageUtility - this.averageUtility;
    double partnerDiff = this.averagePartnerUtility - this.prevAveragePartnerUtility;
    if (this.compromise)
    {
      double gap = Math.abs(this.averageUtility - this.averagePartnerUtility);
      if ((partnerDiff < diff * 0.9D) || 
        (gap > Math.pow(1.0D - time / 100.0D, 2.0D) * 0.9D))
      {
        double p1 = this.maxCompromiseUtility;double p2 = this.maxCompromiseUtility;
        for (int attenuation = 95; attenuation <= 100; attenuation++) {
          if (this.maxCompromiseUtility * attenuation / 100.0D > this.maxUtilityOfPartnerBid)
          {
            p1 = this.maxCompromiseUtility * attenuation / 100.0D;
            break;
          }
        }
        for (int attenuation = 10; attenuation < 1000; attenuation++) {
          if (this.maxCompromiseUtility - gap / attenuation > this.maxUtilityOfPartnerBid)
          {
            p2 = this.maxCompromiseUtility - gap / attenuation;
            break;
          }
        }
        this.maxCompromiseUtility = ((p1 + p2) / 2.0D);
        
        this.prevAverageUtility = this.averageUtility;
        this.compromise = false;
      }
    }
    else if ((partnerDiff > diff * 0.9D) || ((time > 50.0D) && (this.updateMaxPartnerUtility)))
    {
      this.prevAveragePartnerUtility = this.averagePartnerUtility;
      this.compromise = true;
    }
    this.updateMaxPartnerUtility = false;
  }
  
  private BidType chooseBidType(Bid partnerBid)
  {
    BidType bidType = null;
    try
    {
      double time = this.timeline.getTime();
      
      double prevUtility = this.utilitySpace.getUtility(this.prevBid);
      double partnerUtility = this.utilitySpace.getUtility(partnerBid);
      double gap = Math.abs(prevUtility - partnerUtility);
      if (gap < 0.05D) {
        return BidType.APPROACH;
      }
      gap = Math.abs(this.prevAverageUtility - this.prevAverageUtility);
      if ((gap < 0.1D) && (time > 0.8D)) {
        return BidType.APPROACH;
      }
      if (this.random100.nextInt(20) <= 0) {
        return BidType.RESTORE;
      }
      int approachBorder = 5;
      if (time > 0.9D) {
        approachBorder = (int)Math.round(time * 100.0D / 10.0D);
      }
      if (this.random100.nextInt(20) <= approachBorder) {
        return BidType.RESTORE;
      }
      if (prevUtility > this.maxCompromiseUtility * 105.0D / 95.0D) {
        return BidType.COMPROMISE;
      }
      if ((this.continuousKeep > 20) && (time > 0.6D) && 
        (this.random100.nextDouble() > 0.6D)) {
        return BidType.APPROACH;
      }
    }
    catch (Exception e)
    {
      bidType = BidType.RESTORE;
    }
    double rnd = this.random100.nextDouble();
    double compromiseProbability = getCompromiseProbability();
    if (rnd < compromiseProbability) {
      bidType = BidType.COMPROMISE;
    } else if (rnd < getKeepProbability(compromiseProbability) + compromiseProbability) {
      bidType = BidType.KEEP;
    }
    if (bidType == null) {
      bidType = BidType.RESTORE;
    }
    return bidType;
  }
  
  private double getCompromiseProbability()
  {
    double compromiseProbabilty = 0.0D;
    try
    {
      double prevUtility = this.utilitySpace.getUtility(this.prevBid);
      
      double prevUtilityOfPartnerBid = this.utilitySpace.getUtility(this.prevPartnerBid);
      
      double compromiseDegree = prevUtility / this.maxUtility;
      
      double compromisePartnerDegree = 1.0D - prevUtilityOfPartnerBid / this.maxUtility;
      


      double continuous = (this.continuousCompromiseBid + Math.abs(this.continuousPartnerCompromiseBid) + 0.001D) / 2.0D;
      double ratioUtilityToMaxUtility = prevUtility / (this.maxUtility * 0.9D);
      
      compromiseProbabilty = (compromiseDegree + compromisePartnerDegree) / 2.0D;
      
      compromiseProbabilty /= (1.0D + continuous / 8.0D);
      compromiseProbabilty *= ratioUtilityToMaxUtility;
    }
    catch (Exception e)
    {
      compromiseProbabilty = COMPROMISE_PROBABILITY;
    }
    return compromiseProbabilty;
  }
  
  private double getKeepProbability(double compromiseProbability)
  {
    double keepProbability = 1.0D - compromiseProbability;
    try
    {
      double time = this.timeline.getTime();
      double prevUtility = this.utilitySpace.getUtility(this.prevBid);
      
      double prevUtilityOfPartnerBid = this.utilitySpace.getUtility(this.prevPartnerBid);
      double ratioUtilityToMaxUtility = prevUtility / (this.maxUtility * 0.8D);
      if (prevUtility > prevUtilityOfPartnerBid)
      {
        keepProbability *= (prevUtility - prevUtilityOfPartnerBid) / this.maxUtility;
        
        keepProbability *= time;
        
        keepProbability = keepProbability * (1.0D + Math.abs(this.continuousCompromiseBid) / 4.0D);
        keepProbability *= ratioUtilityToMaxUtility;
      }
      else
      {
        keepProbability = 0.0D;
      }
    }
    catch (Exception e)
    {
      keepProbability = KEEP_PROBABILITY;
    }
    return keepProbability;
  }
  
  private Bid getCompromiseBid(Bid partnerBid)
  {
    Bid compromiseBid = this.prevBid;
    try
    {
      compromiseUtility = 0.0D;
      double prevUtility = this.utilitySpace.getUtility(this.prevBid);
      basicUtility = prevUtility;
      gap = Math.abs(prevUtility - this.utilitySpace
        .getUtility(partnerBid));
      values = new HashMap();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Iterator localIterator = issues.iterator(); localIterator.hasNext();)
      {
        issue = (Issue)localIterator.next();
        values.put(Integer.valueOf(issue.getNumber()), this.prevBid
          .getValue(issue.getNumber()));
      }
      changeIssueID = Integer.valueOf(-1);
      for (Issue compromiseIssue : issues)
      {
        Integer compromiseIssueID = Integer.valueOf(compromiseIssue.getNumber());
        if (((this.prevPartnerBid.getValue(compromiseIssueID.intValue()).equals(partnerBid
          .getValue(compromiseIssueID.intValue()))) || (gap <= 0.05D) || (this.continuousKeep >= 20)) && 
          
          (!this.prevBid.getValue(compromiseIssueID.intValue()).equals(partnerBid
          .getValue(compromiseIssueID.intValue()))) && (compromiseIssueID != changeIssueID))
        {
          HashMap<Integer, Value> candidateValues = new HashMap(values);
          
          candidateValues.remove(compromiseIssueID);
          candidateValues.put(compromiseIssueID, 
          
            getCompromiseValue(compromiseIssue, this.prevBid
            .getValue(compromiseIssueID.intValue()), partnerBid
            .getValue(compromiseIssueID.intValue())));
          Bid candidateBid = new Bid(this.utilitySpace.getDomain(), candidateValues);
          
          double candidateUtility = this.utilitySpace.getUtility(candidateBid);
          if ((candidateUtility > compromiseUtility) && (candidateUtility < basicUtility))
          {
            compromiseUtility = candidateUtility;
            compromiseBid = candidateBid;
            changeIssueID = compromiseIssueID;
          }
        }
      }
    }
    catch (Exception e)
    {
      double compromiseUtility;
      double basicUtility;
      double gap;
      HashMap<Integer, Value> values;
      Issue issue;
      Integer changeIssueID;
      e.printStackTrace();
      compromiseBid = this.restoreBid;
    }
    return compromiseBid;
  }
  
  private Value getCompromiseValue(Issue issue, Value val, Value partnerVal)
  {
    Value compromiseVal = null;
    Evaluator eval = this.utilitySpace.getEvaluator(issue.getNumber());
    switch (issue.getType())
    {
    case DISCRETE: 
      EvaluatorDiscrete evalDiscrete = (EvaluatorDiscrete)eval;
      compromiseVal = (ValueDiscrete)val;
      Integer evaluation = evalDiscrete.getValue((ValueDiscrete)val);
      IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
      Integer compromiseEvaluation = Integer.valueOf(0);
      for (int i = 0; i < issueDiscrete.getNumberOfValues(); i++)
      {
        ValueDiscrete candidateVal = issueDiscrete.getValue(i);
        
        Integer candidateEvaluation = evalDiscrete.getValue(candidateVal);
        if ((candidateEvaluation.intValue() >= compromiseEvaluation.intValue()) && 
          (candidateEvaluation.intValue() < evaluation.intValue()))
        {
          compromiseVal = candidateVal;
          compromiseEvaluation = candidateEvaluation;
        }
      }
      break;
    case INTEGER: 
      ValueInteger valInt = (ValueInteger)val;
      int compromiseInt = valInt.getValue();
      ValueInteger partnerValInt = (ValueInteger)partnerVal;
      if (compromiseInt > partnerValInt.getValue()) {
        compromiseInt--;
      } else {
        compromiseInt++;
      }
      compromiseVal = new ValueInteger(compromiseInt);
      break;
    case REAL: 
      ValueReal valReal = (ValueReal)val;
      double compromiseReal = valReal.getValue();
      ValueReal partnerValReal = (ValueReal)partnerVal;
      
      compromiseReal = compromiseReal + new Random().nextDouble() * (partnerValReal.getValue() - compromiseReal) / 10.0D;
      compromiseVal = new ValueReal(compromiseReal);
      break;
    default: 
      compromiseVal = val;
    }
    return compromiseVal;
  }
  
  private Bid getBetweenBid(Bid basicBid, Bid partnerBid, double minUtility, double maxUtility)
  {
    Bid betweenBid = basicBid;
    try
    {
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      HashMap<Integer, Value> values = new HashMap();
      for (Issue issue : issues) {
        values.put(Integer.valueOf(issue.getNumber()), basicBid
          .getValue(issue.getNumber()));
      }
      double utility = this.utilitySpace.getUtility(basicBid);
      for (int i = 0; i < 1000; i++)
      {
        Issue issue = (Issue)issues.get(this.random200.nextInt(issues.size()));
        int issueID = issue.getNumber();
        if (!this.prevBid.getValue(issueID).equals(partnerBid
          .getValue(issueID)))
        {
          Value value = (Value)values.get(Integer.valueOf(issueID));
          values.remove(Integer.valueOf(issueID));
          if (utility > maxUtility) {
            values.put(Integer.valueOf(issueID), getLowerValue(issue, value, values));
          } else {
            values.put(Integer.valueOf(issueID), getHigherValue(issue, value, values));
          }
          Bid candidateBid = new Bid(this.utilitySpace.getDomain(), values);
          utility = this.utilitySpace.getUtility(candidateBid);
          if ((utility > minUtility) && (utility < maxUtility))
          {
            betweenBid = candidateBid;
            break;
          }
        }
      }
    }
    catch (Exception e)
    {
      betweenBid = this.restoreBid;
    }
    return betweenBid;
  }
  
  private Value getHigherValue(Issue issue, Value value, HashMap<Integer, Value> values)
  {
    Value higher = null;
    Evaluator eval = this.utilitySpace.getEvaluator(issue.getNumber());
    switch (issue.getType())
    {
    case DISCRETE: 
      EvaluatorDiscrete evalDiscrete = (EvaluatorDiscrete)eval;
      
      Integer evaluation = evalDiscrete.getValue((ValueDiscrete)value);
      IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
      higher = evalDiscrete.getMaxValue();
      
      Integer highEvaluation = evalDiscrete.getValue((ValueDiscrete)higher);
      for (int i = 0; i < issueDiscrete.getNumberOfValues(); i++)
      {
        ValueDiscrete candidateVal = issueDiscrete.getValue(i);
        
        Integer candidateEvaluation = evalDiscrete.getValue(candidateVal);
        if ((candidateEvaluation.intValue() < highEvaluation.intValue()) && 
          (candidateEvaluation.intValue() > evaluation.intValue()))
        {
          higher = candidateVal;
          highEvaluation = candidateEvaluation;
        }
      }
      break;
    case INTEGER: 
      IssueInteger issueInt = (IssueInteger)issue;
      ValueInteger valInt = (ValueInteger)value;
      try
      {
        Bid bid = new Bid(this.utilitySpace.getDomain(), values);
        values.remove(Integer.valueOf(issueInt.getNumber()));
        values.put(Integer.valueOf(issueInt.getNumber()), new ValueInteger(valInt
          .getValue() - 1));
        Bid candidateBid = new Bid(this.utilitySpace.getDomain(), values);
        if (this.utilitySpace.getUtility(candidateBid) > this.utilitySpace.getUtility(bid)) {
          higher = new ValueInteger(valInt.getValue() - 1);
        } else {
          higher = new ValueInteger(valInt.getValue() + 1);
        }
      }
      catch (Exception e)
      {
        higher = valInt;
      }
    case REAL: 
      IssueReal issueReal = (IssueReal)issue;
      ValueReal valReal = (ValueReal)value;
      try
      {
        Bid bid = new Bid(this.utilitySpace.getDomain(), values);
        values.remove(Integer.valueOf(issueReal.getNumber()));
        values.put(
          Integer.valueOf(issueReal.getNumber()), new ValueReal(valReal
          .getValue() - 
          
          (valReal.getValue() - issueReal.getLowerBound()) / 10.0D));
        Bid candidateBid = new Bid(this.utilitySpace.getDomain(), values);
        if (this.utilitySpace.getUtility(candidateBid) > this.utilitySpace.getUtility(bid)) {
          higher = new ValueReal(valReal.getValue() - new Random().nextDouble() * (valReal.getValue() - issueReal.getLowerBound()) / 10.0D);
        } else {
          higher = new ValueReal(valReal.getValue() + new Random().nextDouble() * (issueReal.getUpperBound() - valReal.getValue()) / 10.0D);
        }
      }
      catch (Exception e)
      {
        higher = valReal;
      }
    default: 
      higher = value;
    }
    return higher;
  }
  
  private Value getLowerValue(Issue issue, Value value, HashMap<Integer, Value> values)
  {
    Value lower = null;
    Evaluator eval = this.utilitySpace.getEvaluator(issue.getNumber());
    switch (issue.getType())
    {
    case DISCRETE: 
      EvaluatorDiscrete evalDiscrete = (EvaluatorDiscrete)eval;
      
      Integer evaluation = evalDiscrete.getValue((ValueDiscrete)value);
      IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
      lower = evalDiscrete.getMinValue();
      
      Integer lowEvaluation = evalDiscrete.getValue((ValueDiscrete)lower);
      for (int i = 0; i < issueDiscrete.getNumberOfValues(); i++)
      {
        ValueDiscrete candidateVal = issueDiscrete.getValue(i);
        
        Integer candidateEvaluation = evalDiscrete.getValue(candidateVal);
        if ((candidateEvaluation.intValue() > lowEvaluation.intValue()) && 
          (candidateEvaluation.intValue() < evaluation.intValue()))
        {
          lower = candidateVal;
          lowEvaluation = candidateEvaluation;
        }
      }
      break;
    case INTEGER: 
      IssueInteger issueInt = (IssueInteger)issue;
      ValueInteger valInt = (ValueInteger)value;
      try
      {
        Bid bid = new Bid(this.utilitySpace.getDomain(), values);
        values.remove(Integer.valueOf(issueInt.getNumber()));
        values.put(Integer.valueOf(issueInt.getNumber()), new ValueInteger(valInt
          .getValue() - 1));
        Bid candidateBid = new Bid(this.utilitySpace.getDomain(), values);
        if (this.utilitySpace.getUtility(candidateBid) < this.utilitySpace.getUtility(bid)) {
          lower = new ValueInteger(valInt.getValue() - 1);
        } else {
          lower = new ValueInteger(valInt.getValue() + 1);
        }
      }
      catch (Exception e)
      {
        lower = valInt;
      }
    case REAL: 
      IssueReal issueReal = (IssueReal)issue;
      ValueReal valReal = (ValueReal)value;
      try
      {
        Bid bid = new Bid(this.utilitySpace.getDomain(), values);
        values.remove(Integer.valueOf(issueReal.getNumber()));
        values.put(
          Integer.valueOf(issueReal.getNumber()), new ValueReal(valReal
          .getValue() - 
          
          (valReal.getValue() - issueReal.getLowerBound()) / 10.0D));
        Bid candidateBid = new Bid(this.utilitySpace.getDomain(), values);
        if (this.utilitySpace.getUtility(candidateBid) < this.utilitySpace.getUtility(bid)) {
          lower = new ValueReal(valReal.getValue() - new Random().nextDouble() * (valReal.getValue() - issueReal.getLowerBound()) / 10.0D);
        } else {
          lower = new ValueReal(valReal.getValue() + new Random().nextDouble() * (issueReal.getUpperBound() - valReal.getValue()) / 10.0D);
        }
      }
      catch (Exception e)
      {
        lower = valReal;
      }
    default: 
      lower = value;
    }
    return lower;
  }
  
  private Bid getApproachBid(Bid partnerBid)
  {
    Bid approachBid = this.prevBid;
    try
    {
      HashMap<Integer, Value> values = new HashMap();
      HashMap<Integer, Value> approachValues = new HashMap();
      ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
      for (Issue issue : issues) {
        values.put(Integer.valueOf(issue.getNumber()), this.prevBid
          .getValue(issue.getNumber()));
      }
      approachValues = values;
      
      double candidateUtility = 0.0D;
      for (Iterator localIterator2 = issues.iterator(); localIterator2.hasNext();)
      {
        issue = (Issue)localIterator2.next();
        int issueID = issue.getNumber();
        if (issue.getType() == ISSUETYPE.REAL)
        {
          IssueReal issueReal = (IssueReal)issue;
          ValueReal valueReal = (ValueReal)this.prevBid.getValue(issueID);
          
          ValueReal partnerValueReal = (ValueReal)partnerBid.getValue(issueID);
          
          ValueReal prevPartnerValueReal = (ValueReal)this.prevPartnerBid.getValue(issueID);
          double gap = Math.abs(valueReal.getValue() - partnerValueReal
            .getValue());
          double gapPartnerValue = Math.abs(partnerValueReal
            .getValue() - prevPartnerValueReal.getValue());
          if ((gap < (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) || 
          
            (gapPartnerValue >= (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D)) {}
        }
        else if (!this.prevBid.getValue(issueID).equals(partnerBid
          .getValue(issueID)))
        {
          HashMap<Integer, Value> candidateValues = new HashMap(values);
          

          candidateValues.remove(Integer.valueOf(issueID));
          candidateValues.put(
            Integer.valueOf(issueID), 
            getApproachValue(issue, this.prevBid.getValue(issueID), partnerBid
            .getValue(issueID)));
          Bid candidateBid = new Bid(this.utilitySpace.getDomain(), candidateValues);
          if (this.utilitySpace.getUtility(candidateBid) > candidateUtility)
          {
            candidateUtility = this.utilitySpace.getUtility(candidateBid);
            approachBid = candidateBid;
            approachValues = candidateValues;
          }
        }
      }
      Issue issue;
      for (;;)
      {
        candidateUtility = 0.0D;
        Object candidateValues = new HashMap(approachValues);
        for (Issue issue : issues)
        {
          HashMap<Integer, Value> tempValues = new HashMap(approachValues);
          

          int issueID = issue.getNumber();
          if (issue.getType() == ISSUETYPE.REAL)
          {
            IssueReal issueReal = (IssueReal)issue;
            
            ValueReal valueReal = (ValueReal)this.prevBid.getValue(issueID);
            
            ValueReal partnerValueReal = (ValueReal)partnerBid.getValue(issueID);
            double gap = Math.abs(valueReal.getValue() - partnerValueReal
              .getValue());
            if (gap < (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) {}
          }
          else if (!this.prevBid.getValue(issueID).equals(partnerBid
            .getValue(issueID)))
          {
            tempValues.remove(Integer.valueOf(issueID));
            tempValues.put(
              Integer.valueOf(issueID), 
              getApproachValue(issue, this.prevBid.getValue(issueID), partnerBid
              .getValue(issueID)));
            
            Bid tempBid = new Bid(this.utilitySpace.getDomain(), tempValues);
            if (this.utilitySpace.getUtility(tempBid) > candidateUtility)
            {
              candidateValues = tempValues;
              candidateUtility = this.utilitySpace.getUtility(tempBid);
            }
          }
        }
        if ((candidateUtility < this.utilitySpace.getUtility(approachBid)) || 
          (((HashMap)candidateValues).equals(approachValues))) {
          break;
        }
        Bid candidateBid = new Bid(this.utilitySpace.getDomain(), (HashMap)candidateValues);
        
        approachBid = candidateBid;
        approachValues = (HashMap<Integer, Value>)candidateValues;
      }
    }
    catch (Exception e)
    {
      approachBid = this.restoreBid;
    }
    return approachBid;
  }
  
  private Value getApproachValue(Issue issue, Value myVal, Value partnerVal)
  {
    Value approachVal = null;
    boolean checkMyVal;
    boolean checkPartnerVal;
    switch (issue.getType())
    {
    case DISCRETE: 
      IssueDiscrete issueDiscrete = (IssueDiscrete)issue;
      
      checkMyVal = false;
      checkPartnerVal = false;
      for (Value value : issueDiscrete.getValues())
      {
        if (checkMyVal)
        {
          approachVal = value;
          break;
        }
        if (myVal.equals(value))
        {
          if (checkPartnerVal) {
            break;
          }
          checkMyVal = true;
        }
        if (partnerVal.equals(value))
        {
          if (checkMyVal)
          {
            approachVal = value;
            break;
          }
          checkPartnerVal = true;
        }
        approachVal = value;
      }
      break;
    case INTEGER: 
      ValueInteger valInt = (ValueInteger)myVal;
      int approachInt = valInt.getValue();
      ValueInteger partnerValInt = (ValueInteger)partnerVal;
      if (approachInt > partnerValInt.getValue()) {
        approachInt--;
      } else {
        approachInt++;
      }
      approachVal = new ValueInteger(approachInt);
      break;
    case REAL: 
      ValueReal valReal = (ValueReal)myVal;
      double approachReal = valReal.getValue();
      ValueReal partnerValReal = (ValueReal)partnerVal;
      
      approachReal = approachReal + new Random().nextDouble() * (partnerValReal.getValue() - approachReal) / 10.0D;
      approachVal = new ValueReal(approachReal);
      break;
    default: 
      approachVal = myVal;
    }
    return approachVal;
  }
  
  private void updateRestoreBid(Bid nextBid)
  {
    ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
    




    double evalGap = 0.0D;
    for (Issue issue : issues)
    {
      int issueID = issue.getNumber();
      Evaluator eval = this.utilitySpace.getEvaluator(issueID);
      try
      {
        evalGap += Math.abs(eval.getEvaluation(this.utilitySpace, nextBid, issueID).doubleValue() - eval
        
          .getEvaluation(this.utilitySpace, this.maxUtilityPartnerBid, issueID).doubleValue());
      }
      catch (Exception e)
      {
        evalGap += 1.0D;
      }
    }
    if (evalGap < this.minGap)
    {
      this.restoreBid = nextBid;
      this.minGap = evalGap;
    }
    else if (evalGap == this.minGap)
    {
      try
      {
        if (this.utilitySpace.getUtility(nextBid) > this.utilitySpace.getUtility(this.restoreBid)) {
          this.restoreBid = nextBid;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
  }
  
  private boolean isAccept(Bid partnerBid)
  {
    boolean accept = false;
    try
    {
      double prevUtility = this.utilitySpace.getUtility(this.prevBid);
      double offeredUtil = this.utilitySpace.getUtility(partnerBid);
      double time = this.timeline.getTime();
      if (offeredUtil > this.maxUtilityOfPartnerBid)
      {
        this.maxUtilityPartnerBid = partnerBid;
        this.maxUtilityOfPartnerBid = offeredUtil;
        this.updateMaxPartnerUtility = true;
      }
      if ((offeredUtil > this.maxUtility * 0.95D) || (offeredUtil >= prevUtility))
      {
        accept = true;
      }
      else
      {
        ArrayList<Issue> issues = this.utilitySpace.getDomain().getIssues();
        
        double evalGap = 0.0D;
        for (Issue issue : issues)
        {
          int issueID = issue.getNumber();
          switch (issue.getType())
          {
          case REAL: 
            IssueReal issueReal = (IssueReal)issue;
            
            ValueReal valueReal = (ValueReal)this.prevBid.getValue(issueID);
            
            ValueReal partnerValueReal = (ValueReal)partnerBid.getValue(issueID);
            double gap = Math.abs(valueReal.getValue() - partnerValueReal
              .getValue());
            if (gap > (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) {
              evalGap += 0.5D;
            }
            break;
          default: 
            if (!this.prevBid.getValue(issueID).equals(partnerBid
              .getValue(issueID))) {
              evalGap += 0.5D;
            }
            break;
          }
          Evaluator eval = this.utilitySpace.getEvaluator(issueID);
          try
          {
            evalGap += Math.abs(eval.getEvaluation(this.utilitySpace, this.prevBid, issueID).doubleValue() - eval
            
              .getEvaluation(this.utilitySpace, partnerBid, issueID).doubleValue());
          }
          catch (Exception e)
          {
            evalGap += 1.0D;
          }
          evalGap += 0.5D;
        }
        evalGap /= 2.0D * issues.size();
        if (time < 0.5D)
        {
          if ((this.prevPartnerBid != null) && (offeredUtil > this.maxCompromiseUtility) && (offeredUtil >= this.maxUtilityOfPartnerBid))
          {
            double acceptCoefficient = -0.1D * time + 1.0D;
            if ((evalGap < 0.3D) && (offeredUtil > prevUtility * acceptCoefficient)) {
              accept = true;
            }
          }
        }
        else
        {
          double acceptCoefficient;
          if (time < 0.8D)
          {
            if ((this.prevPartnerBid != null) && (offeredUtil > this.maxCompromiseUtility * 0.95D) && (offeredUtil > this.maxUtilityOfPartnerBid * 0.95D))
            {
              double diffMyBidAndOffered = prevUtility - offeredUtil;
              if (diffMyBidAndOffered < 0.0D) {
                diffMyBidAndOffered = 0.0D;
              }
              acceptCoefficient = -0.16D * (time - 0.5D) + 0.95D;
              if ((evalGap < 0.35D) && (offeredUtil > prevUtility * acceptCoefficient)) {
                accept = true;
              }
            }
          }
          else if ((this.prevPartnerBid != null) && (offeredUtil > this.maxCompromiseUtility * 0.9D) && (offeredUtil > this.maxUtilityOfPartnerBid * 0.95D))
          {
            double restoreEvalGap = 0.0D;
            for (Issue issue : issues)
            {
              int issueID = issue.getNumber();
              switch (issue.getType())
              {
              case REAL: 
                IssueReal issueReal = (IssueReal)issue;
                
                ValueReal valueReal = (ValueReal)this.restoreBid.getValue(issueID);
                
                ValueReal partnerValueReal = (ValueReal)partnerBid.getValue(issueID);
                double gap = Math.abs(valueReal.getValue() - partnerValueReal
                  .getValue());
                if (gap > (issueReal.getUpperBound() - issueReal.getLowerBound()) / 100.0D) {
                  restoreEvalGap += 0.5D;
                }
                break;
              default: 
                if (!this.restoreBid.getValue(issueID).equals(partnerBid
                  .getValue(issueID))) {
                  restoreEvalGap += 0.5D;
                }
                break;
              }
              Evaluator eval = this.utilitySpace.getEvaluator(issueID);
              try
              {
                restoreEvalGap += Math.abs(eval.getEvaluation(this.utilitySpace, this.prevBid, issueID).doubleValue() - eval
                
                  .getEvaluation(this.utilitySpace, partnerBid, issueID).doubleValue());
              }
              catch (Exception e)
              {
                restoreEvalGap += 1.0D;
              }
              restoreEvalGap += 0.5D;
            }
            restoreEvalGap /= 2.0D * issues.size();
            
            double threshold = 0.4D;
            if (time > 0.9D) {
              threshold = 0.5D;
            }
            if ((restoreEvalGap <= threshold) || (evalGap <= threshold)) {
              accept = true;
            }
          }
        }
      }
    }
    catch (Exception e)
    {
      accept = false;
    }
    return accept;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Nozomi.Nozomi
 * JD-Core Version:    0.7.1
 */