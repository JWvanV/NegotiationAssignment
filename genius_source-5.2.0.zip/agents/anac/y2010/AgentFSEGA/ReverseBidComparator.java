package agents.anac.y2010.AgentFSEGA;

import java.util.Comparator;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class ReverseBidComparator
  implements Comparator<Bid>
{
  private UtilitySpace usp;
  private final boolean TEST_EQUIVALENCE = false;
  
  public ReverseBidComparator(UtilitySpace pUsp)
  {
    this.usp = pUsp;
  }
  
  public int compare(Bid b1, Bid b2)
  {
    try
    {
      double u1 = this.usp.getUtility(b1);
      double u2 = this.usp.getUtility(b2);
      if (u1 > u2) {
        return -1;
      }
      if (u1 < u2) {
        return 1;
      }
      return 0;
    }
    catch (Exception e) {}
    return -1;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.ReverseBidComparator
 * JD-Core Version:    0.7.1
 */