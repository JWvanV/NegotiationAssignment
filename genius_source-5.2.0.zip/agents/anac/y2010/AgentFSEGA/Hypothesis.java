package agents.anac.y2010.AgentFSEGA;

public abstract class Hypothesis
  implements Comparable<Hypothesis>
{
  private double dProbability;
  
  public double getProbability()
  {
    return this.dProbability;
  }
  
  public void setProbability(double probability)
  {
    this.dProbability = probability;
  }
  
  public int compareTo(Hypothesis o)
  {
    if (getProbability() > o.getProbability()) {
      return 1;
    }
    if (getProbability() < o.getProbability()) {
      return -1;
    }
    return 0;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.Hypothesis
 * JD-Core Version:    0.7.1
 */