package agents.anac.y2010.AgentFSEGA;

import negotiator.Bid;
import negotiator.Domain;

public abstract class OpponentModel
{
  protected Domain dDomain;
  
  public Domain getDomain()
  {
    return this.dDomain;
  }
  
  public abstract double getExpectedUtility(Bid paramBid)
    throws Exception;
  
  public abstract void updateBeliefs(Bid paramBid)
    throws Exception;
  
  public abstract double getExpectedWeight(int paramInt);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.OpponentModel
 * JD-Core Version:    0.7.1
 */