package agents.anac.y2010.AgentFSEGA;

import java.util.ArrayList;
import negotiator.Domain;

public class WeightHypothesis
  extends Hypothesis
{
  double[] dWeight;
  
  public WeightHypothesis(Domain pDomain)
  {
    this.dWeight = new double[pDomain.getIssues().size()];
  }
  
  public void setWeight(int index, double value)
  {
    this.dWeight[index] = value;
  }
  
  public double getWeight(int index)
  {
    return this.dWeight[index];
  }
  
  public String toString()
  {
    String lResult = "WeightHypothesis[";
    for (double iWeight : this.dWeight) {
      lResult = lResult + String.format("%1.2f; ", new Object[] { Double.valueOf(iWeight) });
    }
    lResult = lResult + "]";
    
    return lResult;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.WeightHypothesis
 * JD-Core Version:    0.7.1
 */