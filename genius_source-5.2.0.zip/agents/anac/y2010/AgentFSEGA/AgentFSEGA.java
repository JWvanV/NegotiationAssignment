package agents.anac.y2010.AgentFSEGA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class AgentFSEGA
  extends Agent
{
  private Action lastOponentAction;
  private Action myLastAction;
  private OpponentModel opponentModel;
  private ArrayList<Bid> leftBids;
  private double elapsedTimeNorm;
  private static final double SIGMA = 0.01D;
  private static final double MIN_ALLOWED_UTILITY = 0.5D;
  private static final double SIGMA_MAX = 0.5D;
  
  static enum ACTIONTYPE
  {
    START,  OFFER,  ACCEPT,  BREAKOFF;
    
    private ACTIONTYPE() {}
  }
  
  static enum STRATEGY
  {
    SMART,  SERIAL,  RESPONSIVE,  RANDOM,  TIT_FOR_TAT;
    
    private STRATEGY() {}
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void init()
  {
    this.lastOponentAction = null;
    this.myLastAction = null;
    

    this.opponentModel = new MyBayesianOpponentModel(this.utilitySpace);
    

    BidIterator bIterCount = new BidIterator(this.utilitySpace.getDomain());
    
    this.leftBids = new ArrayList();
    
    double[] nrBids = { 0.0D, 0.0D, 0.0D, 0.0D, 0.0D };
    while (bIterCount.hasNext())
    {
      Bid tmpBid = bIterCount.next();
      try
      {
        double utility = this.utilitySpace.getUtility(tmpBid);
        if ((utility > 1.0D) && (utility > 0.9D)) {
          nrBids[0] += 1.0D;
        } else if ((utility <= 0.9D) && (utility > 0.8D)) {
          nrBids[1] += 1.0D;
        } else if ((utility <= 0.8D) && (utility > 0.7D)) {
          nrBids[2] += 1.0D;
        } else if ((utility <= 0.7D) && (utility > 0.6D)) {
          nrBids[3] += 1.0D;
        } else if (utility >= 0.5D) {
          nrBids[4] += 1.0D;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    try
    {
      Thread.sleep(1000L);
    }
    catch (Exception e) {}
    double arrayBidCount = 0.0D;
    int iMin = 0;
    do
    {
      arrayBidCount = nrBids[iMin];
      iMin++;
    } while ((arrayBidCount == 0.0D) && (iMin < 5));
    BidIterator bIter = new BidIterator(this.utilitySpace.getDomain());
    this.leftBids = new ArrayList();
    while (bIter.hasNext())
    {
      Bid tmpBid = bIter.next();
      try
      {
        if (this.utilitySpace.getUtility(tmpBid) >= 0.9D - 0.1D * iMin) {
          this.leftBids.add(tmpBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    Collections.sort(this.leftBids, new ReverseBidComparator(this.utilitySpace));
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.lastOponentAction = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    Bid opponentBid = null;
    try
    {
      switch (getActionType(this.lastOponentAction))
      {
      case OFFER: 
        this.elapsedTimeNorm = this.timeline.getTime();
        int timeCase;
        int timeCase;
        if (this.elapsedTimeNorm < 0.85D)
        {
          timeCase = 0;
        }
        else
        {
          int timeCase;
          if (this.elapsedTimeNorm < 0.95D) {
            timeCase = 1;
          } else {
            timeCase = 2;
          }
        }
        opponentBid = ((Offer)this.lastOponentAction).getBid();
        

        this.opponentModel.updateBeliefs(opponentBid);
        if (this.myLastAction != null)
        {
          if (this.utilitySpace.getUtility(opponentBid) * 1.03D >= this.utilitySpace.getUtility(((Offer)this.myLastAction).getBid()))
          {
            action = new Accept();
          }
          else
          {
            Bid nextBid = getNextBid(timeCase);
            action = new Offer(getAgentID(), nextBid);
            if (this.utilitySpace.getUtility(opponentBid) > this.utilitySpace.getUtility(nextBid)) {
              action = new Accept();
            }
          }
        }
        else if (this.utilitySpace.getUtility(opponentBid) == this.utilitySpace.getUtility(this.utilitySpace.getMaxUtilityBid())) {
          action = new Accept();
        } else {
          action = initialOffer();
        }
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          action = initialOffer();
        } else {
          action = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.myLastAction = action;
    
    return action;
  }
  
  private Action initialOffer()
    throws Exception
  {
    return new Offer(getAgentID(), this.utilitySpace.getMaxUtilityBid());
  }
  
  private ACTIONTYPE getActionType(Action lAction)
  {
    ACTIONTYPE lActionType = ACTIONTYPE.START;
    if ((lAction instanceof Offer)) {
      lActionType = ACTIONTYPE.OFFER;
    } else if ((lAction instanceof Accept)) {
      lActionType = ACTIONTYPE.ACCEPT;
    } else if ((lAction instanceof EndNegotiation)) {
      lActionType = ACTIONTYPE.BREAKOFF;
    }
    return lActionType;
  }
  
  private Bid getNextBid(int pTimeCase)
    throws Exception
  {
    switch (pTimeCase)
    {
    case 0: 
      return getSmartBid(pTimeCase);
    case 1: 
      return getSmartBid(1);
    }
    return getSmartBid(2);
  }
  
  public String getName()
  {
    return "AgentFSEGA";
  }
  
  private Bid getSmartBid(int pTimeCase)
  {
    double currentOpponentUtility = 0.0D;
    double lastOpponentUtility = 0.0D;
    



    Bid nextBest = null;
    Bid theBest = null;
    if (this.leftBids.size() > 0)
    {
      theBest = (Bid)this.leftBids.get(0);
      try
      {
        myBestUtil = this.utilitySpace.getUtility(theBest);
      }
      catch (Exception e)
      {
        double myBestUtil = 1.0D;
      }
      nextBest = theBest;
    }
    else
    {
      return ((Offer)this.myLastAction).getBid();
    }
    double myBestUtil;
    Bid lNext = null;
    
    double minUtilAllowed = Math.max(0.98D * Math.exp(Math.log(0.52D) * this.elapsedTimeNorm), 0.5D);
    
    double minArrayUtility = 0.0D;
    try
    {
      minArrayUtility = this.utilitySpace.getUtility((Bid)this.leftBids.get(this.leftBids.size() - 1));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    if ((minArrayUtility > minUtilAllowed + 0.01D) || (minArrayUtility > myBestUtil - 0.01D))
    {
      BidIterator bIter = new BidIterator(this.utilitySpace.getDomain());
      for (Bid tmpBid = bIter.next(); bIter.hasNext(); tmpBid = bIter.next()) {
        try
        {
          double tmpBidUtil = this.utilitySpace.getUtility(tmpBid);
          if ((tmpBidUtil > 0.5D) && (tmpBidUtil < minArrayUtility) && (tmpBidUtil > Math.min(minUtilAllowed, myBestUtil) - 0.1D)) {
            this.leftBids.add(tmpBid);
          }
        }
        catch (Exception e) {}
      }
      Collections.sort(this.leftBids, new ReverseBidComparator(this.utilitySpace));
    }
    if (this.leftBids.size() > 1)
    {
      lNext = (Bid)this.leftBids.get(1);
    }
    else
    {
      this.leftBids.remove(nextBest);
      return nextBest;
    }
    double myNextUtility;
    try
    {
      myNextUtility = this.utilitySpace.getUtility(lNext);
    }
    catch (Exception e)
    {
      myNextUtility = 0.0D;
    }
    double lowerAcceptableUtilLimit;
    double lowerAcceptableUtilLimit;
    if (pTimeCase == 2)
    {
      lowerAcceptableUtilLimit = myBestUtil - Math.exp(Math.log(0.5D) / (0.05D * this.timeline.getTotalTime())) * this.elapsedTimeNorm;
    }
    else
    {
      double lowerAcceptableUtilLimit;
      if (pTimeCase == 0) {
        lowerAcceptableUtilLimit = Math.max(myBestUtil - 0.01D, minUtilAllowed);
      } else {
        lowerAcceptableUtilLimit = Math.min(myBestUtil - 0.01D, minUtilAllowed);
      }
    }
    Iterator<Bid> lbi = this.leftBids.iterator();
    if (this.leftBids.size() > 1)
    {
      lbi.next();
      lbi.next();
    }
    else
    {
      return ((Offer)this.myLastAction).getBid();
    }
    while ((myNextUtility > lowerAcceptableUtilLimit) && (myNextUtility <= minUtilAllowed))
    {
      if (pTimeCase == 0) {
        try
        {
          if (myNextUtility < this.utilitySpace.getUtility(((Offer)this.lastOponentAction).getBid()))
          {
            nextBest = ((Offer)this.myLastAction).getBid();
            break;
          }
        }
        catch (Exception e) {}
      }
      try
      {
        currentOpponentUtility = this.opponentModel.getExpectedUtility(lNext);
      }
      catch (Exception e)
      {
        currentOpponentUtility = 0.0D;
      }
      if (currentOpponentUtility > lastOpponentUtility)
      {
        lastOpponentUtility = currentOpponentUtility;
        nextBest = lNext;
      }
      if (!lbi.hasNext()) {
        break;
      }
      lNext = (Bid)lbi.next();
      try
      {
        myNextUtility = this.utilitySpace.getUtility(lNext);
      }
      catch (Exception e)
      {
        myNextUtility = 0.0D;
      }
    }
    try
    {
      if (this.utilitySpace.getUtility(nextBest) <= minUtilAllowed) {
        return ((Offer)this.myLastAction).getBid();
      }
    }
    catch (Exception e) {}
    this.leftBids.remove(nextBest);
    
    return nextBest;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.AgentFSEGA
 * JD-Core Version:    0.7.1
 */