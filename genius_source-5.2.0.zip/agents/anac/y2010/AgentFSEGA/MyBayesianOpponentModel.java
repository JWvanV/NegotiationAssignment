package agents.anac.y2010.AgentFSEGA;

import java.util.ArrayList;
import java.util.Collections;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueReal;
import negotiator.utility.EVALFUNCTYPE;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.EvaluatorReal;
import negotiator.utility.UtilitySpace;

public class MyBayesianOpponentModel
  extends OpponentModel
{
  private UtilitySpace uUS;
  private ArrayList<UtilitySpaceHypothesis> uUSHypothesis;
  private double previousBidUtility;
  private double SIGMA = 0.25D;
  private double CONCESSION_STRATEGY = 0.035D;
  private boolean bUseMostProb = true;
  private ArrayList<UtilitySpaceHypothesis> mostProbHyps;
  
  public MyBayesianOpponentModel(UtilitySpace pUS)
  {
    if (pUS == null) {
      throw new NullPointerException("MyBayesianOpponentModel: utility space = null");
    }
    this.uUS = pUS;
    
    this.previousBidUtility = 1.0D;
    this.dDomain = pUS.getDomain();
    

    ArrayList<Issue> issues = this.dDomain.getIssues();
    ArrayList<ArrayList<EvaluatorHypothesis>> aaEvaluatorHypothesis = new ArrayList();
    
    int numberOfIssues = issues.size();
    

    WeightHypothesis[] weightHypothesis = new WeightHypothesis[factorial(numberOfIssues)];
    

    double[] P = new double[numberOfIssues];
    for (int i = 0; i < numberOfIssues; i++) {
      P[i] = (2.0D * (i + 1) / (numberOfIssues * (numberOfIssues + 1)));
    }
    weightPermutations(Integer.valueOf(0), weightHypothesis, P, numberOfIssues - 1);
    for (int i = 0; i < weightHypothesis.length; i++) {
      weightHypothesis[i].setProbability(1.0D / weightHypothesis.length);
    }
    for (int i = 0; i < numberOfIssues; i++)
    {
      ArrayList<EvaluatorHypothesis> lEvalHyps;
      EvaluatorHypothesis lEvaluatorHypothesis;
      switch (this.uUS.getEvaluator(((Issue)issues.get(i)).getNumber()).getType())
      {
      case DISCRETE: 
        lEvalHyps = new ArrayList();
        aaEvaluatorHypothesis.add(lEvalHyps);
        IssueDiscrete lDiscIssue = (IssueDiscrete)this.dDomain.getIssue(i);
        

        EvaluatorDiscrete lDiscreteEvaluator = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEvaluator.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j + 1));
        }
        lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEvaluator, "uphill");
        
        lEvalHyps.add(lEvaluatorHypothesis);
        

        lDiscreteEvaluator = new EvaluatorDiscrete();
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          lDiscreteEvaluator.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1) + 1));
        }
        lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEvaluator, "downhill");
        
        lEvalHyps.add(lEvaluatorHypothesis);
        

        lDiscreteEvaluator = new EvaluatorDiscrete();
        int halfway = lDiscIssue.getNumberOfValues() / 2;
        for (int j = 0; j < lDiscIssue.getNumberOfValues(); j++) {
          if (j < halfway) {
            lDiscreteEvaluator.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * j + 1));
          } else {
            lDiscreteEvaluator.addEvaluation(lDiscIssue.getValue(j), Integer.valueOf(1000 * (lDiscIssue.getNumberOfValues() - j - 1) + 1));
          }
        }
        lEvaluatorHypothesis = new EvaluatorHypothesis(lDiscreteEvaluator, "triangular");
        
        lEvalHyps.add(lEvaluatorHypothesis);
        break;
      case REAL: 
        lEvalHyps = new ArrayList();
        aaEvaluatorHypothesis.add(lEvalHyps);
        IssueReal lRealIssue = (IssueReal)this.dDomain.getIssue(i);
        

        EvaluatorReal lRealEvaluator = new EvaluatorReal();
        lRealEvaluator.setLowerBound(lRealIssue.getLowerBound());
        lRealEvaluator.setUpperBound(lRealIssue.getUpperBound());
        lRealEvaluator.setType(EVALFUNCTYPE.LINEAR);
        lRealEvaluator.addParam(1, 1.0D / (lRealEvaluator.getUpperBound() - lRealEvaluator.getLowerBound()));
        lRealEvaluator.addParam(0, -lRealEvaluator.getLowerBound() / (lRealEvaluator.getUpperBound() - lRealEvaluator.getLowerBound()));
        lEvaluatorHypothesis = new EvaluatorHypothesis(lRealEvaluator, "uphill");
        lEvalHyps.add(lEvaluatorHypothesis);
        

        lRealEvaluator = new EvaluatorReal();
        lRealEvaluator.setLowerBound(lRealIssue.getLowerBound());
        lRealEvaluator.setUpperBound(lRealIssue.getUpperBound());
        lRealEvaluator.setType(EVALFUNCTYPE.LINEAR);
        lRealEvaluator.addParam(1, -1.0D / (lRealEvaluator.getUpperBound() - lRealEvaluator.getLowerBound()));
        lRealEvaluator.addParam(0, 1.0D + lRealEvaluator.getLowerBound() / (lRealEvaluator.getUpperBound() - lRealEvaluator.getLowerBound()));
        lEvaluatorHypothesis = new EvaluatorHypothesis(lRealEvaluator, "downhill");
        lEvalHyps.add(lEvaluatorHypothesis);
        

        int lTotalTriangularFns = 1;
        for (int k = 1; k <= lTotalTriangularFns; k++)
        {
          lRealEvaluator = new EvaluatorReal();
          lRealEvaluator.setLowerBound(lRealIssue.getLowerBound());
          lRealEvaluator.setUpperBound(lRealIssue.getUpperBound());
          lRealEvaluator.setType(EVALFUNCTYPE.TRIANGULAR);
          lRealEvaluator.addParam(0, lRealEvaluator.getLowerBound());
          lRealEvaluator.addParam(1, lRealEvaluator.getUpperBound());
          lRealEvaluator.addParam(2, lRealEvaluator.getLowerBound() + k * (lRealEvaluator.getUpperBound() - lRealEvaluator.getLowerBound()) / (lTotalTriangularFns + 1));
          lEvaluatorHypothesis = new EvaluatorHypothesis(lRealEvaluator, "triangular");
          lEvaluatorHypothesis.setProbability(0.3333333333333333D);
          lEvalHyps.add(lEvaluatorHypothesis);
        }
        for (int k = 0; k < lEvalHyps.size(); k++) {
          ((EvaluatorHypothesis)lEvalHyps.get(k)).setProbability(1.0D / lEvalHyps.size());
        }
        break;
      default: 
        throw new NullPointerException("Evaluator type not implemented: eval type - " + this.uUS.getEvaluator(((Issue)issues.get(i)).getNumber()).getType());
      }
    }
    ArrayList<EvaluatorHypothesis[]> evalHypothesis = new ArrayList();
    EvaluatorHypothesis[] ehTmp = new EvaluatorHypothesis[this.uUS.getNrOfEvaluators()];
    
    buildEvaluationHypothesis(evalHypothesis, ehTmp, this.uUS.getNrOfEvaluators() - 1, aaEvaluatorHypothesis);
    

    buildUtilitySpaceHypothesis(weightHypothesis, evalHypothesis);
  }
  
  private void buildEvaluationHypothesis(ArrayList<EvaluatorHypothesis[]> pHyps, EvaluatorHypothesis[] pEval, int m, ArrayList<ArrayList<EvaluatorHypothesis>> paaEval)
  {
    if (m == 0)
    {
      ArrayList<EvaluatorHypothesis> lEvalHyps = (ArrayList)paaEval.get(this.uUS.getNrOfEvaluators() - 1);
      for (int i = 0; i < lEvalHyps.size(); i++)
      {
        pEval[(this.uUS.getNrOfEvaluators() - 1)] = ((EvaluatorHypothesis)lEvalHyps.get(i));
        EvaluatorHypothesis[] lTmp = new EvaluatorHypothesis[this.uUS.getNrOfEvaluators()];
        for (int j = 0; j < lTmp.length; j++) {
          lTmp[j] = pEval[j];
        }
        pHyps.add(lTmp);
      }
    }
    else
    {
      ArrayList<EvaluatorHypothesis> lEvalHyps = (ArrayList)paaEval.get(this.uUS.getNrOfEvaluators() - m - 1);
      for (int i = 0; i < lEvalHyps.size(); i++)
      {
        pEval[(this.uUS.getNrOfEvaluators() - m - 1)] = ((EvaluatorHypothesis)lEvalHyps.get(i));
        buildEvaluationHypothesis(pHyps, pEval, m - 1, paaEval);
      }
    }
  }
  
  private void buildUtilitySpaceHypothesis(WeightHypothesis[] pWeightHypothesis, ArrayList<EvaluatorHypothesis[]> pEvalHypothesis)
  {
    this.uUSHypothesis = new ArrayList();
    for (int i = 0; i < pWeightHypothesis.length; i++) {
      for (int j = 0; j < pEvalHypothesis.size(); j++)
      {
        UtilitySpaceHypothesis lUSHyp = new UtilitySpaceHypothesis(this.dDomain, this.uUS, pWeightHypothesis[i], (EvaluatorHypothesis[])pEvalHypothesis.get(j));
        this.uUSHypothesis.add(lUSHyp);
      }
    }
    for (int i = 0; i < this.uUSHypothesis.size(); i++) {
      ((UtilitySpaceHypothesis)this.uUSHypothesis.get(i)).setProbability(1.0D / this.uUSHypothesis.size());
    }
  }
  
  private Integer weightPermutations(Integer index, WeightHypothesis[] hyps, double[] P, int m)
  {
    int i;
    if (m == 0)
    {
      WeightHypothesis lWH = new WeightHypothesis(this.dDomain);
      for (i = 0; i < P.length; i++) {
        lWH.setWeight(i, P[i]);
      }
      hyps[index.intValue()] = lWH;
      i = index;Integer localInteger = index = Integer.valueOf(index.intValue() + 1);
    }
    else
    {
      for (int i = 0; i <= m; i++)
      {
        index = weightPermutations(index, hyps, P, m - 1);
        if (i < m)
        {
          double tmp = P[i];
          P[i] = P[m];
          P[m] = tmp;
          reverse(P, m - 1);
        }
      }
    }
    return index;
  }
  
  private void reverse(double[] array, int size)
  {
    int i = 0;int j = size;
    while (i < j)
    {
      double tmp = array[i];
      array[i] = array[j];
      array[j] = tmp;
      i++;
      j--;
    }
  }
  
  private int factorial(int n)
  {
    int result = 1;
    for (; n > 1; n--) {
      result *= n;
    }
    return result;
  }
  
  public void updateBeliefs(Bid pBid)
    throws Exception
  {
    double lProbSum = 0.0D;
    double lMaxProb = 0.0D;
    for (int i = 0; i < this.uUSHypothesis.size(); i++)
    {
      UtilitySpaceHypothesis hyp = (UtilitySpaceHypothesis)this.uUSHypothesis.get(i);
      double condDistrib = hyp.getProbability() * conditionalDistribution(((UtilitySpaceHypothesis)this.uUSHypothesis.get(i)).getUtility(pBid), this.previousBidUtility);
      lProbSum += condDistrib;
      if (condDistrib > lMaxProb) {
        lMaxProb = condDistrib;
      }
      hyp.setProbability(condDistrib);
    }
    if (this.bUseMostProb) {
      this.mostProbHyps = new ArrayList();
    }
    double mostProbHypSum = 0.0D;
    for (int i = 0; i < this.uUSHypothesis.size(); i++)
    {
      UtilitySpaceHypothesis hyp = (UtilitySpaceHypothesis)this.uUSHypothesis.get(i);
      double normalizedProbability = hyp.getProbability() / lProbSum;
      if ((this.bUseMostProb) && 
        (normalizedProbability > lMaxProb * 0.95D / lProbSum))
      {
        this.mostProbHyps.add(hyp);
        mostProbHypSum += normalizedProbability;
      }
      if (normalizedProbability > 0.0D) {
        hyp.setProbability(normalizedProbability);
      } else {
        this.uUSHypothesis.remove(i);
      }
    }
    if (this.bUseMostProb) {
      for (int i = 0; i < this.mostProbHyps.size(); i++)
      {
        UtilitySpaceHypothesis tmpHyp = (UtilitySpaceHypothesis)this.mostProbHyps.get(i);
        double normalizedProbability = tmpHyp.getProbability() / mostProbHypSum;
        tmpHyp.setProbability(normalizedProbability);
      }
    }
    this.previousBidUtility -= this.CONCESSION_STRATEGY;
    

    Collections.sort(this.uUSHypothesis);
    

    int cutPoint = Integer.MAX_VALUE;
    
    double cummulativeSum = 0.0D;
    for (int i = 0; i < this.uUSHypothesis.size(); i++)
    {
      cummulativeSum += ((UtilitySpaceHypothesis)this.uUSHypothesis.get(i)).getProbability();
      if (cummulativeSum > 0.95D)
      {
        cutPoint = i;
        break;
      }
    }
    if (cutPoint != Integer.MAX_VALUE) {
      for (int i = this.uUSHypothesis.size() - 1; i >= cutPoint; i--) {
        this.uUSHypothesis.remove(i);
      }
    }
    for (int i = 0; i < this.uUSHypothesis.size(); i++)
    {
      UtilitySpaceHypothesis currentHyp = (UtilitySpaceHypothesis)this.uUSHypothesis.get(i);
      double newProbability = currentHyp.getProbability() / cummulativeSum;
      currentHyp.setProbability(newProbability);
    }
  }
  
  private double conditionalDistribution(double pUtility, double pPreviousBidUtility)
  {
    if (pPreviousBidUtility < pUtility) {
      return 0.0D;
    }
    double x = (pPreviousBidUtility - pUtility) / pPreviousBidUtility;
    double distribution = 1.0D / (this.SIGMA * Math.sqrt(6.283185307179586D)) * Math.exp(-(x * x) / (2.0D * this.SIGMA * this.SIGMA));
    return distribution;
  }
  
  public double getExpectedUtility(Bid pBid)
    throws Exception
  {
    double lExpectedUtility = 0.0D;
    if ((this.bUseMostProb) && (this.mostProbHyps != null)) {
      for (int i = 0; i < this.mostProbHyps.size(); i++)
      {
        UtilitySpaceHypothesis tmpUSHypothesis = (UtilitySpaceHypothesis)this.mostProbHyps.get(i);
        double p = tmpUSHypothesis.getProbability();
        double u = tmpUSHypothesis.getUtility(pBid);
        lExpectedUtility += p * u;
      }
    } else {
      for (int i = 0; i < this.uUSHypothesis.size(); i++)
      {
        UtilitySpaceHypothesis tmpUSHypothesis = (UtilitySpaceHypothesis)this.uUSHypothesis.get(i);
        double p = tmpUSHypothesis.getProbability();
        double u = tmpUSHypothesis.getUtility(pBid);
        lExpectedUtility += p * u;
      }
    }
    return lExpectedUtility;
  }
  
  public double getExpectedWeight(int pIssueNumber)
  {
    double lExpectedWeight = 0.0D;
    for (int i = 0; i < this.uUSHypothesis.size(); i++)
    {
      UtilitySpaceHypothesis lUSHyp = (UtilitySpaceHypothesis)this.uUSHypothesis.get(i);
      double p = lUSHyp.getProbability();
      double u = lUSHyp.getHeightHyp().getWeight(pIssueNumber);
      lExpectedWeight += p * u;
    }
    return lExpectedWeight;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.MyBayesianOpponentModel
 * JD-Core Version:    0.7.1
 */