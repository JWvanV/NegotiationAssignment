package agents.anac.y2010.AgentFSEGA;

import negotiator.utility.Evaluator;

public class EvaluatorHypothesis
  extends Hypothesis
{
  private Evaluator dEval;
  private String sDescription;
  
  public EvaluatorHypothesis(Evaluator pEval, String pDescription)
  {
    this.dEval = pEval;
    this.sDescription = pDescription;
  }
  
  public Evaluator getEvaluator()
  {
    return this.dEval;
  }
  
  public String getDescription()
  {
    return this.sDescription;
  }
  
  public String toString()
  {
    return "Evaluator hypothesis " + this.sDescription + ": " + this.dEval.toString();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentFSEGA.EvaluatorHypothesis
 * JD-Core Version:    0.7.1
 */