package agents.anac.y2010.AgentSmith;

import negotiator.AgentID;
import negotiator.actions.Action;
import negotiator.utility.UtilitySpace;

public abstract class ABidStrategy
{
  protected BidHistory fBidHistory;
  protected UtilitySpace fUtilitySpace;
  protected PreferenceProfileManager fPreferenceProfile;
  protected AgentID fAgentID;
  
  public ABidStrategy(BidHistory pHist, UtilitySpace pUtilitySpace, PreferenceProfileManager pPreferenceProfile, AgentID pId)
  {
    this.fBidHistory = pHist;
    this.fUtilitySpace = pUtilitySpace;
    this.fPreferenceProfile = pPreferenceProfile;
    this.fAgentID = pId;
  }
  
  public Action getNextAction(double startTime)
  {
    Action lAction = null;
    return lAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.ABidStrategy
 * JD-Core Version:    0.7.1
 */