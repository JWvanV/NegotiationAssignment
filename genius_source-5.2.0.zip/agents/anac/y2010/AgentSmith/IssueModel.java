package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.Bid;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;

public class IssueModel
{
  private ArrayList<Value> fValues;
  private Issue fIssue;
  private Bounds fBounds;
  
  public IssueModel(Issue lIssue)
  {
    this.fValues = new ArrayList();
    this.fIssue = lIssue;
    this.fBounds = new Bounds(this.fIssue);
  }
  
  public double getAverage()
  {
    double lTotal = 0.0D;
    for (Value lWeight : this.fValues) {
      lTotal += getNumberValue(lWeight);
    }
    return lTotal / this.fValues.size();
  }
  
  public double getDeviation()
  {
    double lIssueAverage = getAverage();
    double lTotal = 0.0D;
    for (Value lWeight : this.fValues) {
      lTotal += Math.pow(getNumberValue(lWeight) - lIssueAverage, 2.0D);
    }
    return Math.sqrt(lTotal / this.fValues.size());
  }
  
  public void addValue(Value pValue)
  {
    this.fValues.add(pValue);
  }
  
  public double getNumberValue(Value pValue)
  {
    switch (this.fIssue.getType())
    {
    case DISCRETE: 
      throw new RuntimeException("No get value for discret");
    case REAL: 
      return ((ValueReal)pValue).getValue();
    case INTEGER: 
      return ((ValueInteger)pValue).getValue();
    }
    return 0.0D;
  }
  
  public double getUtility(Bid pBid)
  {
    double lUtility = 0.0D;
    switch (this.fIssue.getType())
    {
    case INTEGER: 
      lUtility = getRealUtility(pBid);
      break;
    case REAL: 
      lUtility = getRealUtility(pBid);
      break;
    case DISCRETE: 
      lUtility = getDiscreteUtility(pBid);
    }
    return lUtility;
  }
  
  public double getDiscreteUtility(Bid pBid)
  {
    double lSame = 0.0D;
    for (Value lValue : this.fValues)
    {
      ValueDiscrete lDiscreteValue = (ValueDiscrete)lValue;
      if (lDiscreteValue.value.equals(((ValueDiscrete)getBidValue(pBid)).value)) {
        lSame += 1.0D;
      }
    }
    return this.fValues.size() == 0 ? 0.0D : lSame / this.fValues.size();
  }
  
  public double getRealUtility(Bid pBid)
  {
    return 1.0D - Math.abs(this.fBounds.normalize(getNumberValue(getBidValue(pBid))) - this.fBounds.normalize(getAverage()));
  }
  
  public double getWeight()
  {
    double lWeight = 0.0D;
    switch (this.fIssue.getType())
    {
    case INTEGER: 
      lWeight = getRealWeight();
      break;
    case REAL: 
      lWeight = getRealWeight();
      break;
    case DISCRETE: 
      lWeight = getDiscreteWeight();
    }
    return lWeight;
  }
  
  public double getDiscreteWeight()
  {
    HashMap<String, Integer> lCounter = new HashMap();
    for (Value lValue : this.fValues)
    {
      ValueDiscrete lDiscreteValue = (ValueDiscrete)lValue;
      int lCount = lCounter.get(lDiscreteValue.value) != null ? ((Integer)lCounter.get(lDiscreteValue.value)).intValue() : 0;
      lCount++;
      lCounter.put(lDiscreteValue.value, Integer.valueOf(lCount));
    }
    double lMax = 0.0D;
    double lTotal = 0.0D;
    for (Iterator i$ = lCounter.values().iterator(); i$.hasNext();)
    {
      int lC = ((Integer)i$.next()).intValue();
      if (lC > lMax) {
        lMax = lC;
      }
      lTotal += lC;
    }
    return lMax / lTotal;
  }
  
  public double getRealWeight()
  {
    return 1.0D / (1.0D + getDeviation());
  }
  
  public Value getBidValue(Bid pBid)
  {
    return getBidValueByIssue(pBid, this.fIssue);
  }
  
  public static Value getBidValueByIssue(Bid pBid, Issue pIssue)
  {
    Value lValue = null;
    try
    {
      lValue = pBid.getValue(pIssue.getNumber());
    }
    catch (Exception e) {}
    return lValue;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.IssueModel
 * JD-Core Version:    0.7.1
 */