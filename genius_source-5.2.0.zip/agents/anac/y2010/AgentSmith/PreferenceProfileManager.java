package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.issue.Issue;
import negotiator.utility.Evaluator;
import negotiator.utility.UtilitySpace;

public class PreferenceProfileManager
{
  protected UtilitySpace fUtilitySpace;
  protected BidHistory fBidHistory;
  private IOpponentModel fOpponentModel;
  
  public PreferenceProfileManager(BidHistory pHist, UtilitySpace pUtilitySpace)
  {
    this.fBidHistory = pHist;
    this.fUtilitySpace = pUtilitySpace;
    this.fOpponentModel = new OpponentModel(this, this.fBidHistory);
  }
  
  public double getOpponentUtility(Bid b)
  {
    return this.fOpponentModel.getUtility(b);
  }
  
  public void addBid(Bid b)
  {
    this.fOpponentModel.addBid(b);
  }
  
  public double getMyUtility(Bid b)
  {
    try
    {
      return this.fUtilitySpace.getUtility(b);
    }
    catch (Exception e) {}
    return 0.0D;
  }
  
  public Evaluator getMyEvaluator(int issueID)
  {
    return this.fUtilitySpace.getEvaluator(issueID);
  }
  
  public Domain getDomain()
  {
    return this.fUtilitySpace.getDomain();
  }
  
  public ArrayList<Issue> getIssues()
  {
    return this.fUtilitySpace.getDomain().getIssues();
  }
  
  public IOpponentModel getOpponentModel()
  {
    return this.fOpponentModel;
  }
  
  public void setOpponentModel(IOpponentModel fOpponentModel)
  {
    this.fOpponentModel = fOpponentModel;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.PreferenceProfileManager
 * JD-Core Version:    0.7.1
 */