package agents.anac.y2010.AgentSmith;

import negotiator.Agent;
import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public class AgentSmith
  extends Agent
{
  private PreferenceProfileManager fPreferenceProfile;
  private ABidStrategy fBidStrategy;
  private BidHistory fBidHistory;
  private boolean firstRound = true;
  private double sMargin = 0.9D;
  
  public String getVersion()
  {
    return "3";
  }
  
  public String getName()
  {
    return "Agent Smith";
  }
  
  public void init()
  {
    this.fBidHistory = new BidHistory();
    this.fPreferenceProfile = new PreferenceProfileManager(this.fBidHistory, this.utilitySpace);
    
    this.fBidStrategy = new SmithBidStrategy(this.fBidHistory, this.utilitySpace, this.fPreferenceProfile, getAgentID());
  }
  
  public void ReceiveMessage(Action pAction)
  {
    if (pAction == null) {
      return;
    }
    if ((pAction instanceof Offer))
    {
      Bid lBid = ((Offer)pAction).getBid();
      
      this.fBidHistory.addOpponentBid(lBid);
      this.fPreferenceProfile.addBid(lBid);
    }
  }
  
  public Action chooseAction()
  {
    Bid currentBid = null;
    Action currentAction = null;
    try
    {
      if ((this.fBidHistory.getOpponentLastBid() != null) && (this.utilitySpace.getUtility(this.fBidHistory.getOpponentLastBid()) > this.sMargin))
      {
        currentAction = new Accept(getAgentID());
      }
      else if ((this.firstRound) && (this.fBidHistory.getMyLastBid() == null))
      {
        this.firstRound = (!this.firstRound);
        currentBid = getInitialBid();
        currentAction = new Offer(getAgentID(), currentBid);
        Bid lBid = ((Offer)currentAction).getBid();
        this.fBidHistory.addMyBid(lBid);
      }
      else
      {
        double utilOpponent = this.utilitySpace.getUtility(this.fBidHistory.getOpponentLastBid());
        
        double utilOur = this.utilitySpace.getUtility(this.fBidHistory.getMyLastBid());
        if (utilOpponent >= utilOur)
        {
          currentAction = new Accept(getAgentID());
        }
        else
        {
          currentAction = this.fBidStrategy.getNextAction(this.timeline.getTime());
          if ((currentAction instanceof Offer))
          {
            Bid lBid = ((Offer)currentAction).getBid();
            this.fBidHistory.addMyBid(lBid);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return currentAction;
  }
  
  private Bid getInitialBid()
    throws Exception
  {
    return this.utilitySpace.getMaxUtilityBid();
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.AgentSmith
 * JD-Core Version:    0.7.1
 */