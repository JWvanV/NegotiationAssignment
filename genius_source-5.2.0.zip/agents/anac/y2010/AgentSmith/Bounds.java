package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.IssueInteger;
import negotiator.issue.IssueReal;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.issue.ValueInteger;
import negotiator.issue.ValueReal;

public class Bounds
{
  private double fLower;
  private double fUpper;
  private double fAmtSteps;
  
  public Bounds() {}
  
  public Bounds(Issue pIssue)
  {
    switch (pIssue.getType())
    {
    case DISCRETE: 
      IssueDiscrete lIssueDiscrete = (IssueDiscrete)pIssue;
      setUpper(lIssueDiscrete.getNumberOfValues());
      setLower(0.0D);
      setAmtSteps(lIssueDiscrete.getNumberOfValues());
      break;
    case REAL: 
      IssueReal lIssueReal = (IssueReal)pIssue;
      setUpper(lIssueReal.getUpperBound());
      setLower(lIssueReal.getLowerBound());
      setAmtSteps(10.0D);
      break;
    case INTEGER: 
      IssueInteger lIssueInteger = (IssueInteger)pIssue;
      setUpper(lIssueInteger.getUpperBound());
      setLower(lIssueInteger.getLowerBound());
      setAmtSteps(10.0D);
    }
  }
  
  public double getLower()
  {
    return this.fLower;
  }
  
  public double getUpper()
  {
    return this.fUpper;
  }
  
  public double getAmtSteps()
  {
    return this.fAmtSteps;
  }
  
  public double getStepSize()
  {
    return (this.fUpper - this.fLower) / this.fAmtSteps;
  }
  
  public void setLower(double pLower)
  {
    this.fLower = pLower;
  }
  
  public void setUpper(double pUpper)
  {
    this.fUpper = pUpper;
  }
  
  public void setAmtSteps(double pAmtSteps)
  {
    this.fAmtSteps = pAmtSteps;
  }
  
  public static HashMap<Integer, Bounds> getIssueBounds(ArrayList<Issue> pIssues)
  {
    HashMap<Integer, Bounds> bounds = new HashMap();
    for (Issue lIssue : pIssues)
    {
      Bounds b = new Bounds(lIssue);
      
      bounds.put(Integer.valueOf(lIssue.getNumber()), b);
    }
    return bounds;
  }
  
  public static Value getIssueValue(Issue pIssue, double pIndex)
  {
    Value v = null;
    switch (pIssue.getType())
    {
    case DISCRETE: 
      v = ((IssueDiscrete)pIssue).getValue((int)pIndex); break;
    case REAL: 
      v = new ValueReal(pIndex); break;
    case INTEGER: 
      v = new ValueInteger((int)pIndex);
    }
    return v;
  }
  
  public static double getScaledIssueValue(Bounds pBounds, Bid pBid, Issue pIssue)
    throws Exception
  {
    Value v = pBid.getValue(pIssue.getNumber());
    
    double value = 0.0D;
    switch (pIssue.getType())
    {
    case DISCRETE: 
      value = ((IssueDiscrete)pIssue).getValueIndex(((ValueDiscrete)v).value); break;
    case REAL: 
      value = ((ValueReal)v).getValue(); break;
    case INTEGER: 
      value = ((ValueInteger)v).getValue();
    }
    return (value - pBounds.getLower()) / (pBounds.getUpper() - pBounds.getLower());
  }
  
  public double normalize(double pValue)
  {
    return (pValue - getLower()) / (getUpper() - getLower());
  }
  
  public String toString()
  {
    return "Upper: " + getUpper() + " Lower: " + getLower();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.Bounds
 * JD-Core Version:    0.7.1
 */