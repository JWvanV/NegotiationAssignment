package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import java.util.List;
import negotiator.Bid;

public class BidHistory
{
  private List<Bid> fMyBids;
  private List<Bid> fOpponentBids;
  private List<IBidHistoryListener> fListeners;
  
  public BidHistory()
  {
    this.fMyBids = new ArrayList();
    this.fOpponentBids = new ArrayList();
    this.fListeners = new ArrayList();
  }
  
  public void addMyBid(Bid pBid)
  {
    if (pBid == null) {
      throw new IllegalArgumentException("vBid can't be null.");
    }
    this.fMyBids.add(pBid);
    for (IBidHistoryListener listener : this.fListeners) {
      listener.myBidAdded(this, pBid);
    }
  }
  
  public int getMyBidCount()
  {
    return this.fMyBids.size();
  }
  
  public Bid getMyBid(int pIndex)
  {
    return (Bid)this.fMyBids.get(pIndex);
  }
  
  public Bid getMyLastBid()
  {
    Bid result = null;
    if (getMyBidCount() > 0) {
      result = (Bid)this.fMyBids.get(getMyBidCount() - 1);
    }
    return result;
  }
  
  public boolean isInsideMyBids(Bid a)
  {
    boolean result = false;
    for (int i = 0; i < getMyBidCount(); i++) {
      if (a.equals(getMyBid(i))) {
        result = true;
      }
    }
    return result;
  }
  
  public void addOpponentBid(Bid pBid)
  {
    if (pBid == null) {
      throw new IllegalArgumentException("vBid can't be null.");
    }
    this.fOpponentBids.add(pBid);
    for (IBidHistoryListener listener : this.fListeners) {
      listener.opponentBidAdded(this, pBid);
    }
  }
  
  public int getOpponentBidCount()
  {
    return this.fOpponentBids.size();
  }
  
  public Bid getOpponentBid(int pIndex)
  {
    return (Bid)this.fOpponentBids.get(pIndex);
  }
  
  public Bid getOpponentLastBid()
  {
    Bid result = null;
    if (getOpponentBidCount() > 0) {
      result = (Bid)this.fOpponentBids.get(getOpponentBidCount() - 1);
    }
    return result;
  }
  
  public void addListener(IBidHistoryListener pListener)
  {
    this.fListeners.add(pListener);
  }
  
  public void removeListener(IBidHistoryListener pListener)
  {
    this.fListeners.remove(pListener);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.BidHistory
 * JD-Core Version:    0.7.1
 */