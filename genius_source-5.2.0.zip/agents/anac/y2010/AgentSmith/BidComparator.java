package agents.anac.y2010.AgentSmith;

import java.util.Comparator;
import negotiator.Bid;

public class BidComparator
  implements Comparator<Bid>
{
  private PreferenceProfileManager fPreferenceProfile;
  
  public BidComparator(PreferenceProfileManager pProfile)
  {
    this.fPreferenceProfile = pProfile;
  }
  
  public int compare(Bid b1, Bid b2)
  {
    return getMeasure(b2) > getMeasure(b1) ? -1 : 1;
  }
  
  public double getMeasure(Bid b1)
  {
    double a = 1.0D - this.fPreferenceProfile.getMyUtility(b1);
    double b = 1.0D - this.fPreferenceProfile.getOpponentUtility(b1);
    
    double alpha = Math.atan(b / a);
    
    return a + b + 1.570796326794897D / alpha * 0.5D * 3.141592653589793D;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.BidComparator
 * JD-Core Version:    0.7.1
 */