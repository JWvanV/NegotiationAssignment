package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import java.util.HashMap;
import negotiator.Bid;
import negotiator.issue.Issue;

public class OpponentModel
  implements IOpponentModel
{
  private PreferenceProfileManager fPreferenceProfileManager;
  private HashMap<Issue, IssueModel> fIssueModels;
  
  public OpponentModel(PreferenceProfileManager pPreferenceProfileManager, BidHistory pBidHistory)
  {
    this.fPreferenceProfileManager = pPreferenceProfileManager;
    this.fIssueModels = new HashMap();
    
    initIssueModels();
  }
  
  private void initIssueModels()
  {
    ArrayList<Issue> lIssues = this.fPreferenceProfileManager.getIssues();
    for (Issue lIssue : lIssues)
    {
      IssueModel lModel = new IssueModel(lIssue);
      this.fIssueModels.put(lIssue, lModel);
    }
  }
  
  public void addBid(Bid pBid)
  {
    ArrayList<Issue> lIssues = this.fPreferenceProfileManager.getIssues();
    for (Issue lIssue : lIssues) {
      ((IssueModel)this.fIssueModels.get(lIssue)).addValue(IssueModel.getBidValueByIssue(pBid, lIssue));
    }
  }
  
  public HashMap<Issue, Double> getWeights()
  {
    HashMap<Issue, Double> lWeights = new HashMap();
    ArrayList<Issue> lIssues = this.fPreferenceProfileManager.getIssues();
    for (Issue lIssue : lIssues) {
      lWeights.put(lIssue, Double.valueOf(((IssueModel)this.fIssueModels.get(lIssue)).getWeight()));
    }
    double lTotal = 0.0D;
    for (Issue lIssue : lIssues) {
      lTotal += ((Double)lWeights.get(lIssue)).doubleValue();
    }
    for (Issue lIssue : lIssues) {
      lWeights.put(lIssue, Double.valueOf(((Double)lWeights.get(lIssue)).doubleValue() / lTotal));
    }
    return lWeights;
  }
  
  public double getUtility(Bid pBid)
  {
    double lUtility = 0.0D;
    HashMap<Issue, Double> lWeights = getWeights();
    ArrayList<Issue> lIssues = this.fPreferenceProfileManager.getIssues();
    for (Issue lIssue : lIssues)
    {
      double lWeight = ((Double)lWeights.get(lIssue)).doubleValue();
      double lLocalUtility = ((IssueModel)this.fIssueModels.get(lIssue)).getUtility(pBid);
      
      lUtility += lWeight * lLocalUtility;
    }
    return lUtility;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.OpponentModel
 * JD-Core Version:    0.7.1
 */