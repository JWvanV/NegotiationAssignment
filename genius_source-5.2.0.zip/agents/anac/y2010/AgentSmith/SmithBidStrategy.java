package agents.anac.y2010.AgentSmith;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import negotiator.AgentID;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public class SmithBidStrategy
  extends ABidStrategy
{
  private int fIndex = 0;
  private static double sUtilyMargin = 0.7D;
  private static double sTimeMargin = 110.0D;
  private static double UTILITY_THRESHOLD = 0.7D;
  private final boolean TEST_EQUIVALENCE = false;
  
  public SmithBidStrategy(BidHistory pHist, UtilitySpace utilitySpace, PreferenceProfileManager pPreferenceProfile, AgentID pId)
  {
    super(pHist, utilitySpace, pPreferenceProfile, pId);
  }
  
  public Action getNextAction(double time)
  {
    double normalTime = time * 180.0D;
    Action lAction = null;
    try
    {
      if (normalTime >= sTimeMargin)
      {
        Bid lastBid = this.fBidHistory.getOpponentLastBid();
        
        boolean result = false;
        


        result = this.fPreferenceProfile.getOpponentUtility(lastBid) >= sUtilyMargin;
        if (result) {
          lAction = new Accept(this.fAgentID);
        } else {
          lAction = new Offer(this.fAgentID, getBestOpponentOffer());
        }
      }
      else
      {
        lAction = new Offer(this.fAgentID, getMostOptimalBid());
      }
    }
    catch (Exception e)
    {
      lAction = null;
    }
    return lAction;
  }
  
  public Bid getMostOptimalBid()
  {
    ArrayList<Bid> lBids = getSampledBidList();
    

    BidComparator lComparator = new BidComparator(this.fPreferenceProfile);
    

    Collections.sort(lBids, lComparator);
    
    Bid lBid = (Bid)lBids.get(this.fIndex);
    if (this.fIndex < lBids.size() - 1) {
      this.fIndex += 1;
    }
    return lBid;
  }
  
  public Bid getBestOpponentOffer()
  {
    double util = 0.0D;
    Bid bestBid = null;
    try
    {
      for (int i = 0; i < this.fBidHistory.getOpponentBidCount(); i++) {
        if (this.fUtilitySpace.getUtility(this.fBidHistory.getOpponentBid(i)) > util)
        {
          util = this.fUtilitySpace.getUtility(this.fBidHistory.getOpponentBid(i));
          bestBid = this.fBidHistory.getOpponentBid(i);
        }
      }
    }
    catch (Exception e)
    {
      bestBid = null;
    }
    return bestBid;
  }
  
  private ArrayList<Bid> getSampledBidList()
  {
    ArrayList<Bid> lBids = new ArrayList();
    ArrayList<Issue> lIssues = this.fPreferenceProfile.getIssues();
    HashMap<Integer, Bounds> lBounds = Bounds.getIssueBounds(lIssues);
    

    HashMap<Integer, Value> lBidValues = new HashMap();
    for (Issue lIssue : lIssues)
    {
      Bounds b = (Bounds)lBounds.get(Integer.valueOf(lIssue.getNumber()));
      Value v = Bounds.getIssueValue(lIssue, b.getLower());
      lBidValues.put(Integer.valueOf(lIssue.getNumber()), v);
    }
    try
    {
      lBids.add(new Bid(this.fPreferenceProfile.getDomain(), lBidValues));
    }
    catch (Exception e) {}
    for (e = lIssues.iterator(); ((Iterator)e).hasNext();)
    {
      lIssue = (Issue)((Iterator)e).next();
      ArrayList<Bid> lTempBids = new ArrayList();
      Bounds b = (Bounds)lBounds.get(Integer.valueOf(lIssue.getNumber()));
      for (Bid lTBid : lBids) {
        for (double i = b.getLower(); i < b.getUpper(); i += b.getStepSize())
        {
          HashMap<Integer, Value> lNewBidValues = getBidValues(lTBid);
          lNewBidValues.put(Integer.valueOf(lIssue.getNumber()), Bounds.getIssueValue(lIssue, i));
          try
          {
            Bid iBid = new Bid(this.fPreferenceProfile.getDomain(), lNewBidValues);
            lTempBids.add(iBid);
          }
          catch (Exception e) {}
        }
      }
      lBids = lTempBids;
    }
    Issue lIssue;
    Object lToDestroy = new ArrayList();
    for (Bid lBid : lBids) {
      if (this.fPreferenceProfile.getMyUtility(lBid) < UTILITY_THRESHOLD) {
        ((ArrayList)lToDestroy).add(lBid);
      }
    }
    for (Bid lBid : (ArrayList)lToDestroy) {
      lBids.remove(lBid);
    }
    return lBids;
  }
  
  private HashMap<Integer, Value> getBidValues(Bid pBid)
  {
    HashMap<Integer, Value> lNewBidValues = new HashMap();
    for (Issue lIssue : this.fPreferenceProfile.getIssues()) {
      try
      {
        lNewBidValues.put(Integer.valueOf(lIssue.getNumber()), pBid.getValue(lIssue.getNumber()));
      }
      catch (Exception e) {}
    }
    return lNewBidValues;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.AgentSmith.SmithBidStrategy
 * JD-Core Version:    0.7.1
 */