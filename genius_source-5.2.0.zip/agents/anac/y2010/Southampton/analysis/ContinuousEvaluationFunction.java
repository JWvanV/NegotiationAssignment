package agents.anac.y2010.Southampton.analysis;

import java.util.ArrayList;

public class ContinuousEvaluationFunction<T extends ContinuousEvaluationSection>
{
  protected double weight;
  protected ArrayList<T> sections;
  
  public ContinuousEvaluationFunction(ArrayList<T> sections, double weight)
  {
    this.sections = sections;
    this.weight = weight;
  }
  
  public int getSectionCount()
  {
    return this.sections.size();
  }
  
  public ContinuousEvaluationSection getSection(int sectionNo)
  {
    return (ContinuousEvaluationSection)this.sections.get(sectionNo);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.analysis.ContinuousEvaluationFunction
 * JD-Core Version:    0.7.1
 */