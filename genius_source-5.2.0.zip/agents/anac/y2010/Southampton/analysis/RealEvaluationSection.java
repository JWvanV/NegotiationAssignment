package agents.anac.y2010.Southampton.analysis;

public class RealEvaluationSection
  extends ContinuousEvaluationSection
{
  public RealEvaluationSection(double lowerBound, double evalLowerBound, double upperBound, double evalUpperBound)
  {
    this.lowerBound = lowerBound;
    this.evalLowerBound = evalLowerBound;
    this.upperBound = upperBound;
    this.evalUpperBound = evalUpperBound;
  }
  
  private double getNormalPart(double weight, double lowerBound, double evalLowerBound, double upperBound, double evalUpperBound)
  {
    if (lowerBound >= upperBound) {
      throw new AssertionError("lowerBound cannot be greater than or equal to upperBound");
    }
    if ((evalLowerBound != 0.0D) && (evalUpperBound != 0.0D)) {
      throw new AssertionError("evalLowerBound or evalUpperBound must be zero");
    }
    if ((evalLowerBound != 1.0D) && (evalUpperBound != 1.0D)) {
      throw new AssertionError("evalLowerBound or evalUpperBound must be one");
    }
    if (evalUpperBound > evalLowerBound) {
      return weight / (upperBound - lowerBound);
    }
    return -weight / (upperBound - lowerBound);
  }
  
  public double getNormal(double weight)
  {
    return getNormalPart(weight, this.lowerBound, this.evalLowerBound, this.upperBound, this.evalUpperBound);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.analysis.RealEvaluationSection
 * JD-Core Version:    0.7.1
 */