package agents.anac.y2010.Southampton;

import agents.anac.y2010.Southampton.utils.OpponentModel;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public class SouthamptonAgentNoExtras
  implements SouthamptonAgentExtrasInterface
{
  public void ReceiveMessage(SouthamptonAgent agent, long agentTimeSpent) {}
  
  public void ReceiveMessage() {}
  
  public void chooseAction(SouthamptonAgent agent, long agentTimeSpent) {}
  
  public void chooseAction() {}
  
  public void log(SouthamptonAgent agent, String message) {}
  
  public void postProposeNextBid(SouthamptonAgent agent, Bid myLastBid, UtilitySpace utilitySpace, OpponentModel opponentModel, Bid bid)
    throws Exception
  {}
  
  public void postReceiveAccept(SouthamptonAgent agent, Bid myLastBid, UtilitySpace utilitySpace, OpponentModel opponentModel) {}
  
  public void postSendAccept(SouthamptonAgent agent, Bid myLastBid, UtilitySpace utilitySpace, OpponentModel opponentModel, Bid opponentBid) {}
  
  public void preProposeNextBid(SouthamptonAgent agent, Bid myLastBid, UtilitySpace utilitySpace, OpponentModel opponentModel, Bid opponentBid) {}
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.SouthamptonAgentNoExtras
 * JD-Core Version:    0.7.1
 */