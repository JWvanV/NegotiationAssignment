package agents.anac.y2010.Southampton;

import java.util.Random;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.utility.UtilitySpace;

public class IAMcrazyHaggler
  extends SouthamptonAgent
{
  private double breakOff = 0.9D;
  private final boolean TEST_EQUIVALENCE = false;
  private Random random100;
  
  public void init()
  {
    super.init();
    MAXIMUM_ASPIRATION = 0.85D;
    if (this.utilitySpace.isDiscounted())
    {
      MAXIMUM_ASPIRATION = 0.9D;
      this.breakOff = 0.95D;
    }
    this.random100 = new Random();
  }
  
  public String getName()
  {
    return "IAMcrazyHaggler";
  }
  
  protected Bid proposeInitialBid()
    throws Exception
  {
    return proposeRandomBid();
  }
  
  protected Bid proposeNextBid(Bid opponentBid)
    throws Exception
  {
    return proposeRandomBid();
  }
  
  private Bid proposeRandomBid()
  {
    Bid bid = null;
    try
    {
      do
      {
        bid = this.utilitySpace.getDomain().getRandomBid(this.random100);
      } while (this.utilitySpace.getUtility(bid) <= this.breakOff);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bid;
  }
  
  public String getVersion()
  {
    return "2.0 (Genius 3.1)";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.IAMcrazyHaggler
 * JD-Core Version:    0.7.1
 */