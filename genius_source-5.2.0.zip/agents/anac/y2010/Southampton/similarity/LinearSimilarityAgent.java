package agents.anac.y2010.Southampton.similarity;

import agents.anac.y2010.Southampton.utils.concession.TimeConcessionFunction;

public class LinearSimilarityAgent
  extends VariableConcessionSimilarityAgent
{
  public LinearSimilarityAgent()
  {
    this.cf = new TimeConcessionFunction(1.0D, 0.0D);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.similarity.LinearSimilarityAgent
 * JD-Core Version:    0.7.1
 */