package agents.anac.y2010.Southampton.similarity;

import agents.anac.y2010.Southampton.SouthamptonAgent;
import agents.anac.y2010.Southampton.analysis.BidSpace;
import agents.anac.y2010.Southampton.utils.OpponentModel;
import agents.anac.y2010.Southampton.utils.Pair;
import java.util.ArrayList;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.utility.UtilitySpace;

public abstract class SimilarityAgent
  extends SouthamptonAgent
{
  protected ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory;
  private Bid bestOpponentBid;
  private double bestOpponentUtility;
  protected double utility0 = 0.0D;
  protected final double utility1 = 0.95D;
  
  public SimilarityAgent()
  {
    this.bestOpponentBidUtilityHistory = new ArrayList();
  }
  
  public void init()
  {
    super.init();
    prepareOpponentModel();
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  protected Bid proposeInitialBid()
  {
    Bid bid = null;
    try
    {
      bid = this.bidSpace.getMaxUtilityBid();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return bid;
  }
  
  protected Bid proposeNextBid(Bid opponentBid)
  {
    try
    {
      performUpdating(opponentBid);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double myUtility = 0.0D;double opponentUtility = 0.0D;
    try
    {
      myUtility = this.utilitySpace.getUtility(this.myLastBid);
      opponentUtility = this.utilitySpace.getUtility(opponentBid);
      if (this.opponentPreviousBid == null) {
        this.utility0 = opponentUtility;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double targetUtility = getTargetUtility(myUtility, opponentUtility);
    Bid nextBid = getTradeOffExhaustive(targetUtility, opponentBid, 1000);
    return nextBid;
  }
  
  protected abstract double getTargetUtility(double paramDouble1, double paramDouble2);
  
  protected Bid getRandomBidInRange(double lowerBound, double upperBound)
    throws Exception
  {
    throw new Exception("Method 'getRandomBidInRange' is not implemented in this agent.");
  }
  
  private Bid getTradeOffExhaustive(double ourUtility, Bid opponentBid, int count)
  {
    this.bestOpponentBid = getBestBid(opponentBid);
    if (this.bestOpponentUtility * 1.02D >= ourUtility) {
      return this.bestOpponentBid;
    }
    ArrayList<Bid> bids = this.bidSpace.Project(this.bidSpace
      .getPoint(this.bestOpponentBid), ourUtility, count, this.utilitySpace, this.opponentModel);
    if (bids.size() == 0) {
      return getTradeOffExhaustive(ourUtility, opponentBid, count + 10000);
    }
    double maxOpponentUtility = 0.0D;
    Bid bestBid = null;
    for (Bid bid : bids) {
      try
      {
        double opponentUtility = this.opponentModel.getNormalizedUtility(bid);
        if (opponentUtility > maxOpponentUtility)
        {
          maxOpponentUtility = opponentUtility;
          bestBid = bid;
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bestBid;
  }
  
  private Bid getBestBid(Bid opponentBid)
  {
    try
    {
      double utility = this.utilitySpace.getUtility(opponentBid);
      if (utility >= this.bestOpponentUtility)
      {
        this.bestOpponentUtility = utility;
        this.bestOpponentBid = opponentBid;
      }
      storeDataPoint(this.bestOpponentUtility);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return this.bestOpponentBid;
  }
  
  private void storeDataPoint(double utility)
  {
    double time = this.timeline.getTime();
    


    this.bestOpponentBidUtilityHistory.add(new Pair(Double.valueOf(utility), 
      Double.valueOf(time)));
  }
  
  private void performUpdating(Bid opponentBid)
    throws Exception
  {
    double currentTime = this.timeline.getTime() * this.timeline.getTotalTime() * 1000.0D;
    
    double totalTime = this.timeline.getTotalTime() * 1000.0D;
    this.opponentModel.updateBeliefs(opponentBid, Math.round(currentTime), totalTime);
  }
  
  private void prepareOpponentModel()
  {
    this.opponentModel = new OpponentModel(this.utilitySpace);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.similarity.SimilarityAgent
 * JD-Core Version:    0.7.1
 */