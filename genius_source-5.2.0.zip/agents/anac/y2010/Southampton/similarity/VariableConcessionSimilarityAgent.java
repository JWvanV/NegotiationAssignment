package agents.anac.y2010.Southampton.similarity;

import agents.anac.y2010.Southampton.utils.concession.ConcessionFunction;
import agents.anac.y2010.Southampton.utils.concession.TimeConcessionFunction;
import java.util.ArrayList;
import java.util.HashMap;
import negotiator.AgentParam;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.tournament.VariablesAndValues.AgentParamValue;
import negotiator.tournament.VariablesAndValues.AgentParameterVariable;
import negotiator.utility.UtilitySpace;

public class VariableConcessionSimilarityAgent
  extends SimilarityAgent
{
  protected ConcessionFunction cf;
  
  protected double getTargetUtility(double myUtility, double oppntUtility)
  {
    try
    {
      return getConcession(this.utilitySpace.getUtility((Bid)this.myPreviousBids.get(0)));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return 0.0D;
  }
  
  private double getConcession(double startUtility)
  {
    if (this.cf == null) {
      this.cf = new TimeConcessionFunction(((AgentParamValue)this.parametervalues.get(new AgentParameterVariable(new AgentParam("common", "beta", Double.valueOf(0.0D), Double.valueOf(10.0D))))).getValue().doubleValue(), 0.0D);
    }
    double currentTime = this.timeline.getTime() * this.timeline.getTotalTime() * 1000.0D;
    double totalTime = this.timeline.getTotalTime() * 1000.0D;
    return this.cf.getConcession(startUtility, Math.round(currentTime), totalTime);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.similarity.VariableConcessionSimilarityAgent
 * JD-Core Version:    0.7.1
 */