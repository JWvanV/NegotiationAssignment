package agents.anac.y2010.Southampton;

import agents.anac.y2010.Southampton.analysis.BidSpace;
import agents.anac.y2010.Southampton.utils.ActionCreator;
import agents.anac.y2010.Southampton.utils.OpponentModel;
import java.util.ArrayList;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.EndNegotiation;
import negotiator.actions.Offer;
import negotiator.utility.UtilitySpace;

public abstract class SouthamptonAgent
  extends Agent
{
  private final boolean TEST_EQUIVALENCE = false;
  
  private static enum ActionType
  {
    ACCEPT,  BREAKOFF,  OFFER,  START;
    
    private ActionType() {}
  }
  
  protected static double MAXIMUM_ASPIRATION = 0.9D;
  protected BidSpace bidSpace;
  private Action messageOpponent;
  
  public String getVersion()
  {
    return "2.0 (Genius 3.1)";
  }
  
  protected Action myLastAction = null;
  protected Bid myLastBid = null;
  protected ArrayList<Bid> myPreviousBids;
  protected ArrayList<Bid> opponentBids;
  protected OpponentModel opponentModel;
  protected Bid opponentPreviousBid = null;
  protected final double acceptMultiplier = 1.02D;
  protected boolean opponentIsHardHead;
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
  }
  
  private ActionType getActionType(Action action)
  {
    ActionType actionType = ActionType.START;
    if ((action instanceof Offer)) {
      actionType = ActionType.OFFER;
    } else if ((action instanceof Accept)) {
      actionType = ActionType.ACCEPT;
    } else if ((action instanceof EndNegotiation)) {
      actionType = ActionType.BREAKOFF;
    }
    return actionType;
  }
  
  public final Action chooseAction()
  {
    Action chosenAction = null;
    Bid opponentBid = null;
    try
    {
      switch (getActionType(this.messageOpponent))
      {
      case OFFER: 
        opponentBid = ((Offer)this.messageOpponent).getBid();
        chosenAction = handleOffer(opponentBid);
        break;
      case ACCEPT: 
      case BREAKOFF: 
        break;
      default: 
        if (this.myLastAction == null) {
          chosenAction = new Offer(getAgentID(), proposeInitialBid());
        } else {
          chosenAction = this.myLastAction;
        }
        break;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
      chosenAction = ActionCreator.createOffer(this, this.myLastBid);
    }
    this.myLastAction = chosenAction;
    if ((this.myLastAction instanceof Offer))
    {
      Bid b = ((Offer)this.myLastAction).getBid();
      this.myPreviousBids.add(b);
      this.myLastBid = b;
    }
    return chosenAction;
  }
  
  public int getAgentNo()
  {
    if (getName() == "Agent A") {
      return 1;
    }
    if (getName() == "Agent B") {
      return 2;
    }
    return 0;
  }
  
  private ArrayList<Bid> getBidsInRange(double lowerBound, double upperBound)
    throws Exception
  {
    ArrayList<Bid> bidsInRange = new ArrayList();
    BidIterator iter = new BidIterator(this.utilitySpace.getDomain());
    while (iter.hasNext())
    {
      Bid tmpBid = iter.next();
      double util = 0.0D;
      try
      {
        util = this.utilitySpace.getUtility(tmpBid);
        if ((util >= lowerBound) && (util <= upperBound)) {
          bidsInRange.add(tmpBid);
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return bidsInRange;
  }
  
  protected Bid getRandomBidInRange(double lowerBound, double upperBound)
    throws Exception
  {
    ArrayList<Bid> bidsInRange = getBidsInRange(lowerBound, upperBound);
    
    int index = new Random().nextInt(bidsInRange.size() - 1);
    
    return (Bid)bidsInRange.get(index);
  }
  
  private Action handleOffer(Bid opponentBid)
    throws Exception
  {
    Action chosenAction = null;
    if (this.myLastAction == null)
    {
      Bid b = proposeInitialBid();
      if (opponentBid != null) {}
      this.myLastBid = b;
      chosenAction = new Offer(getAgentID(), b);
    }
    else if (this.utilitySpace.getUtility(opponentBid) * 1.02D >= this.utilitySpace.getUtility(this.myLastBid))
    {
      chosenAction = ActionCreator.createAccept(this);
      log("Opponent's bid is good enough compared to my last bid, ACCEPTED.");
      this.opponentBids.add(opponentBid);
      this.opponentPreviousBid = opponentBid;
    }
    else if (this.utilitySpace.getUtility(opponentBid) * 1.02D >= MAXIMUM_ASPIRATION)
    {
      chosenAction = ActionCreator.createAccept(this);
      log("Utility of opponent bid: " + this.utilitySpace.getUtility(opponentBid));
      
      log("acceptMultiplier: 1.02");
      log("MAXIMUM_ASPIRATION: " + MAXIMUM_ASPIRATION);
      log("Opponent's bid is good enough compared to my maximum aspiration, ACCEPTED.");
      this.opponentBids.add(opponentBid);
      this.opponentPreviousBid = opponentBid;
    }
    else
    {
      Bid plannedBid = proposeNextBid(opponentBid);
      
      chosenAction = ActionCreator.createOffer(this, plannedBid);
      if (plannedBid == null)
      {
        chosenAction = ActionCreator.createAccept(this);
      }
      else
      {
        if (this.utilitySpace.getUtility(opponentBid) * 1.02D >= this.utilitySpace.getUtility(plannedBid))
        {
          chosenAction = ActionCreator.createAccept(this);
          log("Opponent's bid is good enough compared to my planned bid, ACCEPTED");
        }
        this.opponentBids.add(opponentBid);
        this.opponentPreviousBid = opponentBid;
      }
    }
    return chosenAction;
  }
  
  public void init()
  {
    this.messageOpponent = null;
    this.myLastBid = null;
    this.myLastAction = null;
    this.myPreviousBids = new ArrayList();
    this.opponentBids = new ArrayList();
    try
    {
      this.bidSpace = new BidSpace(this.utilitySpace);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    this.opponentIsHardHead = true;
  }
  
  public final void log(String message) {}
  
  protected abstract Bid proposeInitialBid()
    throws Exception;
  
  protected abstract Bid proposeNextBid(Bid paramBid)
    throws Exception;
  
  public final void ReceiveMessage(Action opponentAction)
  {
    if (opponentAction == null)
    {
      log("Received (null) from opponent.");
    }
    else
    {
      log("--------------------------------------------------------------------------------");
      log("Received " + opponentAction.toString() + " from opponent.");
      if ((opponentAction instanceof Offer)) {
        try
        {
          log("It has a utility of " + this.utilitySpace.getUtility(((Offer)opponentAction).getBid()));
          if ((this.opponentIsHardHead) && (this.opponentBids.size() > 0) && (Math.abs(this.utilitySpace.getUtility((Bid)this.opponentBids.get(0)) - this.utilitySpace.getUtility(((Offer)opponentAction).getBid())) > 0.02D)) {
            this.opponentIsHardHead = false;
          }
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
    this.messageOpponent = opponentAction;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.SouthamptonAgent
 * JD-Core Version:    0.7.1
 */