package agents.anac.y2010.Southampton;

import agents.anac.y2010.Southampton.utils.OpponentModel;
import negotiator.Bid;
import negotiator.utility.UtilitySpace;

public abstract interface SouthamptonAgentExtrasInterface
{
  public abstract void postReceiveAccept(SouthamptonAgent paramSouthamptonAgent, Bid paramBid, UtilitySpace paramUtilitySpace, OpponentModel paramOpponentModel);
  
  public abstract void postSendAccept(SouthamptonAgent paramSouthamptonAgent, Bid paramBid1, UtilitySpace paramUtilitySpace, OpponentModel paramOpponentModel, Bid paramBid2);
  
  public abstract void preProposeNextBid(SouthamptonAgent paramSouthamptonAgent, Bid paramBid1, UtilitySpace paramUtilitySpace, OpponentModel paramOpponentModel, Bid paramBid2);
  
  public abstract void postProposeNextBid(SouthamptonAgent paramSouthamptonAgent, Bid paramBid1, UtilitySpace paramUtilitySpace, OpponentModel paramOpponentModel, Bid paramBid2)
    throws Exception;
  
  public abstract void chooseAction(SouthamptonAgent paramSouthamptonAgent, long paramLong);
  
  public abstract void ReceiveMessage(SouthamptonAgent paramSouthamptonAgent, long paramLong);
  
  public abstract void log(SouthamptonAgent paramSouthamptonAgent, String paramString);
  
  public abstract void chooseAction();
  
  public abstract void ReceiveMessage();
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.SouthamptonAgentExtrasInterface
 * JD-Core Version:    0.7.1
 */