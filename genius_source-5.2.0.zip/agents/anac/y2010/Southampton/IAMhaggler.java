package agents.anac.y2010.Southampton;

import agents.anac.y2010.Southampton.analysis.BidSpace;
import agents.anac.y2010.Southampton.similarity.LinearSimilarityAgent;
import agents.anac.y2010.Southampton.utils.concession.SpecialTimeConcessionFunction;
import negotiator.SupportedNegotiationSetting;
import negotiator.Timeline;
import negotiator.utility.UtilitySpace;

public class IAMhaggler
  extends LinearSimilarityAgent
{
  private double lowestTarget = 1.0D;
  private final double minDiscounting = 0.1D;
  private final double minBeta = 0.01D;
  private double maxBeta = 2.0D;
  private double defaultBeta = 1.0D;
  private final double hardHeadTarget = 0.8D;
  
  public void init()
  {
    super.init();
    int discreteCombinationCount = this.bidSpace.getDiscreteCombinationsCount();
    if (this.bidSpace.isContinuousWeightsZero())
    {
      this.defaultBeta = Math.min(0.5D, Math.max(0.0625D, discreteCombinationCount * 0.001D));
      if (this.utilitySpace.isDiscounted()) {
        this.maxBeta = ((2.0D + 4.0D * Math.min(0.5D, this.utilitySpace.getDiscountFactor())) * this.defaultBeta);
      } else {
        this.maxBeta = (2.0D + 4.0D * this.defaultBeta);
      }
    }
  }
  
  protected double getTargetUtility(double myUtility, double oppntUtility)
  {
    double currentTime = this.timeline.getTime() * this.timeline.getTotalTime() * 1000.0D;
    
    double beta = this.bidSpace.getBeta(this.bestOpponentBidUtilityHistory, this.timeline.getTime(), this.utility0, 0.95D, 0.1D, 0.01D, this.maxBeta, this.defaultBeta, currentTime, currentTime);
    


    this.cf = new SpecialTimeConcessionFunction(beta, this.defaultBeta, 0.5D);
    

    double target = super.getTargetUtility(myUtility, oppntUtility);
    
    this.lowestTarget = Math.min(target, this.lowestTarget);
    if (this.opponentIsHardHead) {
      return Math.max(0.8D, this.lowestTarget);
    }
    return this.lowestTarget;
  }
  
  public String getName()
  {
    return "IAMhaggler";
  }
  
  public String getVersion()
  {
    return "2.0 (Genius 3.1)";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.IAMhaggler
 * JD-Core Version:    0.7.1
 */