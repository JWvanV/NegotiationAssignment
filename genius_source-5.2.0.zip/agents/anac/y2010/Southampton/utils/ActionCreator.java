package agents.anac.y2010.Southampton.utils;

import negotiator.Agent;
import negotiator.Bid;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;

public class ActionCreator
{
  public static Action createOffer(Agent agent, Bid bid)
  {
    return new Offer(agent.getAgentID(), bid);
  }
  
  public static Action createAccept(Agent agent)
  {
    return new Accept(agent.getAgentID());
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.ActionCreator
 * JD-Core Version:    0.7.1
 */