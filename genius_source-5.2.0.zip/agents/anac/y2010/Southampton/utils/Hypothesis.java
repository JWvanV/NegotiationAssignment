package agents.anac.y2010.Southampton.utils;

public class Hypothesis
{
  private double probability;
  
  public double getProbability()
  {
    return this.probability;
  }
  
  public void setProbability(double probability)
  {
    this.probability = probability;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.Hypothesis
 * JD-Core Version:    0.7.1
 */