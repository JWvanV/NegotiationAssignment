package agents.anac.y2010.Southampton.utils;

import negotiator.utility.Evaluator;

public class EvaluatorHypothesis
  extends Hypothesis
{
  private String description;
  private Evaluator evaluator;
  
  public EvaluatorHypothesis(Evaluator evaluator)
  {
    this.evaluator = evaluator;
  }
  
  public Evaluator getEvaluator()
  {
    return this.evaluator;
  }
  
  public String toString()
  {
    return this.description;
  }
  
  public void setDesc(String value)
  {
    this.description = value;
  }
  
  public String getDesc()
  {
    return this.description;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.EvaluatorHypothesis
 * JD-Core Version:    0.7.1
 */