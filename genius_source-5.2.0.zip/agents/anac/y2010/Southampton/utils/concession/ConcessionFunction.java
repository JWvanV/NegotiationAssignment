package agents.anac.y2010.Southampton.utils.concession;

public abstract class ConcessionFunction
{
  public abstract double getConcession(double paramDouble1, long paramLong, double paramDouble2);
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.concession.ConcessionFunction
 * JD-Core Version:    0.7.1
 */