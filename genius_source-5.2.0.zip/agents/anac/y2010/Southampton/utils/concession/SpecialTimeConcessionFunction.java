package agents.anac.y2010.Southampton.utils.concession;

public class SpecialTimeConcessionFunction
  extends ConcessionFunction
{
  private double beta;
  private double breakoff;
  private double defaultBeta;
  
  public SpecialTimeConcessionFunction(double beta, double defaultBeta, double breakoff)
  {
    this.beta = beta;
    this.breakoff = breakoff;
    this.defaultBeta = defaultBeta;
  }
  
  public double getConcession(double startUtility, long currentTime, double totalTime)
  {
    double utilityBeta = startUtility - (startUtility - this.breakoff) * Math.pow(currentTime / totalTime, 1.0D / this.beta);
    double utilityDefaultBeta = startUtility - (startUtility - this.breakoff) * Math.pow(currentTime / totalTime, 1.0D / this.defaultBeta);
    double gamePercent = currentTime / totalTime;
    if (gamePercent < 0.2D) {
      return utilityDefaultBeta;
    }
    if (gamePercent < 0.4D) {
      return utilityDefaultBeta * (1.0D - (gamePercent - 0.2D) / 0.2D) + utilityBeta * ((gamePercent - 0.2D) / 0.2D);
    }
    return utilityBeta;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.concession.SpecialTimeConcessionFunction
 * JD-Core Version:    0.7.1
 */