package agents.anac.y2010.Southampton.utils.concession;

import agents.anac.y2010.Southampton.utils.Pair;
import java.util.ArrayList;
import java.util.Iterator;

public class ConcessionUtils
{
  public static double getBeta(ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory, double time, double discounting, double utility0, double utility1)
  {
    return getBeta(bestOpponentBidUtilityHistory, time, discounting, utility0, utility1, 0.1D, 0.01D, 2.0D, 1.0D, 1.0D, 1.0D);
  }
  
  public static double getBeta(ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory, double time, double discounting, double utility0, double utility1, double minDiscounting, double minBeta, double maxBeta, double defaultBeta, double ourTime, double opponentTime)
  {
    discounting = Math.max(discounting, minDiscounting);
    try
    {
      Pair<Double, Double> params = getRegressionParameters(bestOpponentBidUtilityHistory, utility0);
      double a = ((Double)params.fst).doubleValue();
      double b = ((Double)params.snd).doubleValue();
      
      double maxima = getMaxima(a, b, time, discounting, utility0, opponentTime);
      

      double util = utility0 + Math.exp(a) * Math.pow(maxima, b);
      util = Math.max(0.0D, Math.min(1.0D, util));
      
      double beta = Math.max(0.0D, Math.log(maxima) / Math.log((1.0D - util) / 0.5D));
      







      return Math.min(maxBeta, Math.max(minBeta, beta));
    }
    catch (Exception ex) {}
    return defaultBeta;
  }
  
  private static Pair<Double, Double> getRegressionParameters(ArrayList<Pair<Double, Double>> bestOpponentBidUtilityHistory, double utility0)
  {
    double n = 1.0D;
    double x = 0.0D;
    double y = Math.log(1.0D - utility0);
    double sumlnxlny = 0.0D;
    double sumlnx = 0.0D;
    double sumlny = y;
    double sumlnxlnx = 0.0D;
    for (Pair<Double, Double> d : bestOpponentBidUtilityHistory)
    {
      x = Math.log(((Double)d.snd).doubleValue());
      y = Math.log(((Double)d.fst).doubleValue() - utility0);
      if (Double.isNaN(x)) {
        throw new RuntimeException("Unable to perform regression using provided points (x).");
      }
      if (Double.isNaN(y)) {
        throw new RuntimeException("Unable to perform regression using provided points (y).");
      }
      if ((!Double.isInfinite(x)) && (!Double.isInfinite(y)))
      {
        sumlnxlny += x * y;
        sumlnx += x;
        sumlny += y;
        sumlnxlnx += x * x;
        n += 1.0D;
      }
    }
    double b = (n * sumlnxlny - sumlnx * sumlny) / (n * sumlnxlnx - sumlnx * sumlnx);
    if (Double.isNaN(b)) {
      throw new RuntimeException("Unable to perform regression using provided points (b)." + sumlnxlny + ", " + n * sumlnxlnx + ", " + sumlnx * sumlnx);
    }
    double a = (sumlny - b * sumlnx) / n;
    if (Double.isNaN(a)) {
      throw new RuntimeException("Unable to perform regression using provided points (a).");
    }
    return new Pair(Double.valueOf(a), Double.valueOf(b));
  }
  
  private static double getMaxima(double a, double b, double time, double discounting, double utility0, double opponentTime)
  {
    ArrayList<Double> maxima = new ArrayList();
    maxima.add(Double.valueOf(time));
    for (int i = (int)Math.floor(time * 1000.0D); i <= 1000; i++)
    {
      double root = i / 1000.0D;
      
      maxima.add(Double.valueOf(root));
    }
    maxima.add(Double.valueOf(1.0D));
    double maxUtil = 0.0D;
    double result = 0.0D;
    
    double timeScaledDiscounting = -discounting * getTimeScaleFactor(time, opponentTime);
    double expA = Math.exp(a);
    for (Iterator localIterator = maxima.iterator(); localIterator.hasNext();)
    {
      double maximum = ((Double)localIterator.next()).doubleValue();
      double util = (utility0 + expA * Math.pow(maximum, b)) * Math.exp(timeScaledDiscounting * maximum);
      if (util > maxUtil)
      {
        result = maximum;
        maxUtil = util;
      }
    }
    return result;
  }
  
  private static double getTimeScaleFactor(double ourTime, double opponentTime)
  {
    double sf = (ourTime + opponentTime) / (ourTime * 2.0D);
    return sf;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.anac.y2010.Southampton.utils.concession.ConcessionUtils
 * JD-Core Version:    0.7.1
 */