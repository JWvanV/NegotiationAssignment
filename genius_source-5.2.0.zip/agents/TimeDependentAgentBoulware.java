package agents;

import negotiator.SupportedNegotiationSetting;

public class TimeDependentAgentBoulware
  extends TimeDependentAgent
{
  public double getE()
  {
    return 0.2D;
  }
  
  public String getName()
  {
    return "Boulware";
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TimeDependentAgentBoulware
 * JD-Core Version:    0.7.1
 */