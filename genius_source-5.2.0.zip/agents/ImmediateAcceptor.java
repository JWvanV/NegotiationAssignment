package agents;

import negotiator.Bid;
import negotiator.SupportedNegotiationSetting;
import negotiator.utility.UtilitySpace;

public class ImmediateAcceptor
  extends TimeDependentAgent
{
  public double getE()
  {
    return 0.0D;
  }
  
  public String getName()
  {
    return "Immediate Acceptor";
  }
  
  public boolean isAcceptable(Bid plannedBid)
  {
    Bid opponentLastBid = getOpponentLastBid();
    if (getUtility(opponentLastBid) >= this.utilitySpace.getReservationValue().doubleValue()) {
      return true;
    }
    return false;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.ImmediateAcceptor
 * JD-Core Version:    0.7.1
 */