package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.DiscreteTimeline;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.utility.UtilitySpace;

public abstract class OptimalBidder
  extends Agent
{
  protected double rv = -1.0D;
  protected static int partitions;
  protected static int ownTotalRounds;
  protected static HashMap<Integer, Value> values;
  private static ArrayList<Double> bids;
  protected static Issue pie;
  private Action actionOfPartner = null;
  
  public abstract double bid(int paramInt);
  
  public abstract void getValues()
    throws Exception;
  
  public void init()
  {
    try
    {
      ownTotalRounds = (getTotalRounds() - 1) / 2;
      pie = (Issue)this.utilitySpace.getDomain().getIssues().get(0);
      
      print("=====================================================================");
      print("   ownTotalRounds  = " + ownTotalRounds);
      print("   issue name      = " + pie);
      print("   issue type      = " + pie.getType());
      
      getValues();
      
      this.rv = this.utilitySpace.getReservationValue().doubleValue();
      
      print("   Reservation value = " + this.rv);
      
      bids = new ArrayList(ownTotalRounds);
      for (int i = 0; i < ownTotalRounds; i++) {
        bids.add(Double.valueOf(bid(i + 1)));
      }
      print("   Bids : ");
      for (int i = 0; i < ownTotalRounds; i++) {
        print("\tB[" + i + "] = " + bids.get(i));
      }
      print("\n=====================================================================");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
  
  public String getVersion()
  {
    return "2.0 (Genius 4.2)";
  }
  
  public String getName()
  {
    return "OptimalBidder";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      if (this.actionOfPartner == null) {
        action = chooseOptimalBidAction();
      }
      if ((this.actionOfPartner instanceof Offer)) {
        action = chooseOptimalBidAction();
      }
    }
    catch (Exception e)
    {
      print("Exception in ChooseAction:" + e.getMessage());
    }
    return action;
  }
  
  private Action chooseOptimalBidAction()
  {
    Bid nextBid = null;
    try
    {
      nextBid = getOptimalBid();
    }
    catch (Exception e)
    {
      print("Problem with received bid: <" + e.getMessage() + ">. Cancelling bidding");
      
      System.out.println("\t\t\t\tErrrrr!   => " + nextBid);
      System.exit(0);
    }
    return new Offer(getAgentID(), nextBid);
  }
  
  public int getRound()
  {
    return ((DiscreteTimeline)this.timeline).getRound();
  }
  
  public int getRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getRoundsLeft();
  }
  
  public int getOwnRoundsLeft()
  {
    return ((DiscreteTimeline)this.timeline).getOwnRoundsLeft();
  }
  
  public int getTotalRounds()
  {
    return ((DiscreteTimeline)this.timeline).getTotalRounds();
  }
  
  public double getTotalTime()
  {
    return ((DiscreteTimeline)this.timeline).getTotalTime();
  }
  
  void print(String s)
  {
    System.out.println("############  " + s);
  }
  
  private Bid getOptimalBid()
    throws Exception
  {
    print("############   B's  ####################################");
    print(" Round         = " + getRound());
    print(" RoundsLeft    = " + getRoundsLeft());
    print(" OwnRoundsLeft = " + getOwnRoundsLeft());
    print(" TotalRounds   = " + getTotalRounds());
    print(" TotalTime     = " + getTotalTime());
    
    double min = 1.0D;
    int roundsleft = 0;
    Value optValue = null;
    
    print(" bids.size = " + bids.size());
    print(" getOwnRoundsLeft = " + getOwnRoundsLeft());
    
    TreeMap<Integer, Value> T = new TreeMap(values);
    
    print(" T.size = " + T.size());
    for (Integer key : T.keySet())
    {
      roundsleft = getOwnRoundsLeft();
      
      Double targetBid = (Double)bids.get(roundsleft);
      double piePartition = key.intValue() / partitions;
      if (Math.abs(targetBid.doubleValue() - piePartition) < min)
      {
        min = Math.abs(targetBid.doubleValue() - piePartition);
        optValue = (Value)values.get(key);
      }
    }
    Object optVals = new HashMap();
    ((HashMap)optVals).put(Integer.valueOf(pie.getNumber()), optValue);
    Bid ToBid = new Bid(this.utilitySpace.getDomain(), (HashMap)optVals);
    
    print(" ToBid = " + ToBid);
    
    return ToBid;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.OptimalBidder
 * JD-Core Version:    0.7.1
 */