package agents;

import java.awt.Component;
import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;

class MyCellEditor
  extends DefaultCellEditor
{
  private static final long serialVersionUID = 1L;
  NegoInfo negoinfo;
  
  public MyCellEditor(NegoInfo n)
  {
    super(new JTextField("vaag"));
    this.negoinfo = n;
    setClickCountToStart(1);
  }
  
  public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column)
  {
    return this.negoinfo.getValueAt(row, column);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.MyCellEditor
 * JD-Core Version:    0.7.1
 */