package agents;

import agents.anac.y2011.Nice_Tit_for_Tat.BilateralAgent;
import java.util.List;
import negotiator.Bid;
import negotiator.Timeline;
import negotiator.bidding.BidDetails;
import negotiator.boaframework.SortedOutcomeSpace;
import negotiator.utility.UtilitySpace;

public abstract class TimeDependentAgent
  extends BilateralAgent
{
  private static final double k = 0.0D;
  private SortedOutcomeSpace outcomeSpace;
  private double Pmax;
  private double Pmin;
  
  public abstract double getE();
  
  public String getName()
  {
    return "Time Dependent Agent";
  }
  
  public String getVersion()
  {
    return "1.1";
  }
  
  public void init()
  {
    super.init();
    initFields();
  }
  
  protected void initFields()
  {
    this.outcomeSpace = new SortedOutcomeSpace(this.utilitySpace);
    List<BidDetails> allOutcomes = this.outcomeSpace.getAllOutcomes();
    
    double maximumUtilityInScenario = ((BidDetails)allOutcomes.get(0)).getMyUndiscountedUtil();
    
    double mininimumUtilityInScenario = ((BidDetails)allOutcomes.get(allOutcomes.size() - 1)).getMyUndiscountedUtil();
    double rv = this.utilitySpace.getReservationValueUndiscounted();
    this.Pmax = maximumUtilityInScenario;
    this.Pmin = Math.max(mininimumUtilityInScenario, rv);
  }
  
  public double f(double t)
  {
    if (getE() == 0.0D) {
      return 0.0D;
    }
    double ft = 0.0D + 1.0D * Math.pow(t, 1.0D / getE());
    
    return ft;
  }
  
  public double p(double t)
  {
    return this.Pmin + (this.Pmax - this.Pmin) * (1.0D - f(t));
  }
  
  public Bid pickBidOfUtility(double utility)
  {
    return this.outcomeSpace.getBidNearUtility(utility).getBid();
  }
  
  public Bid makeBid()
  {
    double time = this.timeline.getTime();
    










    double utilityGoal = p(time);
    Bid b = pickBidOfUtility(utilityGoal);
    





    return b;
  }
  
  public Bid chooseCounterBid()
  {
    return makeBid();
  }
  
  public Bid chooseFirstCounterBid()
  {
    return makeBid();
  }
  
  public Bid chooseOpeningBid()
  {
    return makeBid();
  }
  
  public boolean isAcceptable(Bid plannedBid)
  {
    Bid opponentLastBid = getOpponentLastBid();
    if (getUndiscountedUtility(opponentLastBid) >= getUndiscountedUtility(plannedBid)) {
      return true;
    }
    return false;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TimeDependentAgent
 * JD-Core Version:    0.7.1
 */