package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Stack;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.Timeline;
import negotiator.Timeline.Type;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Value;
import negotiator.issue.ValueDiscrete;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;

public class TAgent
  extends Agent
{
  private Action actionOfPartner = null;
  private static int counter;
  private static int index;
  private static int idx;
  private static int m;
  private static int d;
  private static int n;
  private static boolean flag;
  private static boolean all_osr_cuttofs;
  private static boolean two_osr_subsets;
  private static boolean unused;
  private static double rvB;
  private static double totalTime;
  private static double timeLeftBeforeAction;
  private static double timeLeftAfterAction;
  private static double OpponentMaxDuration;
  private static double OwnMaxDuration;
  private static Stack<HashMap<Value, Double>> stack_h = null;
  private static Stack<HashMap<Value, Double>> stack_aux = null;
  private static Stack<HashMap<Value, Double>> stack_hc = null;
  private static ArrayList<ValueDiscrete> max_values = null;
  
  public double bids(int j)
  {
    return j == 1 ? 0.5D * rvB / n + 0.5D : 0.5D * sq(bids(j - 1)) + 0.5D;
  }
  
  public double bids_(double Bj)
  {
    return Math.sqrt(2.0D * Bj - 1.0D);
  }
  
  public void init()
  {
    try
    {
      totalTime = this.timeline.getTotalTime();
      timeLeftAfterAction = this.timeline.getCurrentTime();
      timeLeftBeforeAction = OpponentMaxDuration = OwnMaxDuration = 0.0D;
      counter = index = idx = 0;
      rvB = 0.0D;
      m = 5;
      d = -1;
      n = 1000;
      
      flag = true;
      all_osr_cuttofs = true;
      two_osr_subsets = false;
      unused = false;
      
      stack_h = new Stack();
      stack_aux = new Stack();
      stack_hc = new Stack();
      max_values = new ArrayList();
      
      int number_of_values = -1;
      
      pie = (Issue)this.utilitySpace.getDomain().getIssues().get(0);
      

      System.out.println("######   issue name = " + pie + "\n" + "######   issue type = " + pie.getType());
      
      HashMap<Integer, Value> values = new HashMap();
      switch (pie.getType())
      {
      case DISCRETE: 
        IssueDiscrete discrete_pie = (IssueDiscrete)pie;
        number_of_values = discrete_pie.getNumberOfValues();
        System.out.println("######   number_of_values = " + number_of_values);
        for (i = 0; i < number_of_values; i++)
        {
          ValueDiscrete value = discrete_pie.getValue(i);
          values.put(Integer.valueOf(pie.getNumber()), discrete_pie.getValue(i));
          
          Evaluator eval = this.utilitySpace.getEvaluator(pie.getNumber());
          EvaluatorDiscrete evalDiscrete = (EvaluatorDiscrete)eval;
          Integer evaluation = evalDiscrete.getValue(value);
          


          System.out.println("######   i=" + i + "\t u(" + value.getValue() + ") = " + getUtility(new Bid(this.utilitySpace.getDomain(), values)) + "\t" + "  eval(" + value.getValue() + ") = " + evaluation);
          if (i > number_of_values - m) {
            max_values.add(value);
          }
          if ((evaluation.intValue() != 0) && (flag))
          {
            rvB = i;
            this.utilitySpace.setReservationValue(rvB);
            flag = false;
          }
        }
        System.out.println("\n#########  generating an example of bids vector ###################################");
        for (i = 1; i < ((IssueDiscrete)pie).getNumberOfValues(); i++)
        {
          HashMap<Value, Double> h = new HashMap();
          h.put(discrete_pie.getValue(i), new Double(n * bids(i)));
          
          stack_h.push(h);
        }
        stack_hc.addAll(stack_h);
        

        stack_aux.push(stack_h.pop());
        while (!stack_h.isEmpty()) {
          if (((Double)((HashMap)stack_h.get(stack_h.size() - 1)).values().iterator().next()).equals(((HashMap)stack_aux.get(stack_aux.size() - 1)).values().iterator().next())) {
            stack_h.pop();
          } else {
            stack_aux.push(stack_h.pop());
          }
        }
        for (i = 0; i < stack_aux.size();)
        {
          System.out.println("######     " + i + "  =>  " + stack_aux.get(i));i++; continue;
          



          throw new Exception("Type " + pie.getType() + " not supported by TAgent.");
        }
      }
    }
    catch (Exception e)
    {
      Issue pie;
      int i;
      e.printStackTrace();
    }
  }
  
  private int estimated_rounds_left(boolean opponent)
  {
    if (opponent == true)
    {
      if (timeLeftBeforeAction - timeLeftAfterAction > OpponentMaxDuration) {
        OpponentMaxDuration = timeLeftBeforeAction - timeLeftAfterAction;
      }
    }
    else if (timeLeftAfterAction - timeLeftBeforeAction > OwnMaxDuration) {
      OwnMaxDuration = timeLeftAfterAction - timeLeftBeforeAction;
    }
    if (OpponentMaxDuration + OwnMaxDuration == 0.0D) {
      System.out.println("./0 Exception!");
    }
    double totalDuration = OpponentMaxDuration + OwnMaxDuration;double round = (totalTime - this.timeline.getCurrentTime()) / totalDuration;
    if (((int)round > d) && ((int)round < 1000)) {
      d = (int)round;
    }
    return (int)round;
  }
  
  public String getVersion()
  {
    return "1.0 (Genius 4.2)";
  }
  
  public String getName()
  {
    return "TAgent";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.actionOfPartner = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action action = null;
    try
    {
      timeLeftBeforeAction = this.timeline.getCurrentTime();
      if (this.actionOfPartner == null) {
        action = chooseOSRAction();
      }
      if ((this.actionOfPartner instanceof Offer))
      {
        Bid partnerBid = ((Offer)this.actionOfPartner).getBid();
        
        System.out.println("######   partnerBid === " + partnerBid);
        System.out.println("######   partnerBid.getValues() === " + partnerBid.getValue(1));
        

        double offeredUtilFromOpponent = getUtility(partnerBid);
        
        double time = this.timeline.getTime();
        
        action = chooseOSRAction();
        
        Bid myBid = ((Offer)action).getBid();
        double myOfferedUtil = getUtility(myBid);
        System.out.println("######    u(myBid = " + myBid.getValue(1) + ")  = " + myOfferedUtil);
        
        System.out.println("==========================================================================");
      }
      if (this.timeline.getType().equals(Timeline.Type.Time)) {
        sleep(0.005D);
      }
      timeLeftAfterAction = this.timeline.getCurrentTime();
      estimated_rounds_left(false);
    }
    catch (Exception e)
    {
      System.out.println("Exception in ChooseAction:" + e.getMessage());
      action = new Accept(getAgentID());
    }
    return action;
  }
  
  private boolean isAcceptable(double offeredUtilFromOpponent, double myOfferedUtil, double time)
    throws Exception
  {
    double P = Paccept(offeredUtilFromOpponent, time);
    if (P > Math.random()) {
      return true;
    }
    return false;
  }
  
  private Action chooseOSRAction()
  {
    Bid nextOSRBid = null;
    try
    {
      nextOSRBid = getOSRBid();
    }
    catch (Exception e)
    {
      System.out.println("Problem with received bid:" + e.getMessage() + ". cancelling bidding");
    }
    if (nextOSRBid == null) {
      return new Accept(getAgentID());
    }
    return new Offer(getAgentID(), nextOSRBid);
  }
  
  private Bid getOSRBid()
    throws Exception
  {
    Bid bid = null;
    HashMap<Integer, Value> val = new HashMap();
    if (all_osr_cuttofs)
    {
      Iterator i$ = ((HashMap)stack_hc.pop()).keySet().iterator();
      if (i$.hasNext())
      {
        Value key = (Value)i$.next();
        
        val.put(Integer.valueOf(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber()), key);
        
        counter += 1;
      }
      System.out.println("\n\t       t  =  " + this.timeline.getTime() + "\n\t    size  =  " + stack_hc.size() + "\n\t getCurrentTime  =  " + this.timeline.getCurrentTime() * 1000.0D + "\n\t getTotalTime    =  " + this.timeline.getTotalTime() * 1000.0D + "\n\t estimate rounds left    =  " + estimated_rounds_left(false));
    }
    else
    {
      for (Value key : ((HashMap)stack_hc.get(800 + idx)).keySet()) {
        val.put(Integer.valueOf(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber()), key);
      }
      System.out.println("###########################################################################################");
      
      System.out.println("###### " + stack_aux.size() + " rounds before deadline ##### erl = " + idx + " ############");
      

      System.out.println("###### val = " + val + " ############");
      System.out.println("###########################################################################################");
      

      idx += 1;
    }
    if ((unused) && 
      (estimated_rounds_left(true) < 10))
    {
      System.out.println("###########################################################################################");
      
      System.out.println("######   Approaching deadline! ############################################################");
      
      System.out.println("###########################################################################################");
      for (Value key : ((HashMap)stack_h.get(stack_h.size() - estimated_rounds_left(true))).keySet()) {
        val.put(Integer.valueOf(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber()), key);
      }
      bid = new Bid(this.utilitySpace.getDomain(), val);
      System.out.println("  >>>>>  val = " + val + " \t utility = " + getUtility(bid));
      

      System.out.println("\n##############################################");
      

      System.out.println("\n");
      for (int k = 0; k < stack_h.size(); k++) {
        System.out.print("    " + k + "  =>   " + stack_h.get(k));
      }
      System.out.println("***************************************************************************");
      
      System.out.println("\t   d = " + d);
      System.out.println("***************************************************************************");
      

      System.out.println("\n");
    }
    bid = new Bid(this.utilitySpace.getDomain(), val);
    
    System.out.println("######  offering bid = " + bid);
    
    return bid;
  }
  
  double Paccept(double u, double t1)
    throws Exception
  {
    double t = t1 * t1 * t1;
    if ((u < 0.0D) || (u > 1.05D)) {
      throw new Exception("utility " + u + " outside [0,1]");
    }
    if ((t < 0.0D) || (t > 1.0D)) {
      throw new Exception("time " + t + " outside [0,1]");
    }
    if (u > 1.0D) {
      u = 1.0D;
    }
    if (t == 0.5D) {
      return u;
    }
    return (u - 2.0D * u * t + 2.0D * (-1.0D + t + Math.sqrt(sq(-1.0D + t) + u * (-1.0D + 2.0D * t)))) / (-1.0D + 2.0D * t);
  }
  
  double sq(double x)
  {
    return x * x;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.TAgent
 * JD-Core Version:    0.7.1
 */