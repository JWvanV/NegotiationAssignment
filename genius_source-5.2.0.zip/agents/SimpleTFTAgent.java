package agents;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class SimpleTFTAgent
  extends Agent
{
  private static int round = 0;
  private Bid myLastBid = null;
  private Action opponentAction = null;
  private List<Bid> opponentPreviousBids;
  
  public void init()
  {
    this.opponentPreviousBids = new ArrayList();
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.opponentAction = opponentAction;
  }
  
  public Action chooseAction()
  {
    Action myAction = null;
    if (round == 0) {
      myAction = chooseOpeningAction();
    } else if (round == 1) {
      myAction = chooseOffer2();
    } else if (round == 2) {
      myAction = chooseOffer3();
    } else if (round == 3) {
      myAction = chooseOffer4();
    } else if ((this.opponentAction instanceof Offer)) {
      myAction = chooseCounterOffer();
    }
    try
    {
      Thread.sleep(1000L);
    }
    catch (InterruptedException e)
    {
      e.printStackTrace();
    }
    if ((myAction instanceof Offer)) {
      this.myLastBid = ((Offer)myAction).getBid();
    }
    if ((this.opponentAction instanceof Offer)) {
      this.opponentPreviousBids.add(((Offer)this.opponentAction).getBid());
    }
    System.out.println("Round " + round + ", " + getName() + " offers " + myAction);
    
    round += 1;
    
    return myAction;
  }
  
  private Action chooseCounterOffer()
  {
    Bid opponentBid = ((Offer)this.opponentAction).getBid();
    double opponentOffer = toOffer(opponentBid);
    Bid opponentPreviousBid = (Bid)this.opponentPreviousBids.get(this.opponentPreviousBids
      .size() - 1);
    double previousOpponentOffer = toOffer(opponentPreviousBid);
    
    double myPreviousOffer = toOffer(this.myLastBid);
    


    double myOffer = previousOpponentOffer - opponentOffer + myPreviousOffer;
    if (getName().equals("Agent B")) {
      myOffer = 0.3D - 5.0D / round * 0.1D;
    }
    Domain domain = this.utilitySpace.getDomain();
    Issue pieForOne = (Issue)domain.getIssues().get(0);
    HashMap<Integer, Value> myOfferedPackage = new HashMap();
    ValueReal value = new ValueReal(myOffer);
    myOfferedPackage.put(Integer.valueOf(pieForOne.getNumber()), value);
    Bid firstBid = null;
    try
    {
      firstBid = new Bid(domain, myOfferedPackage);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    System.out.println(getName() + " previously got " + previousOpponentOffer + " and now gets offer " + opponentOffer + " and counter-offers " + myOffer);
    





    return new Offer(getAgentID(), firstBid);
  }
  
  private double toOffer(Bid bid)
  {
    Domain domain = this.utilitySpace.getDomain();
    Issue pieForOne = (Issue)domain.getIssues().get(0);
    try
    {
      return ((ValueReal)bid.getValue(pieForOne.getNumber())).getValue();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return -1.0D;
  }
  
  private ValueReal personalValue2IssueValue(double personalValue)
  {
    ValueReal value;
    ValueReal value;
    if (getName().equals("Agent A")) {
      value = new ValueReal(personalValue);
    } else {
      value = new ValueReal(1.0D - personalValue);
    }
    return value;
  }
  
  private Action chooseOpeningAction()
  {
    Domain domain = this.utilitySpace.getDomain();
    Issue pie = (Issue)domain.getIssues().get(0);
    HashMap<Integer, Value> myOfferedPackage = new HashMap();
    myOfferedPackage.put(Integer.valueOf(pie.getNumber()), personalValue2IssueValue(0.9D));
    Bid firstBid = null;
    try
    {
      firstBid = new Bid(domain, myOfferedPackage);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(getAgentID(), firstBid);
  }
  
  private Action chooseOffer2()
  {
    Domain domain = this.utilitySpace.getDomain();
    Issue pie = (Issue)domain.getIssues().get(0);
    HashMap<Integer, Value> myOfferedPackage = new HashMap();
    myOfferedPackage.put(Integer.valueOf(pie.getNumber()), personalValue2IssueValue(0.9D));
    Bid firstBid = null;
    try
    {
      firstBid = new Bid(domain, myOfferedPackage);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(getAgentID(), firstBid);
  }
  
  private Action chooseOffer3()
  {
    Domain domain = this.utilitySpace.getDomain();
    Issue pie = (Issue)domain.getIssues().get(0);
    HashMap<Integer, Value> myOfferedPackage = new HashMap();
    myOfferedPackage.put(Integer.valueOf(pie.getNumber()), personalValue2IssueValue(0.8D));
    Bid firstBid = null;
    try
    {
      firstBid = new Bid(domain, myOfferedPackage);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(getAgentID(), firstBid);
  }
  
  private Action chooseOffer4()
  {
    Domain domain = this.utilitySpace.getDomain();
    Issue pie = (Issue)domain.getIssues().get(0);
    HashMap<Integer, Value> myOfferedPackage = new HashMap();
    myOfferedPackage.put(Integer.valueOf(pie.getNumber()), personalValue2IssueValue(0.85D));
    Bid firstBid = null;
    try
    {
      firstBid = new Bid(domain, myOfferedPackage);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return new Offer(getAgentID(), firstBid);
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.SimpleTFTAgent
 * JD-Core Version:    0.7.1
 */