package agents;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import negotiator.Agent;
import negotiator.Bid;
import negotiator.Domain;
import negotiator.SupportedNegotiationSetting;
import negotiator.actions.Accept;
import negotiator.actions.Action;
import negotiator.actions.Offer;
import negotiator.issue.Issue;
import negotiator.issue.Value;
import negotiator.issue.ValueReal;
import negotiator.utility.UtilitySpace;

public class FuzzyAgent
  extends Agent
{
  private static int deadline = 100;
  private static int deadlineB = 100;
  private static int deadlineS = 100;
  private static double[][] BuyOffer;
  private static double[][] SellOffer;
  private static int tacticB;
  private static int tacticS;
  private static double K = 0.1D;
  private static double MaxB = 40.0D;
  private static double MinB = 10.0D;
  private static double MaxS = 40.0D;
  private static double MinS = 10.0D;
  private static boolean deal = false;
  private static double Utl = 0.0D;
  private static double BBuy;
  private static double BSell;
  private static double BBuyStretch;
  private static double BSellStretch;
  private static int LBuy;
  private static int LSell;
  private static int iteration = 1;
  private static int MBuy;
  private static int MSell;
  private static double AcceptedValue = 0.0D;
  private static int itercount = 0;
  private static double Scons;
  private static double Bcons;
  private static boolean CBuy = false;
  private static boolean CSell = false;
  private static double[] dist;
  private static double percentageB1;
  private static double percentageB2;
  private static double percentageS1;
  private static double percentageS2;
  private static double threshholdB;
  private static double threshholdS;
  private static final int BUYER = 1;
  private static final int SELLER = 2;
  private int fPlayingFor;
  private int fRound;
  
  public Action chooseAction()
  {
    double lNextBidValue = 0.0D;
    Action lAction = null;
    switch (this.fPlayingFor)
    {
    case 1: 
      deal = Buyer(this.fRound);
      lNextBidValue = BuyOffer[this.fRound][0];
      break;
    case 2: 
      deal = Seller(this.fRound);
      lNextBidValue = SellOffer[this.fRound][0];
    }
    if (deal)
    {
      lAction = new Accept(getAgentID());
    }
    else
    {
      HashMap<Integer, Value> lValues = new HashMap();
      ValueReal lValue = new ValueReal(lNextBidValue);
      lValues.put(Integer.valueOf(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber()), lValue);
      try
      {
        Bid lBid = new Bid(this.utilitySpace.getDomain(), lValues);
        lAction = new Offer(getAgentID(), lBid);
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }
    }
    return lAction;
  }
  
  public String getVersion()
  {
    return "1.0";
  }
  
  public void init()
  {
    this.fRound = 0;
    dist = new double[deadline + 1];
    BuyOffer = new double[deadlineB + 1][2];
    SellOffer = new double[deadlineS + 1][2];
    BuyOffer[0][0] = MinB;
    SellOffer[0][0] = MaxS;
    BuyOffer[0][1] = (BuyOffer[0][0] + percentageB1 * Bcons);
    SellOffer[0][1] = (SellOffer[0][0] - percentageS1 * Scons);
    if (getName().equals("Seller")) {
      this.fPlayingFor = 1;
    } else {
      this.fPlayingFor = 2;
    }
    tacticB = 1;
    tacticS = 1;
    BBuy = 0.01D;
    LBuy = 2;
    MBuy = 2;
    BSell = 50.0D;
    LSell = 2;
    MSell = 2;
    Bcons = 1.0D;
    Scons = 1.0D;
    BBuyStretch = 0.1D;
    BSellStretch = 0.1D;
    
    threshholdB = ThreshFind(deadlineB, 0, BuyOffer[0][0], BuyOffer[0][1]);
    threshholdS = ThreshFind(deadlineS, 0, SellOffer[0][0], SellOffer[0][1]);
  }
  
  public void ReceiveMessage(Action opponentAction)
  {
    this.fRound += 1;
    if ((opponentAction instanceof Offer))
    {
      Offer lOffer = (Offer)opponentAction;
      Bid lBid = lOffer.getBid();
      switch (this.fPlayingFor)
      {
      case 1: 
        try
        {
          SellOffer[this.fRound][0] = ((ValueReal)(ValueReal)lBid.getValue(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber())).getValue();
          

          SellOffer[this.fRound][1] = (SellOffer[this.fRound][0] + percentageB1 * Bcons);
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      case 2: 
        try
        {
          BuyOffer[this.fRound][0] = ((ValueReal)(ValueReal)lBid.getValue(((Issue)this.utilitySpace.getDomain().getIssues().get(0)).getNumber())).getValue();
          

          BuyOffer[this.fRound][1] = (BuyOffer[this.fRound][0] - percentageS1 * Scons);
        }
        catch (Exception e)
        {
          e.printStackTrace();
        }
      }
    }
  }
  
  public static double CalculateCost(double constant, int NoIteration)
  {
    double cost = (Math.exp(NoIteration * constant) - Math.exp(-NoIteration * constant)) / (Math.pow(2.718281828459045D, NoIteration * constant) + Math.pow(2.718281828459045D, -NoIteration * constant));
    



    return cost;
  }
  
  protected static boolean Buyer(int i)
  {
    double A = 0.0D;
    itercount += 1;
    double[] inter = new double[0];
    switch (tacticB)
    {
    case 1: 
      if (i > deadlineB) {
        return true;
      }
      Utl = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
      if (i > 0)
      {
        Utl = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
        if (!CSell) {
          if ((SellOffer[(i - 1)][1] <= BuyOffer[(i - 1)][1]) && (i <= deadlineB))
          {
            double[] xParams = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[(i - 1)][0], BuyOffer[(i - 1)][1] };
            if (BuyOffer[(i - 1)][1] == BuyOffer[(i - 1)][0])
            {
              CBuy = false;
            }
            else
            {
              double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[(i - 1)][0], BuyOffer[(i - 1)][1] };
              

              xParams = x;
              double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
              inter = Intersection(xParams, yParams);
              if (inter[0] <= threshholdB) {
                CBuy = true;
              } else {
                CBuy = false;
              }
            }
          }
        }
      }
      if ((BBuy == 0.01D) || (BBuy == 0.2D)) {
        A = Math.exp(Math.pow(1.0D - Math.min(i + 1, deadlineB) / deadlineB, BBuy) * Math.log(K));
      } else {
        A = K + (1.0D - K) * Math.pow(Math.min(i + 1, deadlineB) / deadlineB, 1.0D / BBuy);
      }
      double tmp = MinB + (MaxB - MinB) * A;
      double tmpUtl = (MaxB - tmp) / (MaxB - MinB);
      if ((CSell == true) && (i >= 2))
      {
        if (SellOffer[(i - 1)][0] <= threshholdB)
        {
          AcceptedValue = SellOffer[(i - 1)][0];
          return true;
        }
        CSell = false;
      }
      if (((float)tmpUtl < (float)Utl) && (!CBuy))
      {
        AcceptedValue = SellOffer[(i - 1)][0];
        return true;
      }
      if (CBuy == true)
      {
        BuyOffer[i][0] = inter[0];
        BuyOffer[i][1] = BuyOffer[i][0];
      }
      else
      {
        BuyOffer[i][0] = tmp;
        if ((BBuyStretch == 0.01D) || (BBuyStretch == 0.2D)) {
          A = Math.exp(Math.pow(1.0D - Math.min(i + 1, deadlineB) / deadlineB, BBuyStretch) * Math.log(K));
        } else {
          A = K + (1.0D - K) * Math.pow(Math.min(i + 1, deadlineB) / deadlineB, 1.0D / BBuyStretch);
        }
        double tmpBcons = percentageB2 * Bcons + (percentageB1 - percentageB2) * Bcons * (1.0D - A);
        if (BuyOffer[i][0] + tmpBcons >= MaxB) {
          BuyOffer[i][1] = MaxB;
        } else {
          BuyOffer[i][1] = (BuyOffer[i][0] + tmpBcons);
        }
      }
      threshholdB = ThreshFind(deadlineB, i + 1, BuyOffer[i][0], BuyOffer[i][1]);
      
      return false;
    case 2: 
      if (i > deadlineB) {
        return true;
      }
      if (i > 0)
      {
        Utl = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
        if (!CSell) {
          if ((SellOffer[(i - 1)][1] <= BuyOffer[(i - 1)][1]) && (i <= deadlineB))
          {
            double[] xParams = new double[4];
            if (BuyOffer[(i - 1)][0] == BuyOffer[(i - 1)][1])
            {
              CBuy = false;
            }
            else
            {
              double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[(i - 1)][0], BuyOffer[(i - 1)][1] };
              

              xParams = x;
              CBuy = true;
              double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
              inter = Intersection(xParams, yParams);
              double DifUtlOurs = (MaxB - BuyOffer[(i - 1)][0]) / (MaxB - MinB);
              
              double MidUtl = (MaxB - inter[0]) / (MaxB - MinB);
              
              DifUtlOurs -= MidUtl;
              double DifUtlOps = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
              
              DifUtlOps = MidUtl - DifUtlOps;
              
              CBuy = true;
              MinB = inter[0];
            }
          }
        }
      }
      if ((CSell == true) && (i >= 2))
      {
        double DifUtlOurs = (MaxB - BuyOffer[(i - 1)][0]) / (MaxB - MinB);
        
        DifUtlOurs -= Utl;
        double DifUtlOps = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
        
        DifUtlOps = Utl - DifUtlOps;
        if ((float)DifUtlOurs <= (float)DifUtlOps)
        {
          AcceptedValue = SellOffer[(i - 1)][0];
          return true;
        }
        CSell = false;
      }
      if (LBuy == 3)
      {
        Random generator = new Random();
        if (i > LBuy)
        {
          double tmp3 = Math.min(Math.max(BuyOffer[(i - 1)][0] + SellOffer[(i - 1 - LBuy)][0] - SellOffer[(i - 1)][0] + 2.0D, MinB), MaxB);
          



          double tmpUtl3 = (MaxB - tmp3) / (MaxB - MinB);
          if (((float)tmpUtl3 <= (float)Utl) && (!CBuy))
          {
            AcceptedValue = SellOffer[(i - 1)][0];
            return true;
          }
          if (CBuy == true)
          {
            BuyOffer[i][0] = inter[0];
            BuyOffer[i][1] = BuyOffer[i][0];
          }
          else
          {
            BuyOffer[i][0] = tmp3;
            if (BuyOffer[i][0] + Bcons >= MaxB) {
              BuyOffer[i][1] = MaxB;
            } else {
              BuyOffer[i][1] = (BuyOffer[i][0] + Bcons);
            }
          }
          return false;
        }
        BuyOffer[i][0] = (MinB + i * 0.5D);
        BuyOffer[i][1] = (MinB + i * 0.5D + Bcons);
        return false;
      }
      if (i > LBuy)
      {
        double tmp2 = Math.min(Math.max(SellOffer[(i - 1 - LBuy)][0] / SellOffer[(i - 1)][0] * BuyOffer[(i - 1)][0], MinB), MaxB);
        






        double tmpUtl2 = (MaxB - tmp2) / (MaxB - MinB);
        if (((float)tmpUtl2 <= (float)Utl) && (!CBuy))
        {
          AcceptedValue = SellOffer[(i - 1)][0];
          return true;
        }
        if (CBuy == true)
        {
          BuyOffer[i][0] = inter[0];
          BuyOffer[i][1] = BuyOffer[i][0];
        }
        else
        {
          BuyOffer[i][0] = tmp2;
          if (BuyOffer[i][0] + Bcons >= MaxB) {
            BuyOffer[i][1] = MaxB;
          } else {
            BuyOffer[i][1] = (BuyOffer[i][0] + Bcons);
          }
        }
        return false;
      }
      BuyOffer[i][0] = (MinB + i * 0.5D);
      BuyOffer[i][1] = (MinB + i * 0.5D + Bcons);
      return false;
    case 3: 
      if (i > deadlineB) {
        return true;
      }
      if (i > 0)
      {
        Utl = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
        if (!CSell) {
          if ((SellOffer[(i - 1)][1] <= BuyOffer[(i - 1)][1]) && (i <= deadlineB))
          {
            double[] xParams = new double[4];
            if (BuyOffer[(i - 1)][0] == BuyOffer[(i - 1)][1])
            {
              CBuy = false;
            }
            else
            {
              double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[(i - 1)][0], BuyOffer[(i - 1)][1] };
              

              xParams = x;
              CBuy = true;
              double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
              inter = Intersection(xParams, yParams);
              double DifUtlOurs = (MaxB - BuyOffer[(i - 1)][0]) / (MaxB - MinB);
              
              double MidUtl = (MaxB - inter[0]) / (MaxB - MinB);
              
              DifUtlOurs -= MidUtl;
              
              double DifUtlOps = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
              
              DifUtlOps = MidUtl - DifUtlOps;
              


              CBuy = true;
              MinB = inter[0];
            }
          }
        }
      }
      if ((CSell == true) && (i >= 2))
      {
        double DifUtlOurs = (MaxB - BuyOffer[(i - 1)][0]) / (MaxB - MinB);
        
        DifUtlOurs -= Utl;
        double DifUtlOps = (MaxB - SellOffer[(i - 1)][0]) / (MaxB - MinB);
        
        DifUtlOps = Utl - DifUtlOps;
        if ((float)DifUtlOurs <= (float)DifUtlOps)
        {
          AcceptedValue = SellOffer[(i - 1)][0];
          return true;
        }
        CSell = false;
      }
      double resource = new Double(MBuy * (1.0D / (i + 1))).doubleValue();
      
      A = K + (1.0D - K) * (1.0D / Math.exp(resource));
      double tmp4 = MinB + (MaxB - MinB) * A;
      double tmpUtl4 = (MaxB - tmp4) / (MaxB - MinB);
      if (((float)tmpUtl4 <= (float)Utl) && (!CBuy))
      {
        AcceptedValue = SellOffer[(i - 1)][0];
        return true;
      }
      if (CBuy == true)
      {
        BuyOffer[i][0] = inter[0];
        BuyOffer[i][1] = BuyOffer[i][0];
      }
      else
      {
        BuyOffer[i][0] = tmp4;
        if (BuyOffer[i][0] + Bcons >= MaxB) {
          BuyOffer[i][1] = MaxB;
        } else {
          BuyOffer[i][1] = (BuyOffer[i][0] + Bcons);
        }
      }
      return false;
    }
    return false;
  }
  
  protected static boolean Seller(int i)
  {
    double A = 0.0D;
    itercount += 1;
    double[] inter = new double[0];
    switch (tacticS)
    {
    case 1: 
      if (i > deadlineS) {
        return true;
      }
      Utl = (BuyOffer[i][0] - MinS) / (MaxS - MinS);
      if ((i > 0) && 
        (!CBuy)) {
        if ((SellOffer[(i - 1)][1] <= BuyOffer[i][1]) && (i <= deadlineS))
        {
          double[] xParams = new double[4];
          if (SellOffer[(i - 1)][0] == SellOffer[(i - 1)][1])
          {
            CSell = false;
          }
          else
          {
            double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[i][0], BuyOffer[i][1] };
            

            xParams = x;
            double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
            inter = Intersection(xParams, yParams);
            if (inter[0] >= threshholdS) {
              CSell = true;
            } else {
              CSell = false;
            }
          }
        }
      }
      if ((BSell == 0.01D) || (BSell == 0.2D)) {
        A = Math.exp(Math.pow(1.0D - Math.min(i + 1, deadlineS) / deadlineS, BSell) * Math.log(K));
      } else {
        A = K + (1.0D - K) * Math.pow(Math.min(i + 1, deadlineS) / deadlineS, 1.0D / BSell);
      }
      double tmp = MinS + (MaxS - MinS) * (1.0D - A);
      double tmpUtl = (tmp - MinS) / (MaxS - MinS);
      if (CBuy == true)
      {
        if (BuyOffer[i][0] >= threshholdS)
        {
          AcceptedValue = BuyOffer[i][0];
          return true;
        }
        CBuy = false;
      }
      if (((float)tmpUtl <= (float)Utl) && (!CSell))
      {
        AcceptedValue = BuyOffer[i][0];
        return true;
      }
      if (CSell == true)
      {
        SellOffer[i][0] = inter[0];
        SellOffer[i][1] = SellOffer[i][0];
      }
      else
      {
        SellOffer[i][0] = tmp;
        if ((BSellStretch == 0.01D) || (BSellStretch == 0.2D)) {
          A = Math.exp(Math.pow(1.0D - Math.min(i + 1, deadlineS) / deadlineS, BSellStretch) * Math.log(K));
        } else {
          A = K + (1.0D - K) * Math.pow(Math.min(i + 1, deadlineS) / deadlineS, 1.0D / BSellStretch);
        }
        double tmpScons = percentageS2 * Scons + (percentageS1 - percentageS2) * Scons * (1.0D - A);
        if (SellOffer[i][0] - tmpScons <= MinS) {
          SellOffer[i][1] = MinS;
        } else {
          SellOffer[i][1] = (SellOffer[i][0] - tmpScons);
        }
      }
      threshholdS = ThreshFind(deadlineS, i + 1, SellOffer[i][0], SellOffer[i][1]);
      
      return false;
    case 2: 
      if (i > deadlineS) {
        return true;
      }
      Utl = (BuyOffer[i][0] - MinS) / (MaxS - MinS);
      if (i > 0)
      {
        if (!CBuy) {
          if ((SellOffer[(i - 1)][1] <= BuyOffer[i][1]) && (i <= deadlineS))
          {
            double[] xParams = new double[4];
            if (SellOffer[(i - 1)][0] == SellOffer[(i - 1)][1])
            {
              CSell = false;
            }
            else
            {
              double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[i][0], BuyOffer[i][1] };
              

              xParams = x;
              CSell = true;
              double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
              inter = Intersection(xParams, yParams);
              double DifUtlOurs = (SellOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
              
              double MinUtl = (inter[0] - MinS) / (MaxS - MinS);
              
              DifUtlOurs -= MinUtl;
              double DifUtlOps = (BuyOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
              
              DifUtlOps = Utl - DifUtlOps;
              
              MaxS = inter[0];
              CSell = true;
            }
          }
        }
        if (CBuy == true)
        {
          double DifUtlOurs = (SellOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
          
          DifUtlOurs -= Utl;
          double DifUtlOps = (BuyOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
          
          DifUtlOps = Utl - DifUtlOps;
          if ((float)DifUtlOurs <= (float)DifUtlOps)
          {
            AcceptedValue = BuyOffer[i][0];
            return true;
          }
          CBuy = false;
        }
      }
      if (LSell == 3)
      {
        Random generator = new Random();
        int rand = generator.nextInt(4);
        rand = 2;
        if (i >= LSell)
        {
          double tmp3 = Math.min(Math.max(SellOffer[(i - 1)][0] + BuyOffer[(i - LSell)][0] - BuyOffer[i][0] - rand, MinS), MaxS);
          


          double tmpUtl3 = (tmp3 - MinS) / (MaxS - MinS);
          if (((float)tmpUtl3 <= (float)Utl) && (!CSell))
          {
            AcceptedValue = BuyOffer[i][0];
            return true;
          }
          if (CSell == true)
          {
            SellOffer[i][0] = inter[0];
            SellOffer[i][1] = SellOffer[i][0];
          }
          else
          {
            SellOffer[i][0] = tmp3;
            if (SellOffer[i][0] - Scons <= MinS) {
              SellOffer[i][1] = MinS;
            } else {
              SellOffer[i][1] = (SellOffer[i][0] - Scons);
            }
          }
          return false;
        }
        SellOffer[i][0] = (MaxS - i * 0.5D);
        SellOffer[i][1] = (MaxS - i * 0.5D - Scons);
        return false;
      }
      if (i >= LSell)
      {
        double tmp2 = Math.min(Math.max(BuyOffer[(i - LSell)][0] / BuyOffer[i][0] * SellOffer[(i - 1)][0], MinS), MaxS);
        


        Utl = (BuyOffer[i][0] - MinS) / (MaxS - MinS);
        
        double tmpUtl2 = (tmp2 - MinS) / (MaxS - MinS);
        if (((float)tmpUtl2 <= (float)Utl) && (!CSell))
        {
          AcceptedValue = BuyOffer[i][0];
          return true;
        }
        if (CSell == true)
        {
          SellOffer[i][0] = inter[0];
          SellOffer[i][1] = SellOffer[i][0];
        }
        else
        {
          SellOffer[i][0] = tmp2;
          if (SellOffer[i][0] - Scons <= MinS) {
            SellOffer[i][1] = MinS;
          } else {
            SellOffer[i][1] = (SellOffer[i][0] - Scons);
          }
        }
        return false;
      }
      SellOffer[i][0] = (MaxS - i * 0.5D);
      SellOffer[i][1] = (MaxS - i * 0.5D - Scons);
      return false;
    case 3: 
      if (i > deadlineS) {
        return true;
      }
      Utl = (BuyOffer[i][0] - MinS) / (MaxS - MinS);
      if (i > 0) {
        if (!CBuy)
        {
          if ((SellOffer[(i - 1)][1] <= BuyOffer[i][1]) && (i <= deadlineS))
          {
            double[] xParams = new double[4];
            if (SellOffer[(i - 1)][0] == SellOffer[(i - 1)][1])
            {
              CSell = false;
            }
            else
            {
              double[] x = { SellOffer[(i - 1)][1], SellOffer[(i - 1)][0], BuyOffer[i][0], BuyOffer[i][1] };
              

              xParams = x;
              CSell = true;
              double[] yParams = { 0.0D, 1.0D, 1.0D, 0.0D };
              inter = Intersection(xParams, yParams);
              double DifUtlOurs = (SellOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
              
              double MinUtl = (inter[0] - MinS) / (MaxS - MinS);
              
              DifUtlOurs -= MinUtl;
              double DifUtlOps = (BuyOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
              
              DifUtlOps = Utl - DifUtlOps;
              
              MaxS = inter[0];
              CSell = true;
            }
          }
        }
        else if (CBuy == true)
        {
          double DifUtlOurs = (SellOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
          
          DifUtlOurs -= Utl;
          double DifUtlOps = (BuyOffer[(i - 1)][0] - MinS) / (MaxS - MinS);
          
          DifUtlOps = Utl - DifUtlOps;
          if ((float)DifUtlOurs <= (float)DifUtlOps)
          {
            AcceptedValue = BuyOffer[i][0];
            return true;
          }
          CBuy = false;
        }
      }
      double resource = new Double(MSell * (1.0D / (i + 1))).doubleValue();
      
      A = K + (1.0D - K) * (1.0D / Math.exp(resource));
      double tmp4 = MinS + (MaxS - MinS) * (1.0D - A);
      double tmpUtl4 = (tmp4 - MinS) / (MaxS - MinS);
      if (((float)tmpUtl4 < (float)Utl) && (!CSell))
      {
        AcceptedValue = BuyOffer[i][0];
        return true;
      }
      if (CSell == true)
      {
        SellOffer[i][0] = inter[0];
        SellOffer[i][1] = SellOffer[i][0];
      }
      else
      {
        SellOffer[i][0] = tmp4;
        if (SellOffer[i][0] - Scons <= MinS) {
          SellOffer[i][1] = MinS;
        } else {
          SellOffer[i][1] = (SellOffer[i][0] - Scons);
        }
      }
      return false;
    }
    return false;
  }
  
  public static double ThreshFind(int deadline, int time, double pick, double stretch)
  {
    double weightStretch = time / deadline;
    double weightPick = (deadline - time) / deadline;
    double thresh = weightPick * pick + weightStretch * stretch;
    return thresh;
  }
  
  public static double[] Intersection(double[] xPars, double[] yPars)
  {
    double ua = 0.0D;
    ua = ((xPars[3] - xPars[2]) * (yPars[0] - yPars[2]) - (yPars[3] - yPars[2]) * (xPars[0] - xPars[2])) / ((yPars[3] - yPars[2]) * (xPars[1] - xPars[0]) - (xPars[3] - xPars[2]) * (yPars[1] - yPars[0]));
    
    double[] interPoint = new double[2];
    xPars[0] += ua * (xPars[1] - xPars[0]);
    interPoint[1] = (yPars[0] + ua * (yPars[1] - yPars[0]));
    return interPoint;
  }
  
  public static void FuzzyDist()
  {
    double midPointXB = 0.0D;
    double midPointYB = 0.0D;
    double midPointXS = 0.0D;
    double midPointYS = 0.0D;
    if (BuyOffer[(iteration - 1)][0] != BuyOffer[(iteration - 1)][1])
    {
      midPointXB += (3.0D * (Math.pow(BuyOffer[(iteration - 1)][0], 2.0D) * BuyOffer[(iteration - 1)][1]) - Math.pow(BuyOffer[(iteration - 1)][1], 3.0D) - 2.0D * Math.pow(BuyOffer[(iteration - 1)][0], 3.0D)) / (6.0D * (BuyOffer[(iteration - 1)][0] - BuyOffer[(iteration - 1)][1]));
      


      midPointXB /= (2.0D * BuyOffer[(iteration - 1)][1] * BuyOffer[(iteration - 1)][0] - Math.pow(BuyOffer[(iteration - 1)][1], 2.0D) - Math.pow(BuyOffer[(iteration - 1)][0], 2.0D)) / (2.0D * (BuyOffer[(iteration - 1)][0] - BuyOffer[(iteration - 1)][1]));
      


      midPointYB = 0.5D;
    }
    else
    {
      midPointXB = BuyOffer[(iteration - 1)][0];
    }
    if (SellOffer[(iteration - 1)][0] != SellOffer[(iteration - 1)][1])
    {
      midPointXS += (3.0D * (Math.pow(SellOffer[(iteration - 1)][1], 2.0D) * SellOffer[(iteration - 1)][0]) - Math.pow(SellOffer[(iteration - 1)][0], 3.0D) - 2.0D * Math.pow(SellOffer[(iteration - 1)][1], 3.0D)) / (6.0D * (SellOffer[(iteration - 1)][0] - SellOffer[(iteration - 1)][1]));
      


      midPointXS /= (2.0D * SellOffer[(iteration - 1)][1] * SellOffer[(iteration - 1)][0] - Math.pow(SellOffer[(iteration - 1)][1], 2.0D) - Math.pow(SellOffer[(iteration - 1)][0], 2.0D)) / (2.0D * (SellOffer[(iteration - 1)][0] - SellOffer[(iteration - 1)][1]));
      



      midPointYS = 0.5D;
    }
    else
    {
      midPointXS = SellOffer[(iteration - 1)][0];
    }
    double last = Math.sqrt(Math.pow(midPointXS - midPointXB, 2.0D) + Math.pow(midPointYS - midPointYB, 2.0D));
    

    dist[(iteration - 1)] = last;
  }
  
  public static double FinalDistance(double[] dist)
  {
    double last = 0.0D;
    for (int i = 0; i < iteration; i++) {
      last += dist[i];
    }
    return last;
  }
  
  public SupportedNegotiationSetting getSupportedNegotiationSetting()
  {
    return SupportedNegotiationSetting.getLinearUtilitySpaceInstance();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     agents.FuzzyAgent
 * JD-Core Version:    0.7.1
 */