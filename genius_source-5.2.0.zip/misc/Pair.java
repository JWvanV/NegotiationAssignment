package misc;

import java.io.Serializable;

public class Pair<A, B>
  implements Serializable
{
  private static final long serialVersionUID = -3269964369920187563L;
  private A fst;
  private B snd;
  
  public Pair(A fst, B snd)
  {
    this.fst = fst;
    this.snd = snd;
  }
  
  public A getFirst()
  {
    return (A)this.fst;
  }
  
  public B getSecond()
  {
    return (B)this.snd;
  }
  
  public void setFirst(A v)
  {
    this.fst = v;
  }
  
  public void setSecond(B v)
  {
    this.snd = v;
  }
  
  public String toString()
  {
    return "Pair[" + this.fst + "," + this.snd + "]";
  }
  
  private static boolean equals(Object x, Object y)
  {
    return ((x == null) && (y == null)) || ((x != null) && (x.equals(y)));
  }
  
  public boolean equals(Object other)
  {
    return ((other instanceof Pair)) && (equals(this.fst, ((Pair)other).fst)) && (equals(this.snd, ((Pair)other).snd));
  }
  
  public int hashCode()
  {
    if (this.fst == null) {
      return this.snd == null ? 0 : this.snd.hashCode() + 1;
    }
    if (this.snd == null) {
      return this.fst.hashCode() + 2;
    }
    return this.fst.hashCode() * 17 + this.snd.hashCode();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.Pair
 * JD-Core Version:    0.7.1
 */