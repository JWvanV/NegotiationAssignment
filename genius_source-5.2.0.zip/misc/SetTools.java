package misc;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetTools
{
  public static <A> Set<Set<A>> cartesianProduct(Set<A>... sets)
  {
    if (sets.length < 2)
    {
      Iterator<A> setIterator = sets[0].iterator();
      Set<Set<A>> mainSet = new HashSet();
      while (setIterator.hasNext())
      {
        A item = setIterator.next();
        Set<A> set = new HashSet();
        set.add(item);
        mainSet.add(set);
      }
      return mainSet;
    }
    return _cartesianProduct(0, sets);
  }
  
  private static <A> Set<Set<A>> _cartesianProduct(int index, Set<A>... sets)
  {
    Set<Set<A>> ret = new HashSet();
    Iterator localIterator1;
    if (index == sets.length) {
      ret.add(new HashSet());
    } else {
      for (localIterator1 = sets[index].iterator(); localIterator1.hasNext();)
      {
        obj = localIterator1.next();
        for (Set<A> set : _cartesianProduct(index + 1, sets))
        {
          set.add(obj);
          ret.add(set);
        }
      }
    }
    A obj;
    return ret;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.SetTools
 * JD-Core Version:    0.7.1
 */