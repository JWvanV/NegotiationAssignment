package misc;

import java.io.Serializable;

public class RangeInt
  implements Serializable
{
  int lowerbound;
  int upperbound;
  
  public RangeInt(int lowerbound, int upperbound)
  {
    this.lowerbound = lowerbound;
    this.upperbound = upperbound;
  }
  
  public int getLowerbound()
  {
    return this.lowerbound;
  }
  
  public int getUpperbound()
  {
    return this.upperbound;
  }
  
  public void setUpperbound(int upperbound)
  {
    this.upperbound = upperbound;
  }
  
  public void setLowerbound(int lowerbound)
  {
    this.lowerbound = lowerbound;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.RangeInt
 * JD-Core Version:    0.7.1
 */