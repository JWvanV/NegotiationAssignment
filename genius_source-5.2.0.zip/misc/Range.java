package misc;

public class Range
{
  private double lowerbound;
  private double upperbound;
  
  public Range(double lowerbound, double upperbound)
  {
    this.lowerbound = lowerbound;
    this.upperbound = upperbound;
  }
  
  public double getUpperbound()
  {
    return this.upperbound;
  }
  
  public double getLowerbound()
  {
    return this.lowerbound;
  }
  
  public void setUpperbound(double upperbound)
  {
    this.upperbound = upperbound;
  }
  
  public void setLowerbound(double lowerbound)
  {
    this.lowerbound = lowerbound;
  }
  
  public void increaseUpperbound(double increment)
  {
    this.upperbound += increment;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.Range
 * JD-Core Version:    0.7.1
 */