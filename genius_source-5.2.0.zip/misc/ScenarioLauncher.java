package misc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import negotiator.Global;
import negotiator.protocol.OldProtocol;
import negotiator.repository.AgentRepItem;
import negotiator.repository.DomainRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.ProtocolRepItem;
import negotiator.repository.RepItem;
import negotiator.repository.Repository;
import negotiator.tournament.TournamentConfiguration;

public class ScenarioLauncher
{
  public static void main(String[] args)
    throws Exception
  {
    try
    {
      int ntournaments = 3;
      boolean trace = false;
      String path = "file:/Users/rafik/Documents/workspace/NegotiatorGUI voor AAMAS competitie/";
      String p = "negotiator.protocol.alternatingoffers.AlternatingOffersProtocol";
      String outputFile = "log/_" + Global.getOutcomesFileName();
      


      Repository agentrepository = Repository.get_agent_repository();
      ArrayList<RepItem> agents_names = Repository.get_agent_repository().getItems();
      Repository repAgent = Repository.get_agent_repository();
      AgentRepItem[] agentsARI = new AgentRepItem[agents_names.size()];
      for (int i = 0; i < agents_names.size(); i++)
      {
        if ((agentsARI[i] = (AgentRepItem)repAgent.getItemByName(((RepItem)agents_names.get(i)).getName())) == null) {
          throw new Exception("Unable to createFrom agent " + ((RepItem)agents_names.get(i)).getName() + "!");
        }
        if (trace) {
          System.out.println(" Agent " + i + " :  " + agentsARI[i].getName() + "\n \t " + agentsARI[i].getDescription() + "\n \t " + agentsARI[i].getClassPath() + "\n \t " + agentsARI[i].getParams() + "\n \t " + agentsARI[i].getVersion());
        }
      }
      Repository domainrepository = Repository.get_domain_repos();
      ArrayList<RepItem> profiles_names = Repository.get_domain_repos().getItems();
      DomainRepItem[] DomainsARI = new DomainRepItem[profiles_names.size()];
      for (int i = 0; i < profiles_names.size(); i++)
      {
        if ((DomainsARI[i] = (DomainRepItem)domainrepository.getItemByName(((RepItem)profiles_names.get(i)).getName())) == null) {
          throw new Exception("Unable to createFrom domain " + ((RepItem)profiles_names.get(i)).getName() + "!");
        }
        if (trace) {
          System.out.println(" Domain " + i + " :  " + DomainsARI[i].getName() + "\n \t " + DomainsARI[i].getClass() + "\n \t " + DomainsARI[i].getFullName() + "\n \t " + DomainsARI[i].getProfiles() + "\n \t " + DomainsARI[i].getURL());
        }
      }
      Thread[] threads = new Thread[ntournaments];
      for (int i = 1; i <= ntournaments; i++)
      {
        String random_A = agentsARI[new Random().nextInt(agentsARI.length)].getClassPath();
        String random_B = new String(random_A);
        while (random_B.equals(random_A)) {
          random_B = agentsARI[new Random().nextInt(agentsARI.length)].getClassPath();
        }
        int rand = new Random().nextInt(DomainsARI.length);
        String random_Domain = DomainsARI[rand].getURL().toString();
        random_Domain = random_Domain.replaceAll("file:", "");
        
        System.out.println(" random_Domain : " + random_Domain);
        System.out.println(" Profiles : " + DomainsARI[rand].getProfiles());
        
        String domainFile = path + random_Domain;
        System.out.println(" domainFile: " + domainFile);
        List<String> profiles = Arrays.asList(new String[] { path + DomainsARI[rand].getProfiles().toArray()[0], path + DomainsARI[rand].getProfiles().toArray()[1] });
        
        System.out.println(" profiles:  profile 1 : " + (String)profiles.get(0) + "\n\tprofile 2 : " + (String)profiles.get(1));
        
        List<String> agents = Arrays.asList(new String[] { random_A, random_B });
        
        System.out.println(" agents:    agent 1 : " + (String)agents.get(0) + "\n\tagent 2 : " + (String)agents.get(1));
        
        outputFile = outputFile.replaceAll(i == 1 ? ".xml" : "__(\\d+).xml", "__" + i + ".xml");
        
        File outcomesFile = new File(outputFile);
        BufferedWriter out = new BufferedWriter(new FileWriter(outcomesFile, true));
        if (!outcomesFile.exists())
        {
          System.out.println("Creating log file " + outputFile);
          out.write("<a>\n");
        }
        out.close();
        System.out.println(" logfile: " + outputFile);
        Global.logPreset = outputFile;
        if (profiles.size() != agents.size()) {
          throw new IllegalArgumentException("The number of profiles does not match the number of agents!");
        }
        ProtocolRepItem protocol = new ProtocolRepItem(p, p, p);
        System.out.println(" protocol name: " + protocol.getDescription());
        DomainRepItem dom = new DomainRepItem(new URL(domainFile));
        ProfileRepItem[] agentProfiles = new ProfileRepItem[profiles.size()];
        for (int j = 0; j < profiles.size(); j++)
        {
          agentProfiles[j] = new ProfileRepItem(new URL((String)profiles.get(j)), dom);
          if (agentProfiles[j].getDomain() != agentProfiles[0].getDomain()) {
            throw new IllegalArgumentException("Profiles for agent 1 and agent " + (j + 1) + " do not have the same domain. Please correct your profiles");
          }
        }
        AgentRepItem[] agentsrep = new AgentRepItem[agents.size()];
        for (int j = 0; j < agents.size(); j++) {
          agentsrep[j] = new AgentRepItem((String)agents.get(j), (String)agents.get(j), (String)agents.get(j));
        }
        OldProtocol ns = Global.createProtocolInstance(protocol, agentsrep, agentProfiles, null);
        
        TournamentConfiguration.addOption("deadline", 60);
        TournamentConfiguration.addOption("oneSidedBidding", 0);
        TournamentConfiguration.addOption("startingAgent", 0);
        TournamentConfiguration.addOption("accessPartnerPreferences", 0);
        TournamentConfiguration.addOption("appendModeAndDeadline", 0);
        TournamentConfiguration.addOption("disableGUI", 0);
        TournamentConfiguration.addOption("logNegotiationTrace", 0);
        TournamentConfiguration.addOption("protocolMode", 0);
        TournamentConfiguration.addOption("allowPausingTimeline", 0);
        TournamentConfiguration.addOption("logFinalAccuracy", 0);
        TournamentConfiguration.addOption("logDetailedAnalysis", 0);
        TournamentConfiguration.addOption("logCompetitiveness", 0);
        
        System.out.println("======== Tournament " + i + "/" + ntournaments + " started ========{");
        
        threads[(i - 1)] = new Thread(ns);
        threads[(i - 1)].start();
        threads[(i - 1)].join();
        System.out.println("Thread " + i + " finished.");
        
        System.out.println("   ns.getName()          = " + ns.getName());
        System.out.println("   ns.getSessionNumber() = " + ns.getSessionNumber());
        System.out.println("   ns.getTotalSessions() = " + ns.getTotalSessions());
        System.out.println("======== Tournament " + i + "/" + ntournaments + " finished ========}");
      }
      System.out.println("\n" + ntournaments + " tournaments finished.");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.ScenarioLauncher
 * JD-Core Version:    0.7.1
 */