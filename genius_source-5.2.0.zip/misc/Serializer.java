package misc;

import TA;;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import javax.xml.bind.DatatypeConverter;

public class Serializer<A>
{
  private final String fileName;
  private final boolean log;
  
  public Serializer(String fileName)
  {
    this(fileName, false);
  }
  
  public Serializer(String fileName, boolean log)
  {
    this.fileName = fileName;
    this.log = log;
  }
  
  public A readFromDisk()
  {
    InputStream is = null;
    ObjectInputStream ois = null;
    A obj = null;
    
    String errorMsg = "Error opening (" + this.fileName + ").\n";
    try
    {
      is = new BufferedInputStream(new FileInputStream(this.fileName), 51200000);
      
      ois = new ObjectInputStream(is);
      
      Object readObject = ois.readObject();
      ois.close();
      is.close();
      return (A)readObject;
    }
    catch (FileNotFoundException e)
    {
      if (this.log) {
        System.out.println(errorMsg + e);
      }
    }
    catch (IOException e)
    {
      System.out.println(errorMsg + e);
    }
    catch (ClassNotFoundException e)
    {
      System.out.println(errorMsg + e);
    }
    catch (ClassCastException e)
    {
      System.out.println(errorMsg + e);
    }
    System.out.println(this.fileName + " is old; It should be rebuilt.");
    return null;
  }
  
  public void writeToDisk(A a)
  {
    OutputStream os = null;
    ObjectOutputStream oos = null;
    try
    {
      os = new BufferedOutputStream(new FileOutputStream(this.fileName));
      
      oos = new ObjectOutputStream(os);
      oos.writeObject(a);
      oos.close();
      os.close();
    }
    catch (IOException ex)
    {
      ex.printStackTrace();
    }
  }
  
  public String writeToString(A a)
  {
    String out = null;
    if (a != null) {
      try
      {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(a);
        out = DatatypeConverter.printBase64Binary(baos.toByteArray());
      }
      catch (IOException e)
      {
        e.printStackTrace();
        return null;
      }
    }
    return out;
  }
  
  public A readStringToObject(String str)
  {
    Object out = null;
    if (str != null) {
      try
      {
        ByteArrayInputStream bios = new ByteArrayInputStream(DatatypeConverter.parseBase64Binary(str));
        ObjectInputStream ois = new ObjectInputStream(bios);
        out = ois.readObject();
      }
      catch (IOException e)
      {
        e.printStackTrace();
        return null;
      }
      catch (ClassNotFoundException e)
      {
        e.printStackTrace();
        return null;
      }
    }
    return (A)out;
  }
  
  public String getFileName()
  {
    return this.fileName;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.Serializer
 * JD-Core Version:    0.7.1
 */