package misc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import negotiator.Global;
import negotiator.protocol.OldProtocol;
import negotiator.repository.AgentRepItem;
import negotiator.repository.DomainRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.ProtocolRepItem;
import negotiator.repository.RepItem;
import negotiator.repository.Repository;
import negotiator.tournament.TournamentConfiguration;

public class Simulator
{
  public static void main(String[] args)
    throws Exception
  {
    try
    {
      SimulatorConfiguration conf = SimulatorConfiguration.getInstance("simulatorrepository.xml");
      

      String path = (String)conf.getConf().get("root");
      String ProtoName = (String)conf.getConf().get("protocol");
      String outputFile = (String)conf.getConf().get("log") + Global.getOutcomesFileName().replaceAll("log/", "");
      boolean trace = !((String)conf.getConf().get("trace")).equals("false");
      boolean all = !((String)conf.getConf().get("all")).equals("false");
      int totaltrials = Integer.parseInt((String)conf.getConf().get("trials"));
      


      boolean first = true;
      int trial = 1;
      OldProtocol ns = null;
      
      Set<Set<String>> AgentsCombinations = null;
      
      Iterator<Set<String>> combination = null;
      
      List<String> profiles = null;
      


      Repository repAgent = Repository.get_agent_repository();
      ArrayList<String> agentsList = conf.get("agents");
      AgentRepItem[] agentsARI = new AgentRepItem[agentsList.size()];
      for (int i = 0; i < agentsList.size(); i++) {
        if (agentsList.contains(repAgent.getItemByName((String)agentsList.get(i)).getName()))
        {
          agentsARI[i] = ((AgentRepItem)repAgent.getItemByName((String)agentsList.get(i)));
          if (agentsARI[i] == null) {
            throw new Exception("Unable to createFrom agent " + (String)agentsList.get(i) + "!");
          }
          if (trace) {
            System.out.println(" Agent #" + (i + 1) + "/" + agentsList.size() + "\n \t agent name     :  " + agentsARI[i].getName() + "\n \t descr class    :  " + agentsARI[i].getDescription() + "\n \t class path     :  " + agentsARI[i].getClassPath() + "\n \t param profiles :  " + agentsARI[i].getParams() + "\n \t version        :  " + agentsARI[i].getVersion());
          }
        }
      }
      Repository domainrepository = Repository.get_domain_repos();
      ArrayList<RepItem> profiles_names = domainrepository.getItems();
      ArrayList<DomainRepItem> Domains__ = new ArrayList();
      for (int i = 0; i < profiles_names.size(); i++)
      {
        DomainRepItem d_ = (DomainRepItem)domainrepository.getItemByName(((RepItem)profiles_names.get(i)).getName());
        if (d_ == null) {
          throw new Exception("Unable to createFrom domain " + ((RepItem)profiles_names.get(i)).getName() + "!");
        }
        if (d_.toString().substring(0, 3).equals(conf.getConf().get("domain"))) {
          Domains__.add((DomainRepItem)domainrepository.getItems().get(i));
        }
      }
      DomainRepItem[] DomainsARI = new DomainRepItem[Domains__.size()];
      for (int j = 0; j < Domains__.size(); j++)
      {
        DomainsARI[j] = ((DomainRepItem)Domains__.get(j));
        
        System.out.println("\n Domain #" + (j + 1) + "/" + Domains__.size() + "  Domain name     :  " + DomainsARI[j].getName() + "\n \t Domain class    :  " + DomainsARI[j].getClass() + "\n \t Domain fullname :  " + DomainsARI[j].getFullName() + "\n \t Domain profiles :  " + DomainsARI[j].getProfiles() + "\n \t Domain URL      :  " + DomainsARI[j].getURL());
      }
      Iterator<String> iter = agentsList.iterator();
      Set<String> NamesSet = new HashSet();
      while (iter.hasNext()) {
        NamesSet.add(iter.next());
      }
      AgentsCombinations = SetTools.cartesianProduct(new Set[] { NamesSet, NamesSet });
      
      System.out.println("\n Total [Agents] combinations  : " + AgentsCombinations.size() + "\n Total [Preferences] profiles : " + DomainsARI.length);
      



      System.out.println("=========== runs ======================================================================================================================================================");
      if (all) {
        totaltrials = AgentsCombinations.size() * DomainsARI.length;
      }
      for (DomainRepItem domain : DomainsARI)
      {
        combination = AgentsCombinations.iterator();
        while (combination.hasNext())
        {
          System.out.println("======== Trial " + trial + "/" + totaltrials + " started ==========={");
          
          String domainFile = path + domain.getURL().toString().replaceAll("file:", "");
          System.out.println(" domainFile: " + domainFile);
          
          profiles = Arrays.asList(new String[] { path + domain.getProfiles().toArray()[0], path + domain.getProfiles().toArray()[1] });
          System.out.println(" profiles:  profile 1 : " + (String)profiles.get(0) + "\n\tprofile 2 : " + (String)profiles.get(1));
          
          Object[] tc = ((Set)combination.next()).toArray();
          



          String AClassPath = null;String BClassPath = null;
          for (int d = 0; d < agentsARI.length; d++)
          {
            if (agentsARI[d].getName().equals(tc[0].toString())) {
              AClassPath = new String(agentsARI[d].getClassPath());
            }
            if (agentsARI[d].getName().equals(tc[1].toString())) {
              BClassPath = new String(agentsARI[d].getClassPath());
            }
          }
          List<String> agents = Arrays.asList(new String[] { AClassPath, BClassPath });
          System.out.println(" agents:    agent 1 : " + (String)agents.get(0) + "\n\tagent 2 : " + (String)agents.get(1));
          if (first)
          {
            outputFile = outputFile.replaceAll(".xml", "__" + trial + ".xml");
            first = false;
          }
          else
          {
            outputFile = outputFile.replaceAll("__(\\d+).xml", "__" + trial + ".xml");
          }
          File outcomesFile = new File(outputFile);
          BufferedWriter out = new BufferedWriter(new FileWriter(outcomesFile, true));
          if (!outcomesFile.exists())
          {
            System.out.println("Creating log file " + outputFile);
            out.write("<a>\n");
          }
          out.close();
          System.out.println(" logfile: " + outputFile);
          Global.logPreset = outputFile;
          if (profiles.size() != agents.size()) {
            throw new IllegalArgumentException("The number of profiles does not match the number of agents!");
          }
          ProtocolRepItem protocol = new ProtocolRepItem(ProtoName, ProtoName, ProtoName);
          DomainRepItem dom = new DomainRepItem(new URL(domainFile));
          ProfileRepItem[] agentProfiles = new ProfileRepItem[profiles.size()];
          
          System.out.println(" protocol name: " + protocol.getDescription());
          for (int j = 0; j < profiles.size(); j++)
          {
            agentProfiles[j] = new ProfileRepItem(new URL((String)profiles.get(j)), dom);
            if (agentProfiles[j].getDomain() != agentProfiles[0].getDomain()) {
              throw new IllegalArgumentException("Profiles for agent 1 and agent " + (j + 1) + " do not have the same domain. Please correct your profiles");
            }
          }
          AgentRepItem[] agentsrep = new AgentRepItem[agents.size()];
          for (int j = 0; j < agents.size(); j++) {
            agentsrep[j] = new AgentRepItem((String)agents.get(j), (String)agents.get(j), (String)agents.get(j));
          }
          System.out.print("\n Loading options...\n");
          for (String option : conf.getTournamentOptions().keySet()) {
            TournamentConfiguration.addOption(option, Integer.parseInt((String)conf.getTournamentOptions().get(option)));
          }
          ns = Global.createProtocolInstance(protocol, agentsrep, agentProfiles, null);
          System.out.print("Negotiation session built: " + ns + "\n");
          ns.startSession();
          
          System.out.print("...\n");
          Thread.sleep(500L);
          

          System.out.println(" \t   ns.getName()          = " + ns.getName());
          System.out.println(" \t   ns.getSessionNumber() = " + ns.getSessionNumber());
          System.out.println(" \t   ns.getTotalSessions() = " + ns.getTotalSessions());
          

          System.out.println("======== Trial " + trial + "/" + totaltrials + " finished ========} \n");
          if ((trial == totaltrials) && (!all))
          {
            System.out.println("\n" + trial + "/" + totaltrials + " trials finished.");
            System.exit(0);
          }
          trial++;
        }
      }
      System.out.println("\n" + (trial - 1) + " trials finished from " + totaltrials + " combinations");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.Simulator
 * JD-Core Version:    0.7.1
 */