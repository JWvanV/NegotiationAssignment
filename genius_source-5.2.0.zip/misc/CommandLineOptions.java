package misc;

import java.util.List;
import joptsimple.OptionParser;
import joptsimple.OptionSet;

public class CommandLineOptions
{
  public boolean newTournament = false;
  public boolean startTournament = false;
  public boolean quitWhenTournamentDone = false;
  public List<String> agents;
  public List<String> profiles;
  public String protocol = "negotiator.protocol.alternatingoffers.AlternatingOffersProtocol";
  public String domain;
  public String outputFile;
  
  public void parse(String[] args)
  {
    OptionParser parser = new OptionParser("stq:q::a:p:d:f:r:");
    OptionSet options = parser.parse(args);
    if (options.has("s")) {
      this.startTournament = true;
    }
    if (options.has("t")) {
      this.newTournament = true;
    }
    if (options.has("q")) {
      this.quitWhenTournamentDone = true;
    }
    if (options.has("a")) {
      this.agents = options.valuesOf("a");
    }
    if (options.has("r")) {
      this.protocol = ((String)options.valueOf("r"));
    }
    if (options.has("p")) {
      this.profiles = options.valuesOf("p");
    }
    if (options.has("d")) {
      this.domain = ((String)options.valueOf("d"));
    }
    if (options.has("f")) {
      this.outputFile = ((String)options.valueOf("f"));
    }
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.CommandLineOptions
 * JD-Core Version:    0.7.1
 */