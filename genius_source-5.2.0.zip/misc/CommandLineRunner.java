package misc;

import java.io.PrintStream;
import java.net.URL;
import java.util.List;
import negotiator.Global;
import negotiator.protocol.OldProtocol;
import negotiator.repository.AgentRepItem;
import negotiator.repository.DomainRepItem;
import negotiator.repository.ProfileRepItem;
import negotiator.repository.ProtocolRepItem;

public class CommandLineRunner
{
  public static void main(String[] args)
  {
    CommandLineOptions options = new CommandLineOptions();
    options.parse(args);
    try
    {
      start(options.protocol, options.domain, options.profiles, options.agents, options.outputFile);
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    System.out.println("ends");
  }
  
  private static void start(String p, String domainFile, List<String> profiles, List<String> agents, String outputFile)
    throws Exception
  {
    Global.logPreset = outputFile;
    if (profiles.size() != agents.size()) {
      throw new IllegalArgumentException("Number of profiles does not match number of agents.");
    }
    OldProtocol ns = null;
    
    ProtocolRepItem protocol = new ProtocolRepItem(p, p, p);
    
    DomainRepItem dom = new DomainRepItem(new URL(domainFile));
    
    ProfileRepItem[] agentProfiles = new ProfileRepItem[profiles.size()];
    for (int i = 0; i < profiles.size(); i++)
    {
      agentProfiles[i] = new ProfileRepItem(new URL((String)profiles.get(i)), dom);
      if (agentProfiles[i].getDomain() != agentProfiles[0].getDomain()) {
        throw new IllegalArgumentException("Profiles for agent 0 and agent " + i + " do not have the same domain. Please correct your profiles");
      }
    }
    AgentRepItem[] agentsrep = new AgentRepItem[agents.size()];
    for (int i = 0; i < agents.size(); i++) {
      agentsrep[i] = new AgentRepItem((String)agents.get(i), (String)agents.get(i), (String)agents.get(i));
    }
    ns = Global.createProtocolInstance(protocol, agentsrep, agentProfiles, null);
    

    ns.startSession();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.CommandLineRunner
 * JD-Core Version:    0.7.1
 */