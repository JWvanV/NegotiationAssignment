package misc;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import javax.swing.JOptionPane;
import negotiator.Bid;
import negotiator.BidIterator;
import negotiator.Domain;
import negotiator.analysis.BidPoint;
import negotiator.analysis.BidSpace;
import negotiator.exceptions.Warning;
import negotiator.issue.Issue;
import negotiator.issue.IssueDiscrete;
import negotiator.issue.Objective;
import negotiator.utility.Evaluator;
import negotiator.utility.EvaluatorDiscrete;
import negotiator.utility.UtilitySpace;
import negotiator.xml.SimpleElement;

public class DomainGenerator
{
  private static Range OPPOSITION = new Range(0.05D, 0.2D);
  private static Range BID_DISTRIBUTION = new Range(0.35D, 0.5D);
  
  public static void main(String[] args)
    throws Exception
  {
    String dir = "c:/Users/Mark/workspace/Genius/etc/AccuracyTestSet/Thompson/";
    

    Domain domain = new Domain(dir + "thompson_employment.xml");
    

    UtilitySpace utilitySpaceA = new UtilitySpace(domain, dir + "thompson_employee.xml");
    UtilitySpace utilitySpaceB = new UtilitySpace(domain, dir + "thompson_employer.xml");
    

    String logToDirA = dir + "thompson_employee_hOhD.xml";
    String logToDirB = dir + "thompson_employer_hOhD.xml";
    





    findDomain(domain, utilitySpaceA, utilitySpaceB, logToDirA, logToDirB, OPPOSITION, BID_DISTRIBUTION, false, false);
  }
  
  public static void findDomain(Domain domain, UtilitySpace spaceA, UtilitySpace spaceB, String logToDirA, String logToDirB, Range opp, Range dist, boolean biasForHighOpp, boolean varyBoth)
    throws Exception
  {
    System.out.println("Starting random domain generator");
    
    double[] result = { Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY };
    boolean found = false;
    while (!found)
    {
      if (varyBoth) {
        randomizeUtilSpace(spaceA, biasForHighOpp);
      }
      randomizeUtilSpace(spaceB, biasForHighOpp);
      result = calculateDistances(spaceA, spaceB);
      if ((result[0] >= opp.getLowerbound()) && (result[0] < opp.getUpperbound()) && 
        (result[1] >= dist.getLowerbound()) && (result[1] < dist.getUpperbound())) {
        found = true;
      }
      result = null;
    }
    if (!varyBoth) {
      JOptionPane.showMessageDialog(null, "saved to: " + logToDirB);
    } else {
      JOptionPane.showMessageDialog(null, "saved to: " + logToDirA + "\n and " + logToDirB);
    }
    if (varyBoth) {
      writeXMLtoFile(spaceA.toXML(), logToDirA);
    }
    writeXMLtoFile(spaceB.toXML(), logToDirB);
  }
  
  private static void randomizeUtilSpace(UtilitySpace utilitySpace, boolean bias)
  {
    if (bias)
    {
      for (Issue i : utilitySpace.getDomain().getIssues()) {
        utilitySpace.setWeight(i, Math.random());
      }
      utilitySpace.normalizeChildren(((Issue)utilitySpace.getDomain().getIssues().get(0)).getParent());
    }
    else
    {
      for (Issue i : utilitySpace.getDomain().getIssues()) {
        setWeightSimple(utilitySpace, i, Math.random());
      }
      utilitySpace.normalizeChildren(((Issue)utilitySpace.getDomain().getIssues().get(0)).getParent());
    }
    try
    {
      for (??? = utilitySpace.getEvaluators().iterator(); ???.hasNext();)
      {
        Map.Entry<Objective, Evaluator> e = (Map.Entry)???.next();
        ((EvaluatorDiscrete)e.getValue()).setEvaluation(utilitySpace.getDomain().getRandomBid().getValue(((IssueDiscrete)e.getKey()).getNumber()), 
          (int)(Math.random() * 1000.0D));
      }
    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  public static void setWeightSimple(UtilitySpace uspace, Issue i, double weight)
  {
    try
    {
      Evaluator ev = uspace.getEvaluator(i.getNumber());
      ev.setWeight(weight);
    }
    catch (NullPointerException e)
    {
      e.printStackTrace();
    }
  }
  
  private static void writeXMLtoFile(SimpleElement simpleElement, String logPath)
  {
    try
    {
      File log = new File(logPath);
      if (log.exists()) {
        log.delete();
      }
      BufferedWriter out = new BufferedWriter(new FileWriter(log, true));
      out.write("" + simpleElement);
      out.close();
    }
    catch (Exception e)
    {
      new Warning("Exception during writing s:" + e);
      e.printStackTrace();
    }
  }
  
  private static double[] calculateDistances(UtilitySpace utilitySpaceA, UtilitySpace utilitySpaceB)
  {
    BidSpace bidSpace = null;
    try
    {
      bidSpace = new BidSpace(new UtilitySpace[] { utilitySpaceA, utilitySpaceB });
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    double opposition = calculateOpposition(bidSpace);
    double bidDistribution = calculateBidDistribution(bidSpace, utilitySpaceA, utilitySpaceB);
    
    double[] result = new double[2];
    result[0] = opposition;
    result[1] = bidDistribution;
    return result;
  }
  
  private static double calculateOpposition(BidSpace bidSpace)
  {
    double result = 0.0D;
    try
    {
      BidPoint kalai = bidSpace.getKalaiSmorodinsky();
      return kalai.getDistance(new BidPoint(null, new Double[] { Double.valueOf(1.0D), Double.valueOf(1.0D) }));
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return result;
  }
  
  private static double calculateBidDistribution(BidSpace bidSpace, UtilitySpace utilitySpaceA, UtilitySpace utilitySpaceB)
  {
    BidIterator iterator = new BidIterator(utilitySpaceA.getDomain());
    double total = 0.0D;
    try
    {
      while (iterator.hasNext())
      {
        Bid bid = iterator.next();
        BidPoint point = new BidPoint(bid, new Double[] { Double.valueOf(utilitySpaceA.getUtility(bid)), Double.valueOf(utilitySpaceB.getUtility(bid)) });
        total += bidSpace.distanceToNearestParetoBid(point);
      }
      return total / utilitySpaceA.getDomain().getNumberOfPossibleBids();
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return -1.0D;
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.DomainGenerator
 * JD-Core Version:    0.7.1
 */