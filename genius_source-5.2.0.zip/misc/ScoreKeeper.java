package misc;

import java.io.Serializable;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class ScoreKeeper<A>
  implements Comparator<A>, Serializable
{
  private static final long serialVersionUID = -8974661138458056269L;
  protected Map<A, Integer> m;
  protected int max;
  protected int total;
  
  public ScoreKeeper()
  {
    this.m = new HashMap();
    this.total = 0;
    this.max = 0;
  }
  
  public ScoreKeeper(ScoreKeeper<A> sk)
  {
    this.m = sk.m;
    this.max = sk.max;
    this.total = sk.total;
  }
  
  public void score(A a)
  {
    Integer freq = (Integer)this.m.get(a);
    if (freq == null) {
      freq = Integer.valueOf(0);
    }
    Integer localInteger1 = freq;Integer localInteger2 = freq = Integer.valueOf(freq.intValue() + 1);
    if (freq.intValue() > this.max) {
      this.max = freq.intValue();
    }
    this.total += 1;
    this.m.put(a, freq);
  }
  
  public void score(A a, int score)
  {
    Integer freq = (Integer)this.m.get(a);
    if (freq == null) {
      freq = Integer.valueOf(0);
    }
    int newValue = freq.intValue() + score;
    if (newValue > this.max) {
      this.max = newValue;
    }
    this.total += score;
    this.m.put(a, Integer.valueOf(newValue));
  }
  
  public int getScore(A a)
  {
    Integer freq = (Integer)this.m.get(a);
    if (freq == null) {
      freq = Integer.valueOf(0);
    }
    return freq.intValue();
  }
  
  public double getNormalizedScore(A a)
  {
    Integer score = (Integer)this.m.get(a);
    if (score == null) {
      score = Integer.valueOf(0);
    }
    return score.intValue() / this.max;
  }
  
  public double getRelativeScore(A a)
  {
    Integer score = (Integer)this.m.get(a);
    if (score == null) {
      score = Integer.valueOf(0);
    }
    return score.intValue() / this.total;
  }
  
  public int compare(A o1, A o2)
  {
    if ((o1 == null) || (o2 == null)) {
      throw new NullPointerException();
    }
    if (o1.equals(o2)) {
      return 0;
    }
    if (getScore(o1) > getScore(o2)) {
      return -1;
    }
    if (getScore(o1) < getScore(o2)) {
      return 1;
    }
    return Integer.valueOf(o1.hashCode()).compareTo(Integer.valueOf(o2.hashCode()));
  }
  
  public String toString()
  {
    TreeMap<A, Integer> sorted = getSortedCopy();
    return getElements().size() + " entries, " + getTotal() + " total: " + sorted.toString() + "\n";
  }
  
  public TreeMap<A, Integer> getSortedCopy()
  {
    TreeMap<A, Integer> sorted = new TreeMap(this);
    sorted.putAll(this.m);
    return sorted;
  }
  
  public int getMaxValue()
  {
    return this.max;
  }
  
  public int getTotal()
  {
    int total = 0;
    for (A a : this.m.keySet()) {
      total += ((Integer)this.m.get(a)).intValue();
    }
    return total;
  }
  
  public Set<A> getElements()
  {
    return this.m.keySet();
  }
  
  public String toMathematicaListPlot()
  {
    StringBuilder s = new StringBuilder("data={");
    boolean first = true;
    TreeSet<A> sortedKeys = new TreeSet(this.m.keySet());
    for (A entry : sortedKeys)
    {
      if (first) {
        first = false;
      } else {
        s.append(",");
      }
      if ((entry instanceof Number)) {
        s.append("{" + entry + "," + this.m.get(entry) + "}");
      }
      if ((entry instanceof String)) {
        s.append("{\"" + entry + "\"," + this.m.get(entry) + "}");
      }
    }
    s.append("};\n");
    s.append("ListPlot[data, PlotRange -> All]");
    return s.toString();
  }
}


/* Location:           D:\Users\Jan-Willem\git\NegotiationAssignment\genius-5.2.0.jar
 * Qualified Name:     misc.ScoreKeeper
 * JD-Core Version:    0.7.1
 */